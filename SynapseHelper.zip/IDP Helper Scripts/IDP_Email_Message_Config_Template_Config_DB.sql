/**********

Select * from [EDW_Config].[Email_Subscription] Where PackageName = 'IDP_ADF_DM_Support'

*/

/*********************** **********************************************

	Use this script to add/update the email distribution for IDP process in Config Table

***********************************************************************/
Begin
	declare @maxId int
	declare @newMsgSuccessId int,
	        @newMsgFailureId int,
			@newDistributionId int,
			@newFailureProcessId int,
			@newSuccessProcessId int,
			@emailSuccessDistribution varchar(255),
			@emailFailureDistribution varchar(255),
			@email_addr varchar(255),
			@package_name varchar(255),
			@db_server_name varchar(255),
			@successSubject varchar(1000),
			@successBody varchar(4000),
			@failureSubject varchar(1000),
			@failureBody varchar(4000),
			@nbr_statements INT,
			@i INT,
			@env varchar(255)
/**************************************************************************************************************************/
/********************************************** START -- update this section for your project **************************************/

	Select @package_name = ''   ---- the package name you configured in EDW_Config.Email_Custom_Message
	Select @successBody = ''
	Select @failureBody = ''



	select @db_server_name= DB_Name()

	-- live/prod
	if @db_server_name = 'imcoimconfigpdsqldb01'
	Begin
		Select @emailSuccessDistribution =''   -- email address separated by ;
		Select @emailFailureDistribution = ''  -- email address separated by ;
		Select @env = 'PROD'
	End

	-- Uat
	if @db_server_name in ('imcoimconfigutsqldb01')
	Begin
		Select @emailSuccessDistribution = ''  -- email address separated by ;
		Select @emailFailureDistribution = ''  -- email address separated by ;
		Select @env = 'UAT'
	End

	-- Dev
	if @db_server_name in ('imcoimconfigdvsqldb01')  
	Begin
		Select @emailSuccessDistribution = ''   -- email address separated by ;
		Select @emailFailureDistribution = ''   -- email address separated by ;
		Select @env='DEV'
	End

	Select @successSubject = '[IDP ' + @env + '] - Success - FRM Report Load from SFTP  '  --- prefix of the subject for the source system load if success
	Select @failureSubject = '[IDP ' + @env + '] - FAILURE - FRM Report Load from SFTP '   --- prefix of the subject for the source system load if failure


/******************************************** END of Update ***************************************************************/
/**************************************************************************************************************************/

	-- Process subscription
	Print 'Deleting ProcessSubscription for package ' + @package_name + '....'

	Delete from EDW_Config.[Email_Process_Subscription]
	where ProcessID in (
		Select ProcessID
		from EDW_Config.[Email_Process]
		where [PackageName] = @package_name
	)

	-- process
	Print 'Deleting Process for package ' + @package_name + '....'

	delete from EDW_Config.[Email_Process]
	where [PackageName] = @package_name

	-- Email messge
	Print 'Deleting Email Message for [' + @failureSubject + '] and [' + @successSubject

	delete from EDW_Config.[Email_Message]
	where [EmailSubject] = @successSubject or EmailSubject = @failureSubject 



	-- Email message insert
	Print 'Inserting Email message for pakage...' + @package_name + '....'

	select @maxId = coalesce(max(EmailMessageID),0) from EDW_Config.[Email_Message]
	
	select @newMsgFailureId = @maxId + 1
	select @newMsgSuccessId = @maxId + 2

	insert into EDW_Config.[Email_Message] (
			[EmailMessageID]
           ,[EmailSubject]
           ,[EmailBody]
           ,[Enabled]
           ,[CreatedDate]
           ,[Priority]
           ,[MessageType]
	)
	Select
		@newMsgFailureId,
		@failureSubject,
		@failureBody,
		1,
		getdate(),
		'High',
		'C'

	insert into EDW_Config.[Email_Message] (
			[EmailMessageID]
           ,[EmailSubject]
           ,[EmailBody]
           ,[Enabled]
           ,[CreatedDate]
           ,[Priority]
           ,[MessageType]
	)
	Select
		@newMsgSuccessId,
		@successSubject,
		@successBody,
		1,
		getdate(),
		'Low',
		'C'

	-- Process insert
	Print 'Inserting Process for package ' + @package_name + '....'

	Select @maxId = coalesce(max([ProcessID]),0) from EDW_Config.[Email_Process]

	Select @newFailureProcessId = @maxId + 1
	Select @newSuccessProcessId = @maxId + 2

	Insert Into EDW_Config.[Email_Process] (
	  [ProcessID]
	  ,[PackageName]
      ,[ProcessType]
      ,[SendEmail]
      ,[Enabled]
      ,[CreatedDate]
      ,[EmailMessageId]
	)
	Select  @newFailureProcessId,
			@package_name,
			'Adhoc',
			'F',
			1,
			getdate(),
	        @newMsgFailureId
	union
		Select @newSuccessProcessId,
			@package_name,
			'Adhoc',
			'S',
			1,
			getdate(),
	       @newMsgSuccessId


	-- email distribution and process subscription insert
	Print 'Inserting email distribution and process subscription for package ' + @package_name + '....'

	/****************** Set for success distribution **********************/
	SELECT value as email_addr, ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS Sequence
	into #tbl
	FROM STRING_SPLIT(@emailSuccessDistribution,';')

	Select @nbr_statements  = (SELECT COUNT(*) FROM #tbl),
		   @i = 1;

	WHILE   @i <= @nbr_statements
	BEGIN
			Select @email_addr = email_addr
			From #tbl
			where Sequence = @i

			print 'check email for ' + @email_addr +'.....'

			select @newDistributionId = coalesce(max([EmailDistributionID]),-1)
			from EDW_Config.[Email_Distribution]
			Where [EmailAddress] = @email_addr


			if coalesce(@newDistributionId,-1) <0
			begin
				Select @maxId = coalesce(max([EmailDistributionID]),0) from EDW_Config.[Email_Distribution]

				Select @newDistributionId = @maxId + 1

				insert into EDW_Config.[Email_Distribution] (
					[EmailDistributionID]
					,[EmailAddress]
					,[Enabled]
					,[CreatedDate]
				)
				Select @newDistributionId,
					   @email_addr,
					   1,
					   GETDATE()
			end

			select @newDistributionId = [EmailDistributionID]
			from EDW_Config.[Email_Distribution]
			Where [EmailAddress] = @email_addr
	
			-- Process subscription for current email
			Select @maxId = coalesce(max([ProcessSubscriptionID]),0) from EDW_Config.[Email_Process_Subscription]

			Insert into EDW_Config.[Email_Process_Subscription] (
				   [ProcessSubscriptionID]
				  ,[EmailDistributionID]
				  ,[ProcessID]
				  ,[Enabled]
				  ,[CreatedDate]
			)
			Select  @maxId+2,
					@newDistributionId,
					@newSuccessProcessId,
					1,
					getdate()


			 SET     @i +=1;

	END

	drop table #tbl;



	/****************** Set for Failure distribution **********************/
	SELECT value as email_addr, ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS Sequence
	into #tbl2
	FROM STRING_SPLIT(@emailFailureDistribution,';')

	Select @nbr_statements  = (SELECT COUNT(*) FROM #tbl2),
			@i  = 1;

	WHILE   @i <= @nbr_statements
	BEGIN
			Select @email_addr = email_addr
			From #tbl2
			where Sequence = @i

			print 'check email for ' + @email_addr +'.....'

			select @newDistributionId = coalesce(max([EmailDistributionID]),-1)
			from EDW_Config.[Email_Distribution]
			Where [EmailAddress] = @email_addr


			if coalesce(@newDistributionId,-1) <0
			begin
				Select @maxId = coalesce(max([EmailDistributionID]),0) from EDW_Config.[Email_Distribution]

				Select @newDistributionId = @maxId + 1

				insert into EDW_Config.[Email_Distribution] (
					[EmailDistributionID]
					,[EmailAddress]
					,[Enabled]
					,[CreatedDate]
				)
				Select @newDistributionId,
					   @email_addr,
					   1,
					   GETDATE()
			end

			select @newDistributionId = [EmailDistributionID]
			from EDW_Config.[Email_Distribution]
			Where [EmailAddress] = @email_addr
	
			-- Process subscription for current email
			Select @maxId = coalesce(max([ProcessSubscriptionID]),0) from EDW_Config.[Email_Process_Subscription]

			Insert into EDW_Config.[Email_Process_Subscription] (
				   [ProcessSubscriptionID]
				  ,[EmailDistributionID]
				  ,[ProcessID]
				  ,[Enabled]
				  ,[CreatedDate]
			)
			Select  @maxId+1,
					@newDistributionId,
					@newFailureProcessId,
					1,
					getdate()

			 SET     @i +=1;

	END

	drop table #tbl2;

end;

GO