-- SP and Views
SELECT s.name SchemaName, o.name ObjectName, o.type_desc,m.definition
FROM sys.sql_modules m 
INNER JOIN sys.objects o ON m.object_id =o.object_id
LEFT JOIN sys.schemas s on s.schema_id = o.schema_id
WHERE m.definition Like '%dateadd%month%'
and o.type_desc = 'VIEW'
order by 1,2

-- Tables
SELECT TABLE_SCHEMA,TABLE_NAME
,STRING_AGG ( upper(COLUMN_NAME), ' | ') Columns
FROM INFORMATION_SCHEMA.columns
WHERE   column_NAME IN ('PERF_ROLLUP_RETURNS_ID','PERF_SUM_INST','SECURITY_ALIAS')
group by TABLE_SCHEMA,TABLE_NAME
having count(*) > 1
order by 1,2

