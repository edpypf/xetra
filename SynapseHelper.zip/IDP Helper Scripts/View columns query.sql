select schema_name(v.schema_id) as schema_name,
v.name as view_name,
c.column_id,
c.name as column_name,
type_name(user_type_id) as data_type,
c.max_length,
c.precision
from sys.columns c
join sys.views v 
     on v.object_id = c.object_id
where v.name = 'V_Eagle_PERF_SEC_RETURNS'
order by schema_name,
         view_name,
         column_id;
