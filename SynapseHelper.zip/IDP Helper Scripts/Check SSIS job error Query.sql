select  
j.name as 'JobName'
,SUSER_SNAME(j.owner_sid) as 'Jobowner'
,h.step_id
,h.step_name
,msdb.dbo.agent_datetime(h.run_date, h.run_time) as 'RunDateTime'
,h.run_status
,h.run_duration
,h.message
,CASE
WHEN h.run_status = 2 THEN 'RETRY_STEP'
WHEN h.run_status = 0 THEN 'ERROR'
WHEN h.run_status = 1 THEN 'SUCCESS'
WHEN h.run_status = 3 THEN 'ABORT'
ELSE NULL
END job_status
     --,*
From msdb.dbo.sysjobs j
INNER JOIN msdb.dbo.sysjobhistory h
ON j.job_id = h.job_id
  AND h.step_id <> 0
where j.enabled = 1  --Only Enabled Jobs
and h.run_status <> 1
order by
JobName
,RunDateTime desc
,h.step_id desc