-- QUERY History - Synapse

SELECT 
  CURRENT_TIMESTAMP,
  s.login_name,
  r.session_id,
  r.status, 
  r.resource_allocation_percentage AS rsc_pct,
  r.command,
  CONVERT(DATETIME, SWITCHOFFSET(r.submit_time, DATEPART(TZOFFSET,r.submit_time AT TIME ZONE 'Eastern Standard Time'))) AS submit_time,
  CONVERT(DATETIME, SWITCHOFFSET(r.start_time, DATEPART(TZOFFSET,r.start_time AT TIME ZONE 'Eastern Standard Time'))) AS start_time,
  r.total_elapsed_time,
  r.resource_class,
  r.importance,
  r.group_name,
  r.classifier_name,
  DATEDIFF(SECOND,r.submit_time,r.start_time) AS queue_wait
FROM sys.dm_pdw_exec_requests r
INNER JOIN sys.dm_pdw_exec_sessions s
  ON r.session_id = s.session_id
WHERE login_name ='vincent.yu@imcoinvest.com' and command like '%Ref_File_Archive%'

-- QUERY History - Azure SQL DB

SELECT TOP 10 execution_count, statement_text
FROM (
    SELECT QS.*,
    SUBSTRING(
        ST.text,
        (QS.statement_start_offset/2) + 1,
        ((
            CASE statement_end_offset
            WHEN -1 THEN DATALENGTH(st.text)
            ELSE QS.statement_end_offset END
            - QS.statement_start_offset
        ) /2) 
        + 1
    ) AS statement_text
    FROM sys.dm_exec_query_stats AS QS
    CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST
) AS query_stats
WHERE statement_text like '%Ref_File_Archive%'
ORDER BY execution_count DESC
