@@ -1,20 +1,62 @@
# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 
This project is the IMCO Automation DB Test Framework 

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:

1.	Installation process

    1.1 Clone from this repo 
    1.2 Install the below python libs as per section 2 on your local machine
    1.3 Configure the root path as per your machine
        Test_Automation\resources\settings.robot
	    ${BASE_DIR}    C:${/}<your root path>${/}Test_Automation

        Test_Automation\resources\globalSettings.py:
        gloabl_base_dir = f'C:\\<your root path>\\Test_Automation'
    
    Configure the db login credential on Test_Automation\resources\settings.robot
        Replace the space holder of <your account> and <your pwd> on this file
    

2.	Software dependencies
3.	Latest releases
4.	API references
    Install the below python dependencies on your local machine using "pip install" command, for example "pip install robotframework"

        Robotframework >=6.0.2
        oracledb >=1.3.1
        pyodbc >=4.0.39
        openpyxl >=3.1.2
        gitpython >=3.1.32
        azure-identity >=1.13.0
        azure-mgmt-datafactory >=3.1.0
        azure-mgmt-resource >=23.0.0 
        azure-core >=1.26.4
        pandas >=2.0.1
        pysftp >=0.2.9

3. Adding the path of robot.exe into the PATH varibale on your machine by raising IT ticket (email to it.servicedesk@imcoinvest.com) , so that robot command can be called directly without specifying the path.

3.  Run the test cases
    In my case, the path is as below but please note that the path is different for every one:

    C:\Users\<user name>\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.11_qbz5n2kfra8p0\LocalCache\local-packages\Python311\Scripts

    After this path is added, you can run below command under PowerShell (the terminal of VSCode) to verify:

    echo $ENV:PATH

4.  Run the test cases
    For the test cases samples, please refer to the confluence page: https://imcoinvest1.atlassian.net/wiki/spaces/CIDS/pages/216268988/Test+Case+Samples

    How run test cases? you can refer to "How to run the test cases" section on https://imcoinvest1.atlassian.net/wiki/spaces/CIDS/pages/216170620/Test+Framework+Structure

    cd Test_Automation/testcases 

    sample1:
    robot -d log -t Perfoo10-D_Curr testPilot.robot

    sample 2:
    robot -d log -t TC_002 sanity.robot

    sample 3:
    robot -d log -t TC_001 Sanity.robot

    sample 4:
    robot -d log testIncreamentalLoad.robot

# Build and Test
TODO: Describe and show how to build your code and run the tests. 
    To see the test results, then 
    
    cd Test_Automation/testcases/log 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)
No newline at end of file
