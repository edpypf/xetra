import pyodbc
import sqlalchemy as sal
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
import pandas as pd

# server_name=
# database_name=
driver = '{ODBC Driver 17 for SQL Server}'
username = 'python_user'
password = 'ImcoSprint@2023'
host = 'imcoimriskdvsql02.database.windows.net'
#host = 'imcoimriskdvsql02'
port = '1433' 
database = 'imcnoimdvmsql02'

#engine = sal.create_engine(f'mysql+pyodbc://{host}/{database}?driver=SQL Server?Trusted_Connection=yes')
engine = sal.create_engine(f'mysql+pyodbc://python_user:{password}@{host}:1433/imcnoimdvmsql02?driver=ODBC+Driver+17+for+SQL+Server?Trusted_Connection=yes')
                  
conn = engine.connect()
