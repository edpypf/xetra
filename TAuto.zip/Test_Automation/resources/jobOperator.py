from azure.identity import ClientSecretCredential
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.mgmt.resource import ResourceManagementClient
import dataConnectAdaptor as dca
from datetime import datetime
import time
import general as g

class jobOperator:
    def __init__(self, pipeline_id=None):

        if pipeline_id is not None:
            self.pipeline_id = pipeline_id
        else:
            self.pipeline_id = None

        # Get the parameters from settings.robt
        conn_obj = dca.dataConnectAdaptor()
        self.data_factory_client, self.resource_client, self.resource_group_name, self.data_factory_name = conn_obj.connect('adf')

    def trigger_pipeline(self, pipeline_name, para):
        para = g.general.convert_stringio_to_dict(para)

        try: 
            # Trigger the specified pipeline in Azure Data Factory
            pipeline_run = self.data_factory_client.pipelines.create_run(
                self.resource_group_name,
                self.data_factory_name,
                pipeline_name,
                parameters = para
            )
            self.pipeline_run_id = pipeline_run.run_id
        except Exception as ex:
            raise AssertionError('Trigger pipeline error:', str(ex))
          
        return self.pipeline_run_id
    
    def is_pipeline_run(self, pipeline_run_id):
        try:
            pipeline_run = self.data_factory_client.pipeline_runs.get(
                self.resource_group_name,
                self.data_factory_name,
                pipeline_run_id)
            return pipeline_run
        except Exception as ex:
            raise AssertionError('Pipeline search error:', str(ex))        
        


    def monitor_pipeline_run(self, pipeline_run_id, check_sequence=None):
        
        if check_sequence==None:
            check_sequence = 120
        
        # Monitor the status of the specified pipeline run
        print('pipeline_run_id:', pipeline_run_id)
        i=1
        try:
            pipeline_run = self.data_factory_client.pipeline_runs.get(
                self.resource_group_name,
                self.data_factory_name,
                pipeline_run_id
            )
            # Check the status of the pipeline run and wait until it completes
            while pipeline_run.status not in ['Succeeded', 'Failed','Cancelled']:
                time.sleep(check_sequence)
                pipeline_run = self.data_factory_client.pipeline_runs.get(
                    self.resource_group_name,
                    self.data_factory_name,
                    pipeline_run_id
                )
                print("%s time: %s, status: %s" % (i, datetime.now(), pipeline_run.status))
                i+=1
        except Exception as ex:
            raise AssertionError('Pipeline search error:', str(ex))

        # Return the final status and time spent of the pipeline run
        time_spent = pipeline_run.run_end - pipeline_run.run_start
        print('pipeline run_start: %s, run_end: %s' % (pipeline_run.run_start, pipeline_run.run_end))

        # Print the reason if the pipeline run failed
        if pipeline_run.status == 'Failed':
            print("Reason: ", pipeline_run.message)

        return pipeline_run.status, time_spent

    def stop_pipeline_run(self, pipeline_run_id):
        # pipeline_run = self.data_factory_client.pipeline_runs(self.resource_group_name, self.data_factory_name, pipeline_run_id)
        # # Check if the pipeline has any child pipeline
        # if hasattr(pipeline_run, 'pipeline_reference'):
        #     for child_pipeline in pipeline_run.pipeline_reference.referenced_pipelines:
        #         self.stop_pipeline_run(child_pipeline)
        pass

# pipeline_name = 'EDW Load - Main'
# # #Para={'Source_System':'PSA_EDP_Eagle','Batch_Date':'1900-01-01','Load_Type':'SYNC','Load_Param':{"input":""}}
# Para={'Source_System':'PSA_EDP_Eagle','Batch_Date':'1900-01-01','Load_Type':'Test','Load_Param':{"input":""}}

# jb = jobOperator()
# pipeline_run_id = jb.trigger_pipeline(pipeline_name, Para)
# # #pipeline_run_id = '3b9a5396-1a09-4c3f-9fb3-10dac2865056'
# run_status, time_spent = jb.monitor_pipeline_run(pipeline_run_id)
# print("pipeline_run_id=%s, status=%s, time_spent=%s" % (pipeline_run_id, run_status, time_spent))