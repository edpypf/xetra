#from general import general
import general as g

class config:
    """
    This module is used to get the value of the key from the config file settings.robot
    """
    @staticmethod
    def read_config_value(config_file, config_key, section='*** Variables ***'):
        """This function is used to return the value of the key from the given config file path
           Examples:
           | Read Config Value | c:{\}qa${\}automation${\}resources${\}settings.robot |
           | Read Config Value | ${CONFIG_FILE} |
        """
        if g.general.is_file_exist(config_file) is not True:
            raise AssertionError("config file doesn't exist: %s" %(config_file))

        with open(config_file,'r') as file:
            section_found = False
            for line in file:
                line = line.strip()
                if line == section:
                    section_found = True
                elif section_found and config_key in line:
                    value = line.split('  ',1)[1].strip()
                    return value
        return None

# config_file='C:/O365SYNC/OneDrive - IMCO/01-Work/QA/Automation/resources/settings.robot'
# config_key='${IDW_PASSWORD}'
# config = config()
# value = config.read_config_value (config_file, config_key)

#print(value)



