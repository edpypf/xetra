import pandas as pd
import pyodbc
from config import config
from general import general
import warnings

class db_sqlserver:

    # SQL server disconnection
    def disconnect_sql_server(self, conn):
        if conn is not None:
            try:
                conn.close()
                return True
            except Exception as ex:
                raise AssertionError('Error occurred while closing SQL Server connection', str(ex))
        else:
            print('No Sql Server connection found.')    
            return False

    
    def exec_sqlserver_query(self, conn, sql_command):
        """
        Execute SQL query in SQL Server
        """
        warnings.filterwarnings('ignore')
        df = pd.read_sql(sql_command, conn)
        warnings.resetwarnings()
        return df



    #Get the sql command from .sql file and execute it
    def exec_sqlserver_query_from_script(self, conn, file):
        if general.is_file_exist(file) is False:
            raise AssertionError("SQL File doesn't exist: %s" %(file))

        with open(file) as f:
                sql_command = f.read()

        # Execute the query and fetch the results into a DataFrame
        df = self.exec_sqlserver_query( conn, sql_command)
        

        # Convert all values to strings
        bit_columns = [col for col in df.columns if df[col].dtype == bool]
        #df[bit_columns] = df[bit_columns].astype(str)
        df[bit_columns] = df[bit_columns].applymap(lambda x: 1 if x else 0)

        print(f'bit_columns={bit_columns}')
        # for col in bit_columns:
        #     print(f'Values in column {col}:')
        #     print(df[col])
        #     print()

        # print("All the column names:")
        # print(df.columns.tolist())

        return df

    #
    def validate_sqlserver_with_excel(self, df_sql, excelfile, sheet_name=None, start_row=0, index_col=None, output_file=None):
        """
        This function to compare the sql server dataframe with the excel dataframe. 
        If the sheet_name and start_row are not specified, then it reads the first sheet from row 0.

        Return: True or Flase
        """
        if general.is_file_exist(excelfile) is False:
            raise AssertionError("Excel File doesn't exist: %s" %(excelfile))
        
        if sheet_name is None:
            sheet_name = pd.ExcelFile(excelfile).sheet_names[0]

        # Close the excel file properly
        with pd.ExcelFile(excelfile) as xls_file:
            df_excel = pd.read_excel(xls_file, sheet_name=sheet_name, skiprows=start_row)
 

        #Convert NaN to None
        df_excel=df_excel.where(pd.notnull(df_excel),None)

        # Convert the column name of the df to lowercase
        df_sql.columns = df_sql.columns.str.lower()
        df_excel.columns = df_excel.columns.str.lower()

        # Strip trailing whitespace in all columns of both dataframes
        df_sql = df_sql.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        df_excel = df_excel.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        

        #Get datatype
        # dtypes_df1 = df_sql.dtypes
        # dtypes_df2 = df_excel.dtypes

        # print(dtypes_df1)
        # print()
        # print(dtypes_df2)

        int64_columns = df_excel.select_dtypes(include=['int64']).columns
        df_excel[int64_columns] = df_excel[int64_columns].astype(object)

        float64_columns = df_excel.select_dtypes(include=['float64']).columns
        df_excel[float64_columns] = df_excel[float64_columns].astype(object)

        # dtypes_df2 = df_excel.dtypes

        # print(dtypes_df1)
        # print()
        # print(dtypes_df2)


        # Compare the row count
        df_sql_count = df_sql.shape[0]
        df_excel_count = df_excel.shape[0]
        if df_sql_count != df_excel.count:
            print(f"Row counts are different: left has {df_sql_count} rows, right has {df_excel_count} rows")


        if index_col is not None:
            merged_df = df_sql.merge(df_excel, left_on=index_col, right_on=index_col, indicator=True, how='outer')
        else:
            merged_df = df_sql.merge(df_excel, indicator=True, how='outer')

        diff_df = merged_df[merged_df['_merge']!='both']

        if diff_df.empty:
            print("These two dataframes are equal.")
            return True
        else: 
            if output_file is not None:
                output_file += "_diff.html"
                with open(output_file,"w") as f:
                    f.write(diff_df.to_html(index=False))
                with open(output_file+"_left.csv","w") as f_df1:
                    f_df1.write(df_sql.to_csv(index=False))
                with  open(output_file+"_right.csv","w") as f_df2:
                    f_df2.write(df_excel.to_csv(index=False))

        
        # comparison_result = df_sql.equals(df_excel)
        # if comparison_result:
        #     print("DataFrames are identical")
        #     return True
        # else:
        #     if output_file is not None:
        #         output_file += "_diff.html"
        #         with open(output_file,"w") as f:
        #             f.write(diff_df.to_html(index=False))
        #         with open(output_file+"_left.csv","w") as f_df1:
        #             f_df1.write(df_sql.to_csv(index=False))
        #         with  open(output_file+"_right.csv","w") as f_df2:
        #             f_df2.write(df_excel.to_csv(index=False))

                print("DataFrames are different")
                return False
        
    def validate_sqlserver_with_csv(self, df_sql, csvFile):
        if general.is_file_exist(csvFile) is False:
            raise AssertionError("Excel File doesn't exist: %s" %(csvFile))
        
        df_excel = pd.read_csv(csvFile, na_filter=False)  # don't convert 'NA' from csv to 'NaN' in the dataframe

        comparison_result = df_sql.equals(df_excel)
        if comparison_result:
            print("DataFrames are identical")
            return True

        else:
            print("DataFrames are different")
            print(comparison_result)
            return False

    def validate_df_with_df(self, df1, df2, index_col=None, output_file=None):
        # Convert the column name of the df to lowercase
        df1.columns = df1.columns.str.lower()
        df2.columns = df2.columns.str.lower()

        # Strip trailing whitespace in all columns of both dataframes
        df1 = df1.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        df2 = df2.applymap(lambda x: x.strip() if isinstance(x, str) else x)

        # Compare the row count
        df1_count = df1.shape[0]
        df2_count = df2.shape[0]
        if df1_count != df2.count:
            print(f"Row counts are different: left has {df1_count} rows, right has {df2_count} rows")
            #raise ValueError(f"Row counts are different: left is {df1_count}, right is {df2_count} ")

        #Get datatype
        dtypes_df1 = df1.dtypes
        dtypes_df2 = df2.dtypes

        # print(dtypes_df1)
        # print()
        # print(dtypes_df2)

        int64_columns = df1.select_dtypes(include=['int64']).columns
        df1[int64_columns] = df1[int64_columns].astype(object)
        dtypes_df1 = df1.dtypes
        # print(dtypes_df1)


        # Find the rows with differences
        # diff_df = pd.concat([df1,df2]).drop_duplicates(keep=False)
        if index_col is not None:
            merged_df = df1.merge(df2, left_on=index_col, right_on=index_col, indicator=True, how='outer')
        else:
            merged_df = df1.merge(df2, indicator=True, how='outer')

        diff_df = merged_df[merged_df['_merge']!='both']

        if diff_df.empty:
            print("These two dataframes are equal.")
            return True
        else: 
            if output_file is not None:
                output_file += "_diff.html"
                with open(output_file,"w") as f:
                    f.write(diff_df.to_html(index=False))
                with open(output_file+"_left.csv","w") as f_df1:
                    f_df1.write(df1.to_csv(index=False))
                with  open(output_file+"_right.csv","w") as f_df2:
                    f_df2.write(df2.to_csv(index=False))
            print("These two dataframes are different.")
            return False



# config_file='C:/01-Work/QA/Automation/resources/settings.robot'
# sql_file='C:/01-Work/QA/Automation/testdata/EDP-sqlsample.sql'


# db = db_sqlserver()
# cnn = db.connect_to_sql_server(config_file)
# df = db.exec_sql_query_from_script(cnn, 'C:/01-Work/QA/Automation/testdata/EDP_Common-Ref_Source_System.sql')
# result = db.validate_sqlserver_with_excel(df, 'C:/01-Work/QA/Automation/testdata/Table-EDP_Common-Ref_Source_System.xlsx')
# print(df)
# print(result)





    



