import pandas as pd

class dataframeUtils:
    # def compare_dataframes(self, df1, df2):
    #     return df1.equals(df2)

    def get_csv_column_titles(self, csv_file):
        """
        Get the column title from a csv file and return the dataframe
        """
        print(csv_file)
        try:
            df = pd.read_csv(csv_file, nrows = 1)
            column_title = df.columns.tolist()
            return column_title
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return None



    
    def filter_df_by_condition(self, data_frame, columns=None, condition=None):
        """
        Retrieve records from a pandas DataFrame based on a given condition and specified columns.\n

        Args:\n
            data_frame (pandas.DataFrame): The DataFrame to retrieve records from.
            columns (list, optional): List of column names to include in the retrieved records. Defaults to None.
            condition (str, optional): The condition to filter records (e.g., "Age > 25"). Defaults to None.
        Returns:\n
            pandas.DataFrame: A new DataFrame containing the retrieved records.
        
        Examples:

        """
        # print(data_frame.columns)
        # print(data_frame)

        if columns is None:
            columns = data_frame.columns

        if condition is None:
            return data_frame[columns]
        else:
            try:
                retrieved_df = data_frame.query(condition)[columns]
                return retrieved_df
            
            except Exception as e:
                print("Error:", e)
                return pd.DataFrame()

    def get_record_count_from_df(self, data_frame):
        """
        Returns the count of data in the dataframe

        Args:\n
            data_frame (pandas.DataFrame): The DataFrame to get the record count from.\n
        Return:\n
            int: Number of data points in the dataframe
        """
        if data_frame.empty:
            print("The dataframe is empty.")
            return None
        else: 
            return len(data_frame)

    def get_duplicate_records_from_df(self, data_frame):

        # for duplicates duplicates = data_frame.duplicates(subset = business_keys, keep=False):
        pass 

    def retrieve_records_by_row(self, data_frame, row_number, columns=None):
        """
        Retrieve records from a pandas DataFrame based on a given row number and specified columns.

        Args:\n
            data_frame (pandas.DataFrame): The DataFrame to retrieve records from.\n
            row_number (int): The row number to retrieve records from (0-based index).\n
            columns (list, optional): List of column names to include in the retrieved records. Defaults to None.\n

        Returns:\n
            pandas.DataFrame: A new DataFrame containing the retrieved records.
        
        Example:\n
            Get the value of column "Age" from the 1st row of the dataframe df, and print its value into the log file.\n
            | ${data}= | Retrive Record By Row | $df | 0 | ["Age"] |
            | ${age}= | Set Variable | ${data[0]["Age"]} |  |  |
            | Log | Age value: | ${age} |  |  |
        """
        if columns is None:
            columns = data_frame.columns

        try:
            retrieved_data = data_frame.iloc[[row_number]][columns]
            return retrieved_data
        except IndexError:
            print("Row number is out of range.")
            return pd.DataFrame()
        
    def compare_sql_df_with_csv_df(self, sql_df, csv_df):
        # Check if the DataFrame4s have the same columns
        if not sql_df.columns.equals(csv_df.columns):
            return "Columns mismatch: SQL dataframe and csv dataframe have different columns."
        
        # Check if the dataframes have the same number of raws
        if len(sql_df) != len(csv_df):
            return "Raw count mismatch: SQL dataframe and csv dataframe have different data counts"
        
        # Compare values in the dataframe
        for column in sql_df.columns:
            if not sql_df[column].equals(csv_df[column]):
                return f"Value mismatch in column '{column}': SQL dataframe and csv dataframe differ."
        
        return "dataframes are equal."



# csv_file = "../testdata/EDP/NexenTaxLot/BNYM-SSE-STAR_Asset-and-Accrual_Tax-Lot-Traded-Cash-With-Accrual_Daily_20231011.csv"
# df_obj = dataframeUtils()
# df_csv = df_obj.get_csv_column_titles(csv_file)
# print(df_csv)




# data = {'First Last': ['Alice', 'Bob', 'Charlie', 'David'],
#         'Age': [25, 30, 28, 22],
#         'Gender': ['Female', 'Male', 'Male', 'Male']}

# df = pd.DataFrame(data)
# df_obj = dataframeUtils()
# print(df_obj.get_record_count_from_df(df))



# condition = "First Last = Alice"
# columns_to_retrieve = ["First Last", "Age"]

# retrieved_data = df_obj.filter_df_by_condition(df, columns_to_retrieve , condition)

# Print the retrieved records
# print(retrieved_data)

# row_number = 0
# columns_to_retrieve = ["Name","Age"]
# retrieved_data = df_obj.retrieve_records_by_row(df, row_number, columns_to_retrieve)
# print(retrieved_data)




    