import os
import re
from general import general

class dataModel:
    def __init__(self, folder_path = None):
        if not folder_path: 
            self.folder_path = folder_path
        self.table_ddls = []
    
    def get_lines_with_keywords(self, str):
        # Get line of it contians pattern of [<data type>]
        pattern = r'.*\[(bigint|datetime|varchar|bit|decimal|date|int)\].*'
        lines = str.split('\n')
        lines_with_keywords = [line for line in lines if re.match(pattern, line)]
        print(lines_with_keywords)

        # the last line may not contains ','. If missing, add a ','
        last_line = lines_with_keywords[-1]
        if not last_line.endswith(','):
            last_line +=','
            lines_with_keywords[-1] = last_line
        return '\n'.join(lines_with_keywords)
    
    def parse_ddl_files(self, path):

        path_type = general.check_path_type(path)
        if path_type == 'path':
            files_list = general.get_file_info(path)
        if path_type == 'file':
            file_name = os.path.basename(path)
            files_list = [{'file_name':file_name, 'file_path':path}]
        print(files_list)

        # If the path is empty, raising error
        if len(files_list) == 0:
            caller_function = general.get_current_function_name()
            raise ValueError(f'Function {caller_function}: path {path} does not contain any file.')
        
        # If none of the file name ends up with .sql, raising error
        file_names = [file_info['file_name'] for file_info in files_list]
        if not any(file_name.lower().endswith('.sql') for file_name in file_names):
            caller_function = general.get_current_function_name()
            raise ValueError(f'Function {caller_function}: path {path} does not contain any .sql file.')

        for filename in files_list:
            file_name = filename["file_name"]
            file_path = filename["file_path"]
            # Check if it's a file and has .ddl exte nsion
            if file_name.lower().endswith('.sql'):
                with open(file_path, 'r') as file:
                    ddl_content = file.read()
                    
                    table_match = re.search(r'CREATE\s+TABLE\s+\[.*?\]\.\[.*?\]\((.*?)\)', ddl_content,  re.IGNORECASE | re.DOTALL)
                    
                    if table_match:
                        table_ddl = table_match.group(0)
                        table_name = re.search(r'\[.*?\]\.\[.*?\]', table_ddl).group(0)   

                        colums_content = self.get_lines_with_keywords(ddl_content)

                        print(colums_content)
                        print('-------------------------------------')
                        # Parse column                         
                        columns = []                 
                        #column_matches = re.findall(r'\[(.*?)\]\s+(.*?),', colums_content)
                        column_matches = re.findall(r'\[(.*?)\]\s+\[(.*?)\]\s+(.*?),\s+', colums_content)
                        #print("column_matches=",column_matches)
                        ordinal_position = 1
                        for match in column_matches:
                            field_name = match[0]
                            extra = match[1].split()
                            data_type = extra[0]
                            
                            print(f'field_name={field_name}')
                            print(f'The length of the rest string: {len(extra)}')
                            print(f'The rest of the string {extra}')

                            if extra[1] == 'IDENTITY(1,1)' and len(extra)>=2:
                                primery_key = "True"
                                columns.append({
                                    "column_name": field_name,
                                    "ordinal_position": ordinal_position,
                                    "data_type": data_type,
                                    "is_nullable": "NO",
                                    "primery_key": primery_key
                                })

                            if extra[1] == 'NULL':
                                nullable = "YES"
                                columns.append({
                                    "column_name": field_name,
                                    "ordinal_position": ordinal_position,
                                    "data_type": data_type,
                                    "is_nullable": nullable
                                })
                            
                            if extra[1] =='NOT': #NOT NULL
                                nullable = "NO"
                                columns.append({
                                    "column_name": field_name,
                                    "ordinal_position": ordinal_position,
                                    "data_type": data_type,
                                    "is_nullable": nullable
                                })
                            if 'decimal' in extra[0] and len(extra)>2:
                                data_type = extra[0]+extra[1]
                                if extra[2] == 'NULL':
                                    nullable = "YES"
                                if extra[2] == 'NOT':
                                    nullable = "NO"
                                columns.append({
                                    "column_name": field_name,
                                    "ordinal_position": ordinal_position,
                                    "data_type": data_type,
                                    "is_nullable": nullable
                                })
                            if 'decimal' in extra[0] and len(extra) ==2:
                                data_type = extra[0]
                                if extra[1] == 'NULL':
                                    nullable = "YES"
                                if extra[1] == 'NOT':
                                    nullable = "NO"
                                columns.append({
                                    "column_name": field_name,
                                    "ordinal_position": ordinal_position,
                                    "data_type": data_type,
                                    "is_nullable": nullable
                                })
                            if len(extra)==1:
                                columns.append({
                                    "column_name": field_name,
                                    "ordinal_position": ordinal_position,
                                    "data_type": data_type,
                                })  
                            ordinal_position +=1                         
                        self.table_ddls.append({
                            "table_name": table_name,
                            "columns": columns
                        })
        return self.table_ddls
        
file_path = '../testlab/EDP_Models/Database Scripts/CreateDDL/EDP_Common.Fact_Daily_Bmk_Security_Performance.sql'
P = dataModel()
# #print(P.parse_ddl_files('../testdata/DDL/EDP_Iteration_1'))
# # #P = dataModel('../testdata/DDL/EDP_Pilot/Tables/Tables_Current')
# # #print(P.parse_ddl_files('../testdata/DDL/'))

print(P.parse_ddl_files(file_path))

