import requests


org_url = 'https://dev.azure.com/ITInvestmentApplications'
project_name = 'IMCO'
token = 'rtty247wfzykdhg3strijcwk5du42gp2ryqkdigpj2rj74etvyta'
test_case_id = 15940

automation_test_case_name = 'Perf0010-D_Curr'


headers = {
    'Authorization': 'Basic ' + token,
    'Content-Type': 'application/json',
    'User-Agent': 'savina.liu@imcoinvest.com'
}


update_url = f"{org_url}/{project_name}/_apis/test/Plans/{test_case_id}?api-version=6.0"
payload = {
    'id': test_case_id,
    'name': automation_test_case_name,
    'fields': {
        'Microsoft.VSTS.TCM.AutomationStatus': 'Automated'
    }
}

response = requests.patch(update_url, headers=headers, json=payload)

if response.status_code == 200:
    print("Test case updated successfully.")
else:
    print(f"Failed to update test case. Error: {response.text}")
