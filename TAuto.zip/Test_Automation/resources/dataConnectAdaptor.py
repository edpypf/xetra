import pyodbc
import oracledb
from azure.identity import ClientSecretCredential
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.mgmt.resource import ResourceManagementClient
from azure.core.exceptions import HttpResponseError, ResourceNotFoundError, AzureError

#from snowflake.connector import connect as snowflake_connect  # The snowflack is not yet in place, so commented out

from config import config as Config
from general import general as g
import globalSettings


class dataConnectAdaptor:
    def __init__(self, config_file = None):

        if config_file == None:
            #self.config_file='C:/O365SYNC/OneDrive - IMCO/01-Work/QA/Automation/resources/settings.robot'
            self.config_file=globalSettings.global_config_file_path
        else:
            self.config_file = config_file

        #self.connection_params ={}
        self.data_factory_client = None
    
    def connect(self, connection_type):
        #config_instance = Config()
        connection_params = {}
        if connection_type == "oracle":
            connection_params['oracle_host'] = Config.read_config_value(self.config_file, '${IDW_HOST}')
            connection_params['oracle_port'] = Config.read_config_value(self.config_file, '${IDW_PORT}')
            connection_params['oracle_service_name'] = Config.read_config_value(self.config_file, '${IDW_SERVICE_NAME}')
            connection_params['oracle_user_name'] = Config.read_config_value(self.config_file, '${IDW_USER_NAME}')
            connection_params['oracle_password'] = Config.read_config_value(self.config_file, '${IDW_PWD}')
            #print(connection_params)

            # Check the input params are valid
            check_result = g.check_input(connection_params)
            if (len(check_result) == 0):
                #return True
                return self.connect_to_oracle(connection_params)
            else:
                raise AssertionError(f'The params {check_result} for Oracle connection have issue.')
        
        elif connection_type == "sql_server_dev02":
            connection_params['sql_server'] = Config.read_config_value(self.config_file, '${SQL_SERVER_NAME_DEV02}')
            connection_params['sql_server_database'] = Config.read_config_value(self.config_file, '${SQL_DATABASE_NAME_DEV02}')
            connection_params['sql_server_user_name'] = Config.read_config_value(self.config_file, '${SQL_USER_NAME_DEV02}')
            connection_params['sql_server_password'] = Config.read_config_value(self.config_file, '${SQL_USER_PWD_DEV02}')
            connection_params['sql_server_driver'] = Config.read_config_value(self.config_file, '${SQL_DRIVER}')
            # Check if the input params are valid
            check_result = g.check_input(connection_params)
            if (len(check_result) == 0):
                return self.connect_to_sql_server(connection_params)
            else:
                raise AssertionError(f'The params {check_result} for {connection_type} connection have issue.')
        elif connection_type == "sql_server_uat":
            connection_params['sql_server'] = Config.read_config_value(self.config_file, '${SQL_SERVER_NAME_UAT}')
            connection_params['sql_server_database'] = Config.read_config_value(self.config_file, '${SQL_DATABASE_NAME_UAT}')
            connection_params['sql_server_user_name'] = Config.read_config_value(self.config_file, '${SQL_USER_NAME_UAT}')
            connection_params['sql_server_password'] = Config.read_config_value(self.config_file, '${SQL_USER_PWD_UAT}')
            connection_params['sql_server_driver'] = Config.read_config_value(self.config_file, '${SQL_DRIVER}')
            # Check if the input params are valid
            check_result = g.check_input(connection_params)
            if (len(check_result) == 0):
                return self.connect_to_sql_server(connection_params)
            else:
                raise AssertionError(f'The params {check_result} for {connection_type} connection have issue.')
        
        elif connection_type == "adf":
            connection_params['adf_client'] = Config.read_config_value(self.config_file, '${ADF_CLIENT}') 
            connection_params['subscription_id'] = Config.read_config_value(self.config_file, '${ADF_SUBSCRIPTION_ID}') 
            connection_params['resource_group_name'] = Config.read_config_value(self.config_file, '${ADF_RESOURCE_GROUP_NAME}')  
            connection_params['data_factory_name'] =  Config.read_config_value(self.config_file, '${ADF_FACTORY_NAME}')  
            connection_params['client_secret'] = Config.read_config_value(self.config_file, '${ADF_CLIENT_SECRET}')  
            connection_params['tenant_id'] = Config.read_config_value(self.config_file, '${ADF_TENNANT_ID}')   

            # Check if the input params are valid
            check_result = g.check_input(connection_params)

            if (len(check_result) == 0):
                return self.connect_to_adf(connection_params)
            else:
                raise AssertionError(f'The params {check_result} for ADF connection have issue.')
            
        # elif self.connection_type == "snowflake":
        #     return self.connect_to_snowflake(connection_params)
        else:
            raise ValueError("Unsupported connection type")

    def connect_to_oracle(self, connection_params):
        try:
            conn = oracledb.connect( 
                user = connection_params['oracle_user_name'], 
                password = connection_params['oracle_password'] , 
                host = connection_params['oracle_host'], 
                port=connection_params['oracle_port'], 
                service_name=connection_params['oracle_service_name'])
            # Get cursor
            #cursor = conn.cursor()
            print("Oracle was connected successfully!")
        except oracledb.DatabaseError as ex:
            # Handle the exception
            raise AssertionError(conn, f'Oracle connection error: {ex}' )
        return conn

    def connect_to_sql_server(self, connection_params):
        driver = connection_params['sql_server_driver']
        server = connection_params['sql_server']
        database = connection_params['sql_server_database']
        uid = connection_params['sql_server_user_name']
        pwd = connection_params['sql_server_password']

        conn_str = f'driver={driver};server={server}.sql.azuresynapse.net;database={database};uid={uid};pwd={pwd}'
        try:
            conn= pyodbc.connect(conn_str)
            print('SQL server was connected successfully!')
        except pyodbc.Error as ex:
            # Handle the exception
            raise AssertionError(f'SQL server connection error: {ex}')  
        return conn


    def connect_to_adf(self, connection_params):
        try:
            credentials = ClientSecretCredential(client_id = connection_params['adf_client'], client_secret = connection_params['client_secret'], tenant_id = connection_params['tenant_id'])
            connection_params['credentials'] = credentials
            data_factory_client = DataFactoryManagementClient(credentials, connection_params['subscription_id'])
            resource_client = ResourceManagementClient(connection_params['credentials'], connection_params['subscription_id'])

            print("ADF was connected successfully!")
            return data_factory_client, resource_client, connection_params['resource_group_name'], connection_params['data_factory_name']
        except ResourceNotFoundError as ex:
            raise AssertionError(f'ADF resource not found: {ex}')
        
        except HttpResponseError as ex:
            raise AssertionError(f'ADF HTTP error: {ex}')

        except AzureError as ex:
            raise AssertionError(f'Azure error: {ex}')

    # def connect_to_snowflake(self, connection_params):
    #     return snowflake_connect(
    #         user=connection_params['user'],
    #         password=connection_params['password'],
    #         account=connection_params['account'],
    #         warehouse=connection_params['warehouse'],
    #         database=connection_params['database'],
    #         schema=connection_params['schema']
    #     )




# adf_conn = dataConnectAdaptor() 
# # adf_conn.connect('sql_server_dev02')
# adf_conn.connect('oracle')
# # adf_conn.connect('adf')


