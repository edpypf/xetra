import oracledb
import pandas as pd
import general as g
#import dataConnectAdaptor

class db_oracle():
    # Disconnect Oracle db
    def disconnect_oralce(self, conn):
        try: 
            conn.close()
        except oracledb.Error as ex:
            raise Exception(f"Function disconnect_oralce: {ex}")
        
    # Execute a sigle sql from a file in Oracle
    def exec_oracle_query_from_script(self, conn, file_path):
        if not g.general.is_file_exist(file_path):
            raise ValueError(f"Function exec_oracle_single_query_from_file: file {file_path} is not exist.")
        if g.general.is_file_is_empty(file_path):
            raise ValueError(f"Function exec_oracle_single_query_from_file: file {file_path} is empty.")
        try: 
            with open(file_path) as f:
                sql_command = f.read()
            cursor = conn.cursor()
            cursor.execute(sql_command)

            # Get column titles (column names)
            column_titles = [desc[0] for desc in cursor.description]
            #print(column_titles)

            result = cursor.fetchall()

            df = pd.DataFrame(result, columns = column_titles)
            cursor.close()
            return df
        except oracledb.Error as ex:
            raise Exception(f"Function exec_oracle_query_from_file: {ex}")

        
    # Execute multiple sql queries from a file in Oracle
    def exec_oracle_multi_queries_from_script(self, conn, cursor, file_path):
        try:
            with open(file_path) as f:
                sql_comamnds = f.read()
            sql_statements = sql_comamnds.split(';')
            results = []
            for sql_statment in sql_statements:
                if sql_statment.strip():
                    cursor.execute(sql_statment)
                    result = cursor.fetchall()
                    results.append(result)
            df = pd.DataFrame(results)
            return df
        except oracledb.Error as ex:
            raise Exception(f"Function exec_oracle_multi_queries_from_file: {ex}")
        


        




