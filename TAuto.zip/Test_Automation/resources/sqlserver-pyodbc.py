import pandas as pd
import pyodbc
import warnings

    #your code goes here

# Set up the connection parameters
server = 'imcnoimdvmsyw02'
database = 'imcnoimdvmsql02'
username = 'python_user'
password = 'ImcoSprint@2023'
driver ='{ODBC Driver 17 for SQL Server}'  # Adjust the driver if necessary
database="imcnoimdvmsql02"

with warnings.catch_warnings(record=True):
    warnings.simplefilter("always")
# Good odbc approach
# Establish the connection
    url = f'driver={driver};server={server}.sql.azuresynapse.net;database={database};uid={username};pwd={password}'
    print(url)
    conn= pyodbc.connect(url)

    # Define the SQL query
    # sql_command = 'SELECT * FROM edp_common.dim_currency'
    # Read the SQL command from .sql file
    with open("testdata/EDP-sqlsample.sql") as f:
        sql_command = f.read()

    # Execute the query and fetch the results into a DataFrame
    df = pd.read_sql(sql_command, conn)

    # Close the database connection
    conn.close()


    # Print the DataFrame
print(df)
