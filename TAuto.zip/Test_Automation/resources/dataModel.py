import os
import re
from general import general

class dataModel:
    """
    This module is used to parse out the table schema defined in DDL files.
    """
    def __init__(self, folder_path = None):

        if not folder_path: 
            self.folder_path = folder_path
        self.table_ddls = []
    
    
    def get_lines_with_keywords(self, str):
        """
        Internally used function.
        """

        # Get line of it contians pattern of [<data type>]
        pattern = r'.*\[(bigint|datetime|datetime2|varchar|bit|decimal|date|int)\].*'
        lines = str.split('\n')
        lines_with_keywords = [line for line in lines if re.match(pattern, line)]
        #print(lines_with_keywords)

        # the last line may not contains ','. If missing, add a ','
        last_line = lines_with_keywords[-1]
        if not last_line.endswith(','):
            last_line +=','
            lines_with_keywords[-1] = last_line
        return '\n'.join(lines_with_keywords)
    
    def parse_column_definition(self, str):
        """
        Internally used function.
        """

        lines = str.strip().split('\n')
        column_list = []
        ordinal_position = 1
        for line in lines:

            match = re.match(r'(.*?)\[(.*?)\]\s+\[(.*?)\]([^\[]*)', line)
            if match:
                column_name = match.group(2)
                data_type = f"[{match.group(3)}]{match.group(4)}".strip()

                nullable = 'null' in line.lower()
                if nullable:
                    nullable = 'not null' not in line.lower()
                    nullable = 'YES' if nullable else 'NO'

                primary_key = 'identity(1,1)' in line.lower()

                # Remove 'null,', 'not null,', and 'identity(1,1)' from data_type
                data_type = re.sub(r'\s*(NULL,|NOT NULL,|identity\(1,1\))', '', data_type)

                column_list.append({
                    'column_name': column_name,
                    "ordinal_position": ordinal_position,
                    'data_type': data_type,
                    'is_nullable': nullable,
                    'primary_key': primary_key
                })
                ordinal_position += 1
        return column_list


    def parse_ddl_files(self, path):
        """This keyword is used to parse the DDL files from a given folder path or a file path 

        Examples:

        | ${expected_result}= | Parse Ddl | ../testlab/EDP_Models/Database Scripts/CreateDDL |
        | ${expected_result}= | Parse Ddl | ${DDL_PATH} |
        | ${expected_result}= | Parse Ddl | ../testlab/EDP_Models/Database Scripts/CreateDDL/EDP_Common.Dim_Benchmark.sql |
        | Should Not Be Equal | ${expected_result} | ${NONE} |
        """

        path_type = general.check_path_type(path)
        if path_type == 'path':
            files_list = general.get_file_info(path)
        if path_type == 'file':
            file_name = os.path.basename(path)
            files_list = [{'file_name':file_name, 'file_path':path}]
        #print(files_list)

        # If the path is empty, raising error
        if len(files_list) == 0:
            caller_function = general.get_current_function_name()
            raise ValueError(f'Function {caller_function}: path {path} does not contain any file.')
        
        # If none of the file name ends up with .sql, raising error
        file_names = [file_info['file_name'] for file_info in files_list]
        if not any(file_name.lower().endswith('.sql') for file_name in file_names):
            caller_function = general.get_current_function_name()
            raise ValueError(f'Function {caller_function}: path {path} does not contain any .sql file.')

        for filename in files_list:
            file_name = filename["file_name"]
            file_path = filename["file_path"]
            # Check if it's a file and has .ddl exte nsion
            if file_name.lower().endswith('.sql'):
                with open(file_path, 'r') as file:
                    ddl_content = file.read()
                    
                    table_match = re.search(r'CREATE\s+TABLE\s+\[.*?\]\.\[.*?\]\((.*?)\)', ddl_content,  re.IGNORECASE | re.DOTALL)
                    
                    if table_match:
                        table_ddl = table_match.group(0)
                        table_name = re.search(r'\[.*?\]\.\[.*?\]', table_ddl).group(0)   

                        colums_content = self.get_lines_with_keywords(ddl_content)

                        #print(colums_content)
                        #print('-------------------------------------')
                        # Parse column
                        columns = []                         
                        columns = self.parse_column_definition(colums_content)

                        self.table_ddls.append({
                            "table_name": table_name,
                            "columns": columns
                        })
        return self.table_ddls
        
        
# file_path = '../testlab/EDP_Models/Database Scripts/CreateDDL/EDP_Common.Dim_Benchmark.sql'
# P = dataModel()
# #print(P.parse_ddl_files('../testdata/DDL/EDP_Iteration_1'))
# #P = dataModel('../testdata/DDL/EDP_Pilot/Tables/Tables_Current')
# #print(P.parse_ddl_files('../testdata/DDL/'))

# print(P.parse_ddl_files(file_path))

