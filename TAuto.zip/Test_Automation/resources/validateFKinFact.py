import pandas as pd

def parse_csv_row(csv_file, row_index):
    try:
        df = pd.read_csv(csv_file)
        if row_index < len(df):
            row = df.iloc[row_index].to_dict()
            return row
        else:
            return {}  # Row index out of range
    except Exception as e:
        print(f"Error: {str(e)}")
        return {}  # Error occurred

# Example usage
csv_file = 'BNYM-STAR-FUNDACCT-Fact_BNYM_Eagle_STAR_General_Ledger_Summary.csv'  # Replace with your CSV file path
row_index = 0  # Index of the row to parse

parsed_row = parse_csv_row(csv_file, row_index)

print(parsed_row)
