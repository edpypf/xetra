import os
import shutil
import stat # This is used in the call-back function, which changes the read only permission of .git folder
from io import StringIO
import json
import inspect # Get the current function name
import zipfile # Unzip the DDL zip file

class general:

    # If the file exist
    @staticmethod
    def is_file_exist(file_name):
        if os.path.exists(file_name):
            #print(f"The file exists: {file_name}") 
            return True
        else:
            print("The file does not exist {file_name}")
            return False
        
    # If the file is empty by checking the size
    @staticmethod
    def is_file_is_empty(file_name):
        if general.is_file_exist(file_name): 
            return os.stat(file_name).st_size == 0
        else:
            return False

    # Remove read only 
    @staticmethod
    def remove_read_only(func, path, excinfo):
        os.chmod(path, stat.S_IWRITE)
        func(path)

    # Check path type
    @staticmethod
    def check_path_type(path):
        if path is None:
            raise ValueError(f'Function check_path_type: Path {path} is None.')
        
        if os.path.isdir(path):
            print(f'Path {path} is a directory.')
            return 'path'
        elif os.path.isfile(path):
            print(f'Path {path} is a file.')
            return 'file'
        else:
            raise ValueError(f'Function check_path_type: Path {path} is not a directory or a file.')
        
    # Get file info under the specific folder
    @staticmethod
    def get_file_info(folder_path):
        if not os.path.exists(folder_path):
            raise ValueError(f'Function get_file_info: folder_path {folder_path} is not exist.')
        
        files=[ f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path,f))]
        file_list=[]
        for f in files:
            file_path = os.path.join(folder_path, f)
            file_info = {"file_name":f, "file_path":file_path}
            file_list.append(file_info)
        # file_json = json.dumps(file_list)
        # return file_json
        return file_list
                 

    # Clean up the files under the specific folder    
    @staticmethod
    def clean_files_under_folder(folder_path):
        print(folder_path)
        # If the folder_path exist
        if os.path.exists(folder_path):
            # Remove all the files under the folder_path
            try:
                # Call-back function to change the read only .git folder to write permission
                shutil.rmtree(folder_path, onerror=general.remove_read_only)
                return True
            except (PermissionError, NotADirectoryError, OSError) as ex:
                print(ex)
                raise AssertionError(f'Error occurred for clean_files_under_folder {folder_path}')
        else:
            print(f'Function clean_files_under_folder: {folder_path} does not exist.')
            return False
              #raise AssertionError(f'Function clean_files_under_folder occurred an error. {folder_path} does not exist.')
              
    @staticmethod
    def create_path(path):
        if path is None or path == '':
            raise AssertionError(f'The path param is invalid.')
        try:
            # Create the path. exist_ok=True to ensure it won't raise exception is the path exists
            os.makedirs(path, exist_ok=True)
            return True
        except Exception as ex:
            raise AssertionError(f'The create_path for {path} got error.')
        
    @staticmethod
    def check_input(params):
        if params is None:
            raise AssertionError('Params for check_input is None.')
        
        invalid_params=[]
        for param, value in params.items():
            if value is None or value=='':
                invalid_params.append(param)
        return invalid_params
    
    @staticmethod
    def convert_str_to_list(this_str, delimiter):
        if this_str is not None and delimiter is not None:
            return this_str.split(delimiter)
        else:
            return None
        
    @staticmethod
    def convert_stringio_to_dict(this_value):
        if isinstance(this_value, StringIO):
            
            # Read the content of this_value
            json_str = this_value.getvalue()

            this_dict = json.loads(json_str)
            return this_dict
        else:
            return this_value
    
    @staticmethod
    def remove_list_elem_from_another_list(list1, list2):
        """
        Remove the elements persent in list1 from list2
        """
        return [x for x in list1 if x not in list2]
    

    @staticmethod
    def make_file_writable(file_path):
        if not os.path.exists(file_path):
            raise AssertionError(f"File '{file_path}' does not exist.")
        # Check if the file is writable
        if os.access(file_path, stat.S_IWRITE):
            print(f"File 'file_path' is writable.")
            return True
        else:
            # Change the permission of the file to writable
            try:
                os.chmod(file_path, stat.S_IWRITE)
                print(f"File {file_path} has chnaged to writable.")
                return True
            except OSError as ex:
                raise AssertionError(f"Error raised from function make_file_writable for file {file_path}: {ex}")
            
    @staticmethod
    # Get the function name who calls this function. 
    # This is used in expection message
    def get_current_function_name():
        caller_frame = inspect.stack()[1]
        return caller_frame.function
    
    @staticmethod
    # Unzip the zip file 
    def unzip_file(file_path):
        if not general.is_file_exist(file_path):
            caller_function = general.get_current_function_name()
            raise ValueError(f'Function {caller_function}: file_path {file_path} is invalid.')
        unzip_dir = os.path.dirname(file_path)
        try:
            with zipfile.ZipFile(file_path,'r') as f:
                f.extractall(unzip_dir)
            print(f'The zip file {file_path} has been uncompressed to {unzip_dir}')
            return True
        
        except Exception as ex:
            raise ValueError('Function unzip_file: {ex}')
        

# print(General.check_input('param1',''))
# print(General.check_input('param2', None))
#print(General.create_path('../testlab/ddl/'))
#print(General.clean_files_under_folder('../testlab/EDP_Models/.git'))

# files = General.get_file_info('../testdata/DDL/EDP_Iteration_1-Copy')
# print(len(files))

# for file in files:          
#     print(file['file_name'])
#     print(file['file_path'])

# print(General.check_path_type('../testdata/DDL/EDP_Iteration_1-Copy'))
# print(General.check_path_type('../testdata/DDL/EDP_Iteration_1-Copy/EDP_Catalogue.Ref_Object_Column_Description.sql'))
# print(General.check_path_type('../testdata/DDL/EDP_Iteration_1-Copy1'))
#print(General.check_path_type(None))

#print('current function name is %s' % (General.get_current_function_name()))
#General.unzip_file('../testlab/EDP_Models/Database Scripts/CreateDDL/DDLs_1_2023-07-25.zip')

