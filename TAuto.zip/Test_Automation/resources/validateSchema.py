import pandas as pd
import json
import re
import dataConnectAdaptor as dca
import warnings
from general import general
from dataframeUtils import dataframeUtils
from db_sqlserver import db_sqlserver


class validateSchema:
    """This module is used to validate the expected DDL result vs the actual DDL schema in the SQL Server"""

    # Extract the schema and table_name from input string
    def extract_schema_table_name(self, this_string):
        """This function is used to extract the schema and table_name from input string.

        Internally used function
        """
        if this_string is None or this_string =='':
            raise ValueError(f"Function extract_schema_table_name: input string is invalid.")
        start_postion = this_string.find('[') + 1
        end_postion = this_string.find(']')
        schema = this_string[start_postion: end_postion]

        start_postion = end_postion+3
        end_postion = this_string.find(']', start_postion)
        table_name = this_string[start_postion: end_postion]

        return schema, table_name  
            
    def parse_data_type(self, data_type):
        """ This function is used to extract text within [ ] 
        
        Internally used function.
        """

        data_type_name = re.search(r'\[(.*?)\]', data_type).group(1)

        # Extract number within ()
        precision = None
        precision_extract = re.search(r'\((\d+)(?:,\s*(\d+))?\)', data_type)
        if precision_extract:
            precision = int(precision_extract.group(1))
        return data_type_name, precision


    def lookup_schema_record(self, df, column_condition):
        """ This function is used to lookup dataframe by the column information as per the input DDL column search condition.
        
        Internally used function.
        """
        error_state={}
        data_type = column_condition['data_type']
        column_condition["character_maximum_length"] = None
        column_condition["character_octet_length"] = None
        column_condition["numeric_precision"] = None
        column_condition["numeric_precision_radix"] = None
        column_condition["numeric_scale"] = None
        column_condition["datetime_precision"] = None
        data_type_name, precision = self.parse_data_type(data_type)
        column_condition["data_type"] = data_type_name
        if data_type_name == "bigint":
            column_condition["numeric_precision"]  = 19
            column_condition["numeric_precision_radix"] = 10
            column_condition["numeric_scale"] = 0
        elif data_type_name == "varchar":
            column_condition["character_maximum_length"]  = precision
            column_condition["character_octet_length"] = precision
        elif data_type_name == "datetime2":
            column_condition["datetime_precision"] = 7
        
        condition = (
            (df["column_name"] ==  column_condition["column_name"]) &
                (df["ordinal_position"] == column_condition["ordinal_position"]) &
                (df["is_nullable"] == column_condition['is_nullable']) &
                (df["data_type"] == column_condition["data_type"])   
            )
        if column_condition["character_maximum_length"] is not None:
            condition &= (df["character_maximum_length"] == column_condition["character_maximum_length"])
        else:
            condition &=  (pd.isna(column_condition["character_maximum_length"]))

        if column_condition["character_octet_length"] is not None:
            condition &= (df["character_octet_length"] == column_condition["character_octet_length"])
        else:
            condition &=  (pd.isna(column_condition["character_octet_length"])) 

        if column_condition["numeric_precision"] is not None:
            condition &= (df["numeric_precision"] == column_condition["numeric_precision"])
        else:
            condition &=  (pd.isna(column_condition["numeric_precision"]))

        if column_condition["numeric_precision_radix"] is not None:
            condition &= (df["numeric_precision_radix"] == column_condition["numeric_precision_radix"])
        else:
            condition &=  (pd.isna(column_condition["numeric_precision_radix"])) 

        if column_condition["numeric_scale"] is not None:
            condition &= (df["numeric_scale"] == column_condition["numeric_scale"])
        else:
            condition &=  (pd.isna(column_condition["numeric_scale"]))    

        if column_condition["datetime_precision"] is not None:
            condition &= (df["datetime_precision"] == column_condition["datetime_precision"])
        else:
            condition &=  (pd.isna(column_condition["datetime_precision"])) 


        result_df = df[condition]
        if len(result_df)==1:
            return True
        else:
            print(f"Error: Column {column_condition['column_name']} did not find in db: {column_condition}")
            return False

    def validate_sqlserver_schema(self, conn, parsed_ddl):
        """This is the keyword that can be used in the test case. It compares the parsed DDL information and the database settings under test.
        Example:
        | ${result}= | Validate Sqlserver Schema | ${conn_dev02} | ${expected_ddl} |
        | Should Be True | ${result}|  |  |
        """
        try:
            parsed_ddl = json.loads(parsed_ddl)
        except Exception as ex:
            print(f"load json exception: {ex}")

        error_flag = False
        for table in parsed_ddl:
            #print(table)
            
            table_schema, table_name = self.extract_schema_table_name(table["table_name"])

            columns = table["columns"]

            # Get the number of the columns from the table ddl
            columns_count = len(columns) 

            # Connect to sqlserver to fetch this table's schema
            #dca_obj = dca.dataConnectAdaptor()
            #conn = dca_obj.connect("sql_server_dev02")
            sql_query = f"select column_name, ordinal_position,is_nullable, data_type,  "\
                        f" character_maximum_length,character_octet_length,  "\
                        f" numeric_precision, numeric_precision_radix, numeric_scale, datetime_precision"\
                        f" from information_schema.columns"\
                        f" where table_schema='{table_schema}' and table_name='{table_name}'"\
                        f" order by ordinal_position asc"
            # Using pandas
            warnings.filterwarnings('ignore')
            df = pd.read_sql_query(sql_query, conn)
            warnings.resetwarnings()

            if df.empty:
                print(f"Error: Table {table_schema}.{table_name} didn't find in db.")
                error_flag = True
            else:
                # The table was found in db
                print(f"Table {table_schema}.{table_name} was found in db")
                #print(df)
                # Validate if the record count in db is the same of the ddl defination
                df_record_count = len(df)
                if  df_record_count != columns_count:
                    print(f"Error: The column number of table is different. DDL: {columns_count} but actual {df_record_count}" )
                    error_flag = True
                    # print("=======DDL========")
                    # print(columns)
                    # print("=======Actual in Database========")
                    # print(df)
                    
                for column in columns:
                    result = self.lookup_schema_record(df, column)
                    if not result:
                        error_flag = True
        if error_flag:
            raise AssertionError("Table schema does not match the DDL files.")
        else: 
            return True
    
    def validate_staging_schema_with_csv_source_file(self, conn, config_file):
        #Read the config file, get the schema, table name and source csv file
        if general.is_file_exist(config_file) is False:
            raise AssertionError("Config File for testing staging schema doesn't exist: %s" %(config_file))
        
        df_config = pd.read_csv(config_file)
        sql_command="select column_name from information_schema.columns where "
        if df_config is not None and not df_config.empty:
            dfu_obj = dataframeUtils()
            db_sqlserver_obj = db_sqlserver()
            ignore_source_col_list = None
            ignore_target_col_list = None

            for index, row in df_config.iterrows():
                for column_name, value in row.items():
                    if column_name == "table_schema":
                        sql_command += " table_schema = '" + value +"'"
                        schema = value
                    elif column_name == "table_name":
                        sql_command += " and table_name = '"+ value +"'"
                        table_name = value
                    elif column_name == "source_file":
                        source_file = value
                    elif column_name == "ignor_source_columns":
                        ignor_source_columns = str(value)
                        print(type(value))
                        print(ignor_source_columns)
                        if ignor_source_columns != 'nan' :
                            ignore_source_col_list = general.convert_str_to_list(ignor_source_columns,';')
                            print(f"ignore_soruce_col_list {ignore_source_col_list}")
                    elif column_name == "ignore_target_columns":
                        ignore_target_columns = value
                        
                        if value is not None and len(value.strip())>0:
                            ignore_target_col_list = general.convert_str_to_list(ignore_target_columns,';')
                            print(f"ignore_soruce_col_list {ignore_target_col_list}")

                    elif column_name == "Enable":
                        if value == "Y":
                            # Execute SQL command 
                            print(sql_command)
                            df_table_schema = db_sqlserver_obj.exec_sqlserver_query(conn, sql_command)
                            list_table_schema = df_table_schema['column_name'].tolist()
                            #print(list_table_schema)
                            # read the column titles from the source file
                            list_csv = dfu_obj.get_csv_column_titles(source_file)
                            #print(list_csv)
                            if ignore_source_col_list is not None:
                                #Remove the ignored elements from the source list
                                list_csv = general.remove_list_elem_from_another_list(ignore_source_col_list, list_csv)
                            if ignore_target_col_list is not None:
                                list_table_schema = general.remove_list_elem_from_another_list(ignore_target_col_list, list_table_schema)
                            if len(list_csv) != len(list_table_schema):
                                print(f"Lengths are different: {source_file} is {len(list_csv)}; {schema}.{table_name} is {len(list_table_schema)}.")
                            else:
                                print("\n Compared the source file title vs staging table schema: Different")
                        
                        #Re-initial the sql command
                        sql_command = "select column_name from information_schema.columns where "
                        source_file=""
                        schema=""
                        table_name=""
                        ignore_source_col_list = None
                        ignore_target_col_list = None
                break



    



        #Run sql command to get schema information



# ddl_json = '''
# [{"table_name": "[EDP_Common].[Dim_Benchmark]", "columns": 
# [{"column_name": "Dim_Benchmark_Key1", "ordinal_position": 1, "data_type": "[bigint]", "is_nullable": "NO", "primery_key": "True"}, 
# {"column_name": "Benchmark_ID", "ordinal_position": 2, "data_type": "[varchar](16)", "is_nullable": "NO"}, 
# {"column_name": "Benchmark_Name", "ordinal_position": 3, "data_type": "[varchar](255)", "is_nullable": "YES"}, 
# {"column_name": "Benchmark_Description", "ordinal_position": 4, "data_type": "[varchar](255)", "is_nullable": "YES"}, 
# {"column_name": "Benchmark_Type_Code", "ordinal_position": 5, "data_type": "[varchar](20)", "is_nullable": "YES"}, 
# {"column_name": "Benchmark_Type_Name", "ordinal_position": 6, "data_type": "[varchar](30)", "is_nullable": "YES"}, 
# {"column_name": "Benchmark_Type_Description", "ordinal_position": 7, "data_type": "[varchar](255)", "is_nullable": "YES"}, 
# {"column_name": "Source_System_Code", "ordinal_position": 8, "data_type": "[varchar](255)", "is_nullable": "NO"}, 
# {"column_name": "Is_Current_Flag", "ordinal_position": 9, "data_type": "[bit]", "is_nullable": "NO"}, 
# {"column_name": "Effective_Start_Datetime", "ordinal_position": 10, "data_type": "[datetime2](7)", "is_nullable": "NO"}, 
# {"column_name": "Effective_End_Datetime", "ordinal_position": 11, "data_type": "[datetime2](7)", "is_nullable": "NO"}, 
# {"column_name": "ETL_Load_Key", "ordinal_position": 12, "data_type": "[bigint]", "is_nullable": "NO"}, 
# {"column_name": "Hash_Diff", "ordinal_position": 13, "data_type": "[varchar](64)", "is_nullable": "NO"}, 
# {"column_name": "Last_Update_User", "ordinal_position": 14, "data_type": "[varchar](255)", "is_nullable": "NO"}, 
# {"column_name": "Last_Update_Datetime", "ordinal_position": 15, "data_type": "[datetime2](7)", "is_nullable": "NO"}]}]
# '''


obj = validateSchema()
# print(obj.validate_sqlserver_schema('conn', ddl_json))
dca_obj = dca.dataConnectAdaptor()
conn = dca_obj.connect("sql_server_dev02")
staging_schema_config_file = '../testdata/EDP/NexenTaxLot/NexenTaxLot_Staging_Config.csv'
obj.validate_staging_schema_with_csv_source_file(conn, staging_schema_config_file)


