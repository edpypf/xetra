import git
from config import config
from general import general as g
import globalSettings

class gitOperator:
    def __init__(self):
        self.config_file = globalSettings.global_config_file_path
        self.organization = config.read_config_value(self.config_file, '${DEVOPS_ORG}')
        self.project = config.read_config_value(self.config_file, '${DEVOPS_PROJECT}')
        self.repo = config.read_config_value(self.config_file, '${GIT_REPO_NAME}')
        self.branch_name = config.read_config_value(self.config_file, '${GIT_BRANCH_NAME}')
        self.local_path = config.read_config_value(self.config_file, '${GIT_LOCAL_PATH}') 


    def clone(self, organization = None, project = None, repo = None, branch_name = None, local_path = None):
        if organization is None or organization =='':
            organization = self.organization
        if project is None or project == '':
            project = self.project
        if branch_name is None or branch_name == '':
            branch_name = self.branch_name
        if repo is None or repo=='':
            repo = self.repo
        if local_path is None or local_path == '':
            local_path = self.local_path

        g.clean_files_under_folder(local_path)
        g.create_path(local_path)

        url = f'https://dev.azure.com/{organization}/{project}/_git/{repo}'
        # Clean the local_path

        # Clone from the specific branch and stored files to the local_path
        try:
            git.Repo.clone_from(url, local_path, branch = branch_name)
            return True
        
        except Exception as ex:
            print(ex)
            raise AssertionError(f'Error occourred on git clone command: url={url}, local_path={local_path}, branch_name={branch_name}')

# obj = gitOperator()
# obj.clone()

        



