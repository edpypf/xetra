import pandas as pd
import pyodbc
import json
import globalSettings
from config import config
import dataConnectAdaptor as dataconn
import db_sqlserver

class validateStagingDataCSV:
    def sum_column_values(csv_df, column_name):
        '''
        Return the sum of a given column name in the csv file
        '''
        try:

            if column_name not in csv_df.columns:
                print(f"Column '{column_name}' not found in the CSV file.")
                return None

            # Calculate the sum
            column_sum = csv_df[column_name].sum()

            return column_sum
        except Exception as e:
            print(f"Error: {e}")
            return None
        
    def count_rows_in_csv(csv_df, column_name, search_value):
        '''
        Return the row count of the value in a given column name of the csv file
        '''
        try:

            if column_name not in csv_df.columns:
                print(f"Column '{column_name}' not found in the CSV file.")
                return None

            # Find the row number where the column has the search value
            row_number = (csv_df[column_name] == search_value).idxmax() + 1

            if row_number == 0:
                print(f"Value '{search_value}' not found in column '{column_name}'.")
                return None

            return row_number

        except Exception as e:
            # Handle any exceptions, e.g., file not found, incorrect format, etc.
            print(f"Error: {e}")
            return None

    def get_column_data_type_in_sqlserver(self, conn, schema,table_name,column_name=None):

        #cursor = conn.cursor()

        sql_command = """
            select column_name, data_type
            from information_schema.columns
            where table_schema= ? and table_name = ? 
        """
        if column_name is not None:
            sql_command += """  and column_name = ?"""
        
        sql_command += """  order by ordinal_postion """
        print(sql_command)
        # cursor.execute(sql_command, (schema, table_name, column_name))
        # column_data_types = cursor.fetchall()
        # return column_data_types
    

obj_db=dataconn()
obj = validateStagingDataCSV()
obj.get_column_data_type_in_sqlserver('conn','EDW_Staging','SS_MySS_MCH_Tax_Lot_Level_Holdings_Daily','Account Number')

 
    


    

    


