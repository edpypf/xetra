import pandas as pd
import pyodbc
import json
import globalSettings
from config import config
import dataConnectAdaptor as dataconn

class validateTableRecordCount:
    def __init__(self, validation_result_file = None):
        if validation_result_file is None:
            config_file_path = globalSettings.global_config_file_path
            print(f'config_file_path: {config_file_path}')
            self.validation_result_file = config.read_config_value(config_file_path, '${ETL_RESULT_FILE}')
        else:
            self.validation_result_file = validation_result_file

    def process_test_case(self, suite_file, testcase_name, validation_result_file = None):
        if validation_result_file is None:
            validation_result_file = self.validation_result_file
        print(validation_result_file)

        # Read the CSV result file which is using specified delimiter 
        df = pd.read_csv(validation_result_file, sep='|')
        filtered_rows = df.loc[(df['suite_file'].str.strip() == suite_file) & (df['testcase_name'].str.strip() == testcase_name)]
        
        if not filtered_rows.empty:
            # Get the first row of the rows
            result_row = filtered_rows.iloc[0]
            print(result_row)
        else:
            raise ValueError(f"No match row for the given suite_file and testcase name: {suite_file},{testcase_name}")    
        
        # Get the database_type and data_count_in_tables from the DataFrame
        database_type = result_row['database_type']
        data_count_in_tables = json.loads(result_row['data_count_in_tables'])
        print(data_count_in_tables)

        # Connect to the SQL Server database based on the database_type
        data_adapter = dataconn.dataConnectAdaptor()
        if database_type == 'sql_server_dev01':
            conn_str = ''
        elif database_type == 'sql_server_dev02':
            # Create instance of dateconn object
            
            conn = data_adapter.connect(database_type)
                
        elif database_type == 'sql_server_uat':
            conn = dataconn.dataConnectAdaptor.connect(database_type)
        # elif database_type == 'sql_server_prod':
        #     conn_str = 'connection_string_for_prod'
        else:
            raise ValueError(f"Invalid database_type: {database_type}")

        cursor = conn.cursor()
        # Query the data_count_in_tables from the database and compare the results
        for table_name, table_info in data_count_in_tables.items():
            expected_count = table_info['count']
            sql_query = table_info['sql']

            cursor.execute(sql_query)
            actual_count = cursor.fetchone()[0]

            if actual_count != expected_count:
                print(f"Test failed for {database_type}, {table_name}. Expected: {expected_count}, Actual: {actual_count}")
            else:
                print(f"Test passed for {database_type}, {table_name}. Count: {actual_count}")

        cursor.close()
        conn.close()

# validate_obj = validateTableRecordCount()
# validate_obj.process_test_case('testETL.robot', 'testcase002','../testdata/ETL_Test_Results_new.csv')
