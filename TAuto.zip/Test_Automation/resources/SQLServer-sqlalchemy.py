import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy import URL
import pyodbc
import sqlalchemy

# Set up the connection parameters
server = 'imcnoimdvmsql02'
database = 'imcnoimdvmsql02' 
username = 'python_user'
password = 'ImcoSprint@2023'
driver ='{ODBC Driver 17 for SQL Server}'  # Adjust the driver if necessary
synapse_workspace = 'imcnoimdvmsyw02'
port = 1433
host='imcnoimdvmsyw02'

database="imcnoimdvmsql02"

url_object = URL.create(
    "mssql+pyodbc",
    username=username,
    password=password,  # plain (unescaped) text
    host=host,
    database=database,
)
#engine = create_engine(f'mssql+pyodbc:///?odbc_connect=DRIVER={{ODBC Driver 17 for SQL Server}};'
#                       f'SERVER={server};DATABASE={database};UID={username};PWD={password}')
connection_string = "DRIVER={ODBC Driver 17 for SQL Server};SERVER="+host+";DATABASE="+database+";UID="+username+";PWD="+password
url = URL.create("mssql+pyodbc", query={"odbc_connect": connection_string})


#engine = create_engine(url_object)

#url = 'mssql+pyodbc://'+username+':'+password+'@'+host+'/'+database+':1433?driver=SQL+Server'
engine = sqlalchemy.create_engine(url)

# Read the SQL command from .sql file
with open("../testdata/EDP-sqlsample.sql") as f:
    sql_command = f.read()

# Execute the query and fetch the results into a DataFrame
#df = pd.read_sql(sql_command, conn)
df = pd.read_sql(sql_command, engine)

# Close the database connection

engine.dispose()

# Print the DataFrame
print(df)
