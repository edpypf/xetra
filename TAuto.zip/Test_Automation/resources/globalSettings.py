#gloabl_base_dir = f'C:\\O365SYNC\\OneDrive - IMCO\\01-Work\\QA\\Automation'
gloabl_base_dir = f'C:\\QA\\Test_Automation'
global_config_file_path = gloabl_base_dir + f'\\resources\\settings.robot'
global_test_data_dir = gloabl_base_dir + f'\\testdata'
global_resources_dir = gloabl_base_dir + f'\\resources'
global_testcase_dir = gloabl_base_dir + f'\\testcase'
global_testlab_dir = gloabl_base_dir + f'\\testlab'

# C:\O365SYNC\OneDrive - IMCO\01-Work\QA\Automation\resources
# print(gloabl_base_dir)
# print(global_config_file_path)
# print(global_test_data_dir)

