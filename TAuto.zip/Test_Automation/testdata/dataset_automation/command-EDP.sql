select top 100 * from
psa.eagle_code_values
where etl_load_key=-200

select * from 
psa.eagle_codes
where etl_load_key=-200

select top 100 * from
psa.eagle_entity
where etl_load_key=-200

select * from 
psa.eagle_perf_sec_returns
where etl_load_key=-200

select top 100 * from
psa.eagle_perf_summary
where etl_load_key=-200

select top 100 * from
psa.eagle_security_master
where etl_load_key=-200





