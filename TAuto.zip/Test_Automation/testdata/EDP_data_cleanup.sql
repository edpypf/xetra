/****** Script for SelectTopNRows command from SSMS  ******/
select count(*) from datawarehouse_staging.eagle_entity  -- 3
select count(*) from datawarehouse_staging.eagle_security_master  --965


select count(*) from PSA.eagle_entity where etl_load_key=-200  --3
select count(*) from PSA.eagle_code_values where etl_load_key=-200 --0
select count(*) from PSA.eagle_security_master where etl_load_key=-200 --965
select count(*) from PSA.eagle_perf_summary where etl_load_key=-200  --2
select count(*) from PSA.eagle_perf_sec_returns where etl_load_key=-200 --964

select count(*) from EDP_Common.Dim_Security where etl_load_key=-200  -- 965
select count(*) from EDP_Common.Fact_daily_bmk_performance where etl_load_key=-200 -- 0
select count(*) from EDP_Common.Fact_Daily_Bmk_Security_Performance where etl_load_key=-200  --0
select count(*) from EDP_Common.Fact_Daily_Portfolio_Performance where etl_load_key=-200  -- 0
select count(*) from EDP_Common.Fact_Daily_Security_Performance where etl_load_key=-200 --963
select count(*) from EDP_Common.Fact_Monthly_Bmk_Performance where etl_load_key=-200 -- 0
select count(*) from EDP_Common.Fact_Monthly_Bmk_Security_Performance where etl_load_key=-200  --0
select count(*) from EDP_Common.Fact_Monthly_Portfolio_Performance where etl_load_key=-200  --0
select count(*) from EDP_Common.Fact_Monthly_Security_Performance where etl_load_key=-200 -- 0
-----------------------------------------------------------------------------------------------
select count(*) from [EDP_Common].[Fact_Daily_Bmk_Performance] where etl_load_key=-200;  --0
select count(*) from [EDP_Common].[Fact_Daily_Portfolio_Performance] where etl_load_key=-200; --0
select count(*) from [EDP_Common].[Dim_Currency] where etl_load_key=-200;  -- 0
select count(*) from [EDP_Common].[Fact_Monthly_Bmk_Security_Performance] where etl_load_key=-200; --0
select count(*) from [EDP_Common].[Fact_Monthly_Security_Performance] where etl_load_key=-200;  --0
select count(*) from [EDP_Common].[Fact_Monthly_Portfolio_Performance] where etl_load_key=-200; --0
select count(*) from [EDP_Common].[Dim_Security] where etl_load_key=-200; -- 965
select count(*) from [EDP_Common].[Dim_Benchmark] where etl_load_key=-200;  -- 222
select count(*) from [EDP_Common].[Fact_Monthly_Bmk_Performance] where etl_load_key=-200; --0
select count(*) from [PSA].[Eagle_Security_Master] where etl_load_key=-200; --965
select count(*) from [EDP_Common].[Fact_Daily_Bmk_Security_Performance] where etl_load_key=-200; --0
select count(*) from [EDP_Common].[Fact_Daily_Security_Performance] where etl_load_key=-200; --963
select count(*) from [EDP_Common].[Dim_Portfolio] where etl_load_key=-200; -- 3
select count(*) from [PSA].[Eagle_Codes] where etl_load_key=-200; --0
-------------------------------------------------------------------------------------------------------
/*
delete from [EDP_Common].[Fact_Daily_Bmk_Performance] where etl_load_key=-200;
delete from [EDP_Common].[Fact_Daily_Portfolio_Performance] where etl_load_key=-200;
delete from [EDP_Common].[Dim_Currency] where etl_load_key=-200;
delete from [EDP_Common].[Fact_Monthly_Bmk_Security_Performance] where etl_load_key=-200;
delete from [EDP_Common].[Fact_Monthly_Security_Performance] where etl_load_key=-200;
delete from [EDP_Common].[Fact_Monthly_Portfolio_Performance] where etl_load_key=-200;
delete from [EDP_Common].[Dim_Security] where etl_load_key=-200;
delete from [EDP_Common].[Dim_Benchmark] where etl_load_key=-200;
delete from [EDP_Common].[Fact_Monthly_Bmk_Performance] where etl_load_key=-200;
delete from [PSA].[Eagle_Security_Master] where etl_load_key=-200;
delete from [EDP_Common].[Fact_Daily_Bmk_Security_Performance] where etl_load_key=-200;
delete from [EDP_Common].[Fact_Daily_Security_Performance] where etl_load_key=-200;
delete from [EDP_Common].[Dim_Portfolio] where etl_load_key=-200;
delete from [PSA].[Eagle_Codes] where etl_load_key=-200;
delete from PSA.Eagle_Entities  where etl_load_key=-200 -- wrong name
delete from PSA.Eagle_Perf_Sec_Returns  where etl_load_key=-200 -- wrong name
delete from datawarehouse_staging.eagle_entity where etl_load_key=-200
*/



/*
declear @deleteSQL nvarchar(MAX) = N'';
select @deleteSQL+= N'select count(*) from ' + quotename(table_schema)+'.'+quotename(table_name)+
	N' where etl_load_key=-200;' +char(13)
from information_schema.columns
where column_name = 'etl_load_key'
print @deleteSQL
*/
select N'select count(*) from ' + quotename(table_schema)+'.'+quotename(table_name)+
	N' where etl_load_key=-200;'
from information_schema.columns
where column_name = 'etl_load_key'
and concat(table_schema,'.',table_name) in (
SELECT distinct concat([Target_Schema],'.',[Target_table])
  FROM [EDW_Config].[Ref_Process_Mapping]
   where source_system='PSA_EDP_eagle'
   union
SELECT distinct concat([Source_Schema],'.',[source_table])
  FROM [EDW_Config].[Ref_Process_Mapping]
   where source_system='PSA_EDP_eagle'
   )
--and table_schema in ('PSA','EDP_Common')----------------------------------------------------------------------------SELECT TOP (1000) [ETL_Load_Layer]
      ,[Source_System]
      ,[Source_Schema]
      ,[Source_Table]
      ,[Target_Schema]
      ,[Target_Table]
      ,[Target_Table_Type]
      ,[Load_Procedure_Schema]
      ,[Load_Procedure_Name]
      ,[Last_Update_DT]
  FROM [EDW_Config].[Ref_Process_Mapping]
   where source_system='PSA_EDP_eagle'--------------------------------------------------------------------------------select * from edw_etl.etl_loadwhere--Run_Pipeline_id='d01a25c5-24b9-11ee-9c9e-74d83ed14d49'source_system='PSA_EDP_Eagle'and load_status = 'in_progress'order by batch_date descupdate edw_etl.etl_loadset load_status = 'Failed'where Run_Pipeline_id='d01a25c5-24b9-11ee-9c9e-74d83ed14d49'source_system='PSA_EDP_Eagle'and load_status = 'in_progress'---------------select count(*) from PSA.Eagle_Codes where etl_load_key=-200
select count(*) from PSA.Eagle_Entities  where etl_load_key=-200 -- wrong name
select count(*) from PSA.Eagle_Perf_Sec_Returns  where etl_load_key=-200 -- wrong name
select count(*) from PSA.Eagle_Security_Master  where etl_load_key=-200












