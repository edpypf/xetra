/*

Select f.*
from [EDP_Common].[Fact_Daily_Security_Performance] f
join EDP_Common.Dim_Portfolio p on f.Dim_Portfolio_Key = p.Dim_Portfolio_Key
Where p.portfolio_Id like 'TEST%'


Select distinct load_datetime from [EDP_Common].[Fact_Daily_Security_Performance]
where load_datetime > '2023-07-06'

delete from  [EDP_Common].[Fact_Daily_Security_Performance] 
where load_datetime > '2023-07-06'


where dim_portfolio_key in (18395, 25105)


Select max(load_datetime) from [EDP_Common].[Fact_Daily_Portfolio_Performance] 
where load_datetime ='2023-07-06 14:28:31.0516920'


Select max(load_datetime) from [EDP_Common].[Fact_Daily_Security_Performance]
where load_datetime ='2023-07-06 14:28:31.0516920'

Select * from [EDP_Common].[Fact_Daily_Security_Performance] where load_datetime = '2023-07-06 15:50:45.7566667'


Select * from EDP_Common.Dim_Portfolio where portfolio_Id like 'TEST%'

Select * From EDP_Common.Dim_Security where try_convert(int, IMCO_SEcurity_Alias_ID) < 0


Select PSR.*
From PSA.Eagle_Perf_Sec_Returns     PSR 
Inner Join PSA.V_Eagle_Perf_Summary PS ON PS.PERF_SUM_INST  = PSR.PERF_SUM_INST
where PS.Entity_Id like 'TEST%'

Delete from PSA.Eagle_Perf_Summary where Entity_Id like 'TEST%'

Select * From PSA.Eagle_Perf_Sec_Returns where load_DTS = '2023-07-06 15:50:45.7566667'
Select * From PSA.Eagle_Perf_Sec_Returns where ETL_Load_Key = -200


*/

Delete f
from [EDP_Common].[Fact_Daily_Portfolio_Performance] f
join EDP_Common.Dim_Portfolio p on f.Dim_Portfolio_Key = p.Dim_Portfolio_Key
Where p.portfolio_Id like 'TEST%'

Delete f
from [EDP_Common].[Fact_Daily_Security_Performance] f
join EDP_Common.Dim_Portfolio p on f.Dim_Portfolio_Key = p.Dim_Portfolio_Key
Where p.portfolio_Id like 'TEST%'

Delete f
from [EDP_Common].[Fact_Monthly_Portfolio_Performance] f
join EDP_Common.Dim_Portfolio p on f.Dim_Portfolio_Key = p.Dim_Portfolio_Key
Where p.portfolio_Id like 'TEST%'

Delete f
from [EDP_Common].[Fact_Monthly_Security_Performance] f
join EDP_Common.Dim_Portfolio p on f.Dim_Portfolio_Key = p.Dim_Portfolio_Key
Where p.portfolio_Id like 'TEST%'



Delete f
from [EDP_Common].[Fact_Daily_Bmk_Performance] f
join EDP_Common.Dim_Benchmark p on f.Dim_Benchmark_Key = p.Dim_Benchmark_Key
Where p.Benchmark_Id like 'TEST%'


Delete f
from [EDP_Common].[Fact_Daily_Bmk_Security_Performance] f
join EDP_Common.Dim_Benchmark p on f.Dim_Benchmark_Key = p.Dim_Benchmark_Key
Where p.Benchmark_Id like 'TEST%'

Delete f
from [EDP_Common].[Fact_Monthly_Bmk_Performance] f
join EDP_Common.Dim_Benchmark p on f.Dim_Benchmark_Key = p.Dim_Benchmark_Key
Where p.Benchmark_Id like 'TEST%'

Delete f
from [EDP_Common].[Fact_Monthly_Bmk_Security_Performance] f
join EDP_Common.Dim_Benchmark p on f.Dim_Benchmark_Key = p.Dim_Benchmark_Key
Where p.Benchmark_Id like 'TEST%'

Delete from EDP_Common.Dim_Portfolio where portfolio_Id like 'TEST%'

Delete From EDP_Common.Dim_Security where try_convert(int, IMCO_SEcurity_Alias_ID) < 0

Delete PSR 
From PSA.Eagle_Perf_Sec_Returns     PSR 
Inner Join PSA.V_Eagle_Perf_Summary PS ON PS.PERF_SUM_INST  = PSR.PERF_SUM_INST
where PS.Entity_Id like 'TEST%'

Delete from PSA.Eagle_Perf_Summary where Entity_Id like 'TEST%'

Delete from PSA.Eagle_Entity where Entity_Id like 'TEST%'

Delete from PSA.Eagle_Security_Master where Security_Alias < 0

