
/* 
 * TABLE: [EDP_Catalogue].[Ref_Object_Column_Description] 
 * Performance Iteration 1, Story 15094
 [{'table_name': '[EDP_Catalogue].[Ref_Object_Column_Description]', 'columns': [
 {'field_name': 'Object_Schema_Name', 'data_type': 'varchar(64)', 'nullable': False}, 
 {'field_name': 'Object_Name', 'data_type': 'varchar(64)', 'nullable': False}, 
 {'field_name': 'Column_Name', 'data_type': 'varchar(64)', 'nullable': False}, 
 {'field_name': 'Column_Description', 'data_type': 'varchar(500)', 'nullable': True}, 
 {'field_name': 'Sample_Data', 'data_type': 'varchar(255)', 'nullable': True},
 {'field_name': 'Source_System_Code', 'data_type': 'varchar(255)', 'nullable': False}, 
 {'field_name': 'Last_Update_User', 'data_type': 'varchar(255)', 'nullable': False},
 {'field_name': 'Last_Update_Datetime', 'data_type': 'datetime2(7)', 'nullable': False}]}]
 
[{'table_name': '[EDP_Common].[Fact_Daily_Bmk_Security_Performance]', 'columns': [
{'column_name': '[Fact_Daily_Bmk_Security_Performance_ID]', 'data_type': '[bigint]', 'nullable': 'NO', 'primary_key': False}, 
{'column_name': '[Dim_Effective_Date_Key]', 'data_type': '[bigint]', 'nullable': 'NO', 'primary_key': False}, 
{'column_name': '[Dim_Benchmark_Key]', 'data_type': '[bigint]', 'nullable': 'NO', 'primary_key': False}, 
{'column_name': '[Dim_Security_Key]', 'data_type': '[bigint]', 'nullable': 'NO', 'primary_key': False}, 
{'column_name': '[Dim_Security_Currency_Key]', 'data_type': '[bigint]', 'nullable': 'NO', 'primary_key': False}, 
{'column_name': '[Dim_Source_Status_Key]', 'data_type': '[bigint]', 'nullable': 'NO', 'primary_key': False}, 
{'column_name': '[Return_Percentage]', 'data_type': '[decimal](28, 12)', 'nullable': 'YES', 'primary_key': False}, 
{'column_name': '[Local_Return_Percentage]', 'data_type': '[decimal](28, 12)', 'nullable': 'YES', 'primary_key': False}, 
{'column_name': '[Beginning_Weight_Percentage]', 'data_type': '[decimal](28, 12)', 'nullable': 'YES', 'primary_key': False}, 
{'column_name': '[Source_System_Code]', 'data_type': '[varchar](255)', 'nullable': 'NO', 'primary_key': False}, 
{'column_name': '[Source_Deleted_Flag]', 'data_type': '[bit]', 'nullable': 'NO', 'primary_key': False}, 
{'column_name': '[ETL_Load_Key]', 'data_type': '[bigint]', 'nullable': 'NO', 'primary_key': False}, 
{'column_name': '[Load_Detail_Description]', 'data_type': '[varchar](4000)', 'nullable': 'YES', 'primary_key': False}, 
{'column_name': '[Last_Update_User]', 'data_type': '[varchar](255)', 'nullable': 'NO', 'primary_key': False}]}]
 
 */

IF OBJECT_ID('[EDP_Catalogue].[Ref_Object_Column_Description]') IS NOT NULL
BEGIN
    DROP TABLE [EDP_Catalogue].[Ref_Object_Column_Description]
    PRINT '<<< DROPPED TABLE [EDP_Catalogue].[Ref_Object_Column_Description] >>>'
END
go


CREATE TABLE [EDP_Catalogue].[Ref_Object_Column_Description](
    [Object_Schema_Name]    varchar(64)     NOT NULL,
    [Object_Name]           varchar(64)     NOT NULL,
    [Column_Name]           varchar(64)     NOT NULL,
    [Column_Description]    varchar(500)    NULL,
    [Sample_Data]           varchar(255)    NULL,
    [Source_System_Code]    varchar(255)    NOT NULL,
    [Last_Update_User]      varchar(255)    NOT NULL,
    [Last_Update_Datetime]  datetime2(7)       NOT NULL,

 CONSTRAINT [PK_Ref_Object_Column_Description] PRIMARY KEY NONCLUSTERED 
	(
		[Object_Schema_Name] ASC,
		[Object_Name] ASC,
		[Column_Name] ASC

	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = HASH ( [Column_Name] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

IF OBJECT_ID('EDP_Catalogue.Ref_Object_Column_Description') IS NOT NULL
    PRINT '<<< CREATED TABLE EDP_Catalogue.Ref_Object_Column_Description >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE EDP_Catalogue.Ref_Object_Column_Description >>>'
go

