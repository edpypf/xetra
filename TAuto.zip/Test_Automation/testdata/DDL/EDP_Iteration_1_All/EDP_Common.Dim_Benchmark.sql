IF OBJECT_ID('[EDP_Common].[Dim_Benchmark]') IS NOT NULL
BEGIN
    DROP TABLE [EDP_Common].[Dim_Benchmark]
    PRINT '<<< DROPPED TABLE [EDP_Common].[Dim_Benchmark] >>>'
END
go
/* 
 * TABLE: [EDP_Common].[Dim_Benchmark] 
 */
 
 /*
 [{'table_name': '[EDP_Common].[Dim_Benchmark]', 'columns': [
 {'field_name': 'Dim_Benchmark_Key', 'data_type': 'bigint', 'primery_key': True}, 
 {'field_name': 'Benchmark_ID', 'data_type': 'varchar(16)', 'nullable': False}, 
 {'field_name': 'Benchmark_Name', 'data_type': 'varchar(255)', 'nullable': True}, 
 {'field_name': 'Benchmark_Description', 'data_type': 'varchar(255)', 'nullable': True}, 
 {'field_name': 'Benchmark_Type_Code', 'data_type': 'varchar(20)', 'nullable': True},
 {'field_name': 'Benchmark_Type_Name', 'data_type': 'varchar(30)', 'nullable': True}, 
 {'field_name': 'Benchmark_Type_Description', 'data_type': 'varchar(255)', 'nullable': True}, 
 {'field_name': 'Source_System_Code', 'data_type': 'varchar(255)', 'nullable': False}, 
 {'field_name': 'Is_Current_Flag', 'data_type': 'bit', 'nullable': False}, 
 {'field_name': 'Effective_Start_Datetime', 'data_type': 'datetime2(7)', 'nullable': False}, 
 {'field_name': 'Effective_End_Datetime', 'data_type': 'datetime2(7)', 'nullable': False}, 
 {'field_name': 'ETL_Load_Key', 'data_type': 'bigint', 'nullable': False}, 
 {'field_name': 'Hash_Diff', 'data_type': 'varchar(64)', 'nullable': False}, 
 {'field_name': 'Last_Update_User', 'data_type': 'varchar(255)', 'nullable': False},
 {'field_name': 'Last_Update_Datetime', 'data_type': 'datetime2(7)', 'nullable': False}
 ]}]
 
 */

CREATE TABLE [EDP_Common].[Dim_Benchmark](
    [Dim_Benchmark_Key]           bigint          IDENTITY(1,1) PRIMARY KEY NONCLUSTERED NOT ENFORCED,
    [Benchmark_ID]                varchar(16)     NOT NULL,
    [Benchmark_Name]              varchar(255)    NULL,
    [Benchmark_Description]       varchar(255)    NULL,
    [Benchmark_Type_Code]         varchar(20)     NULL,
    [Benchmark_Type_Name]         varchar(30)     NULL,
    [Benchmark_Type_Description]  varchar(255)     NULL,
    [Source_System_Code]          varchar(255)    NOT NULL,
    [Is_Current_Flag]             bit             NOT NULL,
    [Effective_Start_Datetime]    datetime2(7)    NOT NULL,
    [Effective_End_Datetime]      datetime2(7)    NOT NULL,
    [ETL_Load_Key]                bigint          NOT NULL,
    [Hash_Diff]                   varchar(64)     NOT NULL,
    [Last_Update_User]            varchar(255)    NOT NULL,
    [Last_Update_Datetime]        datetime2(7)    NOT NULL,
)

WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


IF OBJECT_ID('EDP_Common.Dim_Benchmark') IS NOT NULL
    PRINT '<<< CREATED TABLE EDP_Common.Dim_Benchmark >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE EDP_Common.Dim_Benchmark >>>'
go

