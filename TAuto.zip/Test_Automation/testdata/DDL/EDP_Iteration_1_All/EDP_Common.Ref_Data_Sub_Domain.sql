/* 
 * TABLE: [EDP_Common].[Ref_Data_Sub_Domain] 
  * Performance Iteration 1: Story 14319, Task 14778
  [{'table_name': '[EDP_Common].[Ref_Data_Sub_Domain]', 'columns': [
  {'field_name': 'Data_Domain_Code', 'data_type': 'varchar(64)', 'nullable': False}, 
  {'field_name': 'Data_Domain_Name', 'data_type': 'varchar(255)', 'nullable': True}, 
  {'field_name': 'Data_Domain_Long_Name', 'data_type': 'varchar(255)', 'nullable': True}, 
  {'field_name': 'Data_Sub_Domain_Code', 'data_type': 'varchar(64)', 'nullable': True}, 
  {'field_name': 'Data_Sub_Domain_Name', 'data_type': 'varchar(255)', 'nullable': True}, 
  {'field_name': 'Data_Sub_Domain_Long_Name', 'data_type': 'varchar(255)', 'nullable': True}, 
  {'field_name': 'Source_System_Code', 'data_type': 'varchar(255)', 'nullable': False}, 
  {'field_name': 'Last_Update_User', 'data_type': 'varchar(255)', 'nullable': False}, 
  {'field_name': 'Last_Update_Datetime', 'data_type': 'datetime2(7)', 'nullable': False}]}] 
  
 */

 IF OBJECT_ID('[EDP_Common].[Ref_Data_Sub_Domain]') IS NOT NULL
BEGIN
    DROP TABLE [EDP_Common].[Ref_Data_Sub_Domain]
    PRINT '<<< DROPPED TABLE [EDP_Common].[Ref_Data_Sub_Domain] >>>'
END
go

CREATE TABLE [EDP_Common].[Ref_Data_Sub_Domain](
    [Data_Domain_Code]           varchar(64)     NOT NULL,
    [Data_Domain_Name]           varchar(255)    NULL,
    [Data_Domain_Long_Name]      varchar(255)    NULL,
    [Data_Sub_Domain_Code]       varchar(64)     NULL,
    [Data_Sub_Domain_Name]       varchar(255)    NULL,
    [Data_Sub_Domain_Long_Name]  varchar(255)    NULL,
    [Source_System_Code]         varchar(255)    NOT NULL,
    [Last_Update_User]           varchar(255)    NOT NULL,
    [Last_Update_Datetime]       datetime2(7)    NOT NULL
)

go


IF OBJECT_ID('EDP_Common.Ref_Data_Sub_Domain') IS NOT NULL
    PRINT '<<< CREATED TABLE EDP_Common.Ref_Data_Sub_Domain >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE EDP_Common.Ref_Data_Sub_Domain >>>'
go

