IF OBJECT_ID('[EDP_Common].[Fact_Daily_Bmk_Performance]') IS NOT NULL
BEGIN
    DROP TABLE [EDP_Common].[Fact_Daily_Bmk_Performance]
    PRINT '<<< DROPPED TABLE [EDP_Common].[Fact_Daily_Bmk_Performance] >>>'
END
go
/* 
 * TABLE: [EDP_Common].[Fact_Daily_Bmk_Performance] 
 
 [{'table_name': '[EDP_Common].[Fact_Daily_Bmk_Performance]', 'columns': [
 {'field_name': 'Fact_Daily_Bmk_Performance_ID', 'data_type': 'bigint', 'nullable': False}, 
 {'field_name': 'Dim_Effective_Date_Key', 'data_type': 'bigint', 'nullable': False}, 
 {'field_name': 'Dim_Benchmark_Key', 'data_type': 'bigint', 'nullable': False}, 
 {'field_name': 'Dim_Source_Status_Key', 'data_type': 'bigint', 'nullable': False}, 
 {'field_name': 'Last_Update_Datetime', 'data_type': 'datetime2(7)', 'nullable': False}, 
 {'field_name': 'Load_Datetime', 'data_type': 'datetime2(7)', 'nullable': False}, 
 {'field_name': 'Source_Update_Datetime', 'data_type': 'datetime2(7)', 'nullable': True}, 
 {'field_name': 'Source_System_Code', 'data_type': 'varchar(255)', 'nullable': False}, 
 {'field_name': 'Source_Deleted_Flag', 'data_type': 'bit', 'nullable': False}, 
 {'field_name': 'ETL_Load_Key', 'data_type': 'bigint', 'nullable': False}, 
 {'field_name': 'Load_Detail_Description', 'data_type': 'varchar(4000)', 'nullable': True}, 
 {'field_name': 'Last_Update_User', 'data_type': 'varchar(255)', 'nullable': False}
 ]}]

 */

CREATE TABLE [EDP_Common].[Fact_Daily_Bmk_Performance](
    [Fact_Daily_Bmk_Performance_ID]  bigint             NOT NULL,
	[Dim_Effective_Date_Key]         bigint             NOT NULL,
    [Dim_Benchmark_Key]              bigint             NOT NULL,
    [Dim_Source_Status_Key]          bigint             NOT NULL,
    [Last_Update_Datetime]           datetime2(7)       NOT NULL,
    [Load_Datetime]                  datetime2(7)       NOT NULL,
    [Return_Percentage]              decimal(28, 12)    NULL,
    [Local_Return_Percentage]        decimal(28, 12)    NULL,
    [Source_Update_Datetime]         datetime2(7)       NULL,
    [Source_System_Code]             varchar(255)       NOT NULL,
    [Source_Deleted_Flag]            bit                NOT NULL,
    [ETL_Load_Key]                   bigint             NOT NULL,
    [Load_Detail_Description]        varchar(4000)      NULL,
    [Last_Update_User]               varchar(255)       NOT NULL,


CONSTRAINT [PK_Fact_Daily_Bmk_Performance] PRIMARY KEY NONCLUSTERED 
	(
		[Dim_Benchmark_Key] ASC,
		[Dim_Effective_Date_Key] ASC,
		[Dim_Source_Status_Key] ASC,
		[Last_Update_Datetime] DESC,
		[Load_Datetime] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = HASH ( [Dim_Benchmark_Key] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

IF OBJECT_ID('EDP_Common.Fact_Daily_Bmk_Performance') IS NOT NULL
    PRINT '<<< CREATED TABLE EDP_Common.Fact_Daily_Bmk_Performance >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE EDP_Common.Fact_Daily_Bmk_Performance >>>'
go

