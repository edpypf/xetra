select  'EDP_Common.Fact_Daily_Portfolio_Performance', count(*) from EDP_Common.Fact_Daily_Portfolio_Performance where etl_load_key=-200
-- 1199
select 'EDP_Common.Fact_Daily_Security_Performance', count(*) from EDP_Common.Fact_Daily_Security_Performance where etl_load_key=-200 -- 963
select 'EDP_Common.Fact_Monthly_Portfolio_Performance', count(*) from EDP_Common.Fact_Monthly_Portfolio_Performance where etl_load_key=-200
select 'EDP_Common.Fact_Monthly_Security_Performance', count(*) from EDP_Common.Fact_Monthly_Security_Performance where etl_load_key=-200
select 'EDP_Common.Fact_Daily_Bmk_Performance', count(*) from EDP_Common.Fact_Daily_Bmk_Performance where etl_load_key=-200
select 'EDP_Common.Fact_Daily_Bmk_Security_Performance',count(*) from EDP_Common.Fact_Daily_Bmk_Security_Performance where etl_load_key=-200
select 'EDP_Common.Fact_Monthly_Bmk_Performance ', count(*) from EDP_Common.Fact_Monthly_Bmk_Performance where etl_load_key=-200
select 'EDP_Common.Fact_Monthly_Bmk_Security_Performance', count(*) from  EDP_Common.Fact_Monthly_Bmk_Security_Performance where etl_load_key=-200
select 'EDP_Common.Dim_Portfolio', count(*) from EDP_Common.Dim_Portfolio where etl_load_key=-200
--1070
select 'EDP_Common.Dim_Security', count(*) from EDP_Common.Dim_Security where etl_load_key=-200 -- 965
--965
select 'PSA.Eagle_Perf_Sec_Returns', count(*) from PSA.Eagle_Perf_Sec_Returns where etl_load_key=-200 --964
--3
select 'PSA.Eagle_Perf_Summary',count(*) from PSA.Eagle_Perf_Summary where etl_load_key=-200 -- 2
select 'PSA.Eagle_Entity', count(*) from PSA.Eagle_Entity where etl_load_key=-200 -- 3
--965
select 'PSA.Eagle_Security_Master ', count(*) from PSA.Eagle_Security_Master where etl_load_key=-200
---------------------------------------------------------------------------------------------------------
select * from DataWarehouse_Staging.Eagle_Entity

select * from  DataWarehouse_Staging.Eagle_PERF_SUMMARY
select * from DataWarehouse_Staging.Eagle_PERF_SEC_RETURNS
select * from DataWarehouse_Staging.Eagle_POSITION_DETAIL
select * from DataWarehouse_Staging.Eagle_POSITION_DETAIL_Rimes
select * from [DataWarehouse_Staging].[Eagle_POSITION_COST_DETAIL]

select count(*) from DataWarehouse_Staging.Eagle_PERF_SEC_RETURNS
select count(*) from DataWarehouse_Staging.Eagle_POSITION_DETAIL
select count(*) from DataWarehouse_Staging.Eagle_POSITION_DETAIL_Rimes
select count(*) from [DataWarehouse_Staging].[Eagle_POSITION_COST_DETAIL]
---------------------------------------------------------------------------------------------------------

select * from PSA.Eagle_Perf_Summary where etl_load_key=-200



select * 
from PSA.Eagle_PERF_SUMMARY
where etl_load_key=-200
order by perf_sum_inst desc



select perf_sum_inst, count(*) as rcount
from PSA.eagle_perf_sec_returns
where etl_load_key=-200
group by perf_sum_inst
order by perf_sum_inst desc

select is_src_deleted, count(*) as rcount
from PSA.eagle_perf_sec_returns
--where perf_sum_inst=-21707903
where etl_load_key=-200
group by is_src_deleted










