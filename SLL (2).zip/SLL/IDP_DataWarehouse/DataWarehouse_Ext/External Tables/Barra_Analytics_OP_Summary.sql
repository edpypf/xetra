﻿CREATE EXTERNAL TABLE [DataWarehouse_Ext].[Barra_Analytics_OP_Summary] (
    [BatchID] VARCHAR (500) NULL,
    [Batch_Date] VARCHAR (500) NULL,
    [begin_batch] VARCHAR (500) NULL,
    [Portfolio] VARCHAR (500) NULL,
    [Port_Type] VARCHAR (500) NULL,
    [Model] VARCHAR (500) NULL,
    [Reported] VARCHAR (500) NULL,
    [Client] VARCHAR (500) NULL,
    [Report] VARCHAR (500) NULL,
    [Analysis_Date] VARCHAR (500) NULL,
    [BarraID] VARCHAR (500) NULL,
    [Asset_ID] VARCHAR (500) NULL,
    [Covariance_Date] VARCHAR (500) NULL,
    [Delta] VARCHAR (500) NULL,
    [Delta_Adjusted_Exposure] VARCHAR (500) NULL,
    [Gamma] VARCHAR (500) NULL,
    [Holdings] VARCHAR (500) NULL,
    [Holdings_Date] VARCHAR (500) NULL,
    [Implied_Vol] VARCHAR (500) NULL,
    [Implied_Vol_Type] VARCHAR (500) NULL,
    [Lambda] VARCHAR (500) NULL,
    [Native_Portfolio] VARCHAR (500) NULL,
    [Rho] VARCHAR (500) NULL,
    [Theta] VARCHAR (500) NULL,
    [Vega] VARCHAR (500) NULL,
    [Vol_Vega] VARCHAR (500) NULL,
    [Look_Through_Source_Id] VARCHAR (500) NULL,
    [Inst_Type] VARCHAR (500) NULL
)
    WITH (
    DATA_SOURCE = [DataWarehouse_ADLS_FILE_LOCATION],
    LOCATION = N'Risk/Barra_Analytics_OP_summary.txt',
    FILE_FORMAT = [DATAWAREHOUSE_FLAT_FILE_FORMAT],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );





