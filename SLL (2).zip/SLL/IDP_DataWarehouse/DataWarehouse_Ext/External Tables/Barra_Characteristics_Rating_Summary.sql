﻿CREATE EXTERNAL TABLE [DataWarehouse_Ext].[Barra_Characteristics_Rating_Summary] (
    [BatchID] VARCHAR (500) NULL,
    [Batch_Date] VARCHAR (500) NULL,
    [begin_batch] VARCHAR (500) NULL,
    [Portfolio] VARCHAR (500) NULL,
    [Port_Type] VARCHAR (500) NULL,
    [Model] VARCHAR (500) NULL,
    [Reported] VARCHAR (500) NULL,
    [Client] VARCHAR (500) NULL,
    [Report] VARCHAR (500) NULL,
    [Analysis_Date] VARCHAR (500) NULL,
    [Asset_ID] VARCHAR (500) NULL,
    [BarraID] VARCHAR (500) NULL,
    [Barclays_Rating] VARCHAR (500) NULL,
    [Bond_Quality_Mapping] VARCHAR (500) NULL,
    [Covariance_Date] VARCHAR (500) NULL,
    [Holdings] VARCHAR (500) NULL,
    [Holdings_Date] VARCHAR (500) NULL,
    [Merrill_Rating] VARCHAR (500) NULL,
    [Model_Rating] VARCHAR (500) NULL,
    [Moody_Rating] VARCHAR (500) NULL,
    [Moodys_Credit_Watch_Date] VARCHAR (500) NULL,
    [Moodys_Credit_Watch_Des] VARCHAR (500) NULL,
    [Moodys_Long_Term_issuer_Rating_D] VARCHAR (500) NULL,
    [Moodys_Long_Term_issuer_Rating_F] VARCHAR (500) NULL,
    [Native_Portfolio] VARCHAR (500) NULL,
    [SP_Credit_Watch_Date] VARCHAR (500) NULL,
    [SP_Credit_Watch_Description] VARCHAR (500) NULL,
    [SP_Long_Term_issuer_Rating_D] VARCHAR (500) NULL,
    [SP_Long_Term_issuer_Rating_F] VARCHAR (500) NULL,
    [SP_Rating] VARCHAR (500) NULL,
    [TMX_Rating] VARCHAR (500) NULL,
    [Model_Rating_Override] VARCHAR (500) NULL,
    [Look_Through_Source_Id] VARCHAR (500) NULL,
    [Inst_Type] VARCHAR (500) NULL
)
    WITH (
    DATA_SOURCE = [DataWarehouse_ADLS_FILE_LOCATION],
    LOCATION = N'Risk/Barra_Characteristics_Rating_summary.txt',
    FILE_FORMAT = [DATAWAREHOUSE_FLAT_FILE_FORMAT],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );





