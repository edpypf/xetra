﻿CREATE EXTERNAL TABLE [DataWarehouse_Ext].[Barra_Analytics_EQ_Summary] (
    [BatchID] VARCHAR (500) NULL,
    [Batch_Date] VARCHAR (500) NULL,
    [begin_batch] VARCHAR (500) NULL,
    [Portfolio] VARCHAR (500) NULL,
    [Port_Type] VARCHAR (500) NULL,
    [Model] VARCHAR (500) NULL,
    [Reported] VARCHAR (500) NULL,
    [Client] VARCHAR (500) NULL,
    [Report] VARCHAR (500) NULL,
    [Analysis_Date] VARCHAR (500) NULL,
    [Asset_ID] VARCHAR (500) NULL,
    [BarraID] VARCHAR (500) NULL,
    [Average_60D_Volume] VARCHAR (500) NULL,
    [Average_90D_Volume] VARCHAR (500) NULL,
    [Average_Daily_Traded_Value] VARCHAR (500) NULL,
    [Average_Daily_Volume] VARCHAR (500) NULL,
    [Avg_Bid_Ask_Spread_30D] VARCHAR (500) NULL,
    [Avg_Bid_Ask_Spread_60D] VARCHAR (500) NULL,
    [Avg_Bid_Ask_Spread_90D] VARCHAR (500) NULL,
    [Bid_Ask_Spread] VARCHAR (500) NULL,
    [Bond_Bid_Ask_Model_Name] VARCHAR (500) NULL,
    [Covariance_Date] VARCHAR (500) NULL,
    [Daily_Volume] VARCHAR (500) NULL,
    [Days_to_Trade_Cash] VARCHAR (500) NULL,
    [Dividend_Yield] VARCHAR (500) NULL,
    [FaCS_Growth] VARCHAR (500) NULL,
    [FaCS_Liquidity] VARCHAR (500) NULL,
    [FaCS_Momentum] VARCHAR (500) NULL,
    [FaCS_Quality] VARCHAR (500) NULL,
    [FaCS_Size] VARCHAR (500) NULL,
    [FaCS_Value] VARCHAR (500) NULL,
    [FaCS_Volatility] VARCHAR (500) NULL,
    [FaCS_Yield] VARCHAR (500) NULL,
    [Holdings] VARCHAR (500) NULL,
    [Holdings_Date] VARCHAR (500) NULL,
    [Last_Bid_Ask_Spread_Date] VARCHAR (500) NULL,
    [Mkt_Cap] VARCHAR (500) NULL,
    [Native_Portfolio] VARCHAR (500) NULL,
    [Shares_OS] VARCHAR (500) NULL,
    [Look_Through_Source_Id] VARCHAR (500) NULL,
    [Inst_Type] VARCHAR (500) NULL
)
    WITH (
    DATA_SOURCE = [DataWarehouse_ADLS_FILE_LOCATION],
    LOCATION = N'Risk/Barra_Analytics_EQ_summary.txt',
    FILE_FORMAT = [DATAWAREHOUSE_FLAT_FILE_FORMAT],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );





