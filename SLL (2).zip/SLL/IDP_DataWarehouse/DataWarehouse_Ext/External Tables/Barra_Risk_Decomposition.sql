﻿CREATE EXTERNAL TABLE [DataWarehouse_Ext].[Barra_Risk_Decomposition] (
    [BatchID] VARCHAR (500) NULL,
    [Batch_Date] VARCHAR (500) NULL,
    [begin_batch] VARCHAR (500) NULL,
    [Portfolio] VARCHAR (500) NULL,
    [Port_Type] VARCHAR (500) NULL,
    [Benchmark] VARCHAR (500) NULL,
    [Model] VARCHAR (500) NULL,
    [Reported] VARCHAR (500) NULL,
    [Client] VARCHAR (500) NULL,
    [Report] VARCHAR (500) NULL,
    [Analysis_Date] VARCHAR (500) NULL,
    [Covariance_Date] VARCHAR (500) NULL,
    [Risk_Source] VARCHAR (500) NULL,
    [Factor_Group] VARCHAR (500) NULL,
    [Active_Risk_Pct] VARCHAR (500) NULL,
    [BM_Risk_Pct] VARCHAR (500) NULL,
    [Port_Risk_Pct] VARCHAR (500) NULL,
    [Active_Exposure] VARCHAR (500) NULL,
    [Active_Port_Correlation] VARCHAR (500) NULL,
    [Active_Port_Risk_Contr] VARCHAR (500) NULL,
    [Active_Port_Risk_Contr_Pct] VARCHAR (500) NULL,
    [Active_Risk] VARCHAR (500) NULL,
    [Active_VaR] VARCHAR (500) NULL,
    [Active_Variance] VARCHAR (500) NULL,
    [BM_Correlation] VARCHAR (500) NULL,
    [BM_Exposure] VARCHAR (500) NULL,
    [BM_Risk_Contr_Pct] VARCHAR (500) NULL,
    [BM_Risk] VARCHAR (500) NULL,
    [BM_Risk_Contr] VARCHAR (500) NULL,
    [BM_Variance] VARCHAR (500) NULL,
    [Factor_Correlation_with_Active_Risk] VARCHAR (500) NULL,
    [Factor_Correlation_with_Port_Risk] VARCHAR (500) NULL,
    [Factor_Risk] VARCHAR (500) NULL,
    [Port_Correlation] VARCHAR (500) NULL,
    [Port_Exposure] VARCHAR (500) NULL,
    [Port_Risk] VARCHAR (500) NULL,
    [Port_Risk_Contr] VARCHAR (500) NULL,
    [Port_Risk_Contr_Pct] VARCHAR (500) NULL,
    [Port_VaR] VARCHAR (500) NULL,
    [Port_Variance] VARCHAR (500) NULL
)
    WITH (
    DATA_SOURCE = [DataWarehouse_ADLS_FILE_LOCATION],
    LOCATION = N'Risk/Barra_Risk_Decomposition.txt',
    FILE_FORMAT = [DATAWAREHOUSE_FLAT_FILE_FORMAT],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );





