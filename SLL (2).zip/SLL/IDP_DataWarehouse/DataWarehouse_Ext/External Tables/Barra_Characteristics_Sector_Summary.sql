﻿CREATE EXTERNAL TABLE [DataWarehouse_Ext].[Barra_Characteristics_Sector_Summary] (
    [BatchID] VARCHAR (500) NULL,
    [Batch_Date] VARCHAR (500) NULL,
    [begin_batch] VARCHAR (500) NULL,
    [Portfolio] VARCHAR (500) NULL,
    [Port_Type] VARCHAR (500) NULL,
    [Model] VARCHAR (500) NULL,
    [Reported] VARCHAR (500) NULL,
    [Client] VARCHAR (500) NULL,
    [Report] VARCHAR (500) NULL,
    [Analysis_Date] VARCHAR (500) NULL,
    [Asset_ID] VARCHAR (500) NULL,
    [BarraID] VARCHAR (500) NULL,
    [Barclays_Sector] VARCHAR (500) NULL,
    [Covariance_Date] VARCHAR (500) NULL,
    [GICS_Industry] VARCHAR (500) NULL,
    [GICS_Industry_Group] VARCHAR (500) NULL,
    [GICS_Sector] VARCHAR (500) NULL,
    [GICS_Source] VARCHAR (500) NULL,
    [GICS_SubIndustry] VARCHAR (500) NULL,
    [Holdings] VARCHAR (500) NULL,
    [Holdings_Date] VARCHAR (500) NULL,
    [IMCO_EQ_Sector] VARCHAR (500) NULL,
    [IMCO_FI_Sector] VARCHAR (500) NULL,
    [IMCO_Sector] VARCHAR (500) NULL,
    [Infra_Sector] VARCHAR (500) NULL,
    [Merrill_Sector_Class_1] VARCHAR (500) NULL,
    [Merrill_Sector_Class_2] VARCHAR (500) NULL,
    [Merrill_Sector_Class_3] VARCHAR (500) NULL,
    [Merrill_Sector_Class_4] VARCHAR (500) NULL,
    [Native_Portfolio] VARCHAR (500) NULL,
    [PD_Sector] VARCHAR (500) NULL,
    [PE_Sector] VARCHAR (500) NULL,
    [RE_Sector] VARCHAR (500) NULL,
    [Sector] VARCHAR (500) NULL,
    [Subsector] VARCHAR (500) NULL,
    [TMX_Industry_Group] VARCHAR (500) NULL,
    [TMX_Industry_Sector] VARCHAR (500) NULL,
    [TMX_Industry_SubGroup] VARCHAR (500) NULL,
    [Private_Mkt_Sector] VARCHAR (500) NULL,
    [IMCO_Sector_Key] VARCHAR (500) NULL,
    [Look_Through_Source_Id] VARCHAR (500) NULL,
    [Inst_Type] VARCHAR (500) NULL
)
    WITH (
    DATA_SOURCE = [DataWarehouse_ADLS_FILE_LOCATION],
    LOCATION = N'Risk/Barra_Characteristics_Sector_summary.txt',
    FILE_FORMAT = [DATAWAREHOUSE_FLAT_FILE_FORMAT],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );





