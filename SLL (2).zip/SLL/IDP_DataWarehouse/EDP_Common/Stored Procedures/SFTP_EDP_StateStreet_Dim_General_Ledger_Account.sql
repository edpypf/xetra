﻿CREATE PROC [EDP_Common].[SFTP_EDP_StateStreet_Dim_General_Ledger_Account] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

Declare @today datetime2 = getdate(),
        @loadStartTime datetime2,
		@loadEndTime datetime2,
		@SourceSystem varchar(255),
		@LastUpdateUser varchar(255)

Declare @rowsInserted int = 0,
		@rowsUpdated int = 0,
		@rowsExpired int = 0

	Begin Try

		IF OBJECT_ID('tempdb..#temp_ss_gl_account') IS NOT NULL
		BEGIN
			DROP TABLE #temp_ss_gl_account
		END

	
		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'MySS-SS-MCH', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		-- load latest Eagle entity records from source into temp table
		create table #temp_ss_gl_account
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select	[GL_Account_Number] General_Ledger_Account_ID
				,[GL_Account_Name] General_Ledger_Account_Name
				,[GL_Account_Name] General_Ledger_Account_Description
				,[EDP_Code_Value] General_Ledger_Category_Code
				,[GL_Account_Number] State_Street_General_Ledger_Account_ID 
				,CONVERT(VARCHAR(64), Hashbytes('SHA1', Upper(concat([GL_Account_Name], '|', [EDP_Code_Value] ))), 2 ) Hash_Diff
		From (
			SELECT   [GL_Account_Number]  
					,[GL_Account_Name], source_deleted_flag
					,row_number() over(partition by GL_Account_Number order by last_update_dt desc) as rn
			  FROM [EDW_Raw].[V_SS_MySS_MCH_WTB_General_Ledger]	
			  Where Coalesce([GL_Account_Number], '')<> '' 
		) SS
		Join [EDP_Common].[XRef_Source_Code_EDP_Code_Mapping] X
		On [Domain_Code_Type] = 'FundAcct_General-Ledger-Category'
		And [Origination_Source_System_Code] = 'MySS-SS-MCH'
		And SS.GL_Account_Number like ''+ X.Origination_Source_Code_Value +''
		where rn=1 and source_deleted_flag=0

		--UPDATE/EXPIRE EXISTING RECORDS
		Update tgt
		Set 	Effective_End_Datetime = @today,
				Is_Current_Flag= 0, 
				Last_Update_Datetime=@today, 
				ETL_Load_Key = @ETL_Load_Key,
				Last_Update_User = @LastUpdateUser,
				Source_System_Code = @SourceSystem

		From EDP_Common.Dim_General_Ledger_Account tgt
		Where tgt.Dim_General_Ledger_Account_Key > -1 and tgt.Is_Current_Flag = 1 and Source_System_Code = @SourceSystem and 
		(
			exists
			(	Select	1
				From	#temp_ss_gl_account src
				Where	tgt.General_Ledger_Account_ID = src.General_Ledger_Account_ID 
						and coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')
			)

			or
			not exists (
				Select	1
				From	#temp_ss_gl_account src
				Where	tgt.General_Ledger_Account_ID = src.General_Ledger_Account_ID
			)
		)

		
		--INSERT NEW RECORDS INTO DIM TABLE
		insert into EDP_Common.Dim_General_Ledger_Account
		(
			  [General_Ledger_Account_ID]
			  ,[General_Ledger_Account_Name]
			  ,[General_Ledger_Account_Description]
			  ,[Eagle_STAR_Standard_Account_Name]
			  ,[General_Ledger_Category_Code]
			  ,[State_Street_General_Ledger_Account_ID]
			  ,[Eagle_STAR_General_Ledger_Account_ID]
			  ,[Eagle_STAR_General_Ledger_Standard_Account_ID]
			  ,Is_Current_Flag
			  ,Effective_Start_Datetime
			  ,Effective_End_Datetime
			  ,Last_Update_Datetime
			  ,ETL_Load_Key
			  ,Hash_Diff
			  ,Last_Update_User
			  ,Source_System_Code 
		)
			select src.[General_Ledger_Account_ID]
				  ,src.[General_Ledger_Account_Name]
				  ,src.[General_Ledger_Account_Description]
				  ,NULL
				  ,src.[General_Ledger_Category_Code]
				  ,src.[State_Street_General_Ledger_Account_ID]
				  ,NULL
				  ,NULL
				  ,1
				  ,case when tgt_all.General_Ledger_Account_ID is null then '1900-01-01' else @today End 
				  ,'9999-12-31'
				  ,@today
				  ,@ETL_Load_Key
				  ,src.Hash_Diff
				  ,@LastUpdateUser
				  ,@SourceSystem

			from	#temp_ss_gl_account src
					Left Join EDP_Common.Dim_General_Ledger_Account tgt on src.General_Ledger_Account_ID = tgt.General_Ledger_Account_ID and tgt.Is_Current_Flag = 1
					Left Join (Select Distinct General_Ledger_Account_ID From EDP_Common.Dim_General_Ledger_Account Where Source_System_Code = @SourceSystem) tgt_all on src.General_Ledger_Account_ID = tgt_all.General_Ledger_Account_ID
			where	(
						tgt.General_Ledger_Account_ID is null 
						or (tgt.General_Ledger_Account_ID is not null and src.Hash_Diff <> tgt.Hash_Diff)
					)

		-- Set load end time
		Select @loadEndTime = Getdate()

		--ETL Logging
		Select @rowsInserted = Count(*) 
		From EDP_Common.Dim_General_Ledger_Account
		Where ETL_Load_Key = @ETL_Load_Key and Dim_General_Ledger_Account_Key > 0 and 
		([Effective_Start_Datetime] = @today or [Effective_Start_Datetime]='1900-01-01')
		and Is_Current_Flag = 1

		Select @rowsUpdated = Count(*)
		From EDP_Common.Dim_General_Ledger_Account
		Where ETL_Load_Key = @ETL_Load_Key and [Effective_End_Datetime] = @today

		Select @rowsExpired = Count(*)
		From EDP_Common.Dim_General_Ledger_Account p
		Left Join (Select General_Ledger_Account_ID From EDP_Common.Dim_General_Ledger_Account Where Is_Current_Flag = 1) pc on p.General_Ledger_Account_ID = pc.General_Ledger_Account_ID 
		Where ETL_Load_Key = @ETL_Load_Key and [Effective_End_Datetime] = @today and pc.General_Ledger_Account_ID is null

		-- populate EDW ETL log table
		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Dim_General_Ledger_Account', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Load_DTS, @ETL_Load_Key, 'Dim_General_Ledger_Account', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null


		-- Force cleanup temp tables
		IF OBJECT_ID('tempdb..#temp_ss_gl_account') IS NOT NULL
		BEGIN
			DROP TABLE #temp_ss_gl_account
		END

    END TRY

	--Error Handling
	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Dim_General_Ledger_Account', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Load_DTS, @ETL_Load_Key, 'Dim_General_Ledger_Account', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END