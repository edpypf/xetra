﻿CREATE PROC [EDP_Common].[SFTP_EDP_StateStreet_Fact_SS_MCH_Transaction] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
/*****  exec [EDP_Common].[SFTP_EDP_StateStreet_Fact_SS_MCH_Transaction] 'DELTA','1900-01-01',-1  **/
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)
	
	Begin Try


		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max(Last_Update_Datetime), '1900-01-01'), 
		       @currentMaxId = coalesce(max(Fact_SS_MCH_Transaction_ID), 0)
		From EDP_Common.Fact_SS_MCH_Transaction

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'MySS-SS-MCH', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today


		INSERT INTO EDP_Common.Fact_SS_MCH_Transaction
           ( Fact_SS_MCH_Transaction_ID
			,Dim_Effective_Date_Key
			,Dim_Trade_Date_Key
			,Dim_Portfolio_Key
			,Dim_Broker_Counterparty_Key
			,Dim_Security_Key
			,Dim_Currency_Base_Key
			,Dim_Currency_Local_Key
			,Dim_Income_Currency_Key
			,Dim_Settlement_Currency_Key
			,Dim_Trade_Currency_Key
			,Dim_Long_Short_Direction_Key
			,Dim_Transaction_Type_Key
			,Dim_Transaction_Event_Type_Key
			,Dim_Reference_Transaction_Key
			,Dim_Source_Status_Key
			,Transaction_ID
			,Transaction_Audit_ID
			,Transaction_Lot_Level_ID
			,Last_Update_Datetime
			,Load_Datetime
			,Broker_Counterparty_Code
			,Accounting_Effective_Date
			,Month_End_Accounting_Effective_Date
			,Actual_Settlement_Date
			,Contractual_Settlement_Date
			,Original_Acquisition_Date
			,Post_Date
			,Original_Face_Value_Amount
			,Transaction_Base_Amount
			,Transaction_Local_Amount
			,Contract_Size_Number
			,Price_Base_Amount
			,Price_Local_Amount
			,Share_Or_Par_Amount
			,Trade_Date_Price_Local_Amount
			,Trade_Expense_Local_Amount
			,Coupon_Rate_Percentage
			,Premium_Allocated_Base_Amount
			,Price_Multiplier_Decimal
			,Settlement_Local_Amount
			,Cost_Base_Amount
			,Cost_Local_Amount
			,Original_Cost_Base_Amount
			,Original_Cost_Local_Amount
			,Inflationary_Adjustment_Cost_Base_Amount
			,Inflationary_Adjustment_Cost_Local_Amount
			,Currency_Gain_Loss_Base_Amount
			,Currency_Gain_Loss_on_Income_Base_Amount
			,Currency_Gain_Loss_on_Income_Local_Amount
			,Currency_Gain_Loss_on_Interest_Base_Amount
			,Currency_Gain_Loss_on_Interest_Local_Amount
			,Commission_Base_Amount
			,Commission_Local_Amount
			,Commission_Rate_Base_Percentage
			,Commission_Rate_Local_Percentage
			,Fees_Base_Amount
			,Fees_Local_Amount
			,Trade_Fees_Base_Amount
			,Trade_Fees_Local_Amount
			,Security_Gain_Loss_Base_Amount
			,Security_Gain_Loss_Local_Amount
			,Interest_Rate_Percentage
			,Interest_Purchased_Sold_Base_Amount
			,Interest_Purchased_Sold_Local_Amount
			,Proceeds_Base_Amount
			,Proceeds_Local_Amount
			,Income_Base_Amount
			,Income_Local_Amount
			,Income_Rate_Percentage
			,Principal_Base_Amount
			,Principal_Local_Amount
			,Tax_Base_Amount
			,Tax_Local_Amount
			,Miscellaneous_Tax_Base_Amount
			,Miscellaneous_Tax_Local_Amount
			,Amortized_Base_Amount
			,Amortized_Local_Amount
			,Total_Realized_Gain_Loss_Base_Amount
			,Total_Realized_Gain_Loss_Local_Amount
			,Total_Realized_Gain_Base_Amount
			,Total_Realized_Gain_Local_Amount
			,Total_Realized_Loss_Base_Amount
			,Total_Realized_Loss_Local_Amount
			,Dirty_Principal_Base_Amount
			,Dirty_Principal_Local_Amount
			,Trade_Yield_Percentage
			,Amortization_Yield_Percentage
			,Long_Term_Security_Gain_Loss_Base_Amount
			,Long_Term_Security_Gain_Loss_Local_Amount
			,Short_Term_Security_Gain_Loss_Base_Amount
			,Short_Term_Security_Gain_Loss_Local_Amount
			,Trade_Date_FX_Base_To_Local_Rate
			,Trade_Date_FX_Local_To_Base_Rate
			,Source_Update_Datetime
			,Source_System_Code
			,Source_Deleted_Flag
			,ETL_Load_Key
			,Load_Detail_Description
			,Last_Update_User
		)
		SELECT      @currentMaxId + rn
					,convert(int, convert(varchar(15), Trade_date, 112))    as Dim_Effective_Date_Key
					,convert(int, convert(varchar(15), Trade_date, 112))	as Dim_Trade_Date_Key
					,Coalesce(Dim_Portfolio_Key, -1)						as Dim_Portfolio_Key
					,-1														as Dim_Broker_Counterparty_Key
					,Coalesce(s_ticker.Dim_Security_Key, -1)				as Dim_Security_Key
					,Coalesce(bc.Dim_Currency_Key, -1)						as Dim_Currency_Base_Key
					,Coalesce(lc.Dim_Currency_Key, -1)						as Dim_Currency_Local_Key
					,Coalesce(ic.Dim_Currency_Key, -1)						as Dim_Income_Currency_Key
					,Coalesce(sc.Dim_Currency_Key, -1)						as Dim_Settlement_Currency_Key
					,Coalesce(tc.Dim_Currency_Key, -1)						as Dim_Trade_Currency_Key
					,Coalesce(Dim_Long_Short_Direction_Key, -1)				as Dim_Long_Short_Direction_Key
					,Coalesce(Dim_Transaction_Type_Key, -1)					as Dim_Transaction_Type_Key
					,Coalesce(Dim_Transaction_Event_Type_Key, -1)			as Dim_Transaction_Event_Type_Key
					,Coalesce(Dim_Reference_Transaction_Key, -1)			as Dim_Reference_Transaction_Key
					,Coalesce(Dim_Source_Status_Key, -1)					as Dim_Source_Status_Key
					,Trade_ID												as Transaction_ID
					,'NA'													as Transaction_Audit_ID
					,Lot_Number												as Transaction_Lot_Level_ID
					,src.Last_Update_DT										as Last_Update_Datetime
					,src.Record_Created_DT									as Load_Datetime
					,Broker_Code											as Broker_Counterparty_Code
					,Accounting_Period_End_Date								as Accounting_Effective_Date
					,NULL													as Month_End_Accounting_Effective_Date
					,Actual_Settlement_Date									as Actual_Settlement_Date
					,Contractual_Settlement_Date							as Contractual_Settlement_Date
					,NULL													as Original_Acquisition_Date
					,Post_Date												as Post_Date
					,Original_Face											as Original_Face_Value_Amount
					,Base_Net_Amount										as Transaction_Base_Amount
					,Local_Net_Amount										as Transaction_Local_Amount
					,Shares_Par_Value										as Contract_Size_Number
					,Base_Unit_Price										as Price_Base_Amount
					,Local_Unit_Price										as Price_Local_Amount
					,Shares_Par												as Share_Or_Par_Amount
					,NULL													as Trade_Date_Price_Local_Amount
					,NULL													as Trade_Expense_Local_Amount
					,NULL													as Coupon_Rate_Percentage
					,NULL													as Premium_Allocated_Base_Amount
					,Current_Multiplier										as Price_Multiplier_Decimal
					,Local_Net_Settlement									as Settlement_Local_Amount
					,Base_Current_Average_Cost								as Cost_Base_Amount
					,Local_Current_Average_Cost								as Cost_Local_Amount
					,Base_Original_Average_Cost								as Original_Cost_Base_Amount
					,Local_Original_Average_Cost							as Original_Cost_Local_Amount
					,NULL													as Inflationary_Adjustment_Cost_Base_Amount
					,NULL													as Inflationary_Adjustment_Cost_Local_Amount
					,Base_Currency_Gain_Loss_Amount							as Currency_Gain_Loss_Base_Amount
					,Base_Currency_Gain_Loss_on_Income						as Currency_Gain_Loss_on_Income_Base_Amount
					,NULL													as Currency_Gain_Loss_on_Income_Local_Amount
					,Base_Currency_Gain_Loss_on_Interest					as Currency_Gain_Loss_on_Interest_Base_Amount
					,NULL													as Currency_Gain_Loss_on_Interest_Local_Amount
					,Base_Commission										as Commission_Base_Amount
					,Local_Commission_Amount								as Commission_Local_Amount
					,NULL													as Commission_Rate_Base_Percentage
					,NULL													as Commission_Rate_Local_Percentage
					,Base_Fees												as Fees_Base_Amount
					,Local_Fees												as Fees_Local_Amount
					,Base_Trade_Fees										as Trade_Fees_Base_Amount
					,Local_Trade_Fees										as Trade_Fees_Local_Amount
					,Base_Security_Gain_Loss_Amount							as Security_Gain_Loss_Base_Amount
					,Local_Security_Gain_Loss_Amount						as Security_Gain_Loss_Local_Amount
					,Interest_Rate											as Interest_Rate_Percentage
					,Base_Interest_Amount									as Interest_Purchased_Sold_Base_Amount
					,Local_Interest_Amount									as Interest_Purchased_Sold_Local_Amount
					,Base_Net_Proceed_Amount								as Proceeds_Base_Amount
					,Local_Net_Proceed_Amount								as Proceeds_Local_Amount
					,Base_Income_Amount										as Income_Base_Amount
					,Local_Income_Amount									as Income_Local_Amount
					,Income_Rate											as Income_Rate_Percentage
					,NULL													as Principal_Base_Amount
					,Null													as Principal_Local_Amount
					,Base_Taxes												as Tax_Base_Amount
					,Local_Taxes											as Tax_Local_Amount
					,Base_Taxes_Misc										as Miscellaneous_Tax_Base_Amount
					,Local_Taxes_Misc_Charges								as Miscellaneous_Tax_Local_Amount
					,Base_Amortization_Sold									as Amortized_Base_Amount
					,Local_Amortization_Sold							    as Amortized_Local_Amount
					,null													as Total_Realized_Gain_Loss_Base_Amount
					,null													as Total_Realized_Gain_Loss_Local_Amount
					,null													as Total_Realized_Gain_Base_Amount
					,null													as Total_Realized_Gain_Local_Amount
					,null													as Total_Realized_Loss_Base_Amount
					,null													as Total_Realized_Loss_Local_Amount
					,null													as Dirty_Principal_Base_Amount
					,null													as Dirty_Principal_Local_Amount
					,NULL													as Trade_Yield_Percentage
					,NULL													as Amortization_Yield_Percentage
					,Base_Long_Term_Gain_Loss_Amount						as Long_Term_Security_Gain_Loss_Base_Amount
					,Local_Long_Term_Gain_Loss_Amount						as Long_Term_Security_Gain_Loss_Local_Amount
					,Base_Short_Term_Gain_Loss_Amount						as Short_Term_Security_Gain_Loss_Base_Amount
					,Local_Short_Term_Gain_Loss								as Short_Term_Security_Gain_Loss_Local_Amount
					,Sell_Exchange_Rate										as Trade_Date_FX_Base_To_Local_Rate
					,Case When coalesce(Sell_Exchange_Rate, 0)= 0 then NULL 
						Else 1/Sell_Exchange_Rate End				        as Trade_Date_FX_Local_To_Base_Rate

					,NULL													as Source_Update_Datetime

					,@SourceSystem 											as Source_System_Code
					,src.Source_Deleted_Flag								as Source_Deleted_Flag
					,@ETL_Load_Key											as ETL_Load_Key
 					,case when p.Dim_Portfolio_key is null  
				        or s_ticker.Dim_Security_Key is null  
						or bc.Dim_Currency_Key is null or lc.Dim_Currency_key is null or sc.Dim_Currency_key is null or tc.Dim_Currency_key is null then
						'{' + 
						'"Trade_Id": "' + convert(varchar(50), src.Trade_ID) + '",' + 
						'"Fund": "' + Coalesce(convert(varchar(50), src.Fund),'') + '",' + 
						'"Lot_Number": "' + Coalesce(convert(varchar(50), src.Lot_Number),'') + '",' + 
						'"Cancel_Indicator": "' + Coalesce(convert(varchar(50), src.Cancel_Indicator),'') + '",' + 
						'"CUSIP_Number":"' + Coalesce(convert(varchar(50), src.CUSIP_Number),'') + '",' + 
						'"ISIN_Number":"' + Coalesce(convert(varchar(50), src.ISIN_Number),'') + '",' + 
						'"Bloomberg_Ticker":"' + Coalesce(convert(varchar(50), src.Bloomberg_Ticker),'') + '",' + 
						'"Base_Currency":"' + Coalesce(src.Base_Currency_Code,'') + '",' + 
						'"Local_Currency":"' + Coalesce(src.Local_Currency_Code,'') + '",' + 
						'"Income_Currency":"' + Coalesce(src.Income_Currency_Code,'') + '",' + 
						'"Settlement_Currency_Code":"' + Coalesce(src.Settlement_Currency_Code,'') + '",' + 
						'"Trade_Currency_Code":"' + Coalesce(src.Trade_Currency_Code,'') + '"' + 
						'}'
					else 
						null
					End														as Load_Detail_Description
					,@LastUpdateUser										as Last_Update_User		

		From (
				SELECT Trade_Date 
					,Fund 
					,CUSIP_Number
					,Base_Currency_Code
					,Local_Currency_Code
					,Income_Currency_Code
					,Settlement_Currency_Code
					,Trade_Currency_Code
					,Long_Short_Indicator
					,Transaction_Type
					,Transaction_Category_Name
					,Cancel_Indicator
					,Receive_Pay_Flag 
					,'PRELIM_UNAUD' Source_Status_Code	
					,Case When Cancel_Indicator = 'C' Then 'CANCEL'
							Else 'ACTIVE' End Transaction_Status
					,Case When Cancel_Indicator = 'C' Then 'Y'
							Else 'N' End Cancel_Record_Indicator
					,Case When Receive_Pay_Flag in ('P', 'R') Then Receive_Pay_Flag
							Else 'NA' End Pay_Receive_Indicator
					,'NA' Accrual_Method
					,'NA' Quantity_Type 
					,ISIN_Number 
					,Bloomberg_Ticker
					,Trade_ID 
					,Lot_Number 
					,Broker_Code
					,Accounting_Period_End_Date 
					,Actual_Settlement_Date
					,Contractual_Settlement_Date 
					,Post_Date
					,Original_Face
					,Base_Net_Amount
					,Local_Net_Amount
					,Case When Asset_Class = 'FUTURE' then Shares_Par_Value 
							Else NULL End as Shares_Par_Value					
					,Base_Unit_Price
					,Local_Unit_Price
					,Case When Asset_Class = 'FUTURE' then Notional_Par 
							Else Shares_Par_Value End as Shares_Par
					,Notional_Par 
					,Current_Multiplier
					,Local_Net_Settlement
					,Base_Current_Average_Cost
					,Local_Current_Average_Cost
					,Base_Original_Average_Cost
					,Local_Original_Average_Cost 
					,Base_Currency_Gain_Loss_Amount
					,Base_Currency_Gain_Loss_on_Income 
					,Base_Currency_Gain_Loss_on_Interest 
					,Base_Commission
					,Local_Commission_Amount 
					,Base_Fees
					,Local_Fees
					,Base_Trade_Fees
					,Local_Trade_Fees
					,Base_Security_Gain_Loss_Amount
					,Local_Security_Gain_Loss_Amount
					,Interest_Rate
					,Base_Interest_Amount
					,Local_Interest_Amount
					,Base_Net_Proceed_Amount
					,Local_Net_Proceed_Amount
					,Base_Income_Amount
					,Local_Income_Amount
					,Income_Rate 
					,Base_Taxes
					,Local_Taxes
					,Base_Taxes_Misc
					,Local_Taxes_Misc_Charges
					,Base_Amortization_Sold
					,Local_Amortization_Sold 
					,Base_Long_Term_Gain_Loss_Amount
					,Local_Long_Term_Gain_Loss_Amount
					,Base_Short_Term_Gain_Loss_Amount
					,Local_Short_Term_Gain_Loss
					,Sell_Exchange_Rate 

					,Source_Deleted_Flag  
					,Last_Update_DT
					,Record_Created_DT
					,row_number() Over(Order By (Select 1)) rn
				    FROM  EDW_Raw.SS_MySS_MCH_Purchase_Sales P
                    WHERE Last_Update_DT > Coalesce(@lastLoadeDTS, '1900-01-01')
					AND Trade_Date <= @today

			) src
			Left Join (
				Select State_Street_Portfolio_ID, min(Portfolio_Id) Portfolio_Id
				From EDP_Common.Dim_Portfolio 
				where Is_Current_Flag = 1
				Group By State_Street_Portfolio_ID
			) pc on src.Fund = pc.State_Street_Portfolio_ID
			Left Join EDP_Common.Dim_Portfolio p on pc.Portfolio_Id = p.Portfolio_Id and src.Trade_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31 00:00:00.0000000') 

			Left Join (
				Select State_Street_CUSIP_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
				From EDP_Common.Dim_Security 
				where Is_Current_Flag = 1
				group By State_Street_CUSIP_ID
			) sec on src.CUSIP_Number = sec.State_Street_CUSIP_ID
			Left Join EDP_Common.Dim_Security s on sec.IMCO_Security_Alias_ID = s.IMCO_Security_Alias_ID and src.Trade_Date between s.Effective_Start_Datetime and coalesce(s.Effective_End_Datetime, '9999-12-31') 

			Left Join (
				Select ISIN_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
				From EDP_Common.Dim_Security 
				where Is_Current_Flag = 1
				group By ISIN_ID
			) sec_isin on src.ISIN_Number = sec_isin.ISIN_ID
			Left Join EDP_Common.Dim_Security s_isin on sec_isin.IMCO_Security_Alias_ID = s_isin.IMCO_Security_Alias_ID and src.Trade_Date between s_isin.Effective_Start_Datetime and coalesce(s_isin.Effective_End_Datetime, '9999-12-31') 

			Left Join (
				Select Ticker_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
				From (
					Select Ticker_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
					From EDP_Common.Dim_Security 
					Where BNYM_ID is not null and Is_Current_Flag = 1
					group By Ticker_ID

					union all

					Select Ticker_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
					From EDP_Common.Dim_Security 
					Where BNYM_ID is null and Is_Current_Flag = 1
					group By Ticker_ID
				) si 
				Where Ticker_ID is not null
				Group By Ticker_ID 
			) sec_ticker on src.Bloomberg_Ticker = sec_ticker.Ticker_ID
			Left Join EDP_Common.Dim_Security s_ticker on sec_ticker.IMCO_Security_Alias_ID = s_ticker.IMCO_Security_Alias_ID and src.Trade_Date between s_ticker.Effective_Start_Datetime and coalesce(s_ticker.Effective_End_Datetime, '9999-12-31') 

			Left Join EDP_Common.Dim_Currency lc on src.Local_Currency_Code = lc.CURRENCY_CODE
			Left Join EDP_Common.Dim_Currency bc on src.Base_Currency_Code = bc.CURRENCY_CODE
			Left Join EDP_Common.Dim_Currency ic on src.Income_Currency_Code = ic.CURRENCY_CODE
			Left Join EDP_Common.Dim_Currency sc on src.Settlement_Currency_Code = sc.CURRENCY_CODE
			Left Join EDP_Common.Dim_Currency tc on src.Trade_Currency_Code = tc.CURRENCY_CODE
			Left Join EDP_Common.Dim_Long_Short_Direction ls on src.Long_Short_Indicator = ls.Long_Short_Direction_Indicator 
			Left Join EDP_Common.Dim_Transaction_Type tt on src.Transaction_Type = tt.Transaction_Type_Code
			Left Join EDP_Common.Dim_Transaction_Event_Type te on src.Transaction_Category_Name = te.Transaction_Event_Type_Code
			Left Join EDP_Common.Dim_Source_Record_Status ss on src.Source_Status_Code = ss.Source_Status_Code
			Left Join EDP_Common.Dim_Reference_Transaction rt on src.Transaction_Status=rt.Transaction_Status_Code  
																  AND src.Pay_Receive_Indicator=rt.Pay_Receive_Indicator  
																  AND src.Accrual_Method=rt.Accrual_Method_Code  
																  AND src.Quantity_Type=rt.Quantity_Type_Code 
																  AND src.Cancel_Record_Indicator=rt.Transaction_Cancellation_Indicator

		-- Fix -1 for security key, portfolio key in fact table
		Exec EDW_DQ.EDP_Eagle_SS_Fix_Missing_Keys 'EDP_Common', 'Fact_SS_MCH_Transaction', 'Fact_SS_MCH_Transaction_ID', 'PORT_SEC', '7', @Batch_DTS, @ETL_Load_Key
		
		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.Fact_SS_MCH_Transaction
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_Transaction', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_Transaction', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_Transaction', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_Transaction', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END