﻿CREATE PROC [EDP_Common].[Eagle_Bridge_Portfolio_Benchmark] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)
	
	Begin Try
		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max([Last_Update_Datetime]), '1900-01-01')
		From [EDP_Common].[Bridge_Portfolio_Benchmark]

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'IDW-PERF', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		-- This is to get start_date and end_date based on Effective_Date by Entity_ID
		IF OBJECT_ID('tempdb..#temp_src_Portfolio_Bmk_EffectiveDate') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_Portfolio_Bmk_EffectiveDate
		END

		create table #temp_src_Portfolio_Bmk_EffectiveDate
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as 
				SELECT ENTITY_ID, EFFECTIVE_DATE as Start_Date, coalesce(LEAD(EFFECTIVE_DATE,1) OVER (PARTITION BY ENTITY_ID ORDER BY EFFECTIVE_DATE), '9999-12-31') as End_Date
				FROM (SELECT Entity_Id, Effective_Date
						FROM [PSA].[V_Eagle_Entity_Detail_History] 
						Where ENTITY_TYPE = 'INDX' and SRC_INTFC_INST = -1 and LIST_ORDER>0
						Group by Entity_Id, Effective_Date) as EE

		-- This is the main logic to populate the bridge table
		IF OBJECT_ID('tempdb..#temp_src_Portfolio_Bmk') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_Portfolio_Bmk
		END

		create table #temp_src_Portfolio_Bmk
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as SELECT Dim_Effective_Date_Key,Dim_Portfolio_Key 
					   ,MAX(Dim_Primary_Comparison_Benchmark_Key) Dim_Primary_Comparison_Benchmark_Key,MAX(Dim_Secondary_Comparision_Benchmark_Key) Dim_Secondary_Comparision_Benchmark_Key
					   ,MAX(Dim_Third_Comparison_Benchmark_Key) Dim_Third_Comparison_Benchmark_Key,MAX(Dim_Risk_Free_Benchmark_Key) Dim_Risk_Free_Benchmark_Key
					   ,MAX(Dim_Fourth_Comparison_Benchmark_Key) Dim_Fourth_Comparison_Benchmark_Key,MAX(Dim_Fifth_Comparison_Benchmark_Key) Dim_Fifth_Comparison_Benchmark_Key
					   ,MAX(Dim_Sixth_Comparison_Benchmark_Key) Dim_Sixth_Comparison_Benchmark_Key,MAX(Dim_Seventh_Comparison_Benchmark_Key) Dim_Seventh_Comparison_Benchmark_Key
					   ,MAX(Dim_Eighth_Comparison_Benchmark_Key) Dim_Eighth_Comparison_Benchmark_Key
					   ,MAX(CAST(Source_Deleted_Flag AS INT)) Source_Deleted_Flag, MAX(Source_System_Code) Source_System_Code,MAX(ETL_Load_Key) ETL_Load_Key, MAX(HASH_DIFF) HASH_DIFF
					   ,MAX(Last_Update_User) Last_Update_User,MAX(Last_Update_Datetime) Last_Update_Datetime,'{['+ STRING_AGG(Load_Detail_Description, ',')+']}' Load_Detail_Description
				FROM (Select
					 D.Dim_Date_Key as Dim_Effective_Date_Key
					,Coalesce(p.Dim_Portfolio_Key, -1) as Dim_Portfolio_Key
					,SRC.LIST_ORDER
					,Coalesce(b.DIM_Benchmark_Key, -1) DIM_Benchmark_Key
					,Case when src.List_Order=1 Then Coalesce(b.DIM_Benchmark_Key, -1) Else -1 End Dim_Primary_Comparison_Benchmark_Key
					,Case when src.List_Order=2 Then Coalesce(b.DIM_Benchmark_Key, -1) Else -1 End Dim_Secondary_Comparision_Benchmark_Key
					,Case when src.List_Order=3 Then Coalesce(b.DIM_Benchmark_Key, -1) Else -1 End Dim_Third_Comparison_Benchmark_Key
					,Case when src.List_Order=9 Then Coalesce(b.DIM_Benchmark_Key, -1) Else -1 End Dim_Risk_Free_Benchmark_Key
					,Case when src.List_Order=4 Then Coalesce(b.DIM_Benchmark_Key, -1) Else -1 End Dim_Fourth_Comparison_Benchmark_Key
					,Case when src.List_Order=5 Then Coalesce(b.DIM_Benchmark_Key, -1) Else -1 End Dim_Fifth_Comparison_Benchmark_Key
					,Case when src.List_Order=6 Then Coalesce(b.DIM_Benchmark_Key, -1) Else -1 End Dim_Sixth_Comparison_Benchmark_Key
					,Case when src.List_Order=7 Then Coalesce(b.DIM_Benchmark_Key, -1) Else -1 End Dim_Seventh_Comparison_Benchmark_Key
					,Case when src.List_Order=8 Then Coalesce(b.DIM_Benchmark_Key, -1) Else -1 End Dim_Eighth_Comparison_Benchmark_Key
					,src.Is_Src_Deleted as Source_Deleted_Flag
					,@SourceSystem as Source_System_Code
					,@ETL_Load_Key as ETL_Load_Key
					,'NULL' HASH_DIFF
					,@LastUpdateUser as Last_Update_User
					,@today as Last_Update_Datetime
					, '{' + 
						'"Portfolio_Id": "' + convert(varchar(50), p.Portfolio_Id) + '",' + 
						'"LIST_ORDER":"' + convert(varchar(2), src.LIST_ORDER) + '",' + 
						'"Benchmark_ID":"' + convert(varchar(50), b.Benchmark_ID) + '",' +
						'"Entity_Id":"' + convert(varchar(50), src.Entity_Id) + '",' + 
						'"ENTITY_DETAIL_ID":"' + convert(varchar(50), src.ENTITY_DETAIL_ID) + '"' + 
						'}' as Load_Detail_Description
				from [PSA].[V_Eagle_Entity_Detail_History] src
				Left Join EDP_Common.Dim_Portfolio p on src.Entity_Id = p.Portfolio_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31') 
				Left Join EDP_Common.Dim_Benchmark b on src.ENTITY_DETAIL_ID = REPLACE(b.Benchmark_Id,'BM.','') and src.Effective_Date between b.Effective_Start_Datetime and coalesce(b.Effective_End_Datetime, '9999-12-31') 
				Join #temp_src_Portfolio_Bmk_EffectiveDate tmp on src.Entity_Id=tmp.Entity_Id and src.Effective_Date = tmp.Start_Date
				Join EDP_Common.Dim_Date D on D.Date >= tmp.Start_Date and D.Date < case tmp.End_Date When '9999-12-31' Then getdate() Else tmp.End_Date End	
				where src.ENTITY_TYPE = 'INDX' and src.SRC_INTFC_INST = -1 and src.LIST_ORDER>0) SRC
			GROUP BY  Dim_Effective_Date_Key,Dim_Portfolio_Key

		-- Main Process - insert into target bridge table if rows do not exist
		INSERT INTO [EDP_Common].[Bridge_Portfolio_Benchmark]
			(Dim_Effective_Date_Key
			,Dim_Portfolio_Key
			,Dim_Primary_Comparison_Benchmark_Key
			,Dim_Secondary_Comparision_Benchmark_Key
			,Dim_Third_Comparison_Benchmark_Key
			,Dim_Risk_Free_Benchmark_Key
			,Dim_Fourth_Comparison_Benchmark_Key
			,Dim_Fifth_Comparison_Benchmark_Key
			,Dim_Sixth_Comparison_Benchmark_Key
			,Dim_Seventh_Comparison_Benchmark_Key
			,Dim_Eighth_Comparison_Benchmark_Key
			,Source_Deleted_Flag
			,Source_System_Code
			,ETL_Load_Key
			,Hash_Diff
			,Last_Update_User
			,Last_Update_Datetime
			,Load_Detail_Description
		)
				Select *
				from #temp_src_Portfolio_Bmk s
				where not exists (
					Select 1
					From [EDP_Common].[Bridge_Portfolio_Benchmark] t
					where s.Dim_Effective_Date_Key = t.Dim_Effective_Date_Key 
					and  s.Dim_Portfolio_Key = t.Dim_Portfolio_Key 
					and  s.Dim_Primary_Comparison_Benchmark_Key = t.Dim_Primary_Comparison_Benchmark_Key
					and  s.Dim_Secondary_Comparision_Benchmark_Key = t.Dim_Secondary_Comparision_Benchmark_Key
					and  s.Dim_Third_Comparison_Benchmark_Key = t.Dim_Third_Comparison_Benchmark_Key
					and  s.Dim_Risk_Free_Benchmark_Key = t.Dim_Risk_Free_Benchmark_Key
					and  s.Dim_Fourth_Comparison_Benchmark_Key = t.Dim_Fourth_Comparison_Benchmark_Key
					and  s.Dim_Fifth_Comparison_Benchmark_Key = t.Dim_Fifth_Comparison_Benchmark_Key
					and  s.Dim_Sixth_Comparison_Benchmark_Key = t.Dim_Sixth_Comparison_Benchmark_Key
					and  s.Dim_Seventh_Comparison_Benchmark_Key = t.Dim_Seventh_Comparison_Benchmark_Key
					and  s.Dim_Eighth_Comparison_Benchmark_Key = t.Dim_Eighth_Comparison_Benchmark_Key
					and t.Source_Deleted_Flag = 0)
				and s.Source_Deleted_Flag = 0
				 
		---- Main Process - update target bridge table if rows exist, but change captured - This is ignored as this is relationship table, no change captured
		--Update t 
		--Set Last_Update_Datetime = @today, Source_Deleted_Flag = 1, ETL_Load_Key = @ETL_Load_Key
		--From [EDP_Common].[Bridge_Portfolio_Benchmark] t 
		--Where t.Source_Deleted_Flag = 0 and exists
		--(
		--	Select 1
		--	From #temp_src_Portfolio_Bmk s 
		--	Where s.Dim_Effective_Date_Key = t.Dim_Effective_Date_Key and  s.Dim_Portfolio_Key = t.Dim_Portfolio_Key and  s.Dim_Primary_Comparison_Benchmark_Key = t.Dim_Primary_Comparison_Benchmark_Key
		--			and  s.Dim_Secondary_Comparision_Benchmark_Key = t.Dim_Secondary_Comparision_Benchmark_Key and  s.Dim_Third_Comparison_Benchmark_Key = t.Dim_Third_Comparison_Benchmark_Key
		--			and  s.Dim_Risk_Free_Benchmark_Key = t.Dim_Risk_Free_Benchmark_Key and  s.Dim_Fourth_Comparison_Benchmark_Key = t.Dim_Fourth_Comparison_Benchmark_Key
		--			and  s.Dim_Fifth_Comparison_Benchmark_Key = t.Dim_Fifth_Comparison_Benchmark_Key and  s.Dim_Sixth_Comparison_Benchmark_Key = t.Dim_Sixth_Comparison_Benchmark_Key
		--			and  s.Dim_Seventh_Comparison_Benchmark_Key = t.Dim_Seventh_Comparison_Benchmark_Key and  s.Dim_Eighth_Comparison_Benchmark_Key = t.Dim_Eighth_Comparison_Benchmark_Key
		--	and (
		--		t.hash_diff <> s.hash_diff
		--		--or t.WEIGHT <> s.WEIGHT
		--		or s.Source_Deleted_Flag = 1
		--	)
		--)

		/* expire the deleted relationship */
		Update t
		Set Last_Update_Datetime = @today, Source_Deleted_Flag = 1, ETL_Load_Key = @ETL_Load_Key
		From [EDP_Common].[Bridge_Portfolio_Benchmark] t
		Where t.Source_Deleted_Flag = 0 and not exists
		(
			Select 1
			From #temp_src_Portfolio_Bmk s
			Where s.Dim_Effective_Date_Key = t.Dim_Effective_Date_Key and  s.Dim_Portfolio_Key = t.Dim_Portfolio_Key and  s.Dim_Primary_Comparison_Benchmark_Key = t.Dim_Primary_Comparison_Benchmark_Key
					and  s.Dim_Secondary_Comparision_Benchmark_Key = t.Dim_Secondary_Comparision_Benchmark_Key and  s.Dim_Third_Comparison_Benchmark_Key = t.Dim_Third_Comparison_Benchmark_Key
					and  s.Dim_Risk_Free_Benchmark_Key = t.Dim_Risk_Free_Benchmark_Key and  s.Dim_Fourth_Comparison_Benchmark_Key = t.Dim_Fourth_Comparison_Benchmark_Key
					and  s.Dim_Fifth_Comparison_Benchmark_Key = t.Dim_Fifth_Comparison_Benchmark_Key and  s.Dim_Sixth_Comparison_Benchmark_Key = t.Dim_Sixth_Comparison_Benchmark_Key
					and  s.Dim_Seventh_Comparison_Benchmark_Key = t.Dim_Seventh_Comparison_Benchmark_Key and  s.Dim_Eighth_Comparison_Benchmark_Key = t.Dim_Eighth_Comparison_Benchmark_Key 
		)

		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.Bridge_Portfolio_Benchmark
		Where Last_Update_Datetime = @today and Source_Deleted_Flag = 0

		Select @rowsExpired = Count(*) 
		From EDP_Common.Bridge_Portfolio_Benchmark
		Where Last_Update_Datetime = @today and Source_Deleted_Flag = 1

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Bridge_Portfolio_Benchmark', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Bridge_Portfolio_Benchmark', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Bridge_Portfolio_Benchmark', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Bridge_Portfolio_Benchmark', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END