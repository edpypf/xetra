﻿CREATE PROC [EDP_Common].[Common_Dim_Currency] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate(),
	        @loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)


	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0

	
	Begin Try

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'IDW-REF', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')


		-- Set load start time
		Select @loadStartTime = @today

		IF OBJECT_ID('tempdb..#temp_src_currency_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_currency_records
		END

		
		-- load everything from source
		create table #temp_src_currency_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select	Currency_Code, Currency_Name, Currency_Long_Name
				,convert(varchar(64), Hashbytes('SHA1', upper(concat(Rtrim(Currency_Name), '|', Rtrim(Currency_Long_Name) ))),2) Hash_Diff
		From (	SELECT Distinct CV.SHORT_DESC Currency_Code, CV.LONG_DESC Currency_Name, CV.LONG_DESC Currency_Long_Name
				FROM PSA.V_Eagle_CODES C
				INNER JOIN PSA.V_Eagle_CODE_VALUES CV ON C.INSTANCE = CV.CODE_INST 
				where C.SHORT_DESC='CURRENCY CODE' 
				and CV.INTFC_INST IN (SELECT INSTANCE FROM PSA.V_Eagle_INTERFACES WHERE SHORT_DESC = 'EAGLE PACE')
				and C.Is_Src_Deleted = 0 and CV.Is_Src_Deleted = 0
			 ) src
		Where Currency_Code is not null

		--INSERT INTO DIM TABLE
		Insert Into [EDP_Common].[Dim_Currency] 
		(
			 Currency_Code
			,Currency_Name
			,Currency_Long_Name
			,Source_Deleted_Flag
			,Create_Datetime
			,Last_Update_Datetime
			,Hash_Diff
			,ETL_Load_Key
			,Source_System_Code
			,Last_Update_User
		)

		Select Currency_Code, Currency_Name, Currency_Long_Name, 0, @today, @today, Hash_Diff, @ETL_Load_Key, @SourceSystem Source_System, @LastUpdateUser Last_Update_User
		From #temp_src_currency_records src
		Where not exists 
		(
			Select 1
			From [EDP_Common].[Dim_Currency] tgt
			where src.Currency_Code = tgt.Currency_Code
		)

		--UPDATE/EXPIRE EXISTING RECORDS
		Update tgt
		Set Currency_Name = src.Currency_Name, Currency_Long_Name = src.Currency_Long_Name, Last_Update_Datetime = @today, Hash_Diff = src.Hash_Diff
		    , ETL_Load_Key = @ETL_Load_Key, Source_System_Code = @SourceSystem, Last_Update_User = @LastUpdateUser
		From [EDP_Common].[Dim_Currency] tgt
		Join #temp_src_currency_records src
		On tgt.Currency_Code = src.Currency_Code and coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')

		--UPDATE DELETION FLAG EXISTING RECORDS
		Update tgt
		Set Source_Deleted_Flag = 1, Last_Update_Datetime = @today
		   , ETL_Load_Key = @ETL_Load_Key, Source_System_Code = @SourceSystem, Last_Update_User = @LastUpdateUser
		From [EDP_Common].[Dim_Currency] tgt
		Left Join #temp_src_currency_records src On tgt.Currency_Code = src.Currency_Code 
		Where tgt.Dim_Currency_Key > -1 and src.Hash_Diff is null  
		
		-- Set load end time
		Select @loadEndTime = Getdate()

		--ETL Logging
		Select @rowsInserted = Count(*) 
		From [EDP_Common].[Dim_Currency]
		Where Create_Datetime = @today

		Select @rowsUpdated = Count(*)
		From [EDP_Common].[Dim_Currency]
		Where Last_Update_Datetime = @today and Create_Datetime < @today

		Select @rowsExpired = 0

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDP_Common.Dim_Currency', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Load_DTS, @ETL_Load_Key, 'Dim_Currency', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDP_Common.Dim_Currency', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END