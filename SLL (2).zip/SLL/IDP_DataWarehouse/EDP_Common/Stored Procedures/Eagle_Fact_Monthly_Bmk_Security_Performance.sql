﻿CREATE PROC [EDP_Common].[Eagle_Fact_Monthly_Bmk_Security_Performance] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)
	
	Begin Try


		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max(Load_Datetime), '1900-01-01'), 
		       @currentMaxId = coalesce(max([Fact_Monthly_Bmk_Security_Performance_ID]), 0)
		From [EDP_Common].[Fact_Monthly_Bmk_Security_Performance]

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'IDW-BMK', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today


		INSERT INTO [EDP_Common].[Fact_Monthly_Bmk_Security_Performance]
           (  [Fact_Monthly_Bmk_Security_Performance_ID]
			  ,[Dim_Source_Status_Key]
			  ,[Dim_Effective_Date_Key]
			  ,[Dim_Benchmark_Key]
			  ,[Dim_Security_Key]
			  ,[Dim_Security_Currency_Key]
			  ,[Last_Update_Datetime]

			  ,[Return_Percentage]
			  ,[Local_Return_Percentage]
			  ,[Beginning_Weight_Percentage]

			  ,[Source_Update_Datetime]
			  ,[Load_Detail_Description]

			  ,[ETL_Load_Key]
			  ,Load_Datetime
			  ,Source_Deleted_Flag
			  ,Last_Update_User
			  ,Source_System_Code
		)
		SELECT      @currentMaxId + rn
					,Coalesce(ss.Dim_Source_Status_Key, -1) Dim_Source_Status_Key
					,convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Effective_Date_Key]
					,Coalesce(p.Dim_Benchmark_Key, -1) [Dim_Benchmark_Key]
					,Coalesce(s.Dim_Security_Key, -1) Dim_Security_Key
					,Coalesce(c.Dim_Currency_Key, -1) Dim_Currency_Key

					,@today
					, [PSR_USER_FLOAT8] [Return_Percentage]
					, [PSR_USER_FLOAT32] [Local_Return_Percentage]
					, ABAL [Beginning_Weight_Percentage]

					, UPDATE_DATE [Source_Update_Datetime]
					,Case When ss.Dim_Source_Status_Key is null or p.Dim_Benchmark_Key is null 
							or s.Dim_Security_Key is null or c.Dim_Currency_Key is null Then
						 '{' + 
						'"Benchmark_Id": "' + Coalesce(convert(varchar(50), src.Benchmark_ID),'') + '",' + 
						'"Security_Alias":"' + Coalesce(convert(varchar(50), src.Security_Alias),'') + '",' + 
						'"Currency_Code":"' + Coalesce(convert(varchar(50), src.Currency_Code),'') + '",' + 
						'"PERF_SUM_INST":"' + Coalesce(convert(varchar(50), src.PERF_SUM_INST),'') + '" ' + 
						'}'
					Else 
						'{' + 
						'"PERF_SUM_INST":"' + convert(varchar(50), src.PERF_SUM_INST) + '" ' + 
						'}'
					End 
					,@ETL_Load_Key
					,src.Load_DTS
					,src.Is_Src_Deleted
					,@LastUpdateUser
					,@SourceSystem

		From (
				SELECT PSR.PERF_SUM_INST
					  ,E.Entity_ID Benchmark_Id
				      ,PSR.Security_Alias
				      ,PS.End_Effective_Date Effective_Date
					  ,PSR.Load_DTS
					  ,Case When PS.End_Effective_Date >= '2023-01-01' Then 'PRELIM_UNAUD' Else 'FNL' End Source_Status_Code
					  ,RTRIM(SM.CURRENCY_CODE) CURRENCY_CODE

					  ,PSR.PSR_USER_FLOAT8 
					  ,PSR.PSR_USER_FLOAT32
					  ,PSR.ABAL

					  ,PSR.UPDATE_DATE
					  ,PSR.UPDATE_SOURCE
					  ,PSR.Hash_Diff
					  ,Case when PS.Is_Src_Deleted = 1 then 1 else PSR.Is_Src_Deleted End Is_Src_Deleted
					  ,row_number() Over(Order By (select 1)) rn
				    FROM   PSA.Eagle_Perf_Sec_Returns     PSR 
                    Inner Join PSA.V_Eagle_Perf_Summary PS ON PS.PERF_SUM_INST  = PSR.PERF_SUM_INST 
					Inner Join PSA.V_Eagle_Security_Master SM on PSR.Security_Alias = SM.Security_Alias
                    Inner Join PSA.V_Eagle_Entity       E ON PS.ENTITY_ID      = E.ENTITY_ID 
                    Inner Join PSA.V_Eagle_Interfaces  I ON PS.SRC_INTFC_INST = I.INSTANCE
                    WHERE PSR.PERF_ROLLUP_RETURNS_ID = 0
					AND PS.Dictionary_Id = 0 
                    AND PS.PERF_FREQ_CODE    in ('M')
                    AND PS.PERF_SUMMARY_TYPE = 'S'    
					And E.Entity_Type in ('INDX', 'CIDX') 
					AND I.Short_DESC = 'EAGLE PACE'
					and PSR.Load_DTS > Coalesce(@lastLoadeDTS, '1900-01-01')
					and PS.End_Effective_Date <= @today
			) src
			Left Join EDP_Common.Dim_Benchmark p on src.Benchmark_Id = p.Benchmark_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31') 
			Left Join [EDP_Common].[Dim_Security] s on src.Security_Alias = s.IMCO_Security_Alias_Id and src.Effective_Date between s.Effective_Start_Datetime and coalesce(s.Effective_End_Datetime, '9999-12-31') 
			Left Join [EDP_Common].[Dim_Currency] c on src.CURRENCY_CODE = c.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Source_Record_Status] ss on src.Source_Status_Code = ss.Source_Status_Code

		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.[Fact_Monthly_Bmk_Security_Performance]
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_Monthly_Bmk_Security_Performance', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_Monthly_Bmk_Security_Performance', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_Monthly_Bmk_Security_Performance', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_Monthly_Bmk_Security_Performance', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END