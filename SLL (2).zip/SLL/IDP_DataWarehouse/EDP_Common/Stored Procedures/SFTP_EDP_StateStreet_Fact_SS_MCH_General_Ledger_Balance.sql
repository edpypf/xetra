﻿CREATE PROC [EDP_Common].[SFTP_EDP_StateStreet_Fact_SS_MCH_General_Ledger_Balance] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()
/**
select * from [EDP_Common].Fact_SS_MCH_General_Ledger_Balance
Exec [EDP_Common].[SFTP_EDP_StateStreet_Fact_SS_MCH_General_Ledger_Balance]'DELTA','1900-01-01',-1
select * from [EDP_Common].Fact_SS_MCH_General_Ledger_Balance
**/

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)
	
	Begin Try


		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max([Last_Update_Datetime]), '1900-01-01'), 
		       @currentMaxId = coalesce(max([Fact_SS_MCH_General_Ledger_Balance_ID]), 0)
		From [EDP_Common].[Fact_SS_MCH_General_Ledger_Balance]

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'MySS-SS-MCH', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		INSERT INTO [EDP_Common].Fact_SS_MCH_General_Ledger_Balance
           (  [Fact_SS_MCH_General_Ledger_Balance_ID]
			  ,[Dim_Effective_Date_Key]
			  ,[Dim_Dataset_Frequency_Key]
			  ,[Dim_Portfolio_Key]

			  ,[Dim_General_Ledger_Account_Key]
			  ,[Dim_Accounting_Share_Class_Key]

			  ,[Dim_Currency_Base_Key]
			  ,[Dim_Source_Status_Key]
			  
			  ,[General_Ledger_Currency_Local_Code]
			  ,[Reporting_Basis_Indicator]
			  ,[General_Ledger_Grouping_Code]
			  ,[Last_Update_Datetime]
			  ,Load_Datetime

			  ,[Beginning_Balance_Amount]
			  ,[Net_Debit_Activity_Amount]
			  ,[Net_Credit_Activity_Amount]
			  ,[Net_Activity_Amount]
			  ,[Ending_Balance_Amount]

			  ,[Source_Update_Datetime]
			  ,Source_System_Code
			  ,Source_Deleted_Flag
			  ,[ETL_Load_Key]
			  ,[Load_Detail_Description]
			  ,Last_Update_User

		)
		SELECT      @currentMaxId + rn
					,convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Effective_Date_Key]
					,Coalesce(freq.Dim_Dataset_Frequency_Key, -1) Dim_Dataset_Frequency_Key
					,Coalesce(p.Dim_Portfolio_Key, -1) [Dim_Portfolio_Key]
					
					,Coalesce(glc.Dim_General_Ledger_Account_Key, -1) Dim_General_Ledger_Account_Key
					,-1 Dim_Accounting_Share_Class_Key
					
					,Coalesce(bc.Dim_Currency_Key, -1) Dim_Currency_Base_Key
					,Coalesce(ss.Dim_Source_Status_Key, -1) Dim_Source_Status_Key
					
					,[Local_Currency_Code] [General_Ledger_Currency_Local_Code]
					,[Basis] [Reporting_Basis_Indicator]
					,'NA' [General_Ledger_Grouping_Code]
					,src.Last_Update_DT
					,src.Load_DTS

					,[GL_Account_Starting_Balance]
					,[GL_Account_Debit_Balance]
					,[GL_Account_Credit_Balance]
					,[GL_Account_Net_Activity]
					,[GL_Account_Ending_Balance]

					,null [Source_Update_Datetime]
					,@SourceSystem
					,src.Is_Src_Deleted
					,@ETL_Load_Key
					,Case When freq.Dim_Dataset_Frequency_Key is null or ss.Dim_Source_Status_Key is null or p.Dim_Portfolio_Key is null 
							or glc.Dim_General_Ledger_Account_Key is null or bc.Dim_Currency_Key is null
							or ss.Dim_Source_Status_Key is null or 1=1 
					 Then
						 '{' + 
						'"Report_Freq_Code": "' + Coalesce(convert(varchar(255), src.[Report_Freq_Code]),'') + '",' + 
						'"Fund": "' + Coalesce(convert(varchar(255), src.Fund),'') + '",' + 
						'"GL_Account_Number":"' + Coalesce(convert(varchar(255), src.GL_Account_Number),'') + '",' + 
						'"Financial_Statement_Currency":"' + Coalesce(convert(varchar(255), src.Financial_Statement_Currency),'') + '",' + 
						'"[Local_Currency_Code]":"' + Coalesce(convert(varchar(255), src.[Local_Currency_Code]),'') + '",' + 
						'"[Basis]":"' + Coalesce(convert(varchar(255), src.[Basis]),'') + '",' + 
						'"Source_Status_Code":"' + Coalesce(convert(varchar(50), src.Source_Status_Code),'') + '" ' + 
						'}'
					Else 
						null
					End 
					,@LastUpdateUser


		From (
				select *, row_number() Over(Order By (select 1)) rn from (
				SELECT distinct Period_End_Date as Effective_Date
					  ,[Period_Start_Date]
					  ,[Report_Freq_Code]
					  ,[Fund]
					  ,[Basis]
					  ,[GL_Account_Number]
					  ,[Financial_Statement_Currency]
					  ,[Local_Currency_Code]
					  ,[GL_Account_Starting_Balance]
					  ,[GL_Account_Debit_Balance]
					  ,[GL_Account_Credit_Balance]
					  ,[GL_Account_Net_Activity]
					  ,[GL_Account_Ending_Balance]

					  ,'PRELIM_UNAUD'   Source_Status_Code

					  ,Record_Created_DT Load_DTS
					  ,Last_Update_DT  
					  ,Source_Deleted_Flag Is_Src_Deleted
					FROM [EDW_Raw].[SS_MySS_MCH_WTB_General_Ledger] P
                    WHERE [TB_Total_Line] = 'N'
					and Last_Update_DT > Coalesce(@lastLoadeDTS, '1900-01-01')) as S
					
			) src
			Left Join (
				Select State_Street_Portfolio_ID, min(Portfolio_Id) Portfolio_Id
				From EDP_Common.Dim_Portfolio 
				where Is_Current_Flag = 1
				Group By State_Street_Portfolio_ID
			) pc on src.Fund = pc.State_Street_Portfolio_ID
			Left Join EDP_Common.Dim_Portfolio p on pc.Portfolio_Id = p.Portfolio_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31 00:00:00.0000000') 
			Left Join [EDP_Common].[Dim_Currency] bc on src.[Financial_Statement_Currency] = bc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Dataset_Frequency] freq on src.[Report_Freq_Code] = freq.[Dataset_Frequency_Indicator]
			Left Join [EDP_Common].[Dim_General_Ledger_Account] glc on src.GL_Account_Number = glc.General_Ledger_Account_ID and src.Effective_Date between glc.Effective_Start_Datetime and coalesce(glc.Effective_End_Datetime, '9999-12-31') 
			Left Join [EDP_Common].[Dim_Source_Record_Status] ss on src.Source_Status_Code = ss.Source_Status_Code

		-- Fix -1 for portfolio key in fact table
		exec [EDW_DQ].[EDP_Eagle_SS_Fix_Missing_Keys] 'EDP_Common', 'Fact_SS_MCH_General_Ledger_Balance', 'Fact_SS_MCH_General_Ledger_Balance_ID', 'PORT', '7', @Batch_DTS, @ETL_Load_Key

		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.[Fact_SS_MCH_General_Ledger_Balance]
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_General_Ledger_Balance', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_General_Ledger_Balance', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_General_Ledger_Balance', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_General_Ledger_Balance', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END