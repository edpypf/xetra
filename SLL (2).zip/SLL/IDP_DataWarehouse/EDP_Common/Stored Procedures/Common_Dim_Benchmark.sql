﻿CREATE PROC [EDP_Common].[Common_Dim_Benchmark] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

Declare @today datetime2 = getdate(),
        @loadStartTime datetime2,
		@loadEndTime datetime2,
		@SourceSystem varchar(255),
		@LastUpdateUser varchar(255)

Declare @rowsInserted int = 0,
		@rowsUpdated int = 0,
		@rowsExpired int = 0


	Begin Try

		IF OBJECT_ID('tempdb..#temp_eagle_dim_benchmark_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_dim_benchmark_records
		END


		IF OBJECT_ID('tempdb..#temp_eagle_official_entities') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_official_entities
		END

		IF OBJECT_ID('tempdb..#temp_eagle_port2bmk_entities') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_port2bmk_entities
		END
		
		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'IDW-BMK', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		--Get official entity list
		create table #temp_eagle_official_entities
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		WITH Official_List as (
			  SELECT Rtrim(CV.SHORT_DESC) AS ENTITY_ID
			  FROM PSA.V_Eagle_CODES C
			  INNER JOIN PSA.V_Eagle_CODE_VALUES CV  ON C.INSTANCE           = CV.CODE_INST
			  WHERE C.SHORT_DESC      = 'EDP_RelObjListM'
			  AND   CV.LONG_DESC      = 'OfficialPerfBmkList'
			  AND CV.INTFC_INST       in
				(SELECT instance
				FROM PSA.V_Eagle_INTERFACES
				WHERE short_desc = 'EAGLE PACE'
				)
			  And C.Is_Src_Deleted = 0 and CV.Is_Src_Deleted = 0
		),
		ol_list_member as (
				SELECT  Rtrim(SL.CODE_VALUE) Entity_Id
				FROM PSA.V_Eagle_ENTITY_LIST SL
				INNER JOIN PSA.V_Eagle_ENTITY SE ON SL.CODE_VALUE = SE.ENTITY_ID
				WHERE   SL.ENTITY_ID in ( SELECT ENTITY_ID FROM Official_List )
				AND     SE.ENTITY_TYPE = 'LIST'
				and SL.Is_Src_Deleted = 0 and SE.Is_Src_Deleted = 0

		)
		SELECT  EL.CODE_VALUE Entity_Id
		FROM    PSA.V_Eagle_ENTITY_LIST EL
		Join    PSA.V_Eagle_ENTITY E ON TRIM(EL.CODE_VALUE) = TRIM(E.ENTITY_ID)
		Join    Official_List ol on EL.Entity_Id = ol.Entity_Id
		Where   EL.Is_Src_Deleted = 0 and E.Is_Src_Deleted = 0

		Union

		SELECT  EL.CODE_VALUE Entity_Id
		FROM    PSA.V_Eagle_ENTITY_LIST EL
		Join    PSA.V_Eagle_ENTITY E ON TRIM(EL.CODE_VALUE) = TRIM(E.ENTITY_ID)
		Join    ol_list_member olm on EL.Entity_Id = olm.Entity_Id
		Where   EL.Is_Src_Deleted = 0 and E.Is_Src_Deleted = 0

		create table #temp_eagle_port2bmk_entities
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		WITH Official_p2b_List as (
			  SELECT Rtrim(CV.SHORT_DESC) AS ENTITY_ID
			  FROM PSA.V_Eagle_CODES C
			  INNER JOIN PSA.V_Eagle_CODE_VALUES CV  ON C.INSTANCE           = CV.CODE_INST
			  WHERE C.SHORT_DESC      = 'EDP_RelObjListM'
			  -- AND   CV.LONG_DESC      = 'OfficialPerfBmkList'
			  AND CV.INTFC_INST       in
				(SELECT instance
				FROM PSA.V_Eagle_INTERFACES
				WHERE short_desc = 'EAGLE PACE'
				)
			  And C.Is_Src_Deleted = 0 and CV.Is_Src_Deleted = 0
		)
		SELECT  EL.CODE_VALUE Entity_Id
		FROM    PSA.V_Eagle_ENTITY_LIST EL
		Join    PSA.V_Eagle_ENTITY E ON TRIM(EL.CODE_VALUE) = TRIM(E.ENTITY_ID)
		Join    Official_p2b_List ol on EL.Entity_Id = ol.Entity_Id
		Where   EL.Is_Src_Deleted = 0 and E.Is_Src_Deleted = 0

		-- load latest Eagle entity records from source into temp table
		create table #temp_eagle_dim_benchmark_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select	Rtrim(E.[Entity_ID]) Benchmark_Id
				,Rtrim(E.[Entity_Name]) Benchmark_Name
				,Rtrim(E.[Entity_Long_Name]) Benchmark_Description
				,E.Entity_Type Benchmark_Type_Code
				,ET.Portfolio_Type Benchmark_Type_Name
				,ET.Portfolio_Type Benchmark_Type_Description
				,case when OE.[Entity_ID] is null then 0 else 1 end [Performance_Official_Ownership_Flag]
				,CONVERT(VARCHAR(64), Hashbytes('SHA1', Upper(concat(E.Entity_Type, '|', ET.Portfolio_Type, '|',
								Rtrim(E.[Entity_Name]) , '|', Rtrim(E.[Entity_Long_Name])))), 2 ) Hash_Diff
				,E.Is_Src_Deleted
				,'Eagle' Source_System
		From PSA.V_Eagle_Entity E
		Left Join (
			SELECT Rtrim(CV.SHORT_DESC) Portfolio_Type_Code, Rtrim(CV.LONG_DESC) Portfolio_Type
			From PSA.V_Eagle_CODE_VALUES CV
			Join PSA.V_Eagle_Codes C on CV.Code_INST = C.Instance
			Join PSA.V_Eagle_Interfaces I On CV.INTFC_INST = I.INSTANCE
			Where I.SHORT_DESC = 'EAGLE PACE' and C.SHORT_DESC = 'INT ENT TYPE' 
			and CV.Is_Src_Deleted = 0
		) ET on E.Entity_Type = ET.Portfolio_Type_Code
		Left Join #temp_eagle_official_entities OE on E.[Entity_ID] = OE.[Entity_ID]
		where E.Entity_Type in ('INDX', 'CIDX') 

		UNION

		Select	CONCAT('BM.', Rtrim(E.[Entity_ID])) Benchmark_Id
				,CONCAT('BM.', Rtrim(E.[Entity_Name])) Benchmark_Name
				,CONCAT('BM.', Rtrim(E.[Entity_Name])) Benchmark_Description
				,'INDX' as Benchmark_Type_Code
				,Benchmark_Type_Name
				,Benchmark_Type_Description
				,[Performance_Official_Ownership_Flag]
				,E.Hash_Diff
				,E.Is_Src_Deleted
				,'Eagle' Source_System		
		From  (Select EE.Entity_ID, EE.Entity_Name, ET.Portfolio_Type_Code
			    ,ET.Portfolio_Type Benchmark_Type_Name
				,ET.Portfolio_Type Benchmark_Type_Description
				,case when OE.[Entity_ID] is null then 0 else 1 end [Performance_Official_Ownership_Flag]
				,CONVERT(VARCHAR(64), Hashbytes('SHA1', Upper(concat(EE.Entity_Type, '|', ET.Portfolio_Type, '|',
								Rtrim(EE.[Entity_Name]) , '|', Rtrim(EE.[Entity_Long_Name])))), 2 ) Hash_Diff
				,EE.Is_Src_Deleted 
				from [PSA].[V_Eagle_Entity] EE
		        Join (SELECT ED.ENTITY_DETAIL_ID FROM [PSA].[V_Eagle_Entity_Detail_History] ED 
					 INNER JOIN [PSA].[V_Eagle_Entity] E ON TRIM(ED.ENTITY_DETAIL_ID) = TRIM(E.ENTITY_ID)
					 WHERE ED.LIST_ORDER  > 0 AND ED.ENTITY_TYPE = 'INDX' AND ED.SRC_INTFC_INST = -1 AND E.ENTITY_TYPE NOT IN ('INDX', 'CIDX')
					 GROUP BY ED.ENTITY_DETAIL_ID) PB
				ON EE.Entity_ID = PB.ENTITY_DETAIL_ID	
				left join (SELECT Rtrim(CV.SHORT_DESC) Portfolio_Type_Code, Rtrim(CV.LONG_DESC) Portfolio_Type
					From PSA.V_Eagle_CODE_VALUES CV
					Join PSA.V_Eagle_Codes C on CV.Code_INST = C.Instance
					Join PSA.V_Eagle_Interfaces I On CV.INTFC_INST = I.INSTANCE
					Where I.SHORT_DESC = 'EAGLE PACE' and C.SHORT_DESC = 'INT ENT TYPE' 
					and CV.Is_Src_Deleted = 0) ET 
				ON EE.Entity_Type = ET.Portfolio_Type_Code
				Left Join #temp_eagle_port2bmk_entities OE on EE.[Entity_ID] = OE.[Entity_ID]
				) E  
 
		--UPDATE/EXPIRE EXISTING RECORDS
		Update tgt
		Set 	Effective_End_Datetime = @today,
				Is_Current_Flag= 0, 
				Last_Update_Datetime=@today, 
				ETL_Load_Key = @ETL_Load_Key,
				Last_Update_User = @LastUpdateUser,
				Source_System_Code = @SourceSystem

		From EDP_Common.Dim_Benchmark tgt
		Where tgt.Dim_Benchmark_Key > -1 and tgt.Is_Current_Flag = 1 and 
		(
			exists
			(	Select	1
				From	#temp_eagle_dim_benchmark_records src
				Where	tgt.Benchmark_Id = src.Benchmark_Id 
						and ( coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1 )
			)

			or
			not exists (
				Select	1
				From	#temp_eagle_dim_benchmark_records src
				Where	tgt.Benchmark_Id = src.Benchmark_Id and tgt.Benchmark_Type_Code = src.Benchmark_Type_Code 
			)
		)

		-- Update type 1 fields ([Performance_Official_Ownership_Flag])
		Update tgt
		Set 	[Performance_Official_Ownership_Flag] = 1,
				Last_Update_Datetime=@today, 
				ETL_Load_Key = @ETL_Load_Key,
				Last_Update_User = @LastUpdateUser,
				Source_System_Code = @SourceSystem

		From EDP_Common.Dim_Benchmark tgt
		Join #temp_eagle_official_entities OE on tgt.Benchmark_Id = OE.[Entity_ID] or tgt.Benchmark_Id = CONCAT('BM.', Rtrim(OE.[Entity_ID])) 
		Where tgt.Dim_Benchmark_Key > -1 and coalesce(tgt.[Performance_Official_Ownership_Flag],0) = 0


		--INSERT NEW RECORDS INTO DIM TABLE
		insert into EDP_Common.Dim_Benchmark
		(
			  [Benchmark_ID]
			  ,[Benchmark_Name]
			  ,[Benchmark_Description]
			  ,[Benchmark_Type_Code]
			  ,[Benchmark_Type_Name]
			  ,[Benchmark_Type_Description]
			  ,[Performance_Official_Ownership_Flag]
			  ,Is_Current_Flag
			  ,Effective_Start_Datetime
			  ,Effective_End_Datetime
			  ,Last_Update_Datetime
			  ,ETL_Load_Key
			  ,Hash_Diff
			  ,Last_Update_User
			  ,Source_System_Code 
		)
			select src.[Benchmark_ID]
				  ,src.[Benchmark_Name]
				  ,src.[Benchmark_Description]
				  ,src.[Benchmark_Type_Code]
				  ,src.[Benchmark_Type_Name]
				  ,src.[Benchmark_Type_Description]
				  ,src.[Performance_Official_Ownership_Flag]
				  ,1
				  ,case when tgt_all.Benchmark_Id is null then '1900-01-01' else @today End 
				  ,'9999-12-31'
				  ,@today
				  ,@ETL_Load_Key
				  ,src.Hash_Diff
				  ,@LastUpdateUser
				  ,@SourceSystem

			from	#temp_eagle_dim_benchmark_records src
					Left Join EDP_Common.Dim_Benchmark tgt on src.Benchmark_Id = tgt.Benchmark_Id and tgt.Is_Current_Flag = 1
					Left Join (Select Distinct Benchmark_Id From EDP_Common.Dim_Benchmark) tgt_all on src.Benchmark_Id = tgt_all.Benchmark_Id
			where	(
						tgt.Benchmark_Id is null 
						or (tgt.Benchmark_Id is not null and src.Hash_Diff <> tgt.Hash_Diff)
					)
					and src.Is_Src_Deleted = 0

		-- Set load end time
		Select @loadEndTime = Getdate()

		--ETL Logging
		Select @rowsInserted = Count(*) 
		From EDP_Common.Dim_Benchmark
		Where ETL_Load_Key = @ETL_Load_Key and Dim_Benchmark_Key > 0 and 
		([Effective_Start_Datetime] = @today or [Effective_Start_Datetime]='1900-01-01')
		and Is_Current_Flag = 1

		Select @rowsUpdated = Count(*)
		From EDP_Common.Dim_Benchmark
		Where ETL_Load_Key = @ETL_Load_Key and [Effective_End_Datetime] = @today

		Select @rowsExpired = Count(*)
		From EDP_Common.Dim_Benchmark p
		Left Join (Select Benchmark_Id From EDP_Common.Dim_Benchmark Where Is_Current_Flag = 1) pc on p.Benchmark_Id = pc.Benchmark_Id 
		Where ETL_Load_Key = @ETL_Load_Key and [Effective_End_Datetime] = @today and pc.Benchmark_Id is null

		-- populate EDW ETL log table
		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Dim_Benchmark', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Load_DTS, @ETL_Load_Key, 'Dim_Benchmark', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null


		-- Force cleanup temp tables
		IF OBJECT_ID('tempdb..#temp_eagle_dim_benchmark_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_dim_benchmark_records
		END

		IF OBJECT_ID('tempdb..#temp_eagle_official_entities') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_official_entities
		END

    END TRY

	--Error Handling
	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Dim_Benchmark', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Load_DTS, @ETL_Load_Key, 'Dim_Benchmark', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END