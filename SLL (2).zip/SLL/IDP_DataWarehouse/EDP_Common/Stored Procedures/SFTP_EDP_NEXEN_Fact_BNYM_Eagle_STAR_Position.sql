﻿CREATE PROC [EDP_Common].[SFTP_EDP_NEXEN_Fact_BNYM_Eagle_STAR_Position] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)
	
	Begin Try


		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max([Last_Update_Datetime]), '1900-01-01'), 
		       @currentMaxId = coalesce(max([Fact_BNYM_Eagle_STAR_Position_ID]), 0)
		From [EDP_Common].[Fact_BNYM_Eagle_STAR_Position]

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'NEXEN-BNYM-STAR', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		INSERT INTO [EDP_Common].Fact_BNYM_Eagle_STAR_Position
           (  [Fact_BNYM_Eagle_STAR_Position_ID]
			  ,[Dim_Effective_Date_Key]
			  ,[Dim_Dataset_Frequency_Key]
			  ,[Dim_Portfolio_Key]
			  ,[Dim_Security_Key]
			  ,[Dim_Currency_Base_Key]
			  ,[Dim_Currency_Local_Key]
			  ,[Dim_Long_Short_Direction_Key]
			  ,[Dim_Reference_Position_Key]
			  ,[Dim_Source_Status_Key]
			  ,[Last_Update_Datetime]

			  ,[Last_Priced_Date]
			  ,[Market_Value_Base_Amount]
			  ,[Market_Value_Local_Amount]
			  ,[Market_Value_With_Accruals_Base_Amount]
			  ,[Market_Value_With_Accruals_Local_Amount]
			  ,[Accrued_Interest_Base_Amount]
			  ,[Accrued_Interest_Local_Amount]
			  ,[Price_Base_Amount]
			  ,[Price_Local_Amount]
			  ,[Price_Unchanged_Daycount]
			  ,[Book_Cost_Base_Amount]
			  ,[Book_Cost_Local_Amount]
			  ,[Book_Unit_Cost_Base_Amount]
			  ,[Book_Unit_Cost_Local_Amount]
			  ,[Notional_Cost_Base_Amount]
			  ,[Notional_Cost_Local_Amount]
			  ,[Notional_Value_Base_Amount]
			  ,[Notional_Value_Local_Amount]
			  ,[Original_Face_Amount]
			  ,[Life_To_Date_Amortization_Base_Amount]
			  ,[Share_Or_Par_Amount]
			  ,[Contract_Number]
			  ,[Unrealized_Gain_Loss_Base_Amount]
			  ,[Unrealized_Gain_Loss_Local_Amount]
			  ,[Net_Realized_Gain_Loss_Base_Amount]
			  ,[Unrealized_Currency_Gain_Loss_Base_Amount]
			  ,[Unsettled_Variation_Margin_Base_Amount]
			  ,[Unsettled_Variation_Margin_Local_Amount]
			  ,[Settled_Variation_Margin_Base_Amount]
			  ,[Settled_Variation_Margin_Local_Amount]
			  ,[Net_Income_Receivable_Base_Amount]
			  ,[Net_Income_Receivable_Local_Amount]
			  ,[FX_Local_To_Base_Rate]
			  ,[FX_Base_To_Local_Rate]

			  ,[Source_Update_Datetime]
			  ,[Load_Detail_Description]

			  ,[ETL_Load_Key]
			  ,Load_Datetime
			  ,Source_Deleted_Flag
			  ,Last_Update_User
			  ,Source_System_Code
		)
		SELECT      @currentMaxId + rn
					,convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Effective_Date_Key]
					,Coalesce(freq.Dim_Dataset_Frequency_Key, -1) Dim_Dataset_Frequency_Key
					,Coalesce(p.Dim_Portfolio_Key, -1) [Dim_Portfolio_Key]
					,Coalesce(s.Dim_Security_Key, -1) Dim_Security_Key
					,Coalesce(bc.Dim_Currency_Key, -1) Dim_Currency_Base_Key
					,Coalesce(lc.Dim_Currency_Key, -1) Dim_Currency_Local_Key
					,Coalesce(lsd.Dim_Long_Short_Direction_Key, -1) Dim_Long_Short_Direction_Key
					,Coalesce(rp.Dim_Reference_Position_Key, -1) Dim_Reference_Position_Key
					,Coalesce(ss.Dim_Source_Status_Key, -1) Dim_Source_Status_Key

					,src.Last_Update_DT

					,Last_Priced_Date
					,Market_Value_Base_Amount
					,Market_Value_Local_Amount
					,Market_Value_With_Accruals_Base_Amount
					,Market_Value_With_Accruals_Local_Amount
					,Accrued_Interest_Base_Amount
					,Accrued_Interest_Local_Amount
					,Price_Base_Amount
					,Price_Local_Amount
					,Price_Unchanged_Daycount
					,Book_Cost_Base_Amount
					,Book_Cost_Local_Amount
					,Book_Unit_Cost_Base_Amount
					,Book_Unit_Cost_Local_Amount
					,Notional_Cost_Base_Amount
					,Notional_Cost_Local_Amount
					,Notional_Value_Base_Amount
					,Notional_Value_Local_Amount
					,Original_Face_Amount
					,Life_to_Date_Amortization_Base_Amount
					,Share_Or_Par_Amount
					,Contract_Number
					,Unrealized_Gain_Loss_Base_Amount
					,Unrealized_Gain_Loss_Local_Amount
					,Net_Realized_Gain_Loss_Base_Amount
					,Unrealized_Currency_Gain_Loss_Base_Amount
					,Unsettled_Variation_Margin_Base_Amount
					,Unsettled_Variation_Margin_Local_Amount
					,Settled_Variation_Margin_Base_Amount
					,Settled_Variation_Margin_Local_Amount
					,Net_Income_Receivable_Base_Amount
					,Net_Income_Receivable_Local_Amount
					,FX_Local_to_Base_Rate
					,FX_Base_to_Local_Rate


					,null [Source_Update_Datetime]
					,Case When freq.Dim_Dataset_Frequency_Key is null or ss.Dim_Source_Status_Key is null or p.Dim_Portfolio_Key is null 
							or s.Dim_Security_Key is null or bc.Dim_Currency_Key is null
							or lc.Dim_Currency_Key is null or lsd.Dim_Long_Short_Direction_Key is null or rp.Dim_Reference_Position_Key is null
					 Then
						 '{' + 
						'"Report_Freq_Code": "' + Coalesce(convert(varchar(255), src.[Report_Freq_Code]),'') + '",' + 
						'"Account_Number": "' + Coalesce(convert(varchar(255), src.Account_Number),'') + '",' + 
						'"Security_Alias_Identifier":"' + Coalesce(convert(varchar(255), src.Security_Alias_Identifier),'') + '",' + 
						'"Base_Currency_Code":"' + Coalesce(convert(varchar(255), src.Base_Currency_Code),'') + '",' + 
						'"Local_Currency_Code":"' + Coalesce(convert(varchar(255), src.Local_Currency_Code),'') + '",' + 
						'"Position_Type":"' + Coalesce(convert(varchar(50), src.Position_Type),'') + '" ' + 
						'"Source_Status_Code":"' + Coalesce(convert(varchar(50), src.Source_Status_Code),'') + '" ' + 
						'"Fair_Value_Level":"' + Coalesce(convert(varchar(50), src.Fair_Value_Level),'') + '" ' + 
						'"Price_Type":"' + Coalesce(convert(varchar(50), src.Price_Type),'') + '" ' + 
						'}'
					Else 
						null
					End 
					,@ETL_Load_Key
					,src.Load_DTS
					,src.Is_Src_Deleted
					,@LastUpdateUser
					,@SourceSystem

		From (
				SELECT Effective_Date
					  ,[Report_Freq_Code]
					  ,Account_Number
					  ,Security_Alias_Identifier
					  ,Base_Currency_Code
					  ,Local_Currency_Code
					  ,Position_Type
					  ,[Fair_Value_Level]
					  ,[Price_Type]
					  ,Case When [Fair_Value_Level] in ('1','2','3') Then Fair_Value_Level Else 'NA' End fair_value_level_code
					  ,Case When [Price_Type] in ('Price', 'Px Bid', 'Px Mid', 'Px Last') Then [Price_Type] Else 'NA' End Price_Type_Code 
					  ,Case When [Report_Freq_Code] = 'D' Then 'PRELIM_UNAUD'
					        When [Report_Freq_Code] = 'M' Then 'MTH_END_CLOSED'
					   Else 'NA' End Source_Status_Code

						,Last_Price_Change_Date AS Last_Priced_Date
						,Market_Value_Base AS Market_Value_Base_Amount
						,Market_Value_Local AS Market_Value_Local_Amount
						,Market_Value_Base_With_Accruals AS Market_Value_With_Accruals_Base_Amount
						,Market_Value_Local_With_Accruals AS Market_Value_With_Accruals_Local_Amount

						,Accrued_Income_Base AS Accrued_Interest_Base_Amount
						,Accrued_Income_Local AS Accrued_Interest_Local_Amount
						,Price_Base AS Price_Base_Amount
						,Price_Local AS Price_Local_Amount
						,Days_Price_Unchanged AS Price_Unchanged_Daycount
						,Book_Cost_Base AS Book_Cost_Base_Amount
						,Book_Cost_Local AS Book_Cost_Local_Amount
						,NULL AS Book_Unit_Cost_Base_Amount
						,NULL AS Book_Unit_Cost_Local_Amount
						,Notional_Cost_Base AS Notional_Cost_Base_Amount
						,Notional_Cost_Local AS Notional_Cost_Local_Amount
						,Notional_Value_Base AS Notional_Value_Base_Amount
						,Notional_Value_Local AS Notional_Value_Local_Amount
						,Original_Face AS Original_Face_Amount
						,Amortization_Base_Life_to_Date AS Life_to_Date_Amortization_Base_Amount
						,case when [Asset_Type_Code] = 'FT' Then Shares_Par*Contract_Size Else Shares_Par End AS Share_Or_Par_Amount
						,case when [Asset_Type_Code] = 'FT' Then Shares_Par Else null End AS Contract_Number
						,case when [Asset_Type_Code] = 'FT' Then Unrealized_Gain_Loss_on_Cleared_Derivatives_Base else Unrealized_Security_Gain_Loss_Base End AS Unrealized_Gain_Loss_Base_Amount
						,case when [Asset_Type_Code] = 'FT' Then Unrealized_Gain_Loss_on_Cleared_Derivatives_Local else Unrealized_Security_Gain_Loss_Local End AS Unrealized_Gain_Loss_Local_Amount
						,case when [Asset_Type_Code] = 'FT' Then Unrealized_Gain_Loss_on_Cleared_Derivatives_Base else Total_Unrealized_Gain_Loss_Base End AS Net_Realized_Gain_Loss_Base_Amount
						,Unrealized_Currency_Gain_Loss_Base AS Unrealized_Currency_Gain_Loss_Base_Amount
						,Unsettled_Variation_Margin_Base AS Unsettled_Variation_Margin_Base_Amount
						,Unsettled_Variation_Margin_Local AS Unsettled_Variation_Margin_Local_Amount
						,Settled_Variation_Margin_Base AS Settled_Variation_Margin_Base_Amount
						,Settled_Variation_Margin_Local AS Settled_Variation_Margin_Local_Amount
						,Net_Income_Receivable_Base AS Net_Income_Receivable_Base_Amount
						,Net_Income_Receivable_Local AS Net_Income_Receivable_Local_Amount
						,case when coalesce(Exchange_Rate,0) = 0 then null else 1/Exchange_Rate End AS FX_Local_to_Base_Rate
						,Exchange_Rate AS FX_Base_to_Local_Rate

					  ,Record_Created_DT Load_DTS
					  ,Last_Update_DT
					  ,Hash_Diff
					  ,Source_Deleted_Flag Is_Src_Deleted
					  ,row_number() Over(Order By (select 1)) rn
				    FROM   EDW_Raw.BNYM_SSE_STAR_Asset_and_Accrual_Summary P
                    WHERE Last_Update_DT > Coalesce(@lastLoadeDTS, '1900-01-01')
					and [Taxlot_Summary_Indicator] = 'Summary Level'
					and [Cash_Type_Indicator] = 'Traded'
			) src
			Left Join EDP_Common.Dim_Portfolio p on src.Account_Number = p.Portfolio_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31') 
			Left Join (
				Select BNYM_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
				From [EDP_Common].[Dim_Security] 
				where Is_Current_Flag = 1
				group By BNYM_ID
			) sec on src.Security_Alias_Identifier = sec.BNYM_ID
			Left Join [EDP_Common].[Dim_Security] s on sec.IMCO_Security_Alias_ID = s.IMCO_Security_Alias_ID and src.Effective_Date between s.Effective_Start_Datetime and coalesce(s.Effective_End_Datetime, '9999-12-31') 
			Left Join [EDP_Common].[Dim_Currency] bc on src.Base_Currency_Code = bc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Currency] lc on src.Local_Currency_Code = lc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Dataset_Frequency] freq on src.[Report_Freq_Code] = freq.[Dataset_Frequency_Indicator]
			Left Join [EDP_Common].[Dim_Source_Record_Status] ss on src.Source_Status_Code = ss.Source_Status_Code
			Left Join [EDP_Common].[Dim_Long_Short_Direction] lsd on src.Position_Type = lsd.Long_Short_Direction_Indicator
			Left Join [EDP_Common].Dim_Reference_Position rp on src.fair_value_level_code = rp.fair_value_level_code and src.Price_Type_Code = rp.Price_Type_Code


		-- Fix -1 for security key, portfolio key in fact table
		exec EDW_DQ.EDP_Eagle_Nexen_Fix_Missing_Keys 'EDP_Common', 'Fact_BNYM_Eagle_STAR_Position', 'Fact_BNYM_Eagle_STAR_Position_ID', 'PORT_SEC', '7', @Batch_DTS, @ETL_Load_Key


		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.[Fact_BNYM_Eagle_STAR_Position]
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_BNYM_Eagle_STAR_Position', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_BNYM_Eagle_STAR_Position', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_BNYM_Eagle_STAR_Position', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_BNYM_Eagle_STAR_Position', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END