﻿CREATE PROC [EDP_Common].[SFTP_EDP_StateStreet_Fact_SS_MCH_General_Ledger_Summary] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()
/**
select * from [EDP_Common].Fact_SS_MCH_General_Ledger_Summary
Exec [EDP_Common].[SFTP_EDP_StateStreet_Fact_SS_MCH_General_Ledger_Summary]'DELTA','1900-01-01',-1
select * from [EDP_Common].Fact_SS_MCH_General_Ledger_Summary
**/
	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)
	
	Begin Try


		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max([Last_Update_Datetime]), '1900-01-01'), 
		       @currentMaxId = coalesce(max([Fact_SS_MCH_General_Ledger_Summary_ID]), 0)
		From [EDP_Common].[Fact_SS_MCH_General_Ledger_Summary]

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'MySS-SS-MCH', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		INSERT INTO [EDP_Common].Fact_SS_MCH_General_Ledger_Summary
           (  [Fact_SS_MCH_General_Ledger_Summary_ID]
			  ,[Dim_Effective_Date_Key]
			  ,[Dim_Dataset_Frequency_Key]
			  ,[Dim_Portfolio_Key]
			  ,[Dim_Currency_Base_Key]

			  ,[Dim_General_Ledger_Category_Key]
			  ,[Dim_Accounting_Share_Class_Key]

			  ,[Dim_Reference_Trial_Balance_Key]

			  ,[Dim_Source_Status_Key]
			  ,[Summary_Category_Description]

			  ,[General_Ledger_Currency_Local_Code]
			  ,[Reporting_Basis_Indicator]
			  ,[Reporting_Level_Indicator]
			  
			  ,[Last_Update_Datetime]
			  ,Load_Datetime

			  ,[Beginning_Balance_Amount]
			  ,[Net_Debit_Activity_Amount]
			  ,[Net_Credit_Activity_Amount]
			  ,[Net_Activity_Amount]
			  ,[Ending_Balance_Amount]

			  ,[Source_Update_Datetime]
			  ,Source_System_Code
			  ,Source_Deleted_Flag
			  ,[ETL_Load_Key]
			  ,[Load_Detail_Description]
			  ,Last_Update_User

		)
		SELECT  @currentMaxId + row_number() Over(Order By (select 1)), * FROM 
		(SELECT     DISTINCT
					convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Effective_Date_Key]
					,Coalesce(freq.Dim_Dataset_Frequency_Key, -1) Dim_Dataset_Frequency_Key
					,Coalesce(p.Dim_Portfolio_Key, -1) [Dim_Portfolio_Key]
					,Coalesce(bc.Dim_Currency_Key, -1) Dim_Currency_Base_Key

					,Coalesce(glc.Dim_General_Ledger_Category_Key, -1) Dim_General_Ledger_Category_Key
					,-1 Dim_Accounting_Share_Class_Key

					,Coalesce(Dim_Reference_Trial_Balance_Key, -1) Dim_Reference_Trial_Balance_Key

					,Coalesce(ss.Dim_Source_Status_Key, -1) Dim_Source_Status_Key
					,TB_Line_Description Summary_Category_Description

					,Local_Currency_Code 
					,Basis [Reporting_Basis_Indicator]
					,case when TB_Total_Line is null then 'NA'
					      when TB_Total_Line='Y' then 'Y'
						  when TB_Total_Line='N' then 'N'
				     else NULL End [Reporting_Level_Indicator]

					 ,src.Last_Update_DT
					 ,src.load_DTS

					  ,[TB_Starting_Balance]
					  ,[TB_Debit_Balance]
					  ,[TB_Credit_Balance]
					  ,[TB_Net_Activity_Amount]
					  ,[TB_Ending_Balance]

					,null [Source_Update_Datetime]
					,@SourceSystem AS Source_System_Code
					,src.Is_Src_Deleted
					,@ETL_Load_Key AS ETL_Load_Key
					,Case When freq.Dim_Dataset_Frequency_Key is null or ss.Dim_Source_Status_Key is null or p.Dim_Portfolio_Key is null 
							or glc.Dim_General_Ledger_Category_Key is null or bc.Dim_Currency_Key is null
							or ss.Dim_Source_Status_Key is null or glc.Dim_General_Ledger_Category_Key is null or 1=1
					 Then
						 '{' + 
						'"Report_Freq_Code": "' + Coalesce(convert(varchar(255), src.[Report_Freq_Code]),'') + '",' + 
						'"Fund": "' + Coalesce(convert(varchar(255), src.Fund),'') + '",' + 
						'"Financial_Statement_Currency":"' + Coalesce(convert(varchar(255), src.Financial_Statement_Currency),'') + '",' + 
						'"Local_Currency_Code":"' + Coalesce(convert(varchar(255), src.Local_Currency_Code),'') + '",' + 
						'"Category":"' + Coalesce(convert(varchar(255),  X.EDP_Code_Value),'') + '",' + 
						'"TB_Line_Description":"' + Coalesce(convert(varchar(50), src.TB_Line_Description),'') + '" ' + 
						'"TB_Page_Number":"' + Coalesce(convert(varchar(50), src.TB_Page_Number),'') + '" ' + 
						'"TB_Line_Number":"' + Coalesce(convert(varchar(50), src.TB_Line_Number),'') + '" ' + 
		  			    '"Source_Status_Code":"' + Coalesce(convert(varchar(50), src.Source_Status_Code),'') + '" ' + 
						'}'
					Else 
						null
					End AS [Load_Detail_Description]
					,@LastUpdateUser AS Last_Update_User
					
		From (
				SELECT 
					  [Period_End_Date] as Effective_Date
					  ,[Period_Start_Date]
					  ,[Report_Freq_Code]
					  ,[Fund]
					  ,[Basis]
					  ,[GL_Account_Number]
					  ,[Financial_Statement_Currency]
					  ,[Local_Currency_Code]

					  ,[TB_Starting_Balance]
					  ,[TB_Debit_Balance]
					  ,[TB_Credit_Balance]
					  ,[TB_Net_Activity_Amount]
					  ,[TB_Ending_Balance]
					  ,[TB_Line_Description]
					  ,[TB_Page_Number] 
					  ,[TB_Line_Number]
					  ,[TB_Total_Line]

					  ,'PRELIM_UNAUD' Source_Status_Code

					  ,Record_Created_DT Load_DTS
					  ,Last_Update_DT
					  ,Hash_Diff
					  ,Source_Deleted_Flag Is_Src_Deleted
					  ,row_number() Over(Order By (select 1)) rn
				    FROM [EDW_Raw].[SS_MySS_MCH_WTB_General_Ledger] P
                    WHERE Last_Update_DT > Coalesce(@lastLoadeDTS, '1900-01-01')
					
			) src
			Left Join (
				Select State_Street_Portfolio_ID, min(Portfolio_Id) Portfolio_Id
				From EDP_Common.Dim_Portfolio 
				where Is_Current_Flag = 1
				Group By State_Street_Portfolio_ID
			) pc on src.Fund = pc.State_Street_Portfolio_ID
			Left Join EDP_Common.Dim_Portfolio p on pc.Portfolio_Id = p.Portfolio_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31 00:00:00.0000000') 
			Left Join [EDP_Common].[Dim_Currency] bc on src.Financial_Statement_Currency = bc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Dataset_Frequency] freq on src.[Report_Freq_Code] = freq.[Dataset_Frequency_Indicator]
			Left Join (
				Select Origination_Source_Code_Value, Max(EDP_Code_Value) EDP_Code_Value
				From  EDP_Common.[XRef_Source_Code_EDP_Code_Mapping]
				where Domain_Code_Type = 'FundAcct_General-Ledger-Category'
				and Origination_Source_System_Code = 'MySS-SS-MCH'
				Group By Origination_Source_Code_Value
			) X ON Coalesce(src.GL_Account_Number, 'NA') like ''+ X.Origination_Source_Code_Value +''
			Left Join [EDP_Common].[Dim_General_Ledger_Category] glc on X.EDP_Code_Value = glc.General_Ledger_Category_Code
			--Left Join [EDP_Common].[Dim_General_Ledger_Account] glc on src.GL_Account_Number = glc.General_Ledger_Account_ID and src.Effective_Date between glc.Effective_Start_Datetime and coalesce(glc.Effective_End_Datetime, '9999-12-31') 
			left join [EDP_Common].[Dim_Reference_Trial_Balance] rtb on src.[TB_Line_Description] = rtb.[Trial_Balance_Line_Description_Code] AND
														 src.[TB_Page_Number] = rtb.[Trial_Balance_Reporting_Page_Number] AND
														 src.[TB_Line_Number] = rtb.[Trial_Balance_Reporting_Line_Number] AND
														 '-1' = [Trial_Balance_Reporting_Line_Item_Type_Number]
			Left Join [EDP_Common].[Dim_Source_Record_Status] ss on src.Source_Status_Code = ss.Source_Status_Code) AS RES

		-- Fix -1 for portfolio key in fact table
		exec EDW_DQ.[EDP_Eagle_SS_Fix_Missing_Keys] 'EDP_Common', 'Fact_SS_MCH_General_Ledger_Summary', 'Fact_SS_MCH_General_Ledger_Summary_ID', 'PORT', '7', @Batch_DTS, @ETL_Load_Key

		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.[Fact_SS_MCH_General_Ledger_Summary]
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_General_Ledger_Summary', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_General_Ledger_Summary', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_General_Ledger_Summary', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_General_Ledger_Summary', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END