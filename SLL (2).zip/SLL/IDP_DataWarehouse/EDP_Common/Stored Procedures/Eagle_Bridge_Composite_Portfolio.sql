﻿CREATE PROC [EDP_Common].[Eagle_Bridge_Composite_Portfolio] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)
	
	Begin Try
		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max(Last_Update_Datetime), '1900-01-01')
		From EDP_Common.Bridge_Composite_Portfolio

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'IDW-PERF', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		-- This is to get start_date and end_date based on Effective_Date by Entity_ID
		IF OBJECT_ID('tempdb..#temp_src_Comp_Portfolio_EffectiveDate') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_Comp_Portfolio_EffectiveDate
		END

		create table #temp_src_Comp_Portfolio_EffectiveDate
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as 
				SELECT ENTITY_ID, EFFECTIVE_DATE as Start_Date, coalesce(LEAD(EFFECTIVE_DATE,1) OVER (PARTITION BY ENTITY_ID ORDER BY EFFECTIVE_DATE), '9999-12-31') as End_Date
				FROM (SELECT Entity_Id, Effective_Date
						FROM PSA.V_Eagle_Entity_Detail_History 
						Where ENTITY_TYPE = 'COMP' and (SRC_INTFC_INST = -1 OR SRC_INTFC_INST IS NULL) and LIST_ORDER=0
						Group by Entity_Id, Effective_Date) as EE

		-- This is the main logic to populate the bridge table
		IF OBJECT_ID('tempdb..#temp_src_Composite_Portfolio') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_Composite_Portfolio
		END

		create table #temp_src_Composite_Portfolio
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as    SELECT Dim_Effective_Date_Key
						  ,Dim_Parent_Portfolio_Key
						  ,Dim_Child_Portfolio_Key
						  ,Portfolio_Relationship_Type_Code
						  ,Last_Update_Datetime
						  ,Source_Deleted_Flag
						  ,Source_System_Code
						  ,Load_Detail_Description
						  ,ETL_Load_Key
						  ,Last_Update_User
				FROM (Select
					 D.Dim_Date_Key as Dim_Effective_Date_Key
					,Coalesce(p.Dim_Portfolio_Key, -1) as Dim_Parent_Portfolio_Key 
					,Coalesce(c.Dim_Portfolio_Key, -1) as Dim_Child_Portfolio_Key
					,'COMP' as Portfolio_Relationship_Type_Code
					,@today as Last_Update_Datetime
					,src.Is_Src_Deleted as Source_Deleted_Flag
					,@SourceSystem as Source_System_Code
					, '{' + 
						'"Parent_Portfolio_Id": "' + convert(varchar(50), p.Portfolio_Id) + '",' + 
						'"Child_Portfolio_Id": "' + convert(varchar(50), c.Portfolio_Id) + '",' + 
						'"Entity_Id":"' + convert(varchar(50), src.Entity_Id) + '",' + 
						'"ENTITY_DETAIL_ID":"' + convert(varchar(50), src.ENTITY_DETAIL_ID) + '"' + 
						'}' as Load_Detail_Description
					,@ETL_Load_Key as ETL_Load_Key
					,@LastUpdateUser as Last_Update_User
					,row_number() Over(Order By (select 1)) rn
				from PSA.V_Eagle_Entity_Detail_History src
				Left Join EDP_Common.Dim_Portfolio p on src.Entity_Id = p.Portfolio_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31') 
				Left Join EDP_Common.Dim_Portfolio c on src.Entity_Detail_Id = c.Portfolio_Id and src.Effective_Date between c.Effective_Start_Datetime and coalesce(c.Effective_End_Datetime, '9999-12-31') 
				Join #temp_src_Comp_Portfolio_EffectiveDate tmp on src.Entity_Id=tmp.Entity_Id and src.Effective_Date = tmp.Start_Date
				Join EDP_Common.Dim_Date D on D.Date >= tmp.Start_Date and D.Date < case tmp.End_Date When '9999-12-31' Then getdate() Else tmp.End_Date End	
				where src.ENTITY_TYPE = 'COMP' and (src.SRC_INTFC_INST = -1 or src.SRC_INTFC_INST is null) and src.LIST_ORDER=0) SRC
			--GROUP BY  Dim_Effective_Date_Key,Dim_Parent_Portfolio_Key,Dim_Child_Portfolio_Key

		-- Main Process - insert into target bridge table if rows do not exist
		INSERT INTO EDP_Common.Bridge_Composite_Portfolio
			(Dim_Effective_Date_Key
			,Dim_Parent_Portfolio_Key
			,Dim_Child_Portfolio_Key
			,Portfolio_Relationship_Type_Code
			,Last_Update_Datetime
			,Source_Deleted_Flag
			,Source_System_Code
			,Load_Detail_Description
			,ETL_Load_Key
			,Last_Update_User
		    )
				Select *
				from #temp_src_Composite_Portfolio s
				where not exists (
					Select 1
					From EDP_Common.Bridge_Composite_Portfolio t
					where s.Dim_Effective_Date_Key = t.Dim_Effective_Date_Key 
					and s.Dim_Parent_Portfolio_Key = t.Dim_Parent_Portfolio_Key 
					and s.Dim_Child_Portfolio_Key = t.Dim_Child_Portfolio_Key 
					and t.Source_Deleted_Flag = 0)
				and s.Source_Deleted_Flag = 0
				 
		/* expire the deleted relationship */
		Update t
		Set Last_Update_Datetime = @today, Source_Deleted_Flag = 1, ETL_Load_Key = @ETL_Load_Key
		From EDP_Common.Bridge_Composite_Portfolio t
		Where t.Source_Deleted_Flag = 0 and not exists
		(
			Select 1
			From #temp_src_Composite_Portfolio s
			Where s.Dim_Effective_Date_Key = t.Dim_Effective_Date_Key and  s.Dim_Parent_Portfolio_Key = t.Dim_Parent_Portfolio_Key and  s.Dim_Child_Portfolio_Key = t.Dim_Child_Portfolio_Key
		)

		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.Bridge_Composite_Portfolio
		Where Last_Update_Datetime = @today and Source_Deleted_Flag = 0

		Select @rowsExpired = Count(*) 
		From EDP_Common.Bridge_Composite_Portfolio
		Where Last_Update_Datetime = @today and Source_Deleted_Flag = 1

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Bridge_Composite_Portfolio', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Bridge_Composite_Portfolio', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Bridge_Composite_Portfolio', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Bridge_Composite_Portfolio', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END