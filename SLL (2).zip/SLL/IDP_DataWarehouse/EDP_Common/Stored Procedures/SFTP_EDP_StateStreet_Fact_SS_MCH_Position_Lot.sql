﻿CREATE PROC [EDP_Common].[SFTP_EDP_StateStreet_Fact_SS_MCH_Position_Lot] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)


	Begin Try

		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max([Last_Update_Datetime]), '1900-01-01'), 
		       @currentMaxId = coalesce(max([Fact_SS_MCH_Position_Lot_ID]), 0)
		From [EDP_Common].Fact_SS_MCH_Position_Lot

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'MySS-SS-MCH', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		INSERT INTO [EDP_Common].Fact_SS_MCH_Position_Lot
           (  [Fact_SS_MCH_Position_Lot_ID]
			  ,[Dim_Effective_Date_Key]
			  ,[Dim_Dataset_Frequency_Key]
			  ,[Dim_Portfolio_Key]
			  ,[Dim_Security_Key]
			  ,[Dim_Currency_Base_Key]
			  ,[Dim_Currency_Local_Key]
			  ,[Dim_Long_Short_Direction_Key]
			  ,[Dim_Reference_Position_Key]
			  ,[Dim_Source_Status_Key]

				,Taxation_Lot_Level_ID
				,Trade_ID
				,Trade_Date
				,Last_Priced_Date
				,Market_Value_Base_Amount
				,Market_Value_Local_Amount
				,Market_Value_With_Accruals_Base_Amount
				,Market_Value_With_Accruals_Local_Amount
				,Accrued_Interest_Base_Amount
				,Accrued_Interest_Local_Amount
				,Price_Base_Amount
				,Price_Local_Amount
				,Price_Unchanged_Daycount
				,Book_Cost_Base_Amount
				,Book_Cost_Local_Amount
				,Book_Unit_Cost_Base_Amount
				,Book_Unit_Cost_Local_Amount
				,Notional_Cost_Base_Amount
				,Notional_Cost_Local_Amount
				,Notional_Value_Base_Amount
				,Notional_Value_Local_Amount
				,Original_Face_Amount
				,Life_To_Date_Amortization_Base_Amount
				,Share_Or_Par_Amount
				,Contract_Number
				,Unrealized_Gain_Loss_Base_Amount
				,Unrealized_Gain_Loss_Local_Amount
				,Net_Realized_Gain_Loss_Base_Amount
				,Unrealized_Currency_Gain_Loss_Base_Amount
				,Unsettled_Variation_Margin_Base_Amount
				,Unsettled_Variation_Margin_Local_Amount
				,Settled_Variation_Margin_Base_Amount
				,Settled_Variation_Margin_Local_Amount
				,Net_Income_Receivable_Base_Amount
				,Net_Income_Receivable_Local_Amount
				,FX_Local_To_Base_Rate
				,FX_Base_To_Local_Rate
				,Contractual_Settlement_Date

			  ,[Last_Update_Datetime]
			  ,[Load_Datetime]
			  ,[Source_Update_Datetime]
			  ,[Source_System_Code]
			  ,[Source_Deleted_Flag]
			  ,[ETL_Load_Key]
			  ,[Load_Detail_Description]
			  ,[Last_Update_User]
		)
		SELECT      @currentMaxId + rn
					,convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Effective_Date_Key]
					,Coalesce(freq.Dim_Dataset_Frequency_Key, -1) Dim_Dataset_Frequency_Key
					,Coalesce(p.Dim_Portfolio_Key, -1) [Dim_Portfolio_Key]
					,Coalesce(s.Dim_Security_Key, -1) Dim_Security_Key
					,Coalesce(bc.Dim_Currency_Key, -1) Dim_Currency_Base_Key
					,Coalesce(lc.Dim_Currency_Key, -1) Dim_Currency_Local_Key
					,Coalesce(lsd.Dim_Long_Short_Direction_Key, -1) Dim_Long_Short_Direction_Key
					,-1 Dim_Reference_Position_Key
					,Coalesce(ss.Dim_Source_Status_Key, -1) Dim_Source_Status_Key

					,Taxation_Lot_Level_ID
					,Trade_ID
					,Trade_Date
					,Last_Priced_Date
					,Market_Value_Base_Amount
					,Market_Value_Local_Amount
					,Market_Value_With_Accruals_Base_Amount
					,Market_Value_With_Accruals_Local_Amount
					,Accrued_Interest_Base_Amount
					,Accrued_Interest_Local_Amount
					,Price_Base_Amount
					,Price_Local_Amount
					,Price_Unchanged_Daycount
					,Book_Cost_Base_Amount
					,Book_Cost_Local_Amount
					,Book_Unit_Cost_Base_Amount
					,Book_Unit_Cost_Local_Amount
					,Notional_Cost_Base_Amount
					,Notional_Cost_Local_Amount
					,Notional_Value_Base_Amount
					,Notional_Value_Local_Amount
					,Original_Face_Amount
					,Life_To_Date_Amortization_Base_Amount
					,Share_Or_Par_Amount
					,Contract_Number
					,Unrealized_Gain_Loss_Base_Amount
					,Unrealized_Gain_Loss_Local_Amount
					,Net_Realized_Gain_Loss_Base_Amount
					,Unrealized_Currency_Gain_Loss_Base_Amount
					,Unsettled_Variation_Margin_Base_Amount
					,Unsettled_Variation_Margin_Local_Amount
					,Settled_Variation_Margin_Base_Amount
					,Settled_Variation_Margin_Local_Amount
					,Net_Income_Receivable_Base_Amount
					,Net_Income_Receivable_Local_Amount
					,FX_Local_To_Base_Rate
					,FX_Base_To_Local_Rate
					,Contractual_Settlement_Date

					,src.Last_Update_DT [Last_Update_Datetime]
					,src.Load_DTS [Load_Datetime]
					,null [Source_Update_Datetime]
					,@SourceSystem
					,src.Is_Src_Deleted
					,@ETL_Load_Key

					,Case When freq.Dim_Dataset_Frequency_Key is null or ss.Dim_Source_Status_Key is null or p.Dim_Portfolio_Key is null 
							or Coalesce(Coalesce(s.Dim_Security_Key, s_isin.Dim_Security_Key), s_ticker.Dim_Security_Key) is null or bc.Dim_Currency_Key is null
							or lc.Dim_Currency_Key is null or lsd.Dim_Long_Short_Direction_Key is null Then
						 '{' + 
						'"Report_Freq_Code": "' + Coalesce(convert(varchar(255), src.[Report_Freq_Code]),'') + '",' + 
						'"Fund": "' + Coalesce(convert(varchar(255), src.Fund),'') + '",' + 
						'"CUSIP_Number":"' + Coalesce(convert(varchar(255), src.CUSIP_Number),'') + '",' + 
						'"ISIN_Number":"' + Coalesce(convert(varchar(255), src.ISIN_Number),'') + '",' + 
						'"Bloomberg_Ticker":"' + Coalesce(convert(varchar(255), src.Bloomberg_Ticker),'') + '",' + 
						'"Base_Currency_Code":"' + Coalesce(convert(varchar(255), src.Base_Currency_Code),'') + '",' + 
						'"Local_Currency_Code":"' + Coalesce(convert(varchar(255), src.Local_Currency_Code),'') + '",' + 
						'"Long_Short_Direction_Indicator":"' + Coalesce(convert(varchar(50), src.Position_Flag),'') + '" ' + 
						'}'
					Else 
						null
					End 
				
					,@LastUpdateUser

		From (
				SELECT Period_End_Date Effective_Date
					  ,[Report_Freq_Code]
					  ,Fund
					  ,CUSIP_Number
					  ,ISIN_Number
					  ,Bloomberg_Ticker
					  ,Base_Currency_Code
					  ,Local_Currency_Code
					  ,Position_Flag
					  ,'PRELIM_UNAUD' Source_Status_Code

					,Lot_Number as Taxation_Lot_Level_ID
					,Trade_ID as Trade_ID
					,Trade_Date as Trade_Date
					,Date_Last_Priced as Last_Priced_Date
					,Base_Market_Value as Market_Value_Base_Amount
					,Local_Market_Value as Market_Value_Local_Amount
					,Base_Total_Market_Value as Market_Value_With_Accruals_Base_Amount
					,Local_Total_Market_Value as Market_Value_With_Accruals_Local_Amount
					,Base_Accrued_Interest as Accrued_Interest_Base_Amount
					,Local_Accrued_Interest as Accrued_Interest_Local_Amount
					,Base_Price_Amount as Price_Base_Amount
					,Local_Price_Amount as Price_Local_Amount
					,null as Price_Unchanged_Daycount
					,Base_Original_Cost as Book_Cost_Base_Amount
					,Local_Original_Cost as Book_Cost_Local_Amount
					,Base_Unit_Cost as Book_Unit_Cost_Base_Amount
					,Local_Unit_Cost as Book_Unit_Cost_Local_Amount
					,Base_Notional_Cost as Notional_Cost_Base_Amount
					,Local_Notional_Cost as Notional_Cost_Local_Amount
					,Base_Current_Notional_Value as Notional_Value_Base_Amount
					,Local_Current_Notional_Value as Notional_Value_Local_Amount
					,Face_Amount as Original_Face_Amount
					,null as Life_To_Date_Amortization_Base_Amount
					,Shares_Par_Value as Share_Or_Par_Amount
					,case when coalesce(multiplier,0) = 0 then null 
					 else 
						case when Asset_Class='FUTURE' then Shares_Par_Value/multiplier
						else Shares_Par_Value  end
					 end as Contract_Number
					,Base_Unrealized_Gain_Loss Unrealized_Gain_Loss_Base_Amount
					,Local_Unrealized_Gain_Loss Unrealized_Gain_Loss_Local_Amount
					,null as Net_Realized_Gain_Loss_Base_Amount
					,Base_Unrealized_Currency_Gain_Loss as Unrealized_Currency_Gain_Loss_Base_Amount
					,null as Unsettled_Variation_Margin_Base_Amount
					,null as Unsettled_Variation_Margin_Local_Amount
					,null as Settled_Variation_Margin_Base_Amount
					,null as Settled_Variation_Margin_Local_Amount
					,null as Net_Income_Receivable_Base_Amount
					,null as Net_Income_Receivable_Local_Amount
					,Exchange_Rate as FX_Local_To_Base_Rate
					,Exchange_Rate as FX_Base_To_Local_Rate
					,Contractual_Settlement_Date as Contractual_Settlement_Date

					  ,Record_Created_DT Load_DTS
					  ,Last_Update_DT
					  ,Hash_Diff
					  ,Source_Deleted_Flag Is_Src_Deleted
					  ,row_number() Over(Order By (select 1)) rn
				    FROM   EDW_Raw.SS_MySS_MCH_Tax_Lot_Level_Holdings P
                    WHERE Last_Update_DT > Coalesce(@lastLoadeDTS, '1900-01-01')
			) src
			Left Join EDP_Common.Dim_Portfolio p on src.Fund = p.Portfolio_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31') 
			Left Join (
				Select State_Street_CUSIP_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
				From [EDP_Common].[Dim_Security] 
				where Is_Current_Flag = 1
				group By State_Street_CUSIP_ID
			) sec on src.CUSIP_Number = sec.State_Street_CUSIP_ID
			Left Join [EDP_Common].[Dim_Security] s on sec.IMCO_Security_Alias_ID = s.IMCO_Security_Alias_ID and src.Effective_Date between s.Effective_Start_Datetime and coalesce(s.Effective_End_Datetime, '9999-12-31') 

			Left Join (
				Select ISIN_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
				From [EDP_Common].[Dim_Security] 
				where Is_Current_Flag = 1
				group By ISIN_ID
			) sec_isin on src.ISIN_Number = sec_isin.ISIN_ID
			Left Join [EDP_Common].[Dim_Security] s_isin on sec_isin.IMCO_Security_Alias_ID = s_isin.IMCO_Security_Alias_ID and src.Effective_Date between s_isin.Effective_Start_Datetime and coalesce(s_isin.Effective_End_Datetime, '9999-12-31') 

			Left Join (
				Select Ticker_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
				From (
					Select Ticker_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
					From [EDP_Common].[Dim_Security] 
					Where BNYM_ID is not null and Is_Current_Flag = 1
					group By Ticker_ID

					union all

					Select Ticker_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
					From [EDP_Common].[Dim_Security] 
					Where BNYM_ID is null and Is_Current_Flag = 1
					group By Ticker_ID
				) si 
				Where Ticker_ID is not null
				Group By Ticker_ID 
			) sec_ticker on src.Bloomberg_Ticker = sec_ticker.Ticker_ID
			Left Join [EDP_Common].[Dim_Security] s_ticker on sec_ticker.IMCO_Security_Alias_ID = s_ticker.IMCO_Security_Alias_ID and src.Effective_Date between s_ticker.Effective_Start_Datetime and coalesce(s_ticker.Effective_End_Datetime, '9999-12-31') 

			Left Join [EDP_Common].[Dim_Currency] bc on src.Base_Currency_Code = bc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Currency] lc on src.Local_Currency_Code = lc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Dataset_Frequency] freq on src.[Report_Freq_Code] = freq.[Dataset_Frequency_Indicator]
			Left Join [EDP_Common].[Dim_Source_Record_Status] ss on src.Source_Status_Code = ss.Source_Status_Code
			Left Join [EDP_Common].[Dim_Long_Short_Direction] lsd on src.Position_Flag = lsd.Long_Short_Direction_Indicator

		-- Fix -1 for security key, portfolio key in fact table
		exec EDW_DQ.[EDP_Eagle_SS_Fix_Missing_Keys] 'EDP_Common', 'Fact_SS_MCH_Position_Lot', 'Fact_SS_MCH_Position_Lot_ID', 'PORT_SEC', '7', @Batch_DTS, @ETL_Load_Key

		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.[Fact_SS_MCH_Position_Lot]
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_Position_Lot', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_Position_Lot', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_Position_Lot', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_Position_Lot', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END