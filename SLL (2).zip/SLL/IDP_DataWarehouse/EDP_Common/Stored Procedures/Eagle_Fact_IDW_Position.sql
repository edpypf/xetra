﻿CREATE PROC [EDP_Common].[Eagle_Fact_IDW_Position] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN


	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
            @loadStartTime datetime2,
            @loadEndTime datetime2,
            @SourceSystem varchar(255),
            @LastUpdateUser varchar(255)
	
	Begin Try

		-- get last loaded dts in current fact table
		Select	@lastLoadeDTS = coalesce(max(Load_Datetime), '1900-01-01'),
		        @currentMaxId = coalesce(max(Fact_IDW_Position_ID), 0)
		From	EDP_Common.Fact_IDW_Position

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
                From EDW_ETL.ETL_Load
                Where ETL_Load_Key = @ETL_Load_Key

        Select @SourceSystem = 'IDW-POS', @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')
        -- Set load start time
        Select @loadStartTime = @today

		INSERT INTO EDP_Common.Fact_IDW_Position
		(
		   Fact_IDW_Position_ID
		  ,Dim_Effective_Date_Key
		  ,Dim_Dataset_Frequency_Key
		  ,Dim_Portfolio_Key
		  ,Dim_Security_Key
		  ,Dim_Currency_Base_Key
		  ,Dim_Currency_Local_Key
		  ,Dim_Long_Short_Direction_Key
		  ,Dim_Reference_Position_Key
		  ,Dim_Source_Status_Key
		  ,IDW_Position_Detail_ID
		  ,Last_Update_Datetime
		  ,Load_Datetime
		  ,Last_Priced_Date
		  ,Market_Value_Base_Amount
		  ,Market_Value_Local_Amount
		  ,Market_Value_With_Accruals_Base_Amount
		  ,Market_Value_With_Accruals_Local_Amount
		  ,Accrued_Interest_Base_Amount
		  ,Accrued_Interest_Local_Amount
		  ,Price_Base_Amount
		  ,Price_Local_Amount
		  ,Price_Unchanged_Daycount
		  ,Book_Cost_Base_Amount
		  ,Book_Cost_Local_Amount
		  ,Book_Unit_Cost_Base_Amount
		  ,Book_Unit_Cost_Local_Amount
		  ,Notional_Cost_Base_Amount
		  ,Notional_Cost_Local_Amount
		  ,Notional_Value_Base_Amount
		  ,Notional_Value_Local_Amount
		  ,Original_Face_Amount
		  ,Life_To_Date_Amortization_Base_Amount
		  ,Share_Or_Par_Amount
		  ,Contract_Number
		  ,Unrealized_Gain_Loss_Base_Amount
		  ,Unrealized_Gain_Loss_Local_Amount
		  ,Net_Realized_Gain_Loss_Base_Amount
		  ,Unrealized_Currency_Gain_Loss_Base_Amount
		  ,Unsettled_Variation_Margin_Base_Amount
		  ,Unsettled_Variation_Margin_Local_Amount
		  ,Settled_Variation_Margin_Base_Amount
		  ,Settled_Variation_Margin_Local_Amount
		  ,Net_Income_Receivable_Base_Amount
		  ,Net_Income_Receivable_Local_Amount
		  ,FX_Local_To_Base_Rate
		  ,FX_Base_To_Local_Rate
		  ,Source_Update_Datetime
		  ,Source_System_Code
		  ,Source_Deleted_Flag
		  ,ETL_Load_Key
		  ,Load_Detail_Description
		  ,Last_Update_User
		)
			SELECT	@currentMaxId + rn Fact_IDW_Position_ID
					,convert(int, convert(varchar(15), EFF_DT, 112)) as Dim_Effective_Date_Key
					,coalesce(f.Dim_Dataset_Frequency_Key, -1)				 as Dim_Dataset_Frequency_Key
					,coalesce(p.Dim_Portfolio_Key, -1)						 as Dim_Portfolio_Key
					,coalesce(s.Dim_Security_Key, -1)						 as Dim_Security_Key
					,coalesce(bc.Dim_Currency_Key, -1)						 as Dim_Base_Currency_Key
					,coalesce(lc.Dim_Currency_Key, -1)						 as Dim_Local_Currency_Key
					,coalesce(ls.Dim_Long_Short_Direction_Key, -1)			 as Dim_Long_Short_Direction_Key
					,-1														 as Dim_Reference_Position_Key
					,coalesce(ss.Dim_Source_Status_Key, -1)					 as Dim_Source_Status_Key
					,src.Position_Detail_ID				 					 as IDW_Position_Detail_ID
					,@today													 as Last_Update_Datetime
					,src.LOAD_DTS										     as Load_Datetime
					,NULL													 as Last_Priced_Date
					,MARKET_VALUE											 as Market_Value_Base_Amount
					,LOCAL_MARKET_VALUE										 as Market_Value_Local_Amount
					,MARKET_VALUE_INCOME									 as Market_Value_With_Accruals_Base_Amount
					,MARKET_VALUE_INCOME_LOCAL								 as Market_Value_With_Accruals_Local_Amount
					,NULL													 as Accrued_Interest_Base_Amount
					,NULL													 as Accrued_Interest_Local_Amount
					,Price_Base_Amount										 as Price_Base_Amount
					,PRICE													 as Price_Local_Amount
					,NULL													 as Price_Unchanged_Daycount
					,NULL													 as Book_Cost_Base_Amount
					,NULL													 as Book_Cost_Local_Amount
					,NULL													 as Book_Unit_Cost_Base_Amount
					,NULL													 as Book_Unit_Cost_Local_Amount
					,NULL													 as Notional_Cost_Base_Amount
					,NULL													 as Notional_Cost_Local_Amount
					,NULL													 as Notional_Value_Base_Amount
					,NULL													 as Notional_Value_Local_Amount
					,ORIG_FACE												 as Original_Face_Amount
					,NULL													 as Life_To_Date_Amortization_Base_Amount
					,Share_Or_Par_Amount									 as Share_Or_Par_Amount
					,Contract_Number										 as Contract_Number
					,NULL													 as Unrealized_Gain_Loss_Base_Amount
					,NULL													 as Unrealized_Gain_Loss_Local_Amount
					,NULL													 as Net_Realized_Gain_Loss_Base_Amount
					,UNREALIZED_CURR_GL										 as Unrealized_Currency_Gain_Loss_Base_Amount
					,NULL													 as Unsettled_Variation_Margin_Base_Amount
					,NULL													 as Unsettled_Variation_Margin_Local_Amount
					,NULL													 as Settled_Variation_Margin_Base_Amount
					,NULL													 as Settled_Variation_Margin_Local_Amount
					,NULL													 as Net_Income_Receivable_Base_Amount
					,NULL													 as Net_Income_Receivable_Local_Amount
					,FX_Local_to_Base_Rate									 as FX_Local_To_Base_Rate
					,MKT_EXCHANGE_RATE										 as FX_Base_To_Local_Rate
					,UPDATE_DATE											 as Source_Update_Datetime
					,'IDW-BNYM-STAR'										 as Source_System_Code
					,src.Is_Position_Deleted
					,@ETL_Load_Key
					,case when p.Dim_Portfolio_key is null  
				        or s.Dim_Security_Key is null  
						or bc.Dim_Currency_Key is null or lc.Dim_Currency_key is null then
						'{' + 
						'"Position_Id": "' + convert(varchar(50), src.Position_ID) + '",' + 
						'"Position_detail_Id": "' + convert(varchar(50), src.Position_detail_ID) + '",' + 
						'"Portfolio_Id": "' + convert(varchar(50), src.Portfolio_ID) + '",' + 
						'"Security_Alias":"' + convert(varchar(50), src.Security_Id) + '",' + 
						'"SRC_INTFC_INST":"' + convert(varchar(50), src.SRC_INTFC_INST) + '",' + 
						'"Base_Currency":"' + src.BASE_CURRENCY + '",' + 
						'"Local_Currency":"' + src.Local_CURRENCY + '"' + 
						'}'
					else 
						null
					End														  as Load_Detail_Description
					,@LastUpdateUser
					
					FROM (	SELECT	P.POSITION_ID, PD.POSITION_DETAIL_ID, PD.LOCAL_CURRENCY, PD.BASE_CURRENCY, PD.LONG_SHORT_IND, PD.UPDATE_DATE, PD.LOAD_DTS
									,case when I.Short_DESC = 'BNYM' then 'D' when I.Short_DESC = 'BNYM_ME' then 'M' else 'NA' end as Source_Frequency
									,case when I.Short_DESC = 'BNYM' then 'PRELIM_UNAUD' when I.Short_DESC = 'BNYM_ME' then 'MTH_END_CLOSED' else 'NA' end as Position_Source_Status_Code
									,P.ENTITY_ID as Portfolio_ID
									,coalesce(P.Effective_Date, PD.Effective_Date) as EFF_DT
									,cast(PD.Security_Alias as varchar) as Security_ID
									,MARKET_VALUE
									,LOCAL_MARKET_VALUE				
									,MARKET_VALUE_INCOME
									,MARKET_VALUE_INCOME_LOCAL	
									,case when coalesce(PRICE, 0)=0 or coalesce(MKT_EXCHANGE_RATE, 0)=0 then NULL else PRICE/MKT_EXCHANGE_RATE end as Price_Base_Amount
									,PRICE
									,ORIG_FACE
									,case when SM.investment_type = 'FT' then SM.TRADING_UNIT * SHARE_PAR_VALUE ELSE SHARE_PAR_VALUE end as Share_Or_Par_Amount
									,case when SM.investment_type = 'FT' then SHARE_PAR_VALUE ELSE NULL end as Contract_Number
									,case when coalesce(MKT_EXCHANGE_RATE,0)=0 then NULL else 1/MKT_EXCHANGE_RATE end as FX_Local_to_Base_Rate
									,UNREALIZED_CURR_GL
									,MKT_EXCHANGE_RATE
									,P.SRC_INTFC_INST
									,Case when P.Is_Src_Deleted = 1 then 1 else PD.Is_Src_Deleted End Is_Position_Deleted
									,row_number() Over(Order By (Select 1)) rn
							FROM	PSA.Eagle_Position_Detail  as PD
									INNER JOIN PSA.V_Eagle_Position		   as P ON P.POSITION_ID = PD.POSITION_ID
									INNER JOIN PSA.V_Eagle_Interfaces      as I  ON P.SRC_INTFC_INST = I.INSTANCE
									INNER JOIN PSA.V_Eagle_Entity          as E  ON P.ENTITY_ID = E.ENTITY_ID 
									INNER JOIN PSA.V_Eagle_Security_Master as SM on PD.Security_Alias = SM.Security_Alias
							WHERE	PD.Load_DTS > Coalesce(@lastLoadeDTS, '1900-01-01')
									AND I.Short_DESC IN ( 'BNYM', 'BNYM_ME')
									AND E.ENTITY_TYPE in ('PORT')
									AND P.Effective_Date <= @today
						 ) src
			Left Join EDP_Common.Dim_Portfolio p on src.Portfolio_Id = p.Portfolio_Id and src.EFF_DT between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31 00:00:00.0000000') 
			Left Join [EDP_Common].[Dim_Security] s on src.Security_ID = s.IMCO_Security_Alias_ID and src.EFF_DT between s.Effective_Start_Datetime and coalesce(s.Effective_End_Datetime, '9999-12-31') 
			Left Join [EDP_Common].[Dim_Currency] lc on src.LOCAL_CURRENCY = lc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Currency] bc on src.BASE_CURRENCY = bc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Source_Record_Status] ss on src.Position_Source_Status_Code = ss.Source_Status_Code 
			Left Join [EDP_Common].Dim_Long_Short_Direction ls on src.LONG_SHORT_IND = ls.Long_Short_Direction_Indicator 
			Left Join [EDP_Common].Dim_Dataset_Frequency f on src.Source_Frequency = f.Dataset_Frequency_Indicator

		--LOGGING ETL RESULT
		Select @rowsInserted = Count(*) 
		From EDP_Common.Fact_IDW_Position
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_IDW_Position', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

        -- populate EDP log table
        Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_IDW_Position', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_IDW_Position', 0, 0, 0, 'Failed', @ErrorMessage
        
		-- populate EDP log table
        Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_IDW_Position', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END