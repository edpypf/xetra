﻿CREATE PROC [EDP_Common].[SFTP_EDP_NEXEN_Fact_BNYM_Eagle_STAR_Transaction] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
            @loadStartTime datetime2,
            @loadEndTime datetime2,
            @SourceSystem varchar(255),
            @LastUpdateUser varchar(255)
	
	Begin Try

		-- get last loaded dts in current fact table
		Select	@lastLoadeDTS = coalesce(max(Last_Update_Datetime), '1900-01-01'),
		        @currentMaxId = coalesce(max(Fact_BNYM_Eagle_STAR_Transaction_ID), 0)
		From	EDP_Common.Fact_BNYM_Eagle_STAR_Transaction

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
                From EDW_ETL.ETL_Load
                Where ETL_Load_Key = @ETL_Load_Key

        Select @SourceSystem = 'NEXEN-BNYM-STAR', @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')
        -- Set load start time
        Select @loadStartTime = @today

		INSERT INTO EDP_Common.Fact_BNYM_Eagle_STAR_Transaction
		(  [Fact_BNYM_Eagle_STAR_Transaction_ID]
		  ,[Dim_Effective_Date_Key]
		  ,[Dim_Trade_Date_Key]
		  ,[Dim_Portfolio_Key]
		  ,[Dim_Broker_Counterparty_Key]
		  ,[Dim_Security_Key]
		  ,[Dim_Currency_Base_Key]
		  ,[Dim_Currency_Local_Key]
		  ,[Dim_Income_Currency_Key]
		  ,[Dim_Settlement_Currency_Key]
		  ,[Dim_Trade_Currency_Key]
		  ,[Dim_Long_Short_Direction_Key]
		  ,[Dim_Transaction_Type_Key]
		  ,[Dim_Transaction_Event_Type_Key]
		  ,[Dim_Reference_Transaction_Key]
		  ,[Dim_Source_Status_Key]
		  ,[Transaction_ID]
		  ,[Transaction_Audit_ID]
		  ,[Last_Update_Datetime]
		  ,[Load_Datetime]
		  ,[Broker_Counterparty_Code]
		  ,[Accounting_Effective_Date]
		  ,[Month_End_Accounting_Effective_Date]
		  ,[Actual_Settlement_Date]
		  ,[Contractual_Settlement_Date]
		  ,[Original_Acquisition_Date]
		  ,[Post_Date]
		  ,[Original_Face_Value_Amount]
		  ,[Transaction_Base_Amount]
		  ,[Transaction_Local_Amount]
		  ,[Contract_Size_Number]
		  ,[Price_Base_Amount]
		  ,[Price_Local_Amount]
		  ,[Share_Or_Par_Amount]
		  ,[Trade_Date_Price_Local_Amount]
		  ,[Trade_Expense_Local_Amount]
		  ,[Coupon_Rate_Percentage]
		  ,[Premium_Allocated_Base_Amount]
		  ,[Price_Multiplier_Decimal]
		  ,[Settlement_Local_Amount]
		  ,[Cost_Base_Amount]
		  ,[Cost_Local_Amount]
		  ,[Original_Cost_Base_Amount]
		  ,[Original_Cost_Local_Amount]
		  ,[Inflationary_Adjustment_Cost_Base_Amount]
		  ,[Inflationary_Adjustment_Cost_Local_Amount]
		  ,[Currency_Gain_Loss_Base_Amount]
		  ,[Currency_Gain_Loss_on_Income_Base_Amount]
		  ,[Currency_Gain_Loss_on_Income_Local_Amount]
		  ,[Currency_Gain_Loss_on_Interest_Base_Amount]
		  ,[Currency_Gain_Loss_on_Interest_Local_Amount]
		  ,[Commission_Base_Amount]
		  ,[Commission_Local_Amount]
		  ,[Commission_Rate_Base_Percentage]
		  ,[Commission_Rate_Local_Percentage]
		  ,[Fees_Base_Amount]
		  ,[Fees_Local_Amount]
		  ,[Trade_Fees_Base_Amount]
		  ,[Trade_Fees_Local_Amount]
		  ,[Security_Gain_Loss_Base_Amount]
		  ,[Security_Gain_Loss_Local_Amount]
		  ,[Interest_Rate_Percentage]
		  ,[Interest_Purchased_Sold_Base_Amount]
		  ,[Interest_Purchased_Sold_Local_Amount]
		  ,[Proceeds_Base_Amount]
		  ,[Proceeds_Local_Amount]
		  ,[Income_Base_Amount]
		  ,[Income_Local_Amount]
		  ,[Income_Rate_Percentage]
		  ,[Principal_Base_Amount]
		  ,[Principal_Local_Amount]
		  ,[Tax_Base_Amount]
		  ,[Tax_Local_Amount]
		  ,[Miscellaneous_Tax_Base_Amount]
		  ,[Miscellaneous_Tax_Local_Amount]
		  ,[Amortized_Base_Amount]
		  ,[Amortized_Local_Amount]
		  ,[Total_Realized_Gain_Loss_Base_Amount]
		  ,[Total_Realized_Gain_Loss_Local_Amount]
		  ,[Total_Realized_Gain_Base_Amount]
		  ,[Total_Realized_Gain_Local_Amount]
		  ,[Total_Realized_Loss_Base_Amount]
		  ,[Total_Realized_Loss_Local_Amount]
		  ,[Dirty_Principal_Base_Amount]
		  ,[Dirty_Principal_Local_Amount]
		  ,[Trade_Yield_Percentage]
		  ,[Amortization_Yield_Percentage]
		  ,[Long_Term_Security_Gain_Loss_Base_Amount]
		  ,[Long_Term_Security_Gain_Loss_Local_Amount]
		  ,[Short_Term_Security_Gain_Loss_Base_Amount]
		  ,[Short_Term_Security_Gain_Loss_Local_Amount]
		  ,[Trade_Date_FX_Base_To_Local_Rate]
		  ,[Trade_Date_FX_Local_To_Base_Rate]
		  ,[Source_Update_Datetime]
		  ,[Source_System_Code]
		  ,[Source_Deleted_Flag]
		  ,[ETL_Load_Key]
		  ,[Load_Detail_Description]
		  ,[Last_Update_User]
		)
			SELECT	@currentMaxId + rn										as Fact_BNYM_Eagle_STAR_Transaction_ID
					,convert(int, convert(varchar(15), src.Effective_Date, 112)) as [Dim_Effective_Date_Key]
					,convert(int, convert(varchar(15), Trade_date, 112))	as Dim_Trade_Date_Key
					,Coalesce(Dim_Portfolio_Key, -1)						as Dim_Portfolio_Key
					,-1														as Dim_Broker_Counterparty_Key
					,Coalesce(Dim_Security_Key, -1)							as Dim_Security_Key
					,Coalesce(bc.Dim_Currency_Key, -1)						as Dim_Currency_Base_Key
					,Coalesce(lc.Dim_Currency_Key, -1)						as Dim_Currency_Local_Key
					,-1														as Dim_Income_Currency_Key
					,Coalesce(sc.Dim_Currency_Key, -1)						as Dim_Settlement_Currency_Key
					,Coalesce(tc.Dim_Currency_Key, -1)						as Dim_Trade_Currency_Key
					,Coalesce(Dim_Long_Short_Direction_Key, -1)				as Dim_Long_Short_Direction_Key
					,Coalesce(Dim_Transaction_Type_Key, -1)					as Dim_Transaction_Type_Key
					,Coalesce(Dim_Transaction_Event_Type_Key, -1)			as Dim_Transaction_Event_Type_Key
					,Coalesce(Dim_Reference_Transaction_Key, -1)			as Dim_Reference_Transaction_Key
					,Coalesce(Dim_Source_Status_Key, -1)					as Dim_Source_Status_Key
					,Transaction_Unique_Identifier							as Transaction_ID
					,Transaction_Unique_Identifier_2						as Transaction_Audit_ID
					,src.Last_Update_DT										as Last_Update_Datetime
					,src.Record_Created_DT									as Load_Datetime
					,Broker_Code											as Broker_Counterparty_Code
					,Accounting_Date										as Accounting_Effective_Date
					,Month_End_Accounting_Date								as Month_End_Accounting_Effective_Date
					,Actual_Settlement_Date									as Actual_Settlement_Date
					,Contractual_Settlement_Date							as Contractual_Settlement_Date
					,NULL													as Original_Acquisition_Date
					,Post_Date												as Post_Date
					,Original_Face_Value									as Original_Face_Value_Amount
					,Txn_Amount_Base										as Transaction_Base_Amount
					,Txn_Amount_Local										as Transaction_Local_Amount
					,Contract_Size											as Contract_Size_Number
					,Price_Base												as Price_Base_Amount
					,Price_Local											as Price_Local_Amount
					,Shares_Par												as Share_Or_Par_Amount
					,Trade_Date_Price										as Trade_Date_Price_Local_Amount
					,NULL													as Trade_Expense_Local_Amount
					,NULL													as Coupon_Rate_Percentage
					,NULL													as Premium_Allocated_Base_Amount
					,Price_Multiplier										as Price_Multiplier_Decimal
					,Settle_Amount											as Settlement_Local_Amount
					,Cost_Base												as Cost_Base_Amount
					,Cost_Local												as Cost_Local_Amount
					,Original_Cost_Base										as Original_Cost_Base_Amount
					,Original_Cost_Local									as Original_Cost_Local_Amount
					,NULL													as Inflationary_Adjustment_Cost_Base_Amount
					,NULL													as Inflationary_Adjustment_Cost_Local_Amount
					,Currency_Gain_Loss_Base								as Currency_Gain_Loss_Base_Amount
					,NULL													as Currency_Gain_Loss_on_Income_Base_Amount
					,NULL													as Currency_Gain_Loss_on_Income_Local_Amount
					,NULL													as Currency_Gain_Loss_on_Interest_Base_Amount
					,NULL													as Currency_Gain_Loss_on_Interest_Local_Amount
					,Commission_Base										as Commission_Base_Amount
					,Commission_Local										as Commission_Local_Amount
					,Commission_Rate_Base									as Commission_Rate_Base_Percentage
					,Commission_Rate_Local									as Commission_Rate_Local_Percentage
					,Fees_Base												as Fees_Base_Amount
					,Fees_Local												as Fees_Local_Amount
					,NULL													as Trade_Fees_Base_Amount
					,NULL													as Trade_Fees_Local_Amount
					,Security_Gain_Loss_Base								as Security_Gain_Loss_Base_Amount
					,Security_Gain_Loss_Local								as Security_Gain_Loss_Local_Amount
					,NULL													as Interest_Rate_Percentage
					,Interest_Purchased_Sold_Base							as Interest_Purchased_Sold_Base_Amount
					,Interest_Purchased_Sold_Local							as Interest_Purchased_Sold_Local_Amount
					,Proceeds_Base											as Proceeds_Base_Amount
					,Proceeds_Local											as Proceeds_Local_Amount
					,NULL													as Income_Base_Amount
					,NULL													as Income_Local_Amount
					,NULL													as Income_Rate_Percentage
					,Principal_Base											as Principal_Base_Amount
					,Principal_Local										as Principal_Local_Amount
					,Tax_Amount_Base										as Tax_Base_Amount
					,Tax_Amount_Local										as Tax_Local_Amount
					,NULL													as Miscellaneous_Tax_Base_Amount
					,NULL													as Miscellaneous_Tax_Local_Amount
					,Amortized_Amount_Base									as Amortized_Base_Amount
					,Amortized_Amount_Local								    as Amortized_Local_Amount
					,Total_Realized_Gain_Loss_Base							as Total_Realized_Gain_Loss_Base_Amount
					,Total_Realized_Gain_Loss_Local							as Total_Realized_Gain_Loss_Local_Amount
					,Total_Realized_Gain_Base								as Total_Realized_Gain_Base_Amount
					,Total_Realized_Gain_Local								as Total_Realized_Gain_Local_Amount
					,Total_Realized_Loss_Base								as Total_Realized_Loss_Base_Amount
					,Total_Realized_Loss_Local								as Total_Realized_Loss_Local_Amount
					,Dirty_Principal_Base									as Dirty_Principal_Base_Amount
					,Dirty_Principal_Local									as Dirty_Principal_Local_Amount
					,NULL													as Trade_Yield_Percentage
					,NULL													as Amortization_Yield_Percentage
					,NULL													as Long_Term_Security_Gain_Loss_Base_Amount
					,NULL													as Long_Term_Security_Gain_Loss_Local_Amount
					,NULL													as Short_Term_Security_Gain_Loss_Base_Amount
					,NULL													as Short_Term_Security_Gain_Loss_Local_Amount
					,Trade_Date_Exchange_Rate								as Trade_Date_FX_Base_To_Local_Rate
					,Trade_Date_FX_Local_To_Base_Rate						as Trade_Date_FX_Local_To_Base_Rate
					,NULL													as Source_Update_Datetime

					,@SourceSystem 											as Source_System_Code
					,src.Source_Deleted_Flag								as Source_Deleted_Flag
					,@ETL_Load_Key											as ETL_Load_Key
 					,case when p.Dim_Portfolio_key is null  
				        or s.Dim_Security_Key is null  
						or bc.Dim_Currency_Key is null or lc.Dim_Currency_key is null or sc.Dim_Currency_key is null or tc.Dim_Currency_key is null then
						'{' + 
						'"Transaction_Id": "' + convert(varchar(255), src.Transaction_Unique_Identifier) + '",' + 
						'"Transaction_Audit_Id": "' + convert(varchar(255), src.Transaction_Unique_Identifier_2) + '",' + 
						'"Account_Number": "' + Coalesce(convert(varchar(50), src.Account_Number),'') + '",' + 
						'"Security_Alias_Identifier":"' + Coalesce(convert(varchar(50), src.Security_Alias_Identifier),'') + '",' + 
						'"Base_Currency":"' + Coalesce(src.Base_Currency_Code,'') + '",' + 
						'"Local_Currency":"' + Coalesce(src.Local_Currency_Code,'') + '",' + 
						'"Settlement_Currency":"' + Coalesce(src.Settlement_Currency,'') + '",' + 
						'"Trade_Currency":"' + Coalesce(src.Trade_Currency,'') + '"' + 
						'}'
					else 
						null
					End														as Load_Detail_Description
					,@LastUpdateUser										as [Last_Update_User]					
					FROM (	SELECT 	Effective_Date
									,Trade_Date
								    ,Account_Number
								    ,Security_Alias_Identifier
									,Base_Currency_Code
									,Local_Currency_Code 
									,Settlement_Currency
									,Trade_Currency
									,Long_Short
									,Transaction_Code
									,Transaction_Description_1
									,Case When [Accounting_Status] = 'Preliminary' Then 'PRELIM_UNAUD'
										  When [Accounting_Status] = 'Closed' Then 'MTH_END_CLOSED'
										  Else 'NA' End Source_Status_Code	
									,Case When [Cancel_Trade_Indicator] = 'Y' Then 'CANCEL'
										  Else 'ACTIVE' End Transaction_Status
									,Case When [Pay_Receive_Indicator] in ('P', 'R') Then [Pay_Receive_Indicator]
										  Else 'NA' End Pay_Receive
									,Case When [Accrual_Method] in ('CUM', 'EX') Then [Accrual_Method]
										  Else 'NA' End Accrual_Method
									,Case When [Quantity_Type] in ('PAR', 'CURRENCY', 'SHARES', 'CONTRACTS', 'CASH') Then [Quantity_Type]
										  Else 'NA' End Quantity_Type
									,Cancel_Record_Indicator
									,Transaction_Unique_Identifier
									,Transaction_Unique_Identifier_2 
									,Broker_Code
									,Accounting_Date
									,Month_End_Accounting_Date
									,Actual_Settlement_Date
									,Contractual_Settlement_Date 
									,Post_Date
									,Original_Face_Value
									,Txn_Amount_Base
									,Txn_Amount_Local
									,Contract_Size
									,Price_Base
									,Price_Local
									,Shares_Par
									,Trade_Date_Price 
									,Price_Multiplier
									,Settle_Amount
									,Cost_Base
									,Cost_Local
									,Original_Cost_Base
									,Original_Cost_Local
									,Currency_Gain_Loss_Base 
									,Commission_Base
									,Commission_Local
									,Commission_Rate_Base
									,Commission_Rate_Local
									,Fees_Base
									,Fees_Local 
									,Security_Gain_Loss_Base
									,Security_Gain_Loss_Local 
									,Interest_Purchased_Sold_Base
									,Interest_Purchased_Sold_Local
									,Proceeds_Base
									,Proceeds_Local 
									,Principal_Base
									,Principal_Local
									,Tax_Amount_Base
									,Tax_Amount_Local 
									,Amortized_Amount_Base
									,Amortized_Amount_Local
									,Total_Realized_Gain_Loss_Base
									,Total_Realized_Gain_Loss_Local
									,Total_Realized_Gain_Base
									,Total_Realized_Gain_Local
									,Total_Realized_Loss_Base
									,Total_Realized_Loss_Local
									,Dirty_Principal_Base
									,Dirty_Principal_Local 
									,Trade_Date_Exchange_Rate
									,Case When coalesce([Trade_Date_Exchange_Rate], 0)= 0 then NULL 
									 Else 1/[Trade_Date_Exchange_Rate] End as Trade_Date_FX_Local_To_Base_Rate
									,Source_Deleted_Flag  
									,Last_Update_DT
									,Record_Created_DT
									,row_number() Over(Order By (Select 1)) rn
							FROM	EDW_RAW.BNYM_SSE_STAR_Trade_Activity_Non_Consolidated  
							WHERE	Last_Update_DT > Coalesce(@lastLoadeDTS, '1900-01-01')
									AND Trade_Date <= @today
						 ) src
			Left Join (
				Select Eagle_STAR_Portfolio_ID, min(Portfolio_Id) Portfolio_Id
				From EDP_Common.Dim_Portfolio 
				where Is_Current_Flag = 1
				Group By Eagle_STAR_Portfolio_ID
			) pc on src.Account_Number = pc.Eagle_STAR_Portfolio_ID
			Left Join EDP_Common.Dim_Portfolio p on pc.Portfolio_Id = p.Portfolio_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31 00:00:00.0000000') 

			Left Join (
				Select BNYM_ID, min(IMCO_Security_Alias_ID) IMCO_Security_Alias_ID
				From [EDP_Common].[Dim_Security] 
				where Is_Current_Flag = 1
				group By BNYM_ID
			) sec on src.Security_Alias_Identifier= sec.BNYM_ID
			Left Join [EDP_Common].[Dim_Security] s on sec.IMCO_Security_Alias_ID = s.IMCO_Security_Alias_ID and src.Effective_Date between s.Effective_Start_Datetime and coalesce(s.Effective_End_Datetime, '9999-12-31') 
			
			Left Join [EDP_Common].[Dim_Currency] lc on src.Local_Currency_Code = lc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Currency] bc on src.Base_Currency_Code = bc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Currency] sc on src.Settlement_Currency = sc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Currency] tc on src.Trade_Currency = tc.CURRENCY_CODE
			Left Join [EDP_Common].Dim_Long_Short_Direction ls on src.LONG_SHORT = ls.Long_Short_Direction_Indicator 
			Left Join [EDP_Common].Dim_Transaction_Type tt on src.Transaction_Code = tt.Transaction_Type_Code
			Left Join [EDP_Common].Dim_Transaction_Event_Type te on src.Transaction_Description_1 = te.Transaction_Event_Type_Code
			Left Join [EDP_Common].[Dim_Source_Record_Status] ss on src.Source_Status_Code = ss.Source_Status_Code
			Left Join [EDP_Common].[Dim_Reference_Transaction] rt on src.Transaction_Status=rt.Transaction_Status_Code  
																  AND src.Pay_Receive=rt.Pay_Receive_Indicator  
																  AND src.Accrual_Method=rt.Accrual_Method_Code  
																  AND src.Quantity_Type=rt.Quantity_Type_Code 
																  AND src.Cancel_Record_Indicator=rt.Transaction_Cancellation_Indicator

		-- Fix -1 for security key, portfolio key in fact table
		exec EDW_DQ.EDP_Eagle_Nexen_Fix_Missing_Keys 'EDP_Common', 'Fact_BNYM_Eagle_STAR_Transaction', 'Fact_BNYM_Eagle_STAR_Transaction_ID', 'PORT_SEC', '7', @Batch_DTS, @ETL_Load_Key


		--LOGGING ETL RESULT
		Select @rowsInserted = Count(*) 
		From EDP_Common.Fact_BNYM_Eagle_STAR_Transaction
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_BNYM_Eagle_STAR_Transaction', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

        -- populate EDP log table
        Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_BNYM_Eagle_STAR_Transaction', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_BNYM_Eagle_STAR_Transaction', 0, 0, 0, 'Failed', @ErrorMessage
        
		-- populate EDP log table
        Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_BNYM_Eagle_STAR_Transaction', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END