﻿CREATE PROC [EDP_Common].[Eagle_Rel_Object_List_Membership] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

Declare @today datetime2 = getdate(),
        @loadStartTime datetime2,
		@loadEndTime datetime2,
		@SourceSystem varchar(255),
		@LastUpdateUser varchar(255)

Declare @rowsInserted int = 0,
		@rowsUpdated int = 0,
		@rowsExpired int = 0

	Begin Try

		IF OBJECT_ID('tempdb..#temp_eagle_rel_object_list') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_rel_object_list
		END
		
		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'IDW-LIST', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today


		-- load latest Eagle entity records from source into temp table
		create table #temp_eagle_rel_object_list
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		 with tbl_mapping as (
			  SELECT CV.SHORT_DESC, CV.LONG_DESC
			  FROM PSA.V_Eagle_CODES C
			  INNER JOIN PSA.V_Eagle_CODE_VALUES CV
			  ON C.INSTANCE           = CV.CODE_INST
			  WHERE C.SHORT_DESC      = 'EDP_RelObjListM'
			  AND CV.INTFC_INST in
				(SELECT instance
				 FROM PSA.V_Eagle_INTERFACES
				 WHERE short_desc = 'EAGLE PACE'
				)
			  And C.Is_Src_Deleted = 0 and CV.Is_Src_Deleted =0 
		  ),
		  LM as (
			  SELECT  EL.CODE_VALUE Entity_Id, Rtrim(C.LONG_DESC) Purpose_Code
			  FROM          PSA.V_Eagle_ENTITY_LIST EL
			  INNER JOIN    PSA.V_Eagle_ENTITY E ON EL.CODE_VALUE = E.ENTITY_ID
			  INNER  JOIN    TBL_MAPPING C ON  EL.ENTITY_ID = C.SHORT_DESC
			  WHERE E.ENTITY_TYPE = 'LIST'
			  And EL.Is_Src_Deleted = 0 and E.Is_Src_Deleted = 0
			)
			Select [Object_List_ID],
				   [Object_List_Member_ID],
				   [Object_List_Purpose_Code],
				   [Object_List_Member_Type_Code],
				   [Object_List_Purpose_Name],
				   [Data_Sub_Domain_Code],
				   [Source_System_Code],
				   CONVERT(VARCHAR(64), Hashbytes('SHA1', Upper(concat([Object_List_Member_Type_Code], '|', [Object_List_Purpose_Name], '|',
										[Data_Sub_Domain_Code] , '|'))), 2 ) Hash_Diff
			From (
				Select	Rtrim(EL.Entity_Id) [Object_List_ID], 
						Rtrim(EL.Code_Value) [Object_List_Member_ID],
						Coalesce(EL.Purpose_Code, 'NA') [Object_List_Purpose_Code],
						E.Entity_Type [Object_List_Member_Type_Code], 
						Case when EL.Purpose_Code = 'OfficialPerfPortList' Then 'Official Performance Portfolio List'
							 when EL.Purpose_Code = 'OfficialPerfBmkList'  Then  'Official Performance Benchmark List'
							 Else 'NA'
						End [Object_List_Purpose_Name],
						Case when EL.Purpose_Code = 'OfficialPerfPortList' Then 'Port'
							 when EL.Purpose_Code = 'OfficialPerfBmkList'  Then  'Bmk'
							 Else 'NA'
						End [Data_Sub_Domain_Code],
						'IDW-LIST' [Source_System_Code]
						
				From (
					Select vl.entity_id, vl.code_value, LM.Purpose_Code
					From PSA.V_Eagle_ENTITY_LIST vl
					Join LM on vl.Entity_Id = LM.Entity_Id
					Left Join (
						Select Distinct Entity_Id
						From PSA.V_Eagle_ENTITY_LIST vl
						Where Is_Src_Deleted = 0
						and connector is not null
					) dl on vl.Entity_Id = dl.Entity_Id
					where vl.Is_Src_Deleted = 0 and dl.Entity_Id is null

					union

					Select vl.entity_id, vl.code_value, tm.LONG_DESC Purpose_Code
					From PSA.V_Eagle_ENTITY_LIST vl
					Join tbl_mapping tm on vl.Entity_Id = tm.SHORT_DESC
					where vl.Is_Src_Deleted = 0

				) EL
				JOIN  PSA.V_Eagle_ENTITY E ON EL.CODE_VALUE = E.ENTITY_ID -- and E.Is_Src_Deleted = 0
				-- WHERE E.ENTITY_TYPE = 'LIST' 
				-- And EL.Is_Src_Deleted = 0 
			) src



		--UPDATE/EXPIRE deleted RECORDS
		Update tgt
		Set 	tgt.Source_Deleted_Flag = 1,
				Last_Update_Datetime=@today, 
				ETL_Load_Key = @ETL_Load_Key,
				Last_Update_User = @LastUpdateUser,
				Source_System_Code = @SourceSystem

		From [EDP_Common].[Rel_Object_List_Membership] tgt
		Left Join #temp_eagle_rel_object_list src on tgt.[Object_List_ID] = src.[Object_List_ID]
												And tgt.[Object_List_Member_ID] = src.[Object_List_Member_ID]
												And tgt.[Object_List_Purpose_Code] = src.[Object_List_Purpose_Code]
		Where tgt.Source_Deleted_Flag = 0 and src.[Object_List_ID] is null


		-- Update type 1 fields ([Performance_Official_Ownership_Flag])
		Update tgt
		Set 	tgt.Source_Deleted_Flag = 0,
				tgt.Last_Update_Datetime=@today, 
				tgt.[Object_List_Member_Type_Code] = src.[Object_List_Member_Type_Code],
				tgt.[Object_List_Purpose_Name] = src.[Object_List_Purpose_Name],
				tgt.[Data_Sub_Domain_Code] = src.[Data_Sub_Domain_Code],
				ETL_Load_Key = @ETL_Load_Key,
				Last_Update_User = @LastUpdateUser,
				Source_System_Code = @SourceSystem,
				tgt.Hash_Diff = src.Hash_Diff

		From [EDP_Common].[Rel_Object_List_Membership] tgt
		Join #temp_eagle_rel_object_list src on tgt.[Object_List_ID] = src.[Object_List_ID]
												And tgt.[Object_List_Member_ID] = src.[Object_List_Member_ID]
												And tgt.[Object_List_Purpose_Code] = src.[Object_List_Purpose_Code]
		Where tgt.Hash_Diff <> src.Hash_Diff


		--INSERT NEW RECORDS INTO DIM TABLE
		insert into [EDP_Common].[Rel_Object_List_Membership]
		(
			  [Object_List_ID]
			  ,[Object_List_Member_ID]
			  ,[Object_List_Purpose_Code]
			  ,[Object_List_Member_Type_Code]
			  ,[Object_List_Purpose_Name]
			  ,[Data_Sub_Domain_Code]
			  ,[Source_Deleted_Flag]
			  ,[Source_System_Code]
			  ,[ETL_Load_Key]
			  ,[Hash_Diff]
			  ,[Create_Datetime]
			  ,[Last_Update_User]
			  ,[Last_Update_Datetime]
		)
			select src.[Object_List_ID]
				  ,src.[Object_List_Member_ID]
				  ,src.[Object_List_Purpose_Code]
				  ,src.[Object_List_Member_Type_Code]
				  ,src.[Object_List_Purpose_Name]
				  ,src.[Data_Sub_Domain_Code]
				  ,0 [Source_Deleted_Flag]
				  ,src.[Source_System_Code]
				  ,@ETL_Load_Key
				  ,src.[Hash_Diff]
				  ,@today
				  ,@LastUpdateUser
				  ,@today

		From #temp_eagle_rel_object_list src 
		Left Join [EDP_Common].[Rel_Object_List_Membership] tgt On tgt.[Object_List_ID] = src.[Object_List_ID]
														  And tgt.[Object_List_Member_ID] = src.[Object_List_Member_ID]
														  And tgt.[Object_List_Purpose_Code] = src.[Object_List_Purpose_Code]
		Where tgt.[Object_List_ID] is null


		-- Set load end time
		Select @loadEndTime = Getdate()

		--ETL Logging
		Select @rowsInserted = Count(*) 
		From [EDP_Common].[Rel_Object_List_Membership]
		Where ETL_Load_Key = @ETL_Load_Key and [Create_Datetime] = @today 
		and [Last_Update_Datetime] = @today	and Source_Deleted_Flag = 0

		Select @rowsUpdated = Count(*)
		From [EDP_Common].[Rel_Object_List_Membership]
		Where ETL_Load_Key = @ETL_Load_Key and [Create_Datetime] < @today 
		and [Last_Update_Datetime] = @today	and Source_Deleted_Flag = 0

		Select @rowsExpired = Count(*)
		From [EDP_Common].[Rel_Object_List_Membership]
		Where ETL_Load_Key = @ETL_Load_Key and [Create_Datetime] < @today 
		and [Last_Update_Datetime] = @today	and Source_Deleted_Flag = 1

		-- populate EDW ETL log table
		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Rel_Object_List_Membership', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Rel_Object_List_Membership', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null


		-- Force cleanup temp tables
		IF OBJECT_ID('tempdb..#temp_eagle_rel_object_list') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_rel_object_list
		END


    END TRY

	--Error Handling
	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Rel_Object_List_Membership', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Rel_Object_List_Membership', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END