﻿CREATE PROC [EDP_Common].[Update_Load_Log] @Batch_Date [Date],@ETL_Load_Key [Bigint],@Load_Table [varchar](255),@Load_Start_DT [datetime2],@Load_End_DT [datetime2],@Rows_Inserted [int],@Rows_Updated [int],@Rows_Expired [int],@Load_Status [varchar](255),@Error_Massage [varchar](4000) AS
BEGIN
	Declare @rows int
	Declare @curMaxKey bigint
	Declare @Load_Status_Code varchar(255),
	        @Source_System varchar(255),
			@Load_Type varchar(255)

	Select @Load_Status_Code = case when @Load_Status = 'Completed' then 'S' 
	                              when @Load_Status = 'Failed' then 'F' 
							 else 'Unknown' end

	-- Get Load detail from ETL Load
	Select @Source_System = Source_System, @Load_Type = Load_Type
	From EDW_ETL.ETL_Load
	Where ETL_Load_Key = @ETL_Load_Key

	Select @Source_System = Coalesce(@Source_System, 'Manual Script'),
	       @Load_Type = Coalesce(@Load_Type, 'ONDEMAND')

	Select @rows = count(*) 
	from [EDP_Common].[Load_Log]
	Where ETL_Load_Key = @ETL_Load_Key and Table_Loaded_Long_Name = @Load_Table

	if @rows > 0
	Begin
		Update [EDP_Common].[Load_Log]
		Set [Record_Load_Count] = @Rows_Inserted,
			[Record_Update_Count] = @Rows_Updated,
			[Record_Delete_Count] = @Rows_Expired,
			Load_Status_Code = @Load_Status_Code,
			Load_Status_Name = @Load_Status,
			[Load_Error_Description] = @Error_Massage,
		    [Load_Start_Datetime] = @Load_Start_DT,
			[Load_End_Datetime] = @Load_End_DT
		where ETL_Load_Key = @ETL_Load_Key and Table_Loaded_Long_Name = @Load_Table
	End
	Else
	Begin

		Insert Into [EDP_Common].[Load_Log] (
			 [Batch_Effective_Date]
			  ,[Source_System_Code]
			  ,[Source_System_Name]
			  ,[Table_Loaded_Long_Name]
			  ,[Load_Type_Code]
			  ,[Load_Type_Name]
			  ,[Load_Status_Code]
			  ,[Load_Status_Name]
			  ,[Record_Update_Count]
			  ,[Record_Load_Count]
			  ,[Record_Delete_Count]
			  ,[Load_Error_Description]
			  ,[Load_Start_Datetime]
			  ,[Load_End_Datetime]
			  ,[ETL_Load_Key]		
		)
		Select 
			@Batch_Date,
			@Source_System,
			@Source_System,
			@Load_Table,
			@Load_Type,
			@Load_Type,
			@Load_Status_Code,
			@Load_Status,
			@Rows_Updated,
			@Rows_Inserted,
			@Rows_Expired,
			@Error_Massage,
			@Load_Start_DT,
			@Load_End_DT,
			@ETL_Load_Key
	End

	
END