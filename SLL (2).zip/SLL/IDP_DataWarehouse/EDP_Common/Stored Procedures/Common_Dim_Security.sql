﻿CREATE PROC [EDP_Common].[Common_Dim_Security] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

Declare @today datetime2 = getdate(),
        @loadStartTime datetime2,
		@loadEndTime datetime2,
		@SourceSystem varchar(255),
		@LastUpdateUser varchar(255)

Declare @rowsInserted int = 0,
		@rowsUpdated int = 0,
		@rowsExpired int = 0

	Begin Try

		IF OBJECT_ID('tempdb..#temp_eagle_dim_security_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_dim_security_records
		END
		
		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'IDW-SEC', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		-- load latest Eagle entity records from source into temp table
		create table #temp_eagle_dim_security_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		WITH Official_List as (
			  SELECT C.SHORT_DESC AS CTYPE, Rtrim(CV.SHORT_DESC) AS ENTITY_ID, Rtrim(CV.LONG_DESC) AS LONG_DESC
			  FROM PSA.V_Eagle_CODES C
			  INNER JOIN PSA.V_Eagle_CODE_VALUES CV  ON C.INSTANCE = CV.CODE_INST
			  WHERE C.SHORT_DESC in ('PROCES_SEC_TYPE','INVESTMENT TYPE','SECURITY TYPE')
			  AND CV.INTFC_INST       in
				(SELECT instance
				FROM PSA.V_Eagle_INTERFACES
				WHERE short_desc = 'EAGLE PACE'
				)
			  And C.Is_Src_Deleted = 0 and CV.Is_Src_Deleted = 0
		)
		Select		IMCO_Security_Alias_ID
					,Security_Name
					,Security_Description
					,Security_Currency
					,[CUSIP_ID]
					,[ISIN_ID]
					,[SEDOL_ID]
					,[Ticker_ID]
					,[Dynamo_ID]
					,[BNYM_ID]
					,[GENEVA_ID]
					,[State_Street_CUSIP_ID]
					,IMCO_Asset_Type_Code
					,IMCO_Asset_Type_Name
					,IMCO_Asset_Sub_Type_Code
					,IMCO_Asset_Sub_Type_Name
					,IMCO_Security_Type_Code
					,IMCO_Security_Type_Name
					,BNYM_Eagle_STAR_Primary_Asset_ID
					,trim(replace(replace(BNYM_Eagle_STAR_Primary_Asset_ID_Type, BNYM_Eagle_STAR_Primary_Asset_ID, ''),'_','')) as BNYM_Eagle_STAR_Primary_Asset_ID_Type
					,convert(varchar(64), Hashbytes('SHA1', upper(concat(Security_Name, '|', Security_Description, '|',Security_Currency, '|',
											   [CUSIP_ID], '|',  [ISIN_ID], '|',  [SEDOL_ID],  '|', [Ticker_ID], '|', 
											   [Dynamo_ID],  '|', [BNYM_ID], '|',  [Geneva_ID],  '|', [State_Street_CUSIP_ID],  '|', [IMCO_Asset_Type_Code],  '|', 
											   [IMCO_Asset_Type_Name],  '|', [IMCO_Asset_Sub_Type_Code],  '|', [IMCO_Asset_Sub_Type_Name],  
											   [IMCO_Security_Type_Code],  '|', [IMCO_Security_Type_Name], '|', [BNYM_Eagle_STAR_Primary_Asset_ID], '|', trim(replace(replace(BNYM_Eagle_STAR_Primary_Asset_ID_Type, BNYM_Eagle_STAR_Primary_Asset_ID, ''),'_',''))))) ,2) Hash_Diff 
					,Is_Src_Deleted
		From (
				Select    IMCO_Security_Alias_ID
						  ,Security_Name
						  ,Security_Description
						  ,Security_Currency
						  ,CUSIP [CUSIP_ID]
						  ,ISIN [ISIN_ID]
						  ,SEDOL [SEDOL_ID]
						  ,Ticker [Ticker_ID]
						  ,Dynamo [Dynamo_ID]
						  ,[BNYM_ID]
						  ,GENEVA_ID
						  ,SSC_ID [State_Street_CUSIP_ID]
						  ,IMCO_Asset_Type_Code
						  ,IMCO_Asset_Type_Name
						  ,IMCO_Asset_Sub_Type_Code
						  ,IMCO_Asset_Sub_Type_Name
						  ,IMCO_Security_Type_Code
						  ,IMCO_Security_Type_Name
						  ,BNYM_Eagle_STAR_Primary_Asset_ID
						  ,BNYM_Eagle_STAR_Primary_Asset_ID_Type
						  ,Is_Src_Deleted
				from (

					Select convert(varchar(15), M.Security_Alias) as IMCO_Security_Alias_ID
						 , Coalesce(Rtrim(M.Issue_Name), '') Security_Name
						 , Rtrim(M.Issue_Description) Security_Description
						 , Rtrim(Currency_Code) Security_Currency
						 , coalesce(Rtrim(X.XREF_SECURITY_ID), 'NA') as Security_XRef_ID
						 , Rtrim(X.XREF_TYPE) Security_XRef_Type
						 , Rtrim(M.INVESTMENT_TYPE) 			as IMCO_Asset_Type_Code
						 , Rtrim(CI.LONG_DESC)					as IMCO_Asset_Type_Name
						 , Rtrim(M.PROCESS_SEC_TYPE)			as IMCO_Asset_Sub_Type_Code
						 , Rtrim(CP.LONG_DESC)					as IMCO_Asset_Sub_Type_Name
						 , Rtrim(M.SECURITY_TYPE)				as IMCO_Security_Type_Code
						 , Rtrim(CS.LONG_DESC)					as IMCO_Security_Type_Name
						 , Rtrim(XA.XREF_SECURITY_ID) as BNYM_Eagle_STAR_Primary_Asset_ID
						 , Rtrim(XAT.XREF_SECURITY_ID) as BNYM_Eagle_STAR_Primary_Asset_ID_Type
						 , M.Is_Src_Deleted
					From PSA.V_Eagle_Security_Master M
					Left Join PSA.V_Eagle_XREFERENCE  X on X.Security_Alias = M.Security_Alias and X.Is_Src_Deleted = 0
					Left Join PSA.V_Eagle_XREFERENCE  XA on XA.Security_Alias = M.Security_Alias and XA.Is_Src_Deleted = 0 and XA.XREF_TYPE = 'BNYM_PAID'
					Left Join PSA.V_Eagle_XREFERENCE  XAT on XAT.Security_Alias = M.Security_Alias and XAT.Is_Src_Deleted = 0 and XAT.XREF_TYPE = 'BNYM_PAID_WITH_TYPE'
					Left Join Official_List CI ON CI.CTYPE = 'INVESTMENT TYPE' and CI.ENTITY_ID=M.INVESTMENT_TYPE
					Left Join Official_List CP ON CP.CTYPE = 'PROCES_SEC_TYPE' and CP.ENTITY_ID=M.PROCESS_SEC_TYPE
					Left Join Official_List CS ON CS.CTYPE = 'SECURITY TYPE' and CS.ENTITY_ID=M.SECURITY_TYPE
					--Where Rtrim(X.XREF_TYPE) in (
					--	'BNYM_ID', 'CUSIP', 'ISIN', 'SEDOL', 'TICKER', 'SSC_ID', 'GENEVA_ID', 'DYNAMO'
					--) 
					-- and M.Is_Src_Deleted = 0 
					
				) s
				Pivot (
				  max(Security_XRef_ID) for Security_XRef_Type in (
						BNYM_ID, CUSIP, SSC_ID, ISIN, SEDOL, TICKER, GENEVA_ID, DYNAMO
				  ) 
				) sp
		) src

		--UPDATE/EXPIRE EXISTING RECORDS
		Update tgt
		Set 	Effective_End_Datetime = @today,
				Is_Current_Flag= 0, 
				Last_Update_Datetime=@today, 
				ETL_Load_Key = @ETL_Load_Key,
				Source_System_Code = @SourceSystem, 
				Last_Update_User = @LastUpdateUser

		From EDP_Common.Dim_Security tgt
		Where tgt.Dim_Security_Key > -1 and tgt.Is_Current_Flag = 1 and 
		(
			exists
			(	Select	1
				From	#temp_eagle_dim_security_records src
				Where	tgt.IMCO_Security_Alias_ID = src.IMCO_Security_Alias_ID 
						and ( coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1 )
			)

			or
			not exists (
				Select	1
				From	#temp_eagle_dim_security_records src
				Where	tgt.IMCO_Security_Alias_ID = src.IMCO_Security_Alias_ID
			)
		)


		--INSERT NEW RECORDS INTO DIM TABLE
		insert into EDP_Common.Dim_Security
		(
			  [IMCO_Security_Alias_ID]
			  ,[Security_Name]
			  ,[Security_Description]
			  ,[Security_Currency_Code]
			  ,[CUSIP_ID]
			  ,[ISIN_ID]
			  ,[SEDOL_ID]
			  ,[Ticker_ID]
			  ,[Dynamo_ID]
			  ,[BNYM_ID]
			  ,[Geneva_ID]
			  ,[State_Street_CUSIP_ID]
			  ,[Is_Current_Flag]
			  ,[Effective_Start_Datetime]
			  ,[Effective_End_Datetime]
			  ,[Last_Update_Datetime]
			  ,[ETL_Load_Key]
			  ,[Hash_Diff]
			  ,Source_System_Code
			  ,Last_Update_User
			  ,IMCO_Asset_Type_Code
			  ,IMCO_Asset_Type_Name
			  ,IMCO_Asset_Sub_Type_Code
			  ,IMCO_Asset_Sub_Type_Name
			  ,IMCO_Security_Type_Code
			  ,IMCO_Security_Type_Name
			  ,BNYM_Eagle_STAR_Primary_Asset_ID
			  ,BNYM_Eagle_STAR_Primary_Asset_ID_Type
		)
			select 	src.[IMCO_Security_Alias_ID]
					,src.[Security_Name]
					,src.[Security_Description]
					,src.[Security_Currency]
					,src.[CUSIP_ID]
					,src.[ISIN_ID]
					,src.[SEDOL_ID]
					,src.[Ticker_ID]
					,src.[Dynamo_ID]
					,src.[BNYM_ID]
					,src.[Geneva_ID]
					,src.[State_Street_CUSIP_ID]
				    ,1
				    ,case when tgt_all.[IMCO_Security_Alias_ID] is null then '1900-01-01' else @today End 
				    ,'9999-12-31'
				   ,@today
				   ,@ETL_Load_Key
				   ,src.Hash_Diff
				   ,@SourceSystem
				   ,@LastUpdateUser
				   ,src.IMCO_Asset_Type_Code
				   ,src.IMCO_Asset_Type_Name
				   ,src.IMCO_Asset_Sub_Type_Code
				   ,src.IMCO_Asset_Sub_Type_Name
				   ,src.IMCO_Security_Type_Code
				   ,src.IMCO_Security_Type_Name
				   ,src.BNYM_Eagle_STAR_Primary_Asset_ID
				   ,src.BNYM_Eagle_STAR_Primary_Asset_ID_Type

			from	#temp_eagle_dim_security_records src
					Left Join EDP_Common.Dim_Security tgt on src.IMCO_Security_Alias_ID = tgt.IMCO_Security_Alias_ID and tgt.Is_Current_Flag = 1 
					Left Join (Select Distinct IMCO_Security_Alias_ID From EDP_Common.Dim_Security) tgt_all on src.IMCO_Security_Alias_ID = tgt_all.IMCO_Security_Alias_ID
			where	(
						tgt.IMCO_Security_Alias_ID is null 
						or (tgt.IMCO_Security_Alias_ID is not null and src.Hash_Diff <> tgt.Hash_Diff)
					)
					and src.Is_Src_Deleted = 0

		-- Set load end time
		Select @loadEndTime = Getdate()

		--ETL Logging
		Select @rowsInserted = Count(*) 
		From EDP_Common.Dim_Security
		Where ETL_Load_Key = @ETL_Load_Key and Dim_Security_Key > 0 and 
		([Effective_Start_Datetime] = @today or [Effective_Start_Datetime]='1900-01-01') 
		and Is_Current_Flag = 1

		Select @rowsUpdated = Count(*)
		From EDP_Common.Dim_Security
		Where ETL_Load_Key = @ETL_Load_Key and [Effective_End_Datetime] = @today

		Select @rowsExpired = Count(*)
		From EDP_Common.Dim_Security s
		Left Join (Select IMCO_Security_Alias_ID From EDP_Common.Dim_Security Where Is_Current_Flag = 1) sc on s.IMCO_Security_Alias_ID = sc.IMCO_Security_Alias_ID 
		Where ETL_Load_Key = @ETL_Load_Key and [Effective_End_Datetime] = @today and sc.IMCO_Security_Alias_ID is null


		-- populate EDW ETL log table
		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Dim_Security', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Load_DTS, @ETL_Load_Key, 'Dim_Security', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null


		-- Force cleanup temp tables
		IF OBJECT_ID('tempdb..#temp_eagle_dim_security_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_dim_security_records
		END

    END TRY

	--Error Handling
	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Dim_Security', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Load_DTS, @ETL_Load_Key, 'Dim_Security', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END