﻿CREATE PROC [EDP_Common].[SFTP_EDP_StateStreet_Fact_SS_MCH_Ledger_Trial_Balance_Summary] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)


	Begin Try

		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max([Last_Update_Datetime]), '1900-01-01'), 
		       @currentMaxId = coalesce(max([Fact_SS_MCH_Ledger_Trial_Balance_Summary_ID]), 0)
		From [EDP_Common].Fact_SS_MCH_Ledger_Trial_Balance_Summary

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'MySS-SS-MCH', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		INSERT INTO [EDP_Common].Fact_SS_MCH_Ledger_Trial_Balance_Summary
           (  [Fact_SS_MCH_Ledger_Trial_Balance_Summary_ID]
			  ,[Dim_Effective_Date_Key]
			  ,[Dim_Dataset_Frequency_Key]
			  ,[Dim_Portfolio_Key]
			  ,[Dim_Currency_Base_Key]
			  ,[Dim_Reference_Trial_Balance_Key]
			  ,[Dim_Source_Status_Key]

			  ,Reporting_Basis_Indicator
			  ,Currency_Category_Code
			  ,Beginning_Balance_Amount
		      ,Net_Debit_Activity_Amount
			  ,Net_Credit_Activity_Amount
			  ,Net_Activity_Amount
		      ,Ending_Balance_Amount

			  ,[Last_Update_Datetime]
			  ,[Load_Datetime]
			  ,[Source_Update_Datetime]
			  ,[Source_System_Code]
			  ,[Source_Deleted_Flag]
			  ,[ETL_Load_Key]
			  ,[Load_Detail_Description]
			  ,[Last_Update_User]
		)
		SELECT      @currentMaxId + rn
					,convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Effective_Date_Key]
					,Coalesce(freq.Dim_Dataset_Frequency_Key, -1) Dim_Dataset_Frequency_Key
					,Coalesce(p.Dim_Portfolio_Key, -1) [Dim_Portfolio_Key]
					,Coalesce(bc.Dim_Currency_Key, -1) Dim_Currency_Base_Key
					,Coalesce(rtb.Dim_Reference_Trial_Balance_Key,-1) Dim_Reference_Trial_Balance_Key
					,Coalesce(ss.Dim_Source_Status_Key, -1) Dim_Source_Status_Key

					,Basis
				    ,Currency_Category_Code
				    ,Beginning_Balance_Amount
				    ,Net_Debit_Activity_Amount
				    ,Net_Credit_Activity_Amount
				    ,Net_Activity_Amount
				    ,Ending_Balance_Amount

					,src.Last_Update_DT [Last_Update_Datetime]
					,src.Load_DTS [Load_Datetime]
					,null [Source_Update_Datetime]
					,@SourceSystem
					,src.Is_Src_Deleted
					,@ETL_Load_Key

					,Case When freq.Dim_Dataset_Frequency_Key is null or ss.Dim_Source_Status_Key is null or p.Dim_Portfolio_Key is null 
							or bc.Dim_Currency_Key is null or rtb.Dim_Reference_Trial_Balance_Key is null Then
						 '{' + 
						'"Report_Freq_Code": "' + Coalesce(convert(varchar(255), src.[Report_Freq_Code]),'') + '",' + 
						'"Fund": "' + Coalesce(convert(varchar(255), src.Fund),'') + '",' + 
						'"Base_Currency_Code":"' + Coalesce(convert(varchar(255), src.Base_Currency_Code),'') + '",' + 
						'"Local_Currency_Code":"' + Coalesce(convert(varchar(255), src.Local_Currency_Code),'') + '",' + 
						'"TB_Line_Item_Type":"' + Coalesce(convert(varchar(50), src.TB_Line_Item_Type),'') + '" ' + 
						'"TB_Line_Number":"' + Coalesce(convert(varchar(50), src.TB_Line_Number),'') + '" ' + 
						'"TB_Page_Number":"' + Coalesce(convert(varchar(50), src.TB_Page_Number),'') + '" ' + 
						'}'
					Else 
						null
					End 
				
					,@LastUpdateUser

		From (
				SELECT Period_End_Date Effective_Date
					  ,[Report_Freq_Code]
					  ,Fund
					  ,Base_Currency_Code
					  ,Local_Currency_Code
					  ,TB_Line_Item_Type
					  ,TB_Line_Number
					  ,TB_Page_Number

					  ,'PRELIM_UNAUD' Source_Status_Code

					    ,Basis
						,Local_Currency_Code as Currency_Category_Code
						,Report_Date_Starting_Balance as Beginning_Balance_Amount
						,Report_Date_Debits as Net_Debit_Activity_Amount
						,Report_Date_Credits as Net_Credit_Activity_Amount
						,Net_Activity as Net_Activity_Amount
						,Ending_Balance as Ending_Balance_Amount

					  ,Record_Created_DT Load_DTS
					  ,Last_Update_DT
					  ,Hash_Diff
					  ,Source_Deleted_Flag Is_Src_Deleted
					  ,row_number() Over(Order By (select 1)) rn
				    FROM   EDW_Raw.SS_MySS_MCH_WTB_Ledger P
                    WHERE Last_Update_DT > Coalesce(@lastLoadeDTS, '1900-01-01')
			) src
			Left Join EDP_Common.Dim_Portfolio p on src.Fund = p.Portfolio_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31') 
			Left Join [EDP_Common].[Dim_Currency] bc on src.Base_Currency_Code = bc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Dataset_Frequency] freq on src.[Report_Freq_Code] = freq.[Dataset_Frequency_Indicator]
			Left Join [EDP_Common].[Dim_Source_Record_Status] ss on src.Source_Status_Code = ss.Source_Status_Code
			Left Join [EDP_Common].[Dim_Reference_Trial_Balance] rtb on src.TB_Line_Item_Type = rtb.Trial_Balance_Reporting_Line_Item_Type_Number
						and src.[TB_Line_Number] = rtb.[Trial_Balance_Reporting_Line_Number]
						and src.[TB_Page_Number] = rtb.[Trial_Balance_Reporting_Page_Number]

		-- Fix -1 for security key, portfolio key in fact table
		exec EDW_DQ.[EDP_Eagle_SS_Fix_Missing_Keys] 'EDP_Common', 'Fact_SS_MCH_Ledger_Trial_Balance_Summary', 'Fact_SS_MCH_Ledger_Trial_Balance_Summary_ID', 'PORT', '7', @Batch_DTS, @ETL_Load_Key

		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.[Fact_SS_MCH_Ledger_Trial_Balance_Summary]
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_Ledger_Trial_Balance_Summary', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_Ledger_Trial_Balance_Summary', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_SS_MCH_Ledger_Trial_Balance_Summary', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_SS_MCH_Ledger_Trial_Balance_Summary', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END