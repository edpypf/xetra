﻿CREATE PROC [EDP_Common].[SFTP_EDP_NEXEN_Fact_BNYM_Eagle_STAR_General_Ledger_Balance] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@currentMaxId BigInt = 0,
			@loadStartTime datetime2,
			@loadEndTime datetime2,
			@SourceSystem varchar(255),
			@LastUpdateUser varchar(255)
	
	Begin Try


		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max([Last_Update_Datetime]), '1900-01-01'), 
		       @currentMaxId = coalesce(max([Fact_BNYM_Eagle_STAR_General_Ledger_Balance_ID]), 0)
		From [EDP_Common].[Fact_BNYM_Eagle_STAR_General_Ledger_Balance]

		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'NEXEN-BNYM-STAR', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		INSERT INTO [EDP_Common].Fact_BNYM_Eagle_STAR_General_Ledger_Balance
           (  [Fact_BNYM_Eagle_STAR_General_Ledger_Balance_ID]
			  ,[Dim_Effective_Date_Key]
			  ,[Dim_Dataset_Frequency_Key]
			  ,[Dim_Portfolio_Key]
			  ,[Dim_Currency_Base_Key]
			  ,[Dim_General_Ledger_Account_Key]
			  ,[Dim_Accounting_Share_Class_Key]
			  ,[Dim_Source_Status_Key]
			  ,[Last_Update_Datetime]

			  ,[General_Ledger_Currency_Local_Code]
			  ,[Reporting_Basis_Indicator]
			  ,[General_Ledger_Grouping_Code]
			  ,[Beginning_Balance_Amount]
			  ,[Net_Debit_Activity_Amount]
			  ,[Net_Credit_Activity_Amount]
			  ,[Net_Activity_Amount]
			  ,[Ending_Balance_Amount]

			  ,[Source_Update_Datetime]
			  ,[Load_Detail_Description]

			  ,[ETL_Load_Key]
			  ,Load_Datetime
			  ,Source_Deleted_Flag
			  ,Last_Update_User
			  ,Source_System_Code
		)
		SELECT      @currentMaxId + rn
					,convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Effective_Date_Key]
					,Coalesce(freq.Dim_Dataset_Frequency_Key, -1) Dim_Dataset_Frequency_Key
					,Coalesce(p.Dim_Portfolio_Key, -1) [Dim_Portfolio_Key]
					,Coalesce(bc.Dim_Currency_Key, -1) Dim_Currency_Base_Key
					,Coalesce(glc.Dim_General_Ledger_Account_Key, -1) Dim_General_Ledger_Account_Key
					,Coalesce(sc.Dim_Accounting_Share_Class_Key, -1) Dim_Accounting_Share_Class_Key
					,Coalesce(ss.Dim_Source_Status_Key, -1) Dim_Source_Status_Key
					,src.Last_Update_DT

					,'NA' [General_Ledger_Currency_Local_Code]
					,'NA' [Reporting_Basis_Indicator]
					,[General_Ledger_Grouping_Code]
					,[Beginning_Balance_Amount]
					,[Net_Debit_Activity_Amount]
					,[Net_Credit_Activity_Amount]
					,[Net_Activity_Amount]
					,[Ending_Balance_Amount]


					,null [Source_Update_Datetime]
					,Case When freq.Dim_Dataset_Frequency_Key is null or ss.Dim_Source_Status_Key is null or p.Dim_Portfolio_Key is null 
							or glc.Dim_General_Ledger_Account_Key is null or bc.Dim_Currency_Key is null
							or ss.Dim_Source_Status_Key is null 
					 Then
						 '{' + 
						'"Report_Freq_Code": "' + Coalesce(convert(varchar(255), src.[Report_Freq_Code]),'') + '",' + 
						'"Account_Number": "' + Coalesce(convert(varchar(255), src.Account_Number),'') + '",' + 
						'"Base_Currency_Code":"' + Coalesce(convert(varchar(255), src.Base_Currency_Code),'') + '",' + 
						'"Ledger_Account_Number":"' + Coalesce(convert(varchar(255), src.Ledger_Account_Number),'') + '",' + 
						'"Share_Class":"' + Coalesce(convert(varchar(50), src.Share_Class),'') + '" ' + 
						'"Source_Status_Code":"' + Coalesce(convert(varchar(50), src.Source_Status_Code),'') + '" ' + 
						'}'
					Else 
						null
					End 
					,@ETL_Load_Key
					,src.Load_DTS
					,src.Is_Src_Deleted
					,@LastUpdateUser
					,@SourceSystem

		From (
				SELECT End_Date as Effective_Date
					  ,[Report_Freq_Code]
					  ,Account_Number
					  ,Ledger_Account_Number
					  ,Base_Currency_Code
					  ,Share_Class

					  ,Coalesce(Ledger_Grouping,'NA') as General_Ledger_Grouping_Code
					  ,Beginning_Balance Beginning_Balance_Amount
					  ,Net_Debit_Activity Net_Debit_Activity_Amount
					  ,Net_Credit_Activity Net_Credit_Activity_Amount
					  ,Net_Activity Net_Activity_Amount
					  ,Ending_Balance Ending_Balance_Amount

					  ,Case When [Report_Freq_Code] = 'D' Then 'PRELIM_UNAUD'
					        When [Report_Freq_Code] = 'M' Then 'MTH_END_CLOSED'
					   Else 'NA' End Source_Status_Code

					  ,Record_Created_DT Load_DTS
					  ,Last_Update_DT
					  ,Hash_Diff
					  ,Source_Deleted_Flag Is_Src_Deleted
					  ,row_number() Over(Order By (select 1)) rn
				    FROM EDW_Raw.BNYM_SSE_STAR_WTB_Account_with_Class P
                    WHERE Ledger_Account_Number is not null
					and Last_Update_DT > Coalesce(@lastLoadeDTS, '1900-01-01')
					
			) src
			Left Join EDP_Common.Dim_Portfolio p on src.Account_Number = p.Portfolio_Id and src.Effective_Date between p.Effective_Start_Datetime and coalesce(p.Effective_End_Datetime, '9999-12-31') 
			Left Join [EDP_Common].[Dim_Currency] bc on src.Base_Currency_Code = bc.CURRENCY_CODE
			Left Join [EDP_Common].[Dim_Dataset_Frequency] freq on src.[Report_Freq_Code] = freq.[Dataset_Frequency_Indicator]
			Left Join [EDP_Common].[Dim_General_Ledger_Account] glc on src.Ledger_Account_Number = glc.General_Ledger_Account_ID and src.Effective_Date between glc.Effective_Start_Datetime and coalesce(glc.Effective_End_Datetime, '9999-12-31') 
			Left Join [EDP_Common].[Dim_Accounting_Share_Class] sc on src.Share_Class = sc.Accounting_Share_Class_Code
			Left Join [EDP_Common].[Dim_Source_Record_Status] ss on src.Source_Status_Code = ss.Source_Status_Code

		-- Fix -1 for portfolio key in fact table
		exec EDW_DQ.EDP_Eagle_Nexen_Fix_Missing_Keys 'EDP_Common', 'Fact_BNYM_Eagle_STAR_General_Ledger_Balance', 'Fact_BNYM_Eagle_STAR_General_Ledger_Balance_ID', 'PORT', '7', @Batch_DTS, @ETL_Load_Key

		-- Set load end time
		Select @loadEndTime = Getdate()

		Select @rowsInserted = Count(*) 
		From EDP_Common.[Fact_BNYM_Eagle_STAR_General_Ledger_Balance]
		Where Last_Update_Datetime = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_BNYM_Eagle_STAR_General_Ledger_Balance', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_BNYM_Eagle_STAR_General_Ledger_Balance', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Fact_BNYM_Eagle_STAR_General_Ledger_Balance', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Batch_DTS, @ETL_Load_Key, 'Fact_BNYM_Eagle_STAR_General_Ledger_Balance', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END