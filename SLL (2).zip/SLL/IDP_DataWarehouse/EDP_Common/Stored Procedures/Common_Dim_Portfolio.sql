﻿CREATE PROC [EDP_Common].[Common_Dim_Portfolio] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

Declare @today datetime2 = getdate(),
        @loadStartTime datetime2,
		@loadEndTime datetime2,
		@SourceSystem varchar(255),
		@LastUpdateUser varchar(255)

Declare @rowsInserted int = 0,
		@rowsUpdated int = 0,
		@rowsExpired int = 0

	Begin Try

		IF OBJECT_ID('tempdb..#temp_eagle_dim_portfolio_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_dim_portfolio_records
		END

		IF OBJECT_ID('tempdb..#temp_eagle_official_entities') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_official_entities
		END
		
		Select @SourceSystem = Source_System, @LastUpdateUser = 'svc_EDP_' + Load_Run_Env
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		Select @SourceSystem = 'IDW-PORT', 
			   @LastUpdateUser = coalesce(@LastUpdateUser, 'svc_EDP')

		-- Set load start time
		Select @loadStartTime = @today

		--Get official entity list
		create table #temp_eagle_official_entities
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		WITH Official_List as (
			  SELECT Rtrim(CV.SHORT_DESC) AS ENTITY_ID
			  FROM PSA.V_Eagle_CODES C
			  INNER JOIN PSA.V_Eagle_CODE_VALUES CV  ON C.INSTANCE           = CV.CODE_INST
			  WHERE C.SHORT_DESC      = 'EDP_RelObjListM'
			  AND   CV.LONG_DESC      = 'OfficialPerfPortList'
			  AND CV.INTFC_INST       in
				(SELECT instance
				FROM PSA.V_Eagle_INTERFACES
				WHERE short_desc = 'EAGLE PACE'
				)
			  And C.Is_Src_Deleted = 0 and CV.Is_Src_Deleted = 0
		),
		ol_list_member as (
				SELECT  Rtrim(SL.CODE_VALUE) Entity_Id
				FROM PSA.V_Eagle_ENTITY_LIST SL
				INNER JOIN PSA.V_Eagle_ENTITY SE ON SL.CODE_VALUE = SE.ENTITY_ID
				WHERE   SL.ENTITY_ID in ( SELECT ENTITY_ID FROM Official_List )
				AND     SE.ENTITY_TYPE = 'LIST'
				and SL.Is_Src_Deleted = 0 and SE.Is_Src_Deleted = 0

		)
		SELECT  EL.CODE_VALUE Entity_Id
		FROM    PSA.V_Eagle_ENTITY_LIST EL
		Join    PSA.V_Eagle_ENTITY E ON TRIM(EL.CODE_VALUE) = TRIM(E.ENTITY_ID)
		Join    Official_List ol on EL.Entity_Id = ol.Entity_Id
		Where   EL.Is_Src_Deleted = 0 and E.Is_Src_Deleted = 0

		Union

		SELECT  EL.CODE_VALUE Entity_Id
		FROM    PSA.V_Eagle_ENTITY_LIST EL
		Join    PSA.V_Eagle_ENTITY E ON TRIM(EL.CODE_VALUE) = TRIM(E.ENTITY_ID)
		Join    ol_list_member olm on EL.Entity_Id = olm.Entity_Id
		Where   EL.Is_Src_Deleted = 0 and E.Is_Src_Deleted = 0


		-- load latest Eagle entity records from source into temp table
		create table #temp_eagle_dim_portfolio_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select	Rtrim(E.[Entity_ID]) Portfolio_id
				,Rtrim(E.[Entity_Name]) Portfolio_Name
				,E.Entity_Type Portfolio_Type_Code
				,ET.Portfolio_Type Portfolio_Type_Name
				,ET.Portfolio_Type Portfolio_Type_Description
				,E.User_Date3 Performance_Inception_Date
				,Rtrim(EX.XREF_ACCOUNT_ID) Eagle_STAR_Portfolio_Id
				,Rtrim(EXG.XREF_ACCOUNT_ID) Geneva_Subportfolio_Id
				,Rtrim(EXS.XREF_ACCOUNT_ID) State_Street_Portfolio_Id
				,case when OE.[Entity_ID] is null then 0 else 1 end [Performance_Official_Ownership_Flag]
				,CONVERT(VARCHAR(64), Hashbytes('SHA1', Upper(concat(E.Entity_Type, '|', ET.Portfolio_Type, '|',
								Rtrim(E.[Entity_Name]) , '|', E.User_Date3, '|', Rtrim(EX.XREF_ACCOUNT_ID) , '|', 
								Rtrim(EXG.XREF_ACCOUNT_ID) , '|', Rtrim(EXS.XREF_ACCOUNT_ID), '|'))), 2 ) Hash_Diff
				,E.Is_Src_Deleted
				,'Eagle' Source_System
		From PSA.V_Eagle_Entity E
		Left Join (
			SELECT Rtrim(CV.SHORT_DESC) Portfolio_Type_Code, Rtrim(CV.LONG_DESC) Portfolio_Type
			From PSA.V_Eagle_CODE_VALUES CV
			Join PSA.V_Eagle_Codes C on CV.Code_INST = C.Instance
			Join PSA.V_Eagle_Interfaces I On CV.INTFC_INST = I.INSTANCE
			Where I.SHORT_DESC = 'EAGLE PACE' and C.SHORT_DESC = 'INT ENT TYPE' 
			and CV.Is_Src_Deleted = 0
		) ET on E.Entity_Type = ET.Portfolio_Type_Code
		Left Join PSA.V_Eagle_ENTITY_XREFERENCE EX on E.ENTITY_ID = EX.Entity_Id 
					and EX.XREF_ACCOUNT_ID_TYPE = 'STAR' 
		Left Join PSA.V_Eagle_ENTITY_XREFERENCE EXG on E.ENTITY_ID = EXG.Entity_Id 
					and EXG.XREF_ACCOUNT_ID_TYPE = 'GENEVA_ACCOUNT_ID' 
		Left Join PSA.V_Eagle_ENTITY_XREFERENCE EXS on E.ENTITY_ID = EXS.Entity_Id 
					and EXS.XREF_ACCOUNT_ID_TYPE = 'SSFUNDID' 
		Left Join #temp_eagle_official_entities OE on E.[Entity_ID] = OE.[Entity_ID]
		where E.Entity_Type in ('SUB','PORT','COMP') 


		--UPDATE/EXPIRE EXISTING RECORDS
		Update tgt
		Set 	Effective_End_Datetime = @today,
				Is_Current_Flag= 0, 
				Last_Update_Datetime=@today, 
				ETL_Load_Key = @ETL_Load_Key,
				Last_Update_User = @LastUpdateUser,
				Source_System_Code = @SourceSystem

		From EDP_Common.Dim_Portfolio tgt
		Where tgt.Dim_Portfolio_Key > -1 and tgt.Is_Current_Flag = 1 and 
		(
			exists
			(	Select	1
				From	#temp_eagle_dim_portfolio_records src
				Where	tgt.Portfolio_Id = src.Portfolio_Id 
						and ( coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1 )
			)

			or
			not exists (
				Select	1
				From	#temp_eagle_dim_portfolio_records src
				Where	tgt.Portfolio_Id = src.Portfolio_Id and tgt.Portfolio_Type_Code = src.Portfolio_Type_Code 
			)
		)

		-- Update type 1 fields ([Performance_Official_Ownership_Flag])
		Update tgt
		Set 	[Performance_Official_Ownership_Flag] = 1,
				Last_Update_Datetime=@today, 
				ETL_Load_Key = @ETL_Load_Key,
				Last_Update_User = @LastUpdateUser,
				Source_System_Code = @SourceSystem

		From EDP_Common.Dim_Portfolio tgt
		Join #temp_eagle_official_entities OE on tgt.Portfolio_Id = OE.[Entity_ID]
		Where tgt.Dim_Portfolio_Key > -1 and coalesce(tgt.[Performance_Official_Ownership_Flag],0) = 0


		--INSERT NEW RECORDS INTO DIM TABLE
		insert into EDP_Common.Dim_Portfolio
		(
			  [Portfolio_ID]
			  ,[State_Street_Portfolio_ID]
			  ,[Eagle_STAR_Portfolio_ID]
			  ,[Portfolio_Type_Code]
			  ,[Portfolio_Type_Name]
			  ,[Geneva_Subportfolio_ID]
			  ,[Portfolio_Type_Description]
			  ,[Portfolio_Name]
			  ,[Performance_Inception_Date]
			  ,[Performance_Official_Ownership_Flag]
			  ,Is_Current_Flag
			  ,Effective_Start_Datetime
			  ,Effective_End_Datetime
			  ,Last_Update_Datetime
			  ,ETL_Load_Key
			  ,Hash_Diff
			  ,Last_Update_User
			  ,Source_System_Code 
		)
			select src.[Portfolio_ID]
				  ,src.[State_Street_Portfolio_ID]
				  ,src.[Eagle_STAR_Portfolio_ID]
				  ,src.[Portfolio_Type_Code]
				  ,src.[Portfolio_Type_Name]
				  ,src.[Geneva_Subportfolio_ID]
				  ,src.[Portfolio_Type_Description]
				  ,src.[Portfolio_Name]
				  ,src.[Performance_Inception_Date]
				  ,src.[Performance_Official_Ownership_Flag]
				  ,1
				  ,case when tgt_all.Portfolio_Id is null then '1900-01-01' else @today End 
				  ,'9999-12-31'
				  ,@today
				  ,@ETL_Load_Key
				  ,src.Hash_Diff
				  ,@LastUpdateUser
				  ,@SourceSystem

			from	#temp_eagle_dim_portfolio_records src
					Left Join EDP_Common.Dim_Portfolio tgt on src.Portfolio_Id = tgt.Portfolio_Id and tgt.Is_Current_Flag = 1
					Left Join (Select Distinct Portfolio_Id From EDP_Common.Dim_Portfolio) tgt_all on src.Portfolio_Id = tgt_all.Portfolio_Id
			where	(
						tgt.Portfolio_Id is null 
						or (tgt.Portfolio_Id is not null and src.Hash_Diff <> tgt.Hash_Diff)
					)
					and src.Is_Src_Deleted = 0

		-- Set load end time
		Select @loadEndTime = Getdate()

		--ETL Logging
		Select @rowsInserted = Count(*) 
		From EDP_Common.Dim_Portfolio
		Where ETL_Load_Key = @ETL_Load_Key and Dim_Portfolio_Key > 0 and 
		([Effective_Start_Datetime] = @today or [Effective_Start_Datetime]='1900-01-01')
		and Is_Current_Flag = 1

		Select @rowsUpdated = Count(*)
		From EDP_Common.Dim_Portfolio
		Where ETL_Load_Key = @ETL_Load_Key and [Effective_End_Datetime] = @today

		Select @rowsExpired = Count(*)
		From EDP_Common.Dim_Portfolio p
		Left Join (Select Portfolio_Id From EDP_Common.Dim_Portfolio Where Is_Current_Flag = 1) pc on p.Portfolio_Id = pc.Portfolio_Id 
		Where ETL_Load_Key = @ETL_Load_Key and [Effective_End_Datetime] = @today and pc.Portfolio_Id is null

		-- populate EDW ETL log table
		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Dim_Portfolio', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Load_DTS, @ETL_Load_Key, 'Dim_Portfolio', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null


		-- Force cleanup temp tables
		IF OBJECT_ID('tempdb..#temp_eagle_dim_portfolio_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_dim_portfolio_records
		END

		IF OBJECT_ID('tempdb..#temp_eagle_official_entities') IS NOT NULL
		BEGIN
			DROP TABLE #temp_eagle_official_entities
		END

    END TRY

	--Error Handling
	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDP_Common.Dim_Portfolio', 0, 0, 0, 'Failed', @ErrorMessage

		-- populate EDP log table
		Exec EDP_Common.Update_Load_Log @Load_DTS, @ETL_Load_Key, 'Dim_Portfolio', @loadStartTime, @loadEndTime, @rowsInserted, @rowsUpdated, @rowsExpired, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END