﻿CREATE TABLE [EDP_Common].[Dim_Security] (
    [Dim_Security_Key]                      BIGINT        IDENTITY (1, 1) NOT NULL,
    [IMCO_Security_Alias_ID]                VARCHAR (16)  NOT NULL,
    [Security_Name]                         VARCHAR (255) NOT NULL,
    [Security_Description]                  VARCHAR (255) NULL,
    [Security_Currency_Code]                VARCHAR (16)  NULL,
    [CUSIP_ID]                              VARCHAR (255) NULL,
    [ISIN_ID]                               VARCHAR (255) NULL,
    [SEDOL_ID]                              VARCHAR (255) NULL,
    [Ticker_ID]                             VARCHAR (255) NULL,
    [Dynamo_ID]                             VARCHAR (255) NULL,
    [BNYM_ID]                               VARCHAR (255) NULL,
    [Geneva_ID]                             VARCHAR (255) NULL,
    [State_Street_CUSIP_ID]                 VARCHAR (255) NULL,
    [Is_Current_Flag]                       BIT           NOT NULL,
    [Source_System_Code]                    VARCHAR (255) NULL,
    [ETL_Load_Key]                          BIGINT        NOT NULL,
    [Hash_Diff]                             VARCHAR (64)  NOT NULL,
    [Effective_Start_Datetime]              DATETIME2 (7) NOT NULL,
    [Effective_End_Datetime]                DATETIME2 (7) NOT NULL,
    [Last_Update_User]                      VARCHAR (255) NULL,
    [Last_Update_Datetime]                  DATETIME2 (7) NOT NULL,
    [IMCO_Asset_Type_Code]                  VARCHAR (255) NULL,
    [IMCO_Asset_Type_Name]                  VARCHAR (255) NULL,
    [IMCO_Asset_Sub_Type_Code]              VARCHAR (255) NULL,
    [IMCO_Asset_Sub_Type_Name]              VARCHAR (255) NULL,
    [IMCO_Security_Type_Code]               VARCHAR (255) NULL,
    [IMCO_Security_Type_Name]               VARCHAR (255) NULL,
    [BNYM_Eagle_STAR_Primary_Asset_ID]      VARCHAR (255) NULL,
    [BNYM_Eagle_STAR_Primary_Asset_ID_Type] VARCHAR (255) NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Security_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = REPLICATE);









