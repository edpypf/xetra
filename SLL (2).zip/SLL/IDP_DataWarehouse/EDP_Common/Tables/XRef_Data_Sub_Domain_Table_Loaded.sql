﻿CREATE TABLE [EDP_Common].[XRef_Data_Sub_Domain_Table_Loaded] (
    [Data_Sub_Domain_Code]   VARCHAR (64)  NOT NULL,
    [Table_Loaded_Long_Name] VARCHAR (64)  NOT NULL,
    [Source_System_Code]     VARCHAR (255) NOT NULL,
    [Last_Update_User]       VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]   DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_XREF_Data_Domain] PRIMARY KEY NONCLUSTERED ([Data_Sub_Domain_Code] ASC, [Table_Loaded_Long_Name] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Data_Sub_Domain_Code]));







