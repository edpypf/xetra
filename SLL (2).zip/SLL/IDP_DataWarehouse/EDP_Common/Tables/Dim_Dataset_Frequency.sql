﻿CREATE TABLE [EDP_Common].[Dim_Dataset_Frequency] (
    [Dim_Dataset_Frequency_Key]   BIGINT        IDENTITY (1, 1) NOT NULL,
    [Dataset_Frequency_Indicator] VARCHAR (2)   NOT NULL,
    [Dataset_Frequency_Name]      VARCHAR (255) NOT NULL,
    [Dataset_Frequency_Long_Name] VARCHAR (255) NULL,
    [Source_System_Code]          VARCHAR (255) NOT NULL,
    [Last_Update_User]            VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]        DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Dataset_Frequency_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

