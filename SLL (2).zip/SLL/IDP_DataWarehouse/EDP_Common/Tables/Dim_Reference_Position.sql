﻿CREATE TABLE [EDP_Common].[Dim_Reference_Position] (
    [Dim_Reference_Position_Key] BIGINT        IDENTITY (1, 1) NOT NULL,
    [Fair_Value_Level_Code]      VARCHAR (20)  NOT NULL,
    [Price_Type_Code]            VARCHAR (20)  NOT NULL,
    [Fair_Value_Level_Name]      VARCHAR (255) NOT NULL,
    [Fair_Value_Level_Long_Name] VARCHAR (255) NULL,
    [Price_Type_Name]            VARCHAR (255) NOT NULL,
    [Price_Type_Long_Name]       VARCHAR (255) NULL,
    [Source_System_Code]         VARCHAR (255) NOT NULL,
    [Last_Update_User]           VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]       DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Reference_Position_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

