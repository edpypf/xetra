﻿CREATE TABLE [EDP_Common].[Dim_General_Ledger_Account] (
    [Dim_General_Ledger_Account_Key]                BIGINT        IDENTITY (1, 1) NOT NULL,
    [General_Ledger_Account_ID]                     VARCHAR (64)  NOT NULL,
    [General_Ledger_Account_Name]                   VARCHAR (255) NOT NULL,
    [General_Ledger_Account_Description]            VARCHAR (255) NOT NULL,
    [Eagle_STAR_Standard_Account_Name]              VARCHAR (255) NULL,
    [General_Ledger_Category_Code]                  VARCHAR (255) NULL,
    [State_Street_General_Ledger_Account_ID]        VARCHAR (64)  NULL,
    [Eagle_STAR_General_Ledger_Account_ID]          VARCHAR (64)  NULL,
    [Eagle_STAR_General_Ledger_Standard_Account_ID] VARCHAR (64)  NULL,
    [Source_System_Code]                            VARCHAR (255) NOT NULL,
    [Is_Current_Flag]                               BIT           NOT NULL,
    [Effective_Start_Datetime]                      DATETIME2 (7) NOT NULL,
    [Effective_End_Datetime]                        DATETIME2 (7) NOT NULL,
    [ETL_Load_Key]                                  BIGINT        NOT NULL,
    [Hash_Diff]                                     VARCHAR (64)  NOT NULL,
    [Last_Update_User]                              VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]                          DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_General_Ledger_Account_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

