﻿CREATE TABLE [EDP_Common].[Dim_Portfolio] (
    [Dim_Portfolio_Key]                   BIGINT        IDENTITY (1, 1) NOT NULL,
    [Portfolio_ID]                        VARCHAR (16)  NOT NULL,
    [State_Street_Portfolio_ID]           VARCHAR (16)  NULL,
    [Eagle_STAR_Portfolio_ID]             VARCHAR (16)  NULL,
    [Portfolio_Type_Code]                 VARCHAR (20)  NULL,
    [Portfolio_Type_Name]                 VARCHAR (30)  NOT NULL,
    [Geneva_Subportfolio_ID]              VARCHAR (255) NULL,
    [Portfolio_Type_Description]          VARCHAR (255) NOT NULL,
    [Portfolio_Name]                      VARCHAR (255) NULL,
    [Performance_Inception_Date]          DATE          NULL,
    [Is_Current_Flag]                     BIT           NOT NULL,
    [Source_System_Code]                  VARCHAR (255) NULL,
    [ETL_Load_Key]                        BIGINT        NOT NULL,
    [Hash_Diff]                           VARCHAR (64)  NOT NULL,
    [Effective_Start_Datetime]            DATETIME2 (7) NOT NULL,
    [Effective_End_Datetime]              DATETIME2 (7) NOT NULL,
    [Last_Update_User]                    VARCHAR (255) NULL,
    [Last_Update_Datetime]                DATETIME2 (7) NOT NULL,
    [Performance_Official_Ownership_Flag] BIT           DEFAULT ((0)) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Portfolio_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = REPLICATE);











