﻿CREATE TABLE [EDP_Common].[Fact_BNYM_Eagle_STAR_General_Ledger_Balance] (
    [Fact_BNYM_Eagle_STAR_General_Ledger_Balance_ID] BIGINT           NOT NULL,
    [Dim_Effective_Date_Key]                         BIGINT           NOT NULL,
    [Dim_Dataset_Frequency_Key]                      BIGINT           NOT NULL,
    [Dim_Portfolio_Key]                              BIGINT           NOT NULL,
    [Dim_General_Ledger_Account_Key]                 BIGINT           NOT NULL,
    [Dim_Accounting_Share_Class_Key]                 BIGINT           NOT NULL,
    [Dim_Currency_Base_Key]                          BIGINT           NOT NULL,
    [Dim_Source_Status_Key]                          BIGINT           NOT NULL,
    [General_Ledger_Currency_Local_Code]             VARCHAR (4)      NOT NULL,
    [Reporting_Basis_Indicator]                      VARCHAR (2)      NOT NULL,
    [General_Ledger_Grouping_Code]                   VARCHAR (64)     NOT NULL,
    [Last_Update_Datetime]                           DATETIME2 (7)    NOT NULL,
    [Load_Datetime]                                  DATETIME2 (7)    NOT NULL,
    [Beginning_Balance_Amount]                       DECIMAL (28, 12) NULL,
    [Net_Debit_Activity_Amount]                      DECIMAL (28, 12) NULL,
    [Net_Credit_Activity_Amount]                     DECIMAL (28, 12) NULL,
    [Net_Activity_Amount]                            DECIMAL (28, 12) NULL,
    [Ending_Balance_Amount]                          DECIMAL (28, 12) NULL,
    [Source_Update_Datetime]                         DATETIME2 (7)    NULL,
    [Source_System_Code]                             VARCHAR (255)    NOT NULL,
    [Source_Deleted_Flag]                            BIT              NOT NULL,
    [ETL_Load_Key]                                   BIGINT           NOT NULL,
    [Load_Detail_Description]                        VARCHAR (4000)   NULL,
    [Last_Update_User]                               VARCHAR (255)    NOT NULL,
    CONSTRAINT [PK_Fact_BNYM_Eagle_STAR_General_Ledger_Balance] PRIMARY KEY NONCLUSTERED ([Dim_Effective_Date_Key] ASC, [Dim_Dataset_Frequency_Key] ASC, [Dim_Portfolio_Key] ASC, [Dim_General_Ledger_Account_Key] ASC, [Dim_Accounting_Share_Class_Key] ASC, [Dim_Currency_Base_Key] ASC, [Dim_Source_Status_Key] ASC, [General_Ledger_Currency_Local_Code] ASC, [Reporting_Basis_Indicator] ASC, [General_Ledger_Grouping_Code] ASC, [Last_Update_Datetime] ASC, [Load_Datetime] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Dim_Portfolio_Key]));

