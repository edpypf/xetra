﻿CREATE TABLE [EDP_Common].[Dim_Reference_Trial_Balance] (
    [Dim_Reference_Trial_Balance_Key]               BIGINT        IDENTITY (1, 1) NOT NULL,
    [Trial_Balance_Line_Description_Code]           VARCHAR (64)  NOT NULL,
    [Trial_Balance_Reporting_Line_Number]           INT           NOT NULL,
    [Trial_Balance_Reporting_Page_Number]           INT           NOT NULL,
    [Trial_Balance_Reporting_Line_Item_Type_Number] INT           NOT NULL,
    [Source_System_Code]                            VARCHAR (255) NOT NULL,
    [Last_Update_User]                              VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]                          DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Reference_Trial_Balance_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

