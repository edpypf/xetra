﻿CREATE TABLE [EDP_Common].[Dim_Date] (
    [Dim_Date_Key]         BIGINT        IDENTITY (1, 1) NOT NULL,
    [Date]                 DATE          NOT NULL,
    [Year]                 INT           NULL,
    [Day_Of_Year]          INT           NULL,
    [Day_Of_Month]         INT           NULL,
    [Day_Of_Week]          INT           NULL,
    [First_Day_Of_Month]   DATE          NULL,
    [Last_Day_Of_Month]    DATE          NULL,
    [Weekday_Flag]         BIT           NULL,
    [Month_End_Flag]       BIT           NULL,
    [Month_Full_Name]      VARCHAR (50)  NULL,
    [Month_Short_Name]     VARCHAR (50)  NULL,
    [Weekday_Full_name]    VARCHAR (50)  NULL,
    [Weekday_Short_Name]   VARCHAR (50)  NULL,
    [Quarter_Of_Year]      INT           NULL,
    [Week_Of_Year]         INT           NULL,
    [Month_Of_Year]        INT           NULL,
    [Source_System_Code]   VARCHAR (255) NULL,
    [Last_Update_User]     VARCHAR (255) NULL,
    [Last_Update_Datetime] DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Date_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = REPLICATE);







