﻿CREATE TABLE [EDP_Common].[Dim_Long_Short_Direction] (
    [Dim_Long_Short_Direction_Key]   BIGINT        IDENTITY (1, 1) NOT NULL,
    [Long_Short_Direction_Indicator] VARCHAR (2)   NOT NULL,
    [Long_Short_Direction_Name]      VARCHAR (255) NOT NULL,
    [Long_Short_Direction_Long_Name] VARCHAR (255) NULL,
    [Source_System_Code]             VARCHAR (255) NOT NULL,
    [Last_Update_User]               VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]           DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Long_Short_Direction_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

