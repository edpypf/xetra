﻿CREATE TABLE [EDP_Common].[Dim_Benchmark] (
    [Dim_Benchmark_Key]                   BIGINT        IDENTITY (1, 1) NOT NULL,
    [Benchmark_ID]                        VARCHAR (16)  NOT NULL,
    [Benchmark_Name]                      VARCHAR (255) NULL,
    [Benchmark_Description]               VARCHAR (255) NULL,
    [Benchmark_Type_Code]                 VARCHAR (20)  NULL,
    [Benchmark_Type_Name]                 VARCHAR (30)  NULL,
    [Benchmark_Type_Description]          VARCHAR (255) NULL,
    [Source_System_Code]                  VARCHAR (255) NOT NULL,
    [Is_Current_Flag]                     BIT           NOT NULL,
    [Effective_Start_Datetime]            DATETIME2 (7) NOT NULL,
    [Effective_End_Datetime]              DATETIME2 (7) NOT NULL,
    [ETL_Load_Key]                        BIGINT        NOT NULL,
    [Hash_Diff]                           VARCHAR (64)  NOT NULL,
    [Last_Update_User]                    VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]                DATETIME2 (7) NOT NULL,
    [Performance_Official_Ownership_Flag] BIT           DEFAULT ((0)) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Benchmark_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = REPLICATE);





