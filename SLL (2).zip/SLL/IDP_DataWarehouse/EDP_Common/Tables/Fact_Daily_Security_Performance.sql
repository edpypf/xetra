﻿CREATE TABLE [EDP_Common].[Fact_Daily_Security_Performance] (
    [Fact_Daily_Security_Performance_ID] BIGINT           NOT NULL,
    [Dim_Security_Key]                   BIGINT           NOT NULL,
    [Dim_Source_Status_Key]              BIGINT           NOT NULL,
    [Dim_Effective_Date_Key]             BIGINT           NOT NULL,
    [Dim_Portfolio_Key]                  BIGINT           NOT NULL,
    [Dim_Security_Currency_Key]          BIGINT           NOT NULL,
    [Last_Update_Datetime]               DATETIME2 (7)    NOT NULL,
    [Gross_Market_Value_BOD_Amount]      DECIMAL (28, 12) NULL,
    [Gross_Market_Value_EOD_Amount]      DECIMAL (28, 12) NULL,
    [Gross_Total_Cashflow_Amount]        DECIMAL (28, 12) NULL,
    [Gross_Gain_Loss_Amount]             DECIMAL (28, 12) NULL,
    [Local_Total_Cashflow_Amount]        DECIMAL (28, 12) NULL,
    [Local_Market_Value_BOD_Amount]      DECIMAL (28, 12) NULL,
    [Local_Market_Value_EOD_Amount]      DECIMAL (28, 12) NULL,
    [Local_Gain_Loss_Amount]             DECIMAL (28, 12) NULL,
    [Gross_Investment_Base_Amount]       DECIMAL (28, 12) NULL,
    [Gross_Return_Percentage]            DECIMAL (28, 12) NULL,
    [Local_Return_Percentage]            DECIMAL (28, 12) NULL,
    [Accrued_Income_Amount]              DECIMAL (28, 12) NULL,
    [Portfolio_Proportion_Percentage]    DECIMAL (28, 12) NULL,
    [ETL_Load_Key]                       BIGINT           NOT NULL,
    [Load_Datetime]                      DATETIME2 (7)    NOT NULL,
    [Source_Update_Datetime]             DATETIME2 (7)    NULL,
    [Source_Deleted_Flag]                BIT              NOT NULL,
    [Source_System_Code]                 VARCHAR (255)    NOT NULL,
    [Load_Detail_Description]            VARCHAR (4000)   NULL,
    [Last_Update_User]                   VARCHAR (255)    NULL,
    CONSTRAINT [PK_Fact_Daily_Security_Performance] PRIMARY KEY NONCLUSTERED ([Dim_Security_Key] ASC, [Dim_Portfolio_Key] ASC, [Dim_Security_Currency_Key] ASC, [Dim_Effective_Date_Key] ASC, [Dim_Source_Status_Key] ASC, [Last_Update_Datetime] ASC, [Load_Datetime] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Dim_Security_Key]));





