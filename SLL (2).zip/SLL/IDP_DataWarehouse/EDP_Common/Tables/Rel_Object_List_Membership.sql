﻿CREATE TABLE [EDP_Common].[Rel_Object_List_Membership] (
    [Object_List_ID]               VARCHAR (16)  NOT NULL,
    [Object_List_Member_ID]        VARCHAR (16)  NOT NULL,
    [Object_List_Purpose_Code]     VARCHAR (255) NOT NULL,
    [Object_List_Member_Type_Code] VARCHAR (64)  NOT NULL,
    [Object_List_Purpose_Name]     VARCHAR (255) NULL,
    [Data_Sub_Domain_Code]         VARCHAR (64)  NOT NULL,
    [Source_Deleted_Flag]          BIT           NOT NULL,
    [Source_System_Code]           VARCHAR (255) NOT NULL,
    [ETL_Load_Key]                 BIGINT        NOT NULL,
    [Hash_Diff]                    VARCHAR (64)  NOT NULL,
    [Create_Datetime]              DATETIME2 (7) NOT NULL,
    [Last_Update_User]             VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]         DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_Rel_Object_List_Membership] PRIMARY KEY NONCLUSTERED ([Object_List_ID] ASC, [Object_List_Member_ID] ASC, [Object_List_Purpose_Code] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Object_List_ID]));

