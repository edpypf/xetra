﻿CREATE TABLE [EDP_Common].[Bridge_Portfolio_Benchmark] (
    [Dim_Effective_Date_Key]                  BIGINT         NOT NULL,
    [Dim_Portfolio_Key]                       BIGINT         NOT NULL,
    [Dim_Primary_Comparison_Benchmark_Key]    BIGINT         NOT NULL,
    [Dim_Secondary_Comparision_Benchmark_Key] BIGINT         NOT NULL,
    [Dim_Third_Comparison_Benchmark_Key]      BIGINT         NOT NULL,
    [Dim_Risk_Free_Benchmark_Key]             BIGINT         NOT NULL,
    [Dim_Fourth_Comparison_Benchmark_Key]     BIGINT         NOT NULL,
    [Dim_Fifth_Comparison_Benchmark_Key]      BIGINT         NOT NULL,
    [Dim_Sixth_Comparison_Benchmark_Key]      BIGINT         NOT NULL,
    [Dim_Seventh_Comparison_Benchmark_Key]    BIGINT         NOT NULL,
    [Dim_Eighth_Comparison_Benchmark_Key]     BIGINT         NOT NULL,
    [Last_Update_Datetime]                    DATETIME2 (7)  NOT NULL,
    [Source_Deleted_Flag]                     BIT            NOT NULL,
    [Source_System_Code]                      VARCHAR (255)  NOT NULL,
    [Load_Detail_Description]                 VARCHAR (4000) NULL,
    [ETL_Load_Key]                            BIGINT         NOT NULL,
    [Hash_Diff]                               VARCHAR (64)   NOT NULL,
    [Last_Update_User]                        VARCHAR (255)  NOT NULL,
    CONSTRAINT [PK_Bridge_Portfolio_Benchmark] PRIMARY KEY NONCLUSTERED ([Dim_Effective_Date_Key] ASC, [Dim_Portfolio_Key] ASC, [Dim_Primary_Comparison_Benchmark_Key] ASC, [Dim_Secondary_Comparision_Benchmark_Key] ASC, [Dim_Third_Comparison_Benchmark_Key] ASC, [Dim_Fourth_Comparison_Benchmark_Key] ASC, [Dim_Fifth_Comparison_Benchmark_Key] ASC, [Dim_Sixth_Comparison_Benchmark_Key] ASC, [Dim_Seventh_Comparison_Benchmark_Key] ASC, [Dim_Eighth_Comparison_Benchmark_Key] ASC, [Dim_Risk_Free_Benchmark_Key] ASC, [Last_Update_Datetime] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Dim_Portfolio_Key]));

