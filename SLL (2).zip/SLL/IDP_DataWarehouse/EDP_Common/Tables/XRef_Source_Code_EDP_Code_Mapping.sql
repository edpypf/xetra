﻿CREATE TABLE [EDP_Common].[XRef_Source_Code_EDP_Code_Mapping] (
    [Domain_Code_Type]               VARCHAR (255) NOT NULL,
    [Origination_Source_System_Code] VARCHAR (255) NOT NULL,
    [Origination_Source_Code_Value]  VARCHAR (255) NOT NULL,
    [EDP_Code_Value]                 VARCHAR (255) NOT NULL,
    [Source_System_Code]             VARCHAR (255) NOT NULL,
    [Last_Update_User]               VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]           DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_XRef_Source_Code_EDP_Code_Mapping] PRIMARY KEY NONCLUSTERED ([Domain_Code_Type] ASC, [Origination_Source_System_Code] ASC, [Origination_Source_Code_Value] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Domain_Code_Type]));

