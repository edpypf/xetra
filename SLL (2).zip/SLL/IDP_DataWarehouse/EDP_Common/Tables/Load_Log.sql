﻿CREATE TABLE [EDP_Common].[Load_Log] (
    [Batch_Effective_Date]   DATE           NULL,
    [Source_System_Code]     VARCHAR (255)  NULL,
    [Source_System_Name]     VARCHAR (255)  NULL,
    [Table_Loaded_Long_Name] VARCHAR (255)  NOT NULL,
    [Load_Type_Code]         VARCHAR (255)  NOT NULL,
    [Load_Type_Name]         VARCHAR (255)  NOT NULL,
    [Load_Status_Code]       VARCHAR (16)   NULL,
    [Load_Status_Name]       VARCHAR (255)  NOT NULL,
    [Record_Update_Count]    INT            NOT NULL,
    [Record_Load_Count]      INT            NOT NULL,
    [Record_Delete_Count]    INT            NOT NULL,
    [Load_Error_Description] VARCHAR (4000) NULL,
    [Load_Start_Datetime]    DATETIME2 (7)  NULL,
    [Load_End_Datetime]      DATETIME2 (7)  NULL,
    [ETL_Load_Key]           BIGINT         NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

