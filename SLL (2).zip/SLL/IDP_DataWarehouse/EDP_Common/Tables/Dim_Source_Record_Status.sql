﻿CREATE TABLE [EDP_Common].[Dim_Source_Record_Status] (
    [Dim_Source_Status_Key]       BIGINT        IDENTITY (1, 1) NOT NULL,
    [Source_Status_Code]          VARCHAR (16)  NOT NULL,
    [Source_Status_Name]          VARCHAR (30)  NOT NULL,
    [Source_Status_Long_Name]     VARCHAR (64)  NULL,
    [Enterprise_Status_Code]      VARCHAR (16)  NOT NULL,
    [Enterprise_Status_Name]      VARCHAR (30)  NOT NULL,
    [Enterprise_Status_Long_Name] VARCHAR (64)  NULL,
    [Source_Status_System_Code]   VARCHAR (255) NOT NULL,
    [Last_Update_User]            VARCHAR (255) NULL,
    [Last_Update_Datetime]        DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Source_Status_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = REPLICATE);







