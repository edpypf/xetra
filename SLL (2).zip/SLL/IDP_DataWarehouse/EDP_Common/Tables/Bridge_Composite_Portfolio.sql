﻿CREATE TABLE [EDP_Common].[Bridge_Composite_Portfolio] (
    [Dim_Effective_Date_Key]           BIGINT         NOT NULL,
    [Dim_Parent_Portfolio_Key]         BIGINT         NOT NULL,
    [Dim_Child_Portfolio_Key]          BIGINT         NOT NULL,
    [Portfolio_Relationship_Type_Code] VARCHAR (255)  NOT NULL,
    [Last_Update_Datetime]             DATETIME2 (7)  NOT NULL,
    [Source_Deleted_Flag]              BIT            NOT NULL,
    [Source_System_Code]               VARCHAR (255)  NOT NULL,
    [Load_Detail_Description]          VARCHAR (4000) NULL,
    [ETL_Load_Key]                     BIGINT         NOT NULL,
    [Last_Update_User]                 VARCHAR (255)  NOT NULL,
    CONSTRAINT [PK_Bridge_Composite_Portfolio] PRIMARY KEY NONCLUSTERED ([Dim_Effective_Date_Key] ASC, [Dim_Parent_Portfolio_Key] ASC, [Dim_Child_Portfolio_Key] ASC, [Portfolio_Relationship_Type_Code] ASC, [Last_Update_Datetime] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Dim_Parent_Portfolio_Key]));

