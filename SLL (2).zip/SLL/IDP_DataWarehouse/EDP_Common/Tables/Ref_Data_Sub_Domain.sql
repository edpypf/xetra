﻿CREATE TABLE [EDP_Common].[Ref_Data_Sub_Domain] (
    [Data_Domain_Code]          VARCHAR (64)  NOT NULL,
    [Data_Domain_Name]          VARCHAR (255) NULL,
    [Data_Domain_Long_Name]     VARCHAR (255) NULL,
    [Data_Sub_Domain_Code]      VARCHAR (64)  NOT NULL,
    [Data_Sub_Domain_Name]      VARCHAR (255) NULL,
    [Data_Sub_Domain_Long_Name] VARCHAR (255) NULL,
    [Source_System_Code]        VARCHAR (255) NOT NULL,
    [Last_Update_User]          VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]      DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_Ref_Data_Sub_Domain] PRIMARY KEY NONCLUSTERED ([Data_Sub_Domain_Code] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);









