﻿CREATE TABLE [EDP_Common].[Dim_Transaction_Event_Type] (
    [Dim_Transaction_Event_Type_Key]   BIGINT        IDENTITY (1, 1) NOT NULL,
    [Transaction_Event_Type_Code]      VARCHAR (64)  NOT NULL,
    [Transaction_Event_Type_Name]      VARCHAR (255) NOT NULL,
    [Transaction_Event_Type_Long_Name] VARCHAR (255) NULL,
    [Source_System_Code]               VARCHAR (255) NOT NULL,
    [Last_Update_User]                 VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]             DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Transaction_Event_Type_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

