﻿CREATE TABLE [EDP_Common].[Dim_Currency] (
    [Dim_Currency_Key]     BIGINT        IDENTITY (1, 1) NOT NULL,
    [Currency_Code]        VARCHAR (16)  NOT NULL,
    [Currency_Name]        VARCHAR (255) NULL,
    [Currency_Long_Name]   VARCHAR (255) NULL,
    [Source_Deleted_Flag]  BIT           NULL,
    [Source_System_Code]   VARCHAR (255) NULL,
    [ETL_Load_Key]         BIGINT        NOT NULL,
    [Hash_Diff]            VARCHAR (64)  NOT NULL,
    [Create_Datetime]      DATETIME2 (7) NOT NULL,
    [Last_Update_User]     VARCHAR (255) NULL,
    [Last_Update_Datetime] DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_Dim_Currency] PRIMARY KEY NONCLUSTERED ([Dim_Currency_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = REPLICATE);







