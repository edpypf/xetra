﻿CREATE TABLE [EDP_Common].[Dim_Accounting_Share_Class] (
    [Dim_Accounting_Share_Class_Key]   BIGINT        IDENTITY (1, 1) NOT NULL,
    [Accounting_Share_Class_Code]      VARCHAR (255) NOT NULL,
    [Accounting_Share_Class_Name]      VARCHAR (255) NOT NULL,
    [Accounting_Share_Class_Long_Name] VARCHAR (255) NULL,
    [Source_System_Code]               VARCHAR (255) NOT NULL,
    [Last_Update_User]                 VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]             DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Accounting_Share_Class_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

