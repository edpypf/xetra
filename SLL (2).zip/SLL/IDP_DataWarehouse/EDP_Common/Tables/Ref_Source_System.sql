﻿CREATE TABLE [EDP_Common].[Ref_Source_System] (
    [Source_System_Code]        VARCHAR (255) NOT NULL,
    [Source_System_Name]        VARCHAR (255) NULL,
    [Source_System_Long_Name]   VARCHAR (255) NULL,
    [Source_System_Description] VARCHAR (255) NULL,
    [Last_Update_User]          VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]      DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_Ref_Source_System] PRIMARY KEY NONCLUSTERED ([Source_System_Code] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);









