﻿CREATE TABLE [EDP_Common].[Dim_Reference_Transaction] (
    [Dim_Reference_Transaction_Key]      BIGINT        IDENTITY (1, 1) NOT NULL,
    [Transaction_Status_Code]            VARCHAR (64)  NOT NULL,
    [Transaction_Cancellation_Indicator] VARCHAR (2)   NOT NULL,
    [Pay_Receive_Indicator]              VARCHAR (2)   NOT NULL,
    [Accrual_Method_Code]                VARCHAR (64)  NOT NULL,
    [Quantity_Type_Code]                 VARCHAR (64)  NOT NULL,
    [Transaction_Status_Name]            VARCHAR (255) NOT NULL,
    [Transaction_Status_Long_Name]       VARCHAR (255) NULL,
    [Transaction_Cancellation_Name]      VARCHAR (255) NOT NULL,
    [Transaction_Cancellation_Long_Name] VARCHAR (255) NULL,
    [Pay_Receive_Name]                   VARCHAR (255) NOT NULL,
    [Pay_Receive_Long_Name]              VARCHAR (255) NULL,
    [Accrual_Method_Name]                VARCHAR (255) NOT NULL,
    [Accrual_Method_Long_Name]           VARCHAR (255) NULL,
    [Quantity_Type_Name]                 VARCHAR (255) NOT NULL,
    [Quantity_Type_Long_Name]            VARCHAR (255) NULL,
    [Source_System_Code]                 VARCHAR (255) NOT NULL,
    [Last_Update_User]                   VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]               DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_Reference_Transaction_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

