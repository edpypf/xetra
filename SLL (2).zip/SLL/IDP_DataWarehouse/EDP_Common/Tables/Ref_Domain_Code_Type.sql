﻿CREATE TABLE [EDP_Common].[Ref_Domain_Code_Type] (
    [Domain_Code_Type]             VARCHAR (255) NOT NULL,
    [Domain_Code_Type_Name]        VARCHAR (255) NOT NULL,
    [Domain_Code_Type_Long_Name]   VARCHAR (255) NULL,
    [Domain_Code_Type_Description] VARCHAR (255) NULL,
    [Source_System_Code]           VARCHAR (255) NOT NULL,
    [Last_Update_User]             VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]         DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Domain_Code_Type] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

