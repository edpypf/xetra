﻿CREATE TABLE [EDP_Common].[Dim_General_Ledger_Category] (
    [Dim_General_Ledger_Category_Key]   BIGINT        IDENTITY (1, 1) NOT NULL,
    [General_Ledger_Category_Code]      VARCHAR (64)  NOT NULL,
    [General_Ledger_Category_Name]      VARCHAR (255) NOT NULL,
    [General_Ledger_Category_Long_Name] VARCHAR (255) NULL,
    [Source_System_Code]                VARCHAR (255) NOT NULL,
    [Last_Update_User]                  VARCHAR (255) NOT NULL,
    [Last_Update_Datetime]              DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Dim_General_Ledger_Category_Key] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

