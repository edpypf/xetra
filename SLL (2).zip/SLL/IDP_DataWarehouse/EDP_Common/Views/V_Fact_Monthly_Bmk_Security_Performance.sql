﻿CREATE VIEW [EDP_Common].[V_Fact_Monthly_Bmk_Security_Performance]
AS Select    Fact_Monthly_Bmk_Security_Performance_ID
          ,[Dim_Security_Key]
		  ,[Dim_Source_Status_Key]
		  ,[Dim_Effective_Date_Key]
		  ,[Dim_Benchmark_Key]
		  ,[Dim_Security_Currency_Key]
		  ,[Last_Update_Datetime]
		  ,[Return_Percentage]
		  ,[Local_Return_Percentage]
		  ,[Beginning_Weight_Percentage]
		  ,Source_System_Code
		  ,Load_Datetime
		  ,[Source_Update_Datetime]
From (
	SELECT Fact_Monthly_Bmk_Security_Performance_ID
	      ,[Dim_Security_Key]
		  ,[Dim_Source_Status_Key]
		  ,[Dim_Effective_Date_Key]
		  ,[Dim_Benchmark_Key]
		  ,[Dim_Security_Currency_Key]
		  ,[Last_Update_Datetime]
		  ,[Return_Percentage]
		  ,[Local_Return_Percentage]
		  ,[Beginning_Weight_Percentage]
		  ,Source_System_Code
		  ,Load_Datetime
		  ,[Source_Update_Datetime]
		  ,[Source_Deleted_Flag]

		  ,Row_Number() Over (Partition By Dim_Effective_Date_Key, Dim_Benchmark_Key, Dim_Security_Key, Dim_Security_Currency_Key, [Dim_Source_Status_Key] Order By Last_Update_Datetime desc, Load_Datetime Desc, Source_Update_Datetime Desc) rn

	  FROM [EDP_Common].[Fact_Monthly_Bmk_Security_Performance] sp
) f
Where rn = 1 and Source_Deleted_Flag = 0;