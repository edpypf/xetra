﻿CREATE VIEW [EDP_Common].[V_Dim_Benchmark] AS SELECT
      [Dim_Benchmark_Key]
	  ,[Benchmark_ID]
      ,[Benchmark_Name]
      ,[Benchmark_Description]
      ,[Benchmark_Type_Code]
      ,[Benchmark_Type_Name]
      ,[Benchmark_Type_Description]
	  ,[Performance_Official_Ownership_Flag]
	  ,[Source_System_Code]
      ,[Last_Update_Datetime]
FROM  [EDP_Common].[Dim_Benchmark] 
WHERE [Is_Current_Flag] = 1;