﻿CREATE VIEW [EDP_Common].[V_Dim_Portfolio_Hist] AS SELECT
      p.[Dim_Portfolio_Key]
	  ,pc.Dim_Portfolio_key Current_Portfolio_Key
	  ,p.[Portfolio_ID]
	  ,p.[Performance_Official_Ownership_Flag]

      ,p.[Portfolio_Name]
      ,p.[Portfolio_Type_Code]
      ,p.[Portfolio_Type_Name]
      ,p.[Portfolio_Type_Description]
      ,p.[Eagle_STAR_Portfolio_ID]
      ,p.[State_Street_Portfolio_ID]
      ,p.[Geneva_Subportfolio_ID]
      ,p.[Performance_Inception_Date]
      ,p.[Last_Update_Datetime]

      ,pc.[Portfolio_Name] [Current_Portfolio_Name]
      ,pc.[Portfolio_Type_Code] [Current_Portfolio_Type_Code]
      ,pc.[Portfolio_Type_Name] [Current_Portfolio_Type_Name]
      ,pc.[Portfolio_Type_Description] [Current_Portfolio_Type_Description]
      ,pc.[Eagle_STAR_Portfolio_ID] [Current_Eagle_STAR_Portfolio_ID]
      ,pc.[State_Street_Portfolio_ID] [Current_State_Street_Portfolio_ID]
      ,pc.[Geneva_Subportfolio_ID] [Current_Geneva_Subportfolio_ID]
      ,pc.[Performance_Inception_Date] [Current_Performance_Inception_Date]
      ,pc.[Last_Update_Datetime] [Current_Last_Update_Datetime]

FROM  EDP_Common.Dim_Portfolio p
Join  EDP_Common.Dim_Portfolio pc on p.Portfolio_Id = pc.Portfolio_Id and pc.Is_Current_Flag = 1;