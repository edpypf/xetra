﻿CREATE VIEW [EDP_Common].[V_Dim_Currency]
AS SELECT
      [Dim_Currency_Key]
      ,[Currency_Code]
      ,[Currency_Name]
      ,[Currency_Long_Name]
      ,[Last_Update_Datetime]
FROM  [EDP_Common].[Dim_Currency]
WHERE Coalesce([Source_Deleted_Flag], 0) = 0;