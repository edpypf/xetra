﻿CREATE VIEW [EDP_Common].[V_Dim_Benchmark_Hist] AS SELECT b.[Dim_Benchmark_Key]
      ,bc.Dim_Benchmark_Key Current_Dim_Security_Key
	  ,b.[Benchmark_ID]
	  ,b.[Performance_Official_Ownership_Flag]

      ,b.[Benchmark_Name]
      ,b.[Benchmark_Description]
      ,b.[Benchmark_Type_Code]
      ,b.[Benchmark_Type_Name]
      ,b.[Benchmark_Type_Description]
      ,b.[Last_Update_Datetime]

      ,bc.[Benchmark_Name] [Current_Benchmark_Name]
      ,bc.[Benchmark_Description] [Current_Benchmark_Description]
      ,bc.[Benchmark_Type_Code] [Current_Benchmark_Type_Code]
      ,bc.[Benchmark_Type_Name] [Current_Benchmark_Type_Name]
      ,bc.[Benchmark_Type_Description] [Current_Benchmark_Type_Description]
      ,bc.[Last_Update_Datetime] [Current_Last_Update_Datetime]
  FROM EDP_Common.Dim_Benchmark b 
  Join EDP_Common.Dim_Benchmark bc on b.[Benchmark_ID] = bc.[Benchmark_ID] and bc.Is_Current_Flag = 1;