﻿CREATE VIEW [EDP_Common].[V_Bridge_Composite_Portfolio]
AS Select 
	   [Dim_Effective_Date_Key]
      ,[Dim_Parent_Portfolio_Key]
      ,[Dim_Child_Portfolio_Key]
      ,[Portfolio_Relationship_Type_Code]
      ,[Last_Update_Datetime]
      ,[Source_Deleted_Flag]
      ,[Source_System_Code]
      ,[Load_Detail_Description]
      ,[ETL_Load_Key]
      ,[Last_Update_User]
  FROM [EDP_Common].[Bridge_Composite_Portfolio]
WHERE Source_Deleted_Flag = 0;