﻿CREATE VIEW [EDP_Common].[V_Dim_General_Ledger_Account_Hist]
AS SELECT g.[Dim_General_Ledger_Account_Key]
	  ,gc.[Dim_General_Ledger_Account_Key] Current_General_Ledger_Account_Key
      ,g.[General_Ledger_Account_ID]

      ,g.[General_Ledger_Account_Name]
      ,g.[General_Ledger_Account_Description]
      ,g.[Eagle_STAR_Standard_Account_Name]
      ,g.[General_Ledger_Category_Code]
      ,g.[State_Street_General_Ledger_Account_ID]
      ,g.[Eagle_STAR_General_Ledger_Account_ID]
      ,g.[Eagle_STAR_General_Ledger_Standard_Account_ID]
      ,g.[Source_System_Code]
      ,g.[Last_Update_Datetime]

      ,gc.[General_Ledger_Account_Name] [Current_General_Ledger_Account_Name]
      ,gc.[General_Ledger_Account_Description] [Current_General_Ledger_Account_Description]
      ,gc.[Eagle_STAR_Standard_Account_Name] [Current_Eagle_STAR_Standard_Account_Name]
      ,gc.[General_Ledger_Category_Code] [Current_General_Ledger_Category_Code]
      ,gc.[State_Street_General_Ledger_Account_ID] [Current_State_Street_General_Ledger_Account_ID]
      ,gc.[Eagle_STAR_General_Ledger_Account_ID] [Current_Eagle_STAR_General_Ledger_Account_ID]
      ,gc.[Eagle_STAR_General_Ledger_Standard_Account_ID] [Current_Eagle_STAR_General_Ledger_Standard_Account_ID]
      ,gc.[Source_System_Code] [Current_Source_System_Code]
      ,gc.[Last_Update_Datetime] [Current_Last_Update_Datetime]

FROM [EDP_Common].[Dim_General_Ledger_Account] g
Join  [EDP_Common].[Dim_General_Ledger_Account] gc on g.[General_Ledger_Account_ID] = gc.[General_Ledger_Account_ID] and gc.Is_Current_Flag = 1;