﻿CREATE VIEW [EDP_Consumer].[BV_Monthly_Portfolio_Performance] AS SELECT
       d.[Date] AS Effective_Date
      ,d.[Quarter_Of_Year]
      ,d.[Month_End_Flag]
      ,d.[Weekday_Flag]
      ,d.[Day_Of_Week]
      ,d.[Weekday_Short_Name]
      ,d.[Weekday_Full_name]
      ,d.[Day_Of_Month]
      ,d.[Month_Short_Name]
      ,d.[Month_Full_Name]
	  ,d.[Year]
      ,d.[Day_Of_Year]
      ,d.[Week_Of_Year]
      ,d.[Month_Of_Year]
      ,d.[First_Day_Of_Month]
      ,d.[Last_Day_Of_Month]
      ,dp.[Portfolio_ID]
      ,dp.[Current_Portfolio_Name]			  AS  [Portfolio_Name]
      ,dp.[Current_Portfolio_Type_Code]		  AS  [Portfolio_Type_Code]
      ,dp.[Current_Portfolio_Type_Name]		  AS  [Portfolio_Type_Name]
      ,dp.[Current_Portfolio_Type_Description]  AS  [Portfolio_Type_Description]
      ,dp.[Current_Eagle_STAR_Portfolio_ID]	  AS  [Eagle_STAR_Portfolio_ID]
      ,dp.[Current_State_Street_Portfolio_ID]	  AS  [State_Street_Portfolio_ID]
      ,dp.[Current_Geneva_Subportfolio_ID]	  AS  [Geneva_Subportfolio_ID]
      ,dp.[Current_Performance_Inception_Date]  AS  [Performance_Inception_Date]
	  ,dp.Performance_Official_Ownership_Flag   AS	[Performance_Official_Ownership_Flag]
      ,f.[Gross_Market_Value_BOM_Amount]
      ,f.[Gross_Market_Value_EOM_Amount]
      ,f.[Gross_Total_Cashflow_Amount]
      ,f.[Gross_Gain_Loss_Amount]
      ,f.[Gross_Average_Investment_Base_Amount]
      ,f.[Gross_Return_Percentage]
      ,f.[Local_Return_Percentage]
	  ,f.[Source_System_Code]   
      ,f.[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
      ,dss.[Source_Status_Code]
      ,dss.[Source_Status_Name]
      ,dss.[Source_Status_Long_Name]
      ,dss.[Enterprise_Status_Code]
      ,dss.[Enterprise_Status_Name]
      ,dss.[Enterprise_Status_Long_Name]
	  ,npp.[Net_Return_Percentage]
	  ,npp.Source_System_Code AS [Net_Return_Source_System_Code]
	  ,npp.Last_Update_Datetime AS [Net_Return_Last_Update_Datetime]
      ,nss.[Source_Status_Code]          AS    Net_Return_Source_Status_Code
      ,nss.[Source_Status_Name]			 AS	   Net_Return_Source_Status_Name
      ,nss.[Source_Status_Long_Name]	 AS	   Net_Return_Source_Status_Long_Name
      ,nss.[Enterprise_Status_Code]		 AS	   Net_Return_Enterprise_Status_Code
      ,nss.[Enterprise_Status_Name]		 AS	   Net_Return_Enterprise_Status_Name
      ,nss.[Enterprise_Status_Long_Name] AS	   Net_Return_Enterprise_Status_Long_Name
FROM [EDP_Common].[V_Fact_Monthly_Portfolio_Performance] f
LEFT JOIN [EDP_Common].[Dim_Source_Record_Status] dss ON dss.[Dim_Source_Status_Key] = f.[Dim_Source_Status_Key]
LEFT JOIN [EDP_Common].[Dim_Date] d ON d.[Dim_Date_Key] = f.[Dim_Effective_Date_Key]
LEFT JOIN [EDP_Common].[V_Dim_Portfolio_Hist] dp ON dp.[Dim_Portfolio_Key] = f.[Dim_Portfolio_Key]
LEFT JOIN [EDP_Common].[V_Fact_Monthly_Net_Portfolio_Performance] npp ON f.[Dim_Effective_Date_Key] = npp.[Dim_Effective_Date_Key] AND f.[Dim_Portfolio_Key] = npp.[Dim_Portfolio_Key]	
LEFT JOIN [EDP_Common].[Dim_Source_Record_Status] as nss ON nss.[Dim_Source_Status_Key] = npp.[Dim_Source_Status_Key];