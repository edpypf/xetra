﻿CREATE VIEW [EDP_Consumer].[Ref_Data_Sub_Domain]
AS SELECT
    [Data_Domain_Code]
    ,[Data_Domain_Name]
    ,[Data_Domain_Long_Name]
    ,[Data_Sub_Domain_Code]
    ,[Data_Sub_Domain_Name]
    ,[Data_Sub_Domain_Long_Name]
    ,[Source_System_Code]
    ,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime 
FROM [EDP_Common].[Ref_Data_Sub_Domain];