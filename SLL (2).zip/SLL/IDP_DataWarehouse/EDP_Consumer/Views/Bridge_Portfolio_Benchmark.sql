﻿CREATE VIEW [EDP_Consumer].[Bridge_Portfolio_Benchmark] AS SELECT Dim_Effective_Date_Key
      ,pc.Dim_Portfolio_Key
      ,bc1.Dim_Benchmark_Key as Dim_Primary_Benchmark_Key
      ,bc2.Dim_Benchmark_Key as Dim_Attribution_Benchmark_Key
      ,bc9.Dim_Benchmark_Key as Dim_Risk_Free_Benchmark_Key
      ,bc3.Dim_Benchmark_Key as Dim_Third_Alternative_Benchmark_Key
      ,bc4.Dim_Benchmark_Key as Dim_Fourth_Alternative_Benchmark_Key
      ,sp.Source_System_Code
      ,sp.Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime 
FROM EDP_Common.v_Bridge_Portfolio_Benchmark sp
Join EDP_Common.Dim_Portfolio p on sp.Dim_Portfolio_Key = p.Dim_Portfolio_Key
Join EDP_Common.Dim_Portfolio pc on p.Portfolio_Id = pc.Portfolio_Id and pc.Is_Current_Flag = 1
Join EDP_Common.Dim_Benchmark b1 on sp.Dim_Primary_Comparison_Benchmark_Key = b1.Dim_Benchmark_Key
Join EDP_Common.Dim_Benchmark bc1 on b1.Benchmark_Id = bc1.Benchmark_Id and bc1.Is_Current_Flag = 1
Join EDP_Common.Dim_Benchmark b2 on sp.Dim_Secondary_Comparision_Benchmark_Key = b2.Dim_Benchmark_Key
Join EDP_Common.Dim_Benchmark bc2 on b2.Benchmark_Id = bc2.Benchmark_Id and bc2.Is_Current_Flag = 1
Join EDP_Common.Dim_Benchmark b9 on sp.Dim_Risk_Free_Benchmark_Key = b9.Dim_Benchmark_Key
Join EDP_Common.Dim_Benchmark bc9 on b9.Benchmark_Id = bc9.Benchmark_Id and bc9.Is_Current_Flag = 1
Join EDP_Common.Dim_Benchmark b3 on sp.Dim_Third_Comparison_Benchmark_Key = b3.Dim_Benchmark_Key
Join EDP_Common.Dim_Benchmark bc3 on b3.Benchmark_Id = bc3.Benchmark_Id and bc3.Is_Current_Flag = 1
Join EDP_Common.Dim_Benchmark b4 on sp.Dim_Fourth_Comparison_Benchmark_Key = b4.Dim_Benchmark_Key
Join EDP_Common.Dim_Benchmark bc4 on b4.Benchmark_Id = bc4.Benchmark_Id and bc4.Is_Current_Flag = 1;