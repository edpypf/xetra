﻿CREATE VIEW [EDP_Consumer].[Fact_Monthly_Port_Bmk_Performance] AS Select  
	 bpb.Dim_Effective_Date_Key as Dim_Effective_Date_Key
	,bpb.Dim_Portfolio_Key as Dim_Portfolio_Key
	,bpb.Dim_Primary_Benchmark_Key as Dim_Primary_Benchmark_Key
	,bpb.Dim_Attribution_Benchmark_Key as Dim_Attribution_Benchmark_Key
	,bpb.Dim_Risk_Free_Benchmark_Key
	,bpb.Dim_Third_Alternative_Benchmark_Key as Dim_Third_Alternative_Benchmark_Key
	,bpb.Dim_Fourth_Alternative_Benchmark_Key as Dim_Fourth_Alternative_Benchmark_Key
	,fp.Gross_Return_Percentage as Portfolio_Gross_Return_Percentage
	,fp.Local_Return_Percentage as Portfolio_Local_Return_Percentage
	,fb1.Return_Percentage as Primary_Benchmark_Return_Percentage
	,fb1.Local_Return_Percentage as Primary_Benchmark_Local_Return_Percentage
	,fb2.Return_Percentage as Attribution_Benchmark_Return_Percentage
	,fb2.Local_Return_Percentage as Attribution_Benchmark_Local_Return_Percentage
	,fb9.Return_Percentage as Risk_Free_Benchmark_Return_Percentage
	,fb9.Local_Return_Percentage as Risk_Free_Benchmark_Local_Return_Percentage
	,fb3.Return_Percentage as Third_Alternative_Benchmark_Return_Percentage
	,fb3.Local_Return_Percentage as Third_Alternative_Benchmark_Local_Return_Percentage
	,fb4.Return_Percentage as Fourth_Alternative_Benchmark_Return_Percentage
	,fb4.Local_Return_Percentage as Fourth_Alternative_Benchmark_Local_Return_Percentage
	,bpb.Source_System_Code
	,bpb.Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' as Last_Update_Datetime 
	,s.Source_Status_Code
	,s.Source_Status_Name
	,s.Enterprise_Status_Code
	,s.Enterprise_Status_Name -- INTO DBO.VYUTEST
FROM EDP_Consumer.Bridge_Portfolio_Benchmark bpb
join (Select * from EDP_Common.Dim_Date where Month_End_Flag=1) d on bpb.Dim_Effective_Date_Key  = d.Dim_Date_Key 
left join EDP_Consumer.Fact_Monthly_Portfolio_Performance fp on bpb.Dim_Effective_Date_Key = fp.Dim_Effective_Date_Key and bpb.Dim_Portfolio_Key = fp.Dim_Portfolio_Key
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb1 on bpb.Dim_Effective_Date_Key = fb1.Dim_Effective_Date_Key and bpb.Dim_Primary_Benchmark_Key = fb1.Dim_Benchmark_Key
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb2 on bpb.Dim_Effective_Date_Key = fb2.Dim_Effective_Date_Key and bpb.Dim_Attribution_Benchmark_Key = fb2.Dim_Benchmark_Key
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb9 on bpb.Dim_Effective_Date_Key = fb9.Dim_Effective_Date_Key and bpb.Dim_Risk_Free_Benchmark_Key = fb9.Dim_Benchmark_Key
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb3 on bpb.Dim_Effective_Date_Key = fb3.Dim_Effective_Date_Key and bpb.Dim_Third_Alternative_Benchmark_Key = fb3.Dim_Benchmark_Key
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb4 on bpb.Dim_Effective_Date_Key = fb4.Dim_Effective_Date_Key and bpb.Dim_Fourth_Alternative_Benchmark_Key = fb4.Dim_Benchmark_Key
left join EDP_Common.Dim_Source_Record_Status s ON fp.Dim_Source_Status_Key = s.Dim_Source_Status_Key;