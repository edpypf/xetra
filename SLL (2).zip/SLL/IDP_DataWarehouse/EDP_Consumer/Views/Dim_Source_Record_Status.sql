﻿CREATE VIEW [EDP_Consumer].[Dim_Source_Record_Status]
AS SELECT [Dim_Source_Status_Key]
    ,[Source_Status_Code]
    ,[Source_Status_Name]
    ,[Source_Status_Long_Name]
	,[Source_Status_System_Code]
    ,[Enterprise_Status_Code]
    ,[Enterprise_Status_Name]
    ,[Enterprise_Status_Long_Name]
    ,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM [EDP_Common].[Dim_Source_Record_Status];