﻿CREATE VIEW [EDP_Consumer].[Dim_Reference_Position]
AS SELECT
	Dim_Reference_Position_Key
	,Fair_Value_Level_Code
	,Price_Type_Code
	,Fair_Value_Level_Name
	,Fair_Value_Level_Long_Name
	,Price_Type_Name
	,Price_Type_Long_Name
	,Source_System_Code 
    ,Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM EDP_Common.Dim_Reference_Position;