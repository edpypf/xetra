﻿CREATE VIEW [EDP_Consumer].[Dim_General_Ledger_Category]
AS SELECT [Dim_General_Ledger_Category_Key]
      ,[General_Ledger_Category_Code]
      ,[General_Ledger_Category_Name]
      ,[General_Ledger_Category_Long_Name]
      ,[Source_System_Code]
      ,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM [EDP_Common].[Dim_General_Ledger_Category];