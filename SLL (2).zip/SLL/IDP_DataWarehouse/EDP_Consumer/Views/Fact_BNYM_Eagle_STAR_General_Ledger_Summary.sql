﻿CREATE VIEW [EDP_Consumer].[Fact_BNYM_Eagle_STAR_General_Ledger_Summary]
AS Select  [Dim_Effective_Date_Key]
		  ,[Dim_Dataset_Frequency_Key]
		  ,p.Current_Portfolio_Key [Dim_Portfolio_Key]
		  ,[Dim_Currency_Base_Key]
		  ,[Dim_General_Ledger_Category_Key]
		  ,[Dim_Accounting_Share_Class_Key]
		  ,[Dim_Source_Status_Key]
		  ,[Summary_Category_Description]
		  ,[Beginning_Balance_Amount]
		  ,[Net_Debit_Activity_Amount]
		  ,[Net_Credit_Activity_Amount]
		  ,[Net_Activity_Amount]
		  ,[Ending_Balance_Amount]
		  ,[Source_System_Code]
		  ,sp.[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM [EDP_Common].[V_Fact_BNYM_Eagle_STAR_General_Ledger_Summary] sp
Join EDP_Common.V_Dim_Portfolio_Hist p on sp.Dim_Portfolio_Key = p.Dim_Portfolio_Key;