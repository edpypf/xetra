﻿CREATE VIEW [EDP_Consumer].[Fact_Daily_Portfolio_Performance] AS SELECT  
       pp.[Dim_Effective_Date_Key]
      ,pc.[Dim_Portfolio_Key]
      ,pp.[Dim_Source_Status_Key]
	  ,npp.[Dim_Source_Status_Key] AS Dim_Net_Return_Source_Status_Key
      ,[Gross_Market_Value_BOD_Amount]
      ,[Gross_Market_Value_EOD_Amount]
      ,[Gross_Total_Cashflow_Amount]
      ,[Gross_Gain_Loss_Amount]
      ,[Gross_Investment_Base_Amount]
      ,[Gross_Return_Percentage]
      ,[Local_Return_Percentage]
	  ,pp.Source_System_Code AS [Source_System_Code]
      ,pp.[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
	  ,npp.[Net_Return_Percentage]
	  ,npp.[Source_System_Code] AS Net_Return_Source_System_Code
	  ,npp.[Last_Update_Datetime] AS Net_Return_Last_Update_Datetime
FROM [EDP_Common].[V_Fact_Daily_Portfolio_Performance] pp
Join EDP_Common.Dim_Portfolio p on pp.Dim_Portfolio_Key = p.Dim_Portfolio_Key
Join EDP_Common.Dim_Portfolio pc on p.Portfolio_Id = pc.Portfolio_Id and pc.Is_Current_Flag = 1
LEFT JOIN  [EDP_Common].[V_Fact_Daily_Net_Portfolio_Performance] npp
ON npp.[Dim_Effective_Date_Key] = pp.[Dim_Effective_Date_Key]
AND npp.[Dim_Portfolio_Key] = pp.[Dim_Portfolio_Key];