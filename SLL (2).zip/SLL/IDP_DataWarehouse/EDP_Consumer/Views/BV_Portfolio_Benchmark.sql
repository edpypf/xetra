﻿CREATE VIEW [EDP_Consumer].[BV_Portfolio_Benchmark] AS Select 
	     d.Date	Effective_Date
		,d.Quarter_Of_Year as Quarter_Of_Year
		,d.Month_End_Flag as Month_End_Flag
		,d.Weekday_Flag as Weekday_Flag
		,d.Day_Of_Week as Day_Of_Week
		,d.Weekday_Short_Name as Weekday_Short_Name
		,d.Weekday_Full_name as Weekday_Full_name
		,d.Day_Of_Month as Day_Of_Month
		,d.Month_Short_Name as Month_Short_Name
		,d.Month_Full_Name as Month_Full_Name
		,d.Year as Year
		,d.Day_Of_Year as Day_Of_Year
		,d.Week_Of_Year as Week_Of_Year
		,d.Month_Of_Year as Month_Of_Year
		,d.First_Day_Of_Month as First_Day_Of_Month
		,d.Last_Day_Of_Month as Last_Day_Of_Month
		,p.Portfolio_ID as Portfolio_ID
		,p.Portfolio_Name as Portfolio_Name
		,p.Portfolio_Type_Code as Portfolio_Type_Code
		,p.Portfolio_Type_Name as Portfolio_Type_Name
		,p.Eagle_STAR_Portfolio_ID as Eagle_STAR_Portfolio_ID
		,p.State_Street_Portfolio_ID as State_Street_Portfolio_ID
		,p.Geneva_Subportfolio_ID as Geneva_Subportfolio_ID
		,b1.Benchmark_ID as Primary_Benchmark_ID				
		,b1.Benchmark_Name as Primary_Benchmark_Name
		,b1.Benchmark_Description as Primary_Benchmark_Description
		,b1.Benchmark_Type_Code as Primary_Benchmark_Type_Code
		,b1.Benchmark_Type_Name as Primary_Benchmark_Type_Name
		,b1.Benchmark_Type_Description as Primary_Benchmark_Type_Description
		,b2.Benchmark_ID as Attribution_Benchmark_ID
		,b2.Benchmark_Name as Attribution_Benchmark_Name
		,b2.Benchmark_Description as Attribution_Benchmark_Description
		,b2.Benchmark_Type_Code as Attribution_Benchmark_Type_Code
		,b2.Benchmark_Type_Name as Attribution_Benchmark_Type_Name
		,b2.Benchmark_Type_Description as Attribution_Benchmark_Type_Description
		,b3.Benchmark_ID as Risk_Free_Benchmark_ID
		,b3.Benchmark_Name as Risk_Free_Benchmark_Name
		,b3.Benchmark_Description as Risk_Free_Benchmark_Description
		,b3.Benchmark_Type_Code as Risk_Free_Benchmark_Type_Code
		,b3.Benchmark_Type_Name as Risk_Free_Benchmark_Type_Name
		,b3.Benchmark_Type_Description as Risk_Free_Benchmark_Type_Description
		,b4.Benchmark_ID as Third_Alternative_Benchmark_ID
		,b4.Benchmark_Name as Third_Alternative_Benchmark_Name
		,b4.Benchmark_Description as Third_Alternative_Benchmark_Description
		,b4.Benchmark_Type_Code as Third_Alternative_Benchmark_Type_Code
		,b4.Benchmark_Type_Name as Third_Alternative_Benchmark_Type_Name
		,b4.Benchmark_Type_Description as Third_Alternative_Benchmark_Type_Description
		,b5.Benchmark_ID as Fourth_Alternative_Benchmark_ID
		,b5.Benchmark_Name as Fourth_Alternative_Benchmark_Name
		,b5.Benchmark_Description as Fourth_Alternative_Benchmark_Description
		,b5.Benchmark_Type_Code as Fourth_Alternative_Benchmark_Type_Code
		,b5.Benchmark_Type_Name as Fourth_Alternative_Benchmark_Type_Name
		,b5.Benchmark_Type_Description as Fourth_Alternative_Benchmark_Type_Description
		,f.Source_System_Code
		,f.Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' as Last_Update_Datetime 
FROM EDP_Consumer.Bridge_Portfolio_Benchmark f
LEFT OUTER JOIN EDP_Common.Dim_Date d on f.Dim_Effective_Date_Key = d.Dim_Date_Key
LEFT OUTER JOIN EDP_Consumer.Dim_Portfolio p on f.Dim_Portfolio_Key = p.Dim_Portfolio_Key
LEFT OUTER JOIN EDP_Consumer.Dim_Benchmark b1 on f.Dim_Primary_Benchmark_Key = b1.Dim_Benchmark_Key
LEFT OUTER JOIN EDP_Consumer.Dim_Benchmark b2 on f.Dim_Attribution_Benchmark_Key = b2.Dim_Benchmark_Key
LEFT OUTER JOIN EDP_Consumer.Dim_Benchmark b3 on f.Dim_Risk_Free_Benchmark_Key = b3.Dim_Benchmark_Key
LEFT OUTER JOIN EDP_Consumer.Dim_Benchmark b4 on f.Dim_Third_Alternative_Benchmark_Key = b4.Dim_Benchmark_Key
LEFT OUTER JOIN EDP_Consumer.Dim_Benchmark b5 on f.Dim_Fourth_Alternative_Benchmark_Key = b5.Dim_Benchmark_Key;