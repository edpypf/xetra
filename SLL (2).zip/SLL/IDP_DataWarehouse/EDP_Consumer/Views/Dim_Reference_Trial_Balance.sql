﻿CREATE VIEW [EDP_Consumer].[Dim_Reference_Trial_Balance]
AS SELECT [Dim_Reference_Trial_Balance_Key]
      ,[Trial_Balance_Line_Description_Code]
      ,[Trial_Balance_Reporting_Line_Number]
      ,[Trial_Balance_Reporting_Page_Number]
      ,[Trial_Balance_Reporting_Line_Item_Type_Number]
      ,[Source_System_Code]
      ,[Last_Update_User]
      ,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM [EDP_Common].[Dim_Reference_Trial_Balance];