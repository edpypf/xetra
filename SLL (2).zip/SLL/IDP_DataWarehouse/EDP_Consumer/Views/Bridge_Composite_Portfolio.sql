﻿CREATE VIEW [EDP_Consumer].[Bridge_Composite_Portfolio]
AS SELECT Dim_Effective_Date_Key
  		  ,pc.Dim_Portfolio_Key as Dim_Parent_Portfolio_Key
		  ,cc.Dim_Portfolio_Key as Dim_Child_Portfolio_Key
		  ,Portfolio_Relationship_Type_Code
          ,b.Source_System_Code
          ,b.Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime 
FROM EDP_Common.v_Bridge_Composite_Portfolio b
Join EDP_Common.Dim_Portfolio p on p.Dim_Portfolio_Key = b.Dim_Parent_Portfolio_Key
Join EDP_Common.Dim_Portfolio pc on p.Portfolio_Id = pc.Portfolio_Id and pc.Is_Current_Flag = 1
Join EDP_Common.Dim_Portfolio c on c.Dim_Portfolio_Key = b.Dim_Child_Portfolio_Key
Join EDP_Common.Dim_Portfolio cc on c.Portfolio_Id = cc.Portfolio_Id and cc.Is_Current_Flag = 1
WHERE pc.Dim_Portfolio_Key <>-1
AND cc.Dim_Portfolio_Key <>-1;