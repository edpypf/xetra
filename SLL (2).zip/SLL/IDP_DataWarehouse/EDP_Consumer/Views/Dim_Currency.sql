﻿CREATE VIEW [EDP_Consumer].[Dim_Currency]
AS SELECT
      [Dim_Currency_Key]
      ,[Currency_Code]
      ,[Currency_Name]
      ,[Currency_Long_Name]
	  ,Source_System_Code
      ,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM  [EDP_Common].[Dim_Currency]
WHERE Coalesce([Source_Deleted_Flag], 0) = 0;