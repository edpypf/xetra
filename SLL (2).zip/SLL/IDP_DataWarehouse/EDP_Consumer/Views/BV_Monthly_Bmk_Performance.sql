﻿CREATE VIEW [EDP_Consumer].[BV_Monthly_Bmk_Performance] AS SELECT 
dd.Date AS Effective_Date
,dd.Quarter_Of_Year
,dd.Month_End_Flag
,dd.Weekday_Flag
,dd.Day_Of_Week
,dd.Weekday_Short_Name
,dd.Weekday_Full_name
,dd.Day_Of_Month
,dd.Month_Short_Name
,dd.Month_Full_Name
,dd.Year
,dd.Day_Of_Year
,dd.Week_Of_Year
,dd.Month_Of_Year
,dd.First_Day_Of_Month
,dd.Last_Day_Of_Month
,db.Benchmark_ID
,db.Current_Benchmark_Name             as     Benchmark_Name
,db.Current_Benchmark_Description      as     Benchmark_Description
,db.Current_Benchmark_Type_Code        as     Benchmark_Type_Code
,db.Current_Benchmark_Type_Name        as     Benchmark_Type_Name
,db.Current_Benchmark_Type_Description as     Benchmark_Type_Description
,db.Performance_Official_Ownership_Flag as	  Performance_Official_Ownership_Flag
,f.Return_Percentage
,f.Local_Return_Percentage
,f.Source_System_Code
,f.Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
,ds.Source_Status_Code
,ds.Source_Status_Name
,ds.Source_Status_Long_Name
,ds.Enterprise_Status_Code
,ds.Enterprise_Status_Name
,ds.Enterprise_Status_Long_Name
FROM EDP_Common.V_Fact_Monthly_Bmk_Performance f
LEFT JOIN EDP_Common.Dim_Date dd ON dd.Dim_Date_Key = f.Dim_Effective_Date_Key
LEFT JOIN EDP_Common.V_Dim_Benchmark_Hist db ON db.Dim_Benchmark_Key = f.Dim_Benchmark_Key
LEFT JOIN EDP_Common.Dim_Source_Record_Status ds ON ds.Dim_Source_Status_Key = f.Dim_Source_Status_Key;