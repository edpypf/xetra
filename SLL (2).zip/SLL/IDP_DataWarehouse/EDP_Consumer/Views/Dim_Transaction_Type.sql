﻿CREATE VIEW [EDP_Consumer].[Dim_Transaction_Type]
AS SELECT
		[Dim_Transaction_Type_Key]
		,[Transaction_Type_Code]
		,[Transaction_Type_Name]
		,[Transaction_Type_Long_Name]
		,[Source_System_Code]
		,[Last_Update_Datetime]
FROM  [EDP_Common].[Dim_Transaction_Type];