﻿CREATE VIEW [EDP_Consumer].[Fact_Daily_Bmk_Security_Performance]
AS SELECT    [Dim_Effective_Date_Key]
		  ,bc.[Dim_Benchmark_Key]
	      ,sc.[Dim_Security_Key]
		  ,[Dim_Security_Currency_Key]
		  ,[Dim_Source_Status_Key]
		  ,[Return_Percentage]
		  ,[Local_Return_Percentage]
		  ,[Beginning_Weight_Percentage]
		  ,sp.[Source_System_Code]
		  ,sp.[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime

FROM [EDP_Common].[V_Fact_Daily_Bmk_Security_Performance] sp
Join EDP_Common.Dim_Benchmark b on sp.Dim_Benchmark_Key = b.Dim_Benchmark_Key
Join EDP_Common.Dim_Benchmark bc on b.Benchmark_Id = bc.Benchmark_Id and bc.Is_Current_Flag = 1

Join EDP_Common.Dim_Security s on sp.Dim_Security_Key = s.Dim_Security_Key
Join EDP_Common.Dim_Security sc on s.IMCO_Security_Alias_Id = sc.IMCO_Security_Alias_Id and sc.Is_Current_Flag = 1;