﻿CREATE VIEW [EDP_Consumer].[BV_Composite_Portfolio]
AS Select 
	     d.Date	Effective_Date
		,d.Quarter_Of_Year as Quarter_Of_Year
		,d.Month_End_Flag as Month_End_Flag
		,d.Weekday_Flag as Weekday_Flag
		,d.Day_Of_Week as Day_Of_Week
		,d.Weekday_Short_Name as Weekday_Short_Name
		,d.Weekday_Full_name as Weekday_Full_name
		,d.Day_Of_Month as Day_Of_Month
		,d.Month_Short_Name as Month_Short_Name
		,d.Month_Full_Name as Month_Full_Name
		,d.Year as Year
		,d.Day_Of_Year as Day_Of_Year
		,d.Week_Of_Year as Week_Of_Year
		,d.Month_Of_Year as Month_Of_Year
		,d.First_Day_Of_Month as First_Day_Of_Month
		,d.Last_Day_Of_Month as Last_Day_Of_Month
		,p.Portfolio_ID as Parent_Portfolio_ID
		,p.Portfolio_Name as Parent_Portfolio_Name
		,p.Portfolio_Type_Code as Parent_Portfolio_Type_Code
		,p.Portfolio_Type_Name as Parent_Portfolio_Type_Name
		,p.Eagle_STAR_Portfolio_ID as Parent_Eagle_STAR_Portfolio_ID
		,p.State_Street_Portfolio_ID as Parent_State_Street_Portfolio_ID
		,p.Geneva_Subportfolio_ID as Parent_Geneva_Subportfolio_ID
		,p.Performance_Inception_Date as Parent_Portfolio_Performance_Inception_Date
		,p.Performance_Official_Ownership_Flag as Parent_Portfolio_Performance_Official_Ownership_Flag
		,c.Portfolio_ID as Child_Portfolio_ID
		,c.Portfolio_Name as Child_Portfolio_Name
		,c.Portfolio_Type_Code as Child_Portfolio_Type_Code
		,c.Portfolio_Type_Name as Child_Portfolio_Type_Name
		,c.Eagle_STAR_Portfolio_ID as Child_Eagle_STAR_Portfolio_ID
		,c.State_Street_Portfolio_ID as Child_State_Street_Portfolio_ID
		,c.Geneva_Subportfolio_ID as Child_Geneva_Subportfolio_ID		
		,c.Performance_Inception_Date as Child_Portfolio_Performance_Inception_Date
		,c.Performance_Official_Ownership_Flag as Child_Portfolio_Performance_Official_Ownership_Flag
		,f.Portfolio_Relationship_Type_Code as Portfolio_Relationship_Type_Code
		,f.Source_System_Code
		,f.Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' as Last_Update_Datetime 
FROM [EDP_Consumer].[Bridge_Composite_Portfolio] f
LEFT OUTER JOIN EDP_Common.Dim_Date d on f.Dim_Effective_Date_Key = d.Dim_Date_Key
LEFT OUTER JOIN EDP_Common.V_Dim_Portfolio p on f.Dim_Parent_Portfolio_Key = p.Dim_Portfolio_Key
LEFT OUTER JOIN EDP_Common.V_Dim_Portfolio c on f.Dim_Child_Portfolio_Key = c.Dim_Portfolio_Key
WHERE f.Dim_Parent_Portfolio_Key <>-1 AND f.Dim_Child_Portfolio_Key <>-1;