﻿CREATE VIEW [EDP_Consumer].[Fact_SS_MCH_General_Ledger_Balance] AS Select  [Dim_Effective_Date_Key]
		  ,[Dim_Dataset_Frequency_Key]
		  ,p.Current_Portfolio_Key [Dim_Portfolio_Key]
		  ,gla.[Current_General_Ledger_Account_Key] AS [Dim_General_Ledger_Account_Key] 
		  ,[Dim_Accounting_Share_Class_Key]
		  ,[Dim_Currency_Base_Key]
		  ,[Dim_Source_Status_Key]
		  ,[General_Ledger_Currency_Local_Code]
		  ,[Reporting_Basis_Indicator]
		  ,[General_Ledger_Grouping_Code]
		  ,[Beginning_Balance_Amount]
		  ,[Net_Debit_Activity_Amount]
		  ,[Net_Credit_Activity_Amount]
		  ,[Net_Activity_Amount]
		  ,[Ending_Balance_Amount]
		  ,sp.[Source_System_Code] 
		  ,sp.[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM [EDP_Common].[V_Fact_SS_MCH_General_Ledger_Balance] sp
Join EDP_Common.V_Dim_Portfolio_Hist p on sp.Dim_Portfolio_Key = p.Dim_Portfolio_Key
JOIN [EDP_Common].[V_Dim_General_Ledger_Account_Hist] gla ON gla.Dim_General_Ledger_Account_Key = sp.Dim_General_Ledger_Account_Key;