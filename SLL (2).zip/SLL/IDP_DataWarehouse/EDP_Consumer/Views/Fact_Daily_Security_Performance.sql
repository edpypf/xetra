﻿CREATE VIEW [EDP_Consumer].[Fact_Daily_Security_Performance] AS SELECT 
      [Dim_Effective_Date_Key]
      ,pc.[Dim_Portfolio_Key]
      ,sc.[Dim_Security_Key]
      ,[Dim_Security_Currency_Key]
      ,[Dim_Source_Status_Key]
      ,[Gross_Market_Value_BOD_Amount]
	  ,[Gross_Market_Value_EOD_Amount]
      ,[Gross_Total_Cashflow_Amount]
      ,[Gross_Gain_Loss_Amount]
      ,[Gross_Investment_Base_Amount]
	  ,[Gross_Return_Percentage]
      ,[Portfolio_Proportion_Percentage]
      ,[Local_Market_Value_BOD_Amount]
      ,[Local_Market_Value_EOD_Amount]
      ,[Local_Total_Cashflow_Amount]
      ,[Local_Gain_Loss_Amount]
      ,[Local_Return_Percentage]
      ,sp.[Source_System_Code] 
      ,sp.[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime

FROM [EDP_Common].[V_Fact_Daily_Security_Performance] sp
Join EDP_Common.Dim_Portfolio p on sp.Dim_Portfolio_Key = p.Dim_Portfolio_Key
Join EDP_Common.Dim_Portfolio pc on p.Portfolio_Id = pc.Portfolio_Id and pc.Is_Current_Flag = 1

Join EDP_Common.Dim_Security s on sp.Dim_Security_Key = s.Dim_Security_Key
Join EDP_Common.Dim_Security sc on s.IMCO_Security_Alias_Id = sc.IMCO_Security_Alias_Id and sc.Is_Current_Flag = 1;