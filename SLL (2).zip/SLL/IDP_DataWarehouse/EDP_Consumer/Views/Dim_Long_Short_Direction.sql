﻿CREATE VIEW [EDP_Consumer].[Dim_Long_Short_Direction]
AS SELECT
	 Dim_Long_Short_Direction_Key
	,Long_Short_Direction_Indicator
	,Long_Short_Direction_Name
	,Long_Short_Direction_Long_Name
	,Source_System_Code
    ,Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM EDP_Common.Dim_Long_Short_Direction;