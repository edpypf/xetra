﻿CREATE VIEW [EDP_Consumer].[BV_Daily_Bmk_Security_Performance] AS SELECT dd.Date AS Effective_Date
,dd.Quarter_Of_Year
,dd.Month_End_Flag
,dd.Weekday_Flag
,dd.Day_Of_Week
,dd.Weekday_Short_Name
,dd.Weekday_Full_name
,dd.Day_Of_Month
,dd.Month_Short_Name
,dd.Month_Full_Name
,dd.Year
,dd.Day_Of_Year
,dd.Week_Of_Year
,dd.Month_Of_Year
,dd.First_Day_Of_Month
,dd.Last_Day_Of_Month
,db.Benchmark_ID
,db.Current_Benchmark_Name              as     Benchmark_Name
,db.Current_Benchmark_Description       as     Benchmark_Description
,db.Current_Benchmark_Type_Code         as     Benchmark_Type_Code
,db.Current_Benchmark_Type_Name         as     Benchmark_Type_Name
,db.Current_Benchmark_Type_Description  as     Benchmark_Type_Description
,db.Performance_Official_Ownership_Flag as	   Performance_Official_Ownership_Flag
,ds.IMCO_Security_Alias_ID
,ds.Current_Security_Name               as      Security_Name
,ds.Current_Security_Description        as      Security_Description
,ds.Current_BNYM_ID                     as      BNYM_ID
,ds.Current_State_Street_CUSIP_ID       as      State_Street_CUSIP_ID
,ds.Current_Geneva_ID                   as      Geneva_ID
,ds.Current_Dynamo_ID                   as      Dynamo_ID
,ds.Current_CUSIP_ID                    as      CUSIP_ID
,ds.Current_ISIN_ID                     as      ISIN_ID
,ds.Current_SEDOL_ID                    as      SEDOL_ID
,ds.Current_Ticker_ID                   as      Ticker_ID
,ds.[Current_IMCO_Asset_Type_Code]		AS		[IMCO_Asset_Type_Code]
,ds.[Current_IMCO_Asset_Type_Name]		AS		[IMCO_Asset_Type_Name]
,ds.[Current_IMCO_Asset_Sub_Type_Code]	AS		[IMCO_Asset_Sub_Type_Code]
,ds.[Current_IMCO_Asset_Sub_Type_Name]	AS		[IMCO_Asset_Sub_Type_Name]
,ds.[Current_IMCO_Security_Type_Code]	AS		[IMCO_Security_Type_Code]
,ds.[Current_IMCO_Security_Type_Name]	AS		[IMCO_Security_Type_Name]
,dc.Currency_Code AS Security_Currency_Code
,dc.Currency_Name AS Security_Currency_Name
,f.Return_Percentage
,f.Local_Return_Percentage
,f.Beginning_Weight_Percentage
,f.Source_System_Code
,f.Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
,drs.Source_Status_Code
,drs.Source_Status_Name
,drs.Source_Status_Long_Name
,drs.Enterprise_Status_Code
,drs.Enterprise_Status_Name
,drs.Enterprise_Status_Long_Name  
FROM EDP_Common.V_Fact_Daily_Bmk_Security_Performance f
LEFT JOIN EDP_Common.Dim_Date dd ON dd.Dim_Date_Key = f.Dim_Effective_Date_Key
LEFT JOIN EDP_Common.V_Dim_Benchmark_Hist db ON db.Dim_Benchmark_Key = f.Dim_Benchmark_Key
LEFT JOIN EDP_Common.V_Dim_Security_Hist ds ON ds.Dim_Security_Key = f.Dim_Security_Key
LEFT JOIN EDP_Common.Dim_Currency dc ON dc.Dim_Currency_Key = f.Dim_Security_Currency_Key
LEFT OUTER JOIN [EDP_Common].[Dim_Source_Record_Status] drs ON drs.[Dim_Source_Status_Key] = f.Dim_Source_Status_Key;