﻿CREATE VIEW [EDP_Consumer].[Dim_Accounting_Share_Class]
AS SELECT [Dim_Accounting_Share_Class_Key]
      ,[Accounting_Share_Class_Code]
      ,[Accounting_Share_Class_Name]
      ,[Accounting_Share_Class_Long_Name]
      ,[Source_System_Code]
      ,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM [EDP_Common].[Dim_Accounting_Share_Class];