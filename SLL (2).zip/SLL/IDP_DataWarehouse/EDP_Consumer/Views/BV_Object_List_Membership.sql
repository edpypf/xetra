﻿CREATE VIEW [EDP_Consumer].[BV_Object_List_Membership] AS SELECT
r.Object_List_ID,
r.Object_List_Member_ID,
coalesce(dp.portfolio_name, db.benchmark_name, 'N/A') Object_List_Member_Name,
r.Object_List_Member_Type_Code,
coalesce(dp.portfolio_type_name, db.benchmark_type_name, 'N/A') Object_List_Member_Type_Name,
r.Object_List_Purpose_Code,
r.Object_List_Purpose_Name,
sd.Data_Domain_Code,
sd.Data_Domain_Name,
r.Data_Sub_Domain_Code,
sd.Data_Sub_Domain_Name,
r.Source_System_Code,
r.Create_Datetime,
r.Last_Update_Datetime
FROM EDP_Common.V_Rel_Object_List_Membership r 
LEFT OUTER JOIN EDP_Common.Ref_Data_Sub_Domain sd ON sd.Data_Sub_Domain_Code = r.Data_Sub_Domain_Code
LEFT OUTER JOIN EDP_Common.V_Dim_Portfolio dp ON upper(dp.Portfolio_ID) = r.Object_List_Member_ID and r.Data_Sub_Domain_Code = 'Port' 
LEFT OUTER JOIN EDP_Common.V_Dim_Benchmark db ON upper(db.Benchmark_ID) = r.Object_List_Member_ID and r.Data_Sub_Domain_Code = 'Bmk';