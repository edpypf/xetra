﻿CREATE VIEW [EDP_Consumer].[Ref_Source_System]
AS SELECT
	[Source_System_Code]
	,[Source_System_Name]
	,[Source_System_Long_Name]
	,[Source_System_Description] 
	,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime 
FROM [EDP_Common].[Ref_Source_System];