﻿CREATE VIEW [EDP_Consumer].[Dim_Dataset_Frequency]
AS SELECT
	 Dim_Dataset_Frequency_Key
	,Dataset_Frequency_Indicator
	,Dataset_Frequency_Name
	,Dataset_Frequency_Long_Name
	,Source_System_Code 
    ,Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM EDP_Common.Dim_Dataset_Frequency;