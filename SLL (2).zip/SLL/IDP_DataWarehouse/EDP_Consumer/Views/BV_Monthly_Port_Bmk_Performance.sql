﻿CREATE VIEW [EDP_Consumer].[BV_Monthly_Port_Bmk_Performance] AS Select  
	 d.Date									as Effective_Date
	,d.Quarter_Of_Year						as Quarter_Of_Year
	,d.Month_End_Flag						as Month_End_Flag
	,d.Weekday_Flag							as Weekday_Flag
	,d.Day_Of_Week							as Day_Of_Week
	,d.Weekday_Short_Name					as Weekday_Short_Name
	,d.Weekday_Full_name					as Weekday_Full_name
	,d.Day_Of_Month							as Day_Of_Month
	,d.Month_Short_Name						as Month_Short_Name
	,d.Month_Full_Name						as Month_Full_Name
	,d.Year									as Year
	,d.Day_Of_Year							as Day_Of_Year
	,d.Week_Of_Year							as Week_Of_Year
	,d.Month_Of_Year						as Month_Of_Year
	,d.First_Day_Of_Month					as First_Day_Of_Month
	,d.Last_Day_Of_Month					as Last_Day_Of_Month
	,p.Portfolio_ID							as Portfolio_ID
	,p.Portfolio_Name						as Portfolio_Name
	,p.Portfolio_Type_Code					as Portfolio_Type_Code
	,p.Portfolio_Type_Name					as Portfolio_Type_Name
	,p.Eagle_STAR_Portfolio_ID				as Eagle_STAR_Portfolio_ID
	,p.State_Street_Portfolio_ID			as State_Street_Portfolio_ID
	,p.Geneva_Subportfolio_ID				as Geneva_Subportfolio_ID
	,fp.Gross_Return_Percentage				as Portfolio_Gross_Return_Percentage
	,fp.Local_Return_Percentage				as Portfolio_Local_Return_Percentage
	,b1.Benchmark_ID						as Primary_Benchmark_ID
	,b1.Benchmark_Name				as Primary_Benchmark_Name
	,b1.Benchmark_Description		as Primary_Benchmark_Description
	,b1.Benchmark_Type_Code			as Primary_Benchmark_Type_Code
	,b1.Benchmark_Type_Name			as Primary_Benchmark_Type_Name
	,b1.Benchmark_Type_Description	as Primary_Benchmark_Type_Description
	,fb1.Return_Percentage					as Primary_Benchmark_Return_Percentage
	,fb1.Local_Return_Percentage			as Primary_Benchmark_Local_Return_Percentage
	,b2.Benchmark_ID						as Attribution_Benchmark_ID
	,b2.Benchmark_Name				as Attribution_Benchmark_Name
	,b2.Benchmark_Description		as Attribution_Benchmark_Description
	,b2.Benchmark_Type_Code			as Attribution_Benchmark_Type_Code
	,b2.Benchmark_Type_Name			as Attribution_Benchmark_Type_Name
	,b2.Benchmark_Type_Description	as Attribution_Benchmark_Type_Description
	,fb2.Return_Percentage					as Attribution_Benchmark_Return_Percentage
	,fb2.Local_Return_Percentage			as Attribution_Benchmark_Local_Return_Percentage
	,b9.Benchmark_ID						as Risk_Free_Benchmark_ID
	,b9.Benchmark_Name				as Risk_Free_Benchmark_Name
	,b9.Benchmark_Description		as Risk_Free_Benchmark_Description
	,b9.Benchmark_Type_Code			as Risk_Free_Benchmark_Type_Code
	,b9.Benchmark_Type_Name			as Risk_Free_Benchmark_Type_Name
	,b9.Benchmark_Type_Description	as Risk_Free_Benchmark_Type_Description
	,fb9.Return_Percentage					as Risk_Free_Benchmark_Return_Percentage
	,fb9.Local_Return_Percentage			as Risk_Free_Benchmark_Local_Return_Percentage
	,b3.Benchmark_ID						as Third_Alternative_Benchmark_ID
	,b3.Benchmark_Name				as Third_Alternative_Benchmark_Name
	,b3.Benchmark_Description		as Third_Alternative_Benchmark_Description
	,b3.Benchmark_Type_Code			as Third_Alternative_Benchmark_Type_Code
	,b3.Benchmark_Type_Name			as Third_Alternative_Benchmark_Type_Name
	,b3.Benchmark_Type_Description	as Third_Alternative_Benchmark_Type_Description
	,fb3.Return_Percentage					as Third_Alternative_Benchmark_Return_Percentage
	,fb3.Local_Return_Percentage			as Third_Alternative_Benchmark_Local_Return_Percentage
	,b4.Benchmark_ID						as Fourth_Alternative_Benchmark_ID
	,b4.Benchmark_Name				as Fourth_Alternative_Benchmark_Name
	,b4.Benchmark_Description		as Fourth_Alternative_Benchmark_Description
	,b4.Benchmark_Type_Code			as Fourth_Alternative_Benchmark_Type_Code
	,b4.Benchmark_Type_Name			as Fourth_Alternative_Benchmark_Type_Name
	,b4.Benchmark_Type_Description	as Fourth_Alternative_Benchmark_Type_Description
	,fb4.Return_Percentage					as Fourth_Alternative_Benchmark_Return_Percentage
	,fb4.Local_Return_Percentage			as Fourth_Alternative_Benchmark_Local_Return_Percentage
	,b.Source_System_Code
	,b.Last_Update_Datetime AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' as Last_Update_Datetime 
	,s.Source_Status_Code
	,s.Source_Status_Name
	,s.Enterprise_Status_Code
	,s.Enterprise_Status_Name
FROM [EDP_Consumer].[Bridge_Portfolio_Benchmark] b
join (Select * from EDP_Common.Dim_Date where Month_End_Flag=1) d on b.Dim_Effective_Date_Key  = d.Dim_Date_Key 
left join EDP_Consumer.Dim_Portfolio p on b.Dim_Portfolio_Key  = p.Dim_Portfolio_Key 
left join EDP_Consumer.Fact_Monthly_Portfolio_Performance fp on b.Dim_Effective_Date_Key = fp.Dim_Effective_Date_Key and b.Dim_Portfolio_Key = fp.Dim_Portfolio_Key
left join EDP_Consumer.Dim_Benchmark b1 on b.Dim_Primary_Benchmark_Key = b1.Dim_Benchmark_Key 
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb1 on b.Dim_Effective_Date_Key = fb1.Dim_Effective_Date_Key and b.Dim_Primary_Benchmark_Key = fb1.Dim_Benchmark_Key
left join EDP_Consumer.Dim_Benchmark b2 on b.Dim_Attribution_Benchmark_Key  = b2.Dim_Benchmark_Key 
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb2 on b.Dim_Effective_Date_Key = fb2.Dim_Effective_Date_Key and b.Dim_Attribution_Benchmark_Key = fb2.Dim_Benchmark_Key
left join EDP_Consumer.Dim_Benchmark b9 on b.Dim_Risk_Free_Benchmark_Key  = b9.Dim_Benchmark_Key 
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb9 on b.Dim_Effective_Date_Key = fb9.Dim_Effective_Date_Key and b.Dim_Risk_Free_Benchmark_Key = fb9.Dim_Benchmark_Key
left join EDP_Consumer.Dim_Benchmark b3 on b.Dim_Third_Alternative_Benchmark_Key  = b3.Dim_Benchmark_Key 
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb3 on b.Dim_Effective_Date_Key = fb3.Dim_Effective_Date_Key and b.Dim_Third_Alternative_Benchmark_Key = fb3.Dim_Benchmark_Key
left join EDP_Consumer.Dim_Benchmark b4 on b.Dim_Fourth_Alternative_Benchmark_Key  = b4.Dim_Benchmark_Key 
left join EDP_Consumer.Fact_Monthly_Bmk_Performance fb4 on b.Dim_Effective_Date_Key = fb4.Dim_Effective_Date_Key and b.Dim_Fourth_Alternative_Benchmark_Key = fb4.Dim_Benchmark_Key
left join EDP_Common.Dim_Source_Record_Status s ON fp.Dim_Source_Status_Key = s.Dim_Source_Status_Key;