﻿CREATE VIEW [EDP_Consumer].[XRef_Data_Sub_Domain_Table_Loaded]
AS SELECT 
	[Data_Sub_Domain_Code]
	,[Table_Loaded_Long_Name] 
    ,[Source_System_Code]
	,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime 
FROM [EDP_Common].[XRef_Data_Sub_Domain_Table_Loaded];