﻿CREATE VIEW [EDP_Consumer].[Dim_Portfolio] AS SELECT
      [Dim_Portfolio_Key]
	  ,[Portfolio_ID]
      ,[Portfolio_Name]
      ,[Portfolio_Type_Code]
      ,[Portfolio_Type_Name]
      ,[Portfolio_Type_Description]
      ,[Eagle_STAR_Portfolio_ID]
      ,[State_Street_Portfolio_ID]
      ,[Geneva_Subportfolio_ID]
      ,[Performance_Inception_Date]
	  ,[Performance_Official_Ownership_Flag]
	  ,Source_System_Code
      ,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM  [EDP_Common].[Dim_Portfolio] 
WHERE [Is_Current_Flag] = 1;