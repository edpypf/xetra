﻿CREATE VIEW [EDP_Consumer].[Dim_General_Ledger_Account]
AS SELECT [Dim_General_Ledger_Account_Key]
      ,[General_Ledger_Account_ID]
      ,[General_Ledger_Account_Name]
      ,[General_Ledger_Account_Description]
      ,[Eagle_STAR_Standard_Account_Name]
      ,[General_Ledger_Category_Code]
      ,[State_Street_General_Ledger_Account_ID]
      ,[Eagle_STAR_General_Ledger_Account_ID]
      ,[Eagle_STAR_General_Ledger_Standard_Account_ID]
      ,[Source_System_Code]
      ,[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM [EDP_Common].[Dim_General_Ledger_Account]
Where [Is_Current_Flag] = 1;