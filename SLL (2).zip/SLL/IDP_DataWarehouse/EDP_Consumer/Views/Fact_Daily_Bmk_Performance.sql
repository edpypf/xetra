﻿CREATE VIEW [EDP_Consumer].[Fact_Daily_Bmk_Performance]
AS Select    [Dim_Effective_Date_Key]
		  ,bc.[Dim_Benchmark_Key]
		  ,[Dim_Source_Status_Key]
		  ,[Return_Percentage]
		  ,[Local_Return_Percentage]
		  ,bp.Source_System_Code
		  ,bp.[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
FROM [EDP_Common].[V_Fact_Daily_Bmk_Performance] bp
Join EDP_Common.Dim_Benchmark b on bp.Dim_Benchmark_Key = b.Dim_Benchmark_Key
Join EDP_Common.Dim_Benchmark bc on b.Benchmark_Id = bc.Benchmark_Id and bc.Is_Current_Flag = 1;