﻿CREATE VIEW [EDP_Consumer].[BV_Daily_Portfolio_Performance] AS SELECT
       d.[Date] AS Effective_Date
      ,d.[Quarter_Of_Year]
      ,d.[Month_End_Flag]
      ,d.[Weekday_Flag]
      ,d.[Day_Of_Week]
      ,d.[Weekday_Short_Name]
      ,d.[Weekday_Full_name]
      ,d.[Day_Of_Month]
      ,d.[Month_Short_Name]
      ,d.[Month_Full_Name]
	  ,d.[Year]
      ,d.[Day_Of_Year]
      ,d.[Week_Of_Year]
      ,d.[Month_Of_Year]
      ,d.[First_Day_Of_Month]
      ,d.[Last_Day_Of_Month]
      ,p.[Portfolio_ID]
      ,p.[Current_Portfolio_Name] Portfolio_Name
      ,p.[Current_Portfolio_Type_Code] Portfolio_Type_Code
      ,p.[Current_Portfolio_Type_Name] Portfolio_Type_Name
      ,p.[Current_Portfolio_Type_Description] Portfolio_Type_Description
      ,p.[Current_Eagle_STAR_Portfolio_ID] Eagle_STAR_Portfolio_ID
      ,p.[Current_State_Street_Portfolio_ID] State_Street_Portfolio_ID
      ,p.[Current_Geneva_Subportfolio_ID] Geneva_Subportfolio_ID
      ,p.[Current_Performance_Inception_Date] Performance_Inception_Date
      ,P.Performance_Official_Ownership_Flag as Performance_Official_Ownership_Flag
      ,f.[Gross_Market_Value_BOD_Amount]
      ,f.[Gross_Market_Value_EOD_Amount]
      ,f.[Gross_Total_Cashflow_Amount]
      ,f.[Gross_Gain_Loss_Amount]
      ,f.[Gross_Investment_Base_Amount]
      ,f.[Gross_Return_Percentage]
      ,f.[Local_Return_Percentage]
	  ,f.[Source_System_Code] 
	  ,f.[Last_Update_Datetime] AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' Last_Update_Datetime
      ,srs.[Source_Status_Code]
      ,srs.[Source_Status_Name]
      ,srs.[Source_Status_Long_Name]
      ,srs.[Enterprise_Status_Code]
      ,srs.[Enterprise_Status_Name]
      ,srs.[Enterprise_Status_Long_Name]
	  ,npp.[Net_Return_Percentage]
	  ,npp.Source_System_Code AS [Net_Return_Source_System_Code]
	  ,npp.Last_Update_Datetime AS [Net_Return_Last_Update_Datetime]
      ,nss.[Source_Status_Code]          AS    Net_Return_Source_Status_Code
      ,nss.[Source_Status_Name]			 AS	   Net_Return_Source_Status_Name
      ,nss.[Source_Status_Long_Name]	 AS	   Net_Return_Source_Status_Long_Name
      ,nss.[Enterprise_Status_Code]		 AS	   Net_Return_Enterprise_Status_Code
      ,nss.[Enterprise_Status_Name]		 AS	   Net_Return_Enterprise_Status_Name
      ,nss.[Enterprise_Status_Long_Name] AS	   Net_Return_Enterprise_Status_Long_Name
FROM [EDP_Common].[V_Fact_Daily_Portfolio_Performance] f   
LEFT JOIN [EDP_Common].[Dim_Source_Record_Status] srs ON srs.[Dim_Source_Status_Key] = f.[Dim_Source_Status_Key]
LEFT JOIN [EDP_Common].[Dim_Date] d ON d.[Dim_Date_Key] = f.[Dim_Effective_Date_Key]
LEFT JOIN [EDP_Common].[V_Dim_Portfolio_Hist] p  ON p.[Dim_Portfolio_Key] = f.[Dim_Portfolio_Key]
LEFT JOIN [EDP_Common].[V_Fact_Daily_Net_Portfolio_Performance] npp ON f.[Dim_Effective_Date_Key] = npp.[Dim_Effective_Date_Key] AND f.[Dim_Portfolio_Key] = npp.[Dim_Portfolio_Key]	
LEFT JOIN [EDP_Common].[Dim_Source_Record_Status] as nss ON nss.[Dim_Source_Status_Key] = npp.[Dim_Source_Status_Key];