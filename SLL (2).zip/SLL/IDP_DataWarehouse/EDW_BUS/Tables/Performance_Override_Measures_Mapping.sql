﻿CREATE TABLE [EDW_BUS].[Performance_Override_Measures_Mapping] (
    [OLAP_Measure_Name] VARCHAR (255) NOT NULL,
    [View_Field_Name]   VARCHAR (255) NOT NULL,
    [Updated_Time]      DATETIME      NULL,
    [Updated_By]        VARCHAR (50)  NULL,
    [Date_Created]      DATETIME2 (7) NULL,
    CONSTRAINT [Cnstr_Manual_Performance_Config_Report_PK] PRIMARY KEY NONCLUSTERED ([View_Field_Name] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

