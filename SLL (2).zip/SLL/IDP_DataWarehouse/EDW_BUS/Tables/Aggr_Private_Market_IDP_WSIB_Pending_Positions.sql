﻿CREATE TABLE [EDW_BUS].[Aggr_Private_Market_IDP_WSIB_Pending_Positions] (
    [Effective_Date]       DATE             NOT NULL,
    [Fund]                 VARCHAR (100)    NOT NULL,
    [Fund_Name]            VARCHAR (255)    NULL,
    [Base_Market_Value]    NUMERIC (28, 12) NULL,
    [Security_Description] VARCHAR (255)    NULL,
    [Security_Name]        VARCHAR (255)    NULL,
    [CUSIP_Number]         VARCHAR (100)    NULL,
    [Load_DTS]             DATETIME2 (7)    NOT NULL,
    [Hash_Diff]            VARCHAR (64)     NULL,
    [ETL_Load_Key]         BIGINT           NOT NULL,
    [Is_Src_Deleted]       BIT              NULL,
    CONSTRAINT [Cnstr_Aggr_Private_Market_IDP_WSIB_Pending_Position_PK] PRIMARY KEY NONCLUSTERED ([Effective_Date] ASC, [Fund] ASC, [Load_DTS] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

