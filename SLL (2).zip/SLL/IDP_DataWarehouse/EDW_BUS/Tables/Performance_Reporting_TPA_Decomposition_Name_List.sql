﻿CREATE TABLE [EDW_BUS].[Performance_Reporting_TPA_Decomposition_Name_List] (
    [Decomposition_Name] VARCHAR (500) NOT NULL,
    [Sort_Order]         INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

