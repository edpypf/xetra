﻿CREATE TABLE [EDW_BUS].[Aggr_WSIB_Benchmark_Drifting_SAA_Weight] (
    [Dim_Date_Key]                INT              NOT NULL,
    [Dim_Client_Key]              INT              NOT NULL,
    [Dim_Strategy_Key]            INT              NOT NULL,
    [Load_DTS]                    DATETIME2 (7)    NOT NULL,
    [SAA_Date]                    DATE             NOT NULL,
    [Benchmark_MTD]               NUMERIC (38, 18) NULL,
    [Initial_Weight]              NUMERIC (38, 18) NULL,
    [Benchmark_Drifting_Weight]   NUMERIC (38, 18) NULL,
    [Rescaled_BM_Drifting_Weight] NUMERIC (38, 18) NULL,
    [Other_Info]                  VARCHAR (1000)   NULL,
    [Last_Update_DTS]             DATETIME2 (7)    NOT NULL,
    [Hash_Diff]                   VARCHAR (64)     NULL,
    [ETL_Load_Key]                BIGINT           NOT NULL,
    CONSTRAINT [Cnstr_PK_Aggr_WSIB_Benchmark_Drifting_SAA_Weight] PRIMARY KEY NONCLUSTERED ([Dim_Date_Key] ASC, [Dim_Client_Key] ASC, [Dim_Strategy_Key] ASC, [SAA_Date] ASC, [Load_DTS] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Dim_Strategy_Key]));



