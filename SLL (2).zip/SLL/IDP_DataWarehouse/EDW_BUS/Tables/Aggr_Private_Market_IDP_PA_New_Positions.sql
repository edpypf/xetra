﻿CREATE TABLE [EDW_BUS].[Aggr_Private_Market_IDP_PA_New_Positions] (
    [Effective_Date]        DATE          NOT NULL,
    [Asset_Class]           VARCHAR (255) NULL,
    [Primary_Asset_ID_Type] VARCHAR (100) NOT NULL,
    [Portfolio_ID]          VARCHAR (100) NOT NULL,
    [Accounting_Fund_ID]    VARCHAR (100) NOT NULL,
    [Dynamo_Fund_ID]        VARCHAR (100) NOT NULL,
    [Dynamo_Fund_Name]      VARCHAR (100) NULL,
    [Position_Count]        INT           NULL,
    [Load_DTS]              DATETIME2 (7) NOT NULL,
    [Hash_Diff]             VARCHAR (64)  NULL,
    [ETL_Load_Key]          BIGINT        NOT NULL,
    [Is_Src_Deleted]        BIT           NULL,
    CONSTRAINT [Cnstr_Aggr_Private_Market_IDP_PA_New_Positions_PK] PRIMARY KEY NONCLUSTERED ([Effective_Date] ASC, [Portfolio_ID] ASC, [Accounting_Fund_ID] ASC, [Dynamo_Fund_ID] ASC, [Load_DTS] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

