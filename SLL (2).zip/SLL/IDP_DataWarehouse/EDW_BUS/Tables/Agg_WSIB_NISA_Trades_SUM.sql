﻿CREATE TABLE [EDW_BUS].[Agg_WSIB_NISA_Trades_SUM] (
    [HOLDING_DATE]               VARCHAR (15)  NULL,
    [ASSET_CLASS]                VARCHAR (100) NULL,
    [ACCOUNT]                    VARCHAR (100) NULL,
    [ACCOUNT_DESCRIPTION]        VARCHAR (500) NULL,
    [COMPOSITE_ID]               VARCHAR (30)  NULL,
    [BASE_MARKET_VALUE]          VARCHAR (500) NULL,
    [BASE_MARKET_VALUE_CURRENCY] VARCHAR (100) NULL,
    [WEIGHT]                     VARCHAR (100) NULL,
    [TREE_PART]                  VARCHAR (100) NULL,
    [BUCKETLIST]                 VARCHAR (100) NULL,
    [Load_DTS]                   DATETIME2 (7) NOT NULL,
    [Hash_Diff]                  VARCHAR (64)  NULL,
    [ETL_Load_Key]               BIGINT        NOT NULL,
    [Source_Deleted_Flag]        BIT           NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

