﻿CREATE TABLE [EDW_BUS].[Aggr_Client_Portfolio_Ownership] (
    [Dim_Date_Key]                 INT              NOT NULL,
    [Dim_Client_Key]               INT              NOT NULL,
    [Dim_Strategy_Key]             INT              NOT NULL,
    [Dim_Portfolio_Key]            INT              NOT NULL,
    [Load_DTS]                     DATETIME2 (7)    NOT NULL,
    [Percent_Portfolio_Owned]      NUMERIC (38, 19) NULL,
    [Percent_Portfolio_Represents] NUMERIC (38, 19) NULL,
    [Market_Value_Portfolio]       NUMERIC (38, 19) NULL,
    [Market_Value_Client]          NUMERIC (38, 19) NULL,
    [Market_Value_Portfolio_Owned] NUMERIC (38, 19) NULL,
    [Other_Info]                   VARCHAR (4000)   NULL,
    [Last_Update_DTS]              DATETIME2 (7)    NOT NULL,
    [Hash_Diff]                    VARCHAR (64)     NULL,
    [ETL_Load_Key]                 BIGINT           NOT NULL,
    [Is_Src_Deleted]               BIT
    CONSTRAINT [Cnstr_Aggr_Client_Portfolio_Ownership_PK] PRIMARY KEY NONCLUSTERED ([Dim_Date_Key] ASC, [Dim_Client_Key] ASC, [Dim_Strategy_Key] ASC, [Dim_Portfolio_Key] ASC, LOAD_DTS ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Dim_Portfolio_Key]));



