﻿CREATE TABLE [EDW_BUS].[Aggr_TPM_Account_Level_Holdings] (
    [Effective_Date]                     DATE             NOT NULL,
    [Client_ID]                          VARCHAR (255)    NOT NULL,
    [IPS_Strategy]                       VARCHAR (255)    NOT NULL,
    [Parent_Portfolio_ID]                VARCHAR (255)    NOT NULL,
    [Portfolio_ID]                       VARCHAR (255)    NOT NULL,
    [Security_ID]                        VARCHAR (255)    NOT NULL,
    [Security_Name]                      VARCHAR (255)    NULL,
    [Security_Market_Value]              NUMERIC (38, 19) NULL,
    [Pool_Percent_Security_Market_Value] NUMERIC (38, 19) NULL,
    [Load_DTS]                           DATETIME2 (7)    NOT NULL,
    [Other_Info]                         VARCHAR (4000)   NULL,
    [Last_Update_DTS]                    DATETIME2 (7)    NOT NULL,
    [Hash_Diff]                          VARCHAR (64)     NULL,
    [ETL_Load_Key]                       BIGINT           NOT NULL,
    [Is_Src_Deleted]                     BIT              NULL,
    [Type]                               VARCHAR (255)    NULL,
    CONSTRAINT [Const_Aggr_TPM_Account_Level_Holdings] PRIMARY KEY NONCLUSTERED ([Effective_Date] ASC, [Client_ID] ASC, [IPS_Strategy] ASC, [Parent_Portfolio_ID] ASC, [Portfolio_ID] ASC, [Security_ID] ASC, [Load_DTS] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

