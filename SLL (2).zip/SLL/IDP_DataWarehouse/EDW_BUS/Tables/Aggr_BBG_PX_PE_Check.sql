﻿CREATE TABLE [EDW_BUS].[Aggr_BBG_PX_PE_Check] (
    [Bloomberg_Identifier] VARCHAR (255) NOT NULL,
    [Security_Name]        VARCHAR (255) NULL,
    [ISIN]                 VARCHAR (255) NULL,
    [CUSIP]                VARCHAR (255) NULL,
    [SEDOL1]               VARCHAR (255) NULL,
    [Currency]             CHAR (3)      NULL,
    [Effective_Date]       CHAR (10)     NULL,
    [PRICE]                VARCHAR (255) NULL,
    [PRICE_DATE]           CHAR (10)     NULL,
    [Batch_Date]           CHAR (10)     NULL,
    [Pool_Name]            VARCHAR (4)   NOT NULL,
    [IsMonday]             BIT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

