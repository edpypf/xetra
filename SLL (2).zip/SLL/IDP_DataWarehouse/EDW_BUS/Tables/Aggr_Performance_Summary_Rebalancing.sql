﻿CREATE TABLE [EDW_BUS].[Aggr_Performance_Summary_Rebalancing] (
    [Report_Number]    INT             NOT NULL,
    [Client_ID]        VARCHAR (20)    NOT NULL,
    [Entity_id]        VARCHAR (20)    NOT NULL,
    [WTD_Value]        NUMERIC (38, 8) NULL,
    [MTD_Value]        NUMERIC (38, 8) NULL,
    [QTD_Value]        NUMERIC (38, 8) NULL,
    [YTD_Value]        NUMERIC (38, 8) NULL,
    [Month1_Value]     NUMERIC (38, 8) NULL,
    [Month_QTD_Value]  NUMERIC (38, 8) NULL,
    [Month_YTD_Value]  NUMERIC (38, 8) NULL,
    [Month_12_Value]   NUMERIC (38, 8) NULL,
    [Month_36_Value]   NUMERIC (38, 8) NULL,
    [Month_60_Value]   NUMERIC (38, 8) NULL,
    [Month_120_Value]  NUMERIC (38, 8) NULL,
    [Effective_Date]   DATE            NULL,
    [Updated_DateTime] DATETIME        NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

