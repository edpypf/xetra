﻿CREATE TABLE [EDW_BUS].[Aggr_Private_Market_Cash_Flow_Realized_FX_BKP20231117] (
    [Dim_Date_Key]                   INT              NOT NULL,
    [Dim_Portfolio_Key]              INT              NOT NULL,
    [Dim_Eagle_Portfolio_Detail_Key] INT              NOT NULL,
    [Previou_Local_Total_FX]         NUMERIC (38, 12) NULL,
    [Previou_Base_Total_FX]          NUMERIC (38, 12) NULL,
    [Current_Local_Total_FX]         NUMERIC (38, 12) NULL,
    [Current_Base_Total_FX]          NUMERIC (38, 12) NULL,
    [Moving_Avg_Fx]                  NUMERIC (38, 12) NULL,
    [ROC_Avg_Fx]                     NUMERIC (38, 12) NULL,
    [Hash_Diff]                      VARCHAR (64)     NULL,
    [Load_DTS]                       DATETIME2 (7)    NOT NULL,
    [Last_Update_DTS]                DATETIME2 (7)    NOT NULL,
    [ETL_Load_Key]                   INT              NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

