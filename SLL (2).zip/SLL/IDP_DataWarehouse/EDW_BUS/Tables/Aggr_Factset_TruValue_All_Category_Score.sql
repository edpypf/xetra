﻿CREATE TABLE [EDW_BUS].[Aggr_Factset_TruValue_All_Category_Score] (
    [effective_date]         DATE         NULL,
    [isin]                   VARCHAR (12) NULL,
    [pulse_score]            FLOAT (53)   NULL,
    [adjusted_insight_score] FLOAT (53)   NULL,
    [momentum_score]         FLOAT (53)   NULL,
    [ttm_article_volume]     INT          NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);


GO
CREATE CLUSTERED COLUMNSTORE INDEX [edw_bus_factset_truvalue_all_category_score]
    ON [EDW_BUS].[Aggr_Factset_TruValue_All_Category_Score] ORDER([effective_date]);

