﻿CREATE TABLE [EDW_BUS].[Aggr_Performance_RPT_TPA_Exhibit_Summary] (
    [Report_Number]      INT              NOT NULL,
    [Client_ID]          VARCHAR (255)    NOT NULL,
    [Entity_ID]          VARCHAR (255)    NOT NULL,
    [Effective_Date]     DATE             NULL,
    [Decomposition_Name] VARCHAR (500)    NOT NULL,
    [Sort_Order]         INT              NULL,
    [YTD_value]          NUMERIC (38, 12) NULL,
    [MTD_Value]          NUMERIC (38, 12) NULL,
    [QTD_Value]          NUMERIC (38, 12) NULL,
    [Batch_DTS]          DATETIME         NULL,
    [ETL_Load_Key]       BIGINT           NULL,
    [Daily_Value]        NUMERIC (38, 12) NULL,
    [WTD_Value]          NUMERIC (38, 12) NULL,
    [MTD_Daily_Value]    NUMERIC (38, 12) NULL,
    [QTD_Daily_Value]    NUMERIC (38, 12) NULL,
    [YTD_Daily_Value]    NUMERIC (38, 12) NULL,
    [type]               VARCHAR (500)    NULL,
    [Updated_Datetime]   DATETIME         NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);



