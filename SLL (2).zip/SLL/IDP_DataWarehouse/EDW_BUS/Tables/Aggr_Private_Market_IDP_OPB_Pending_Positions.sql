﻿CREATE TABLE [EDW_BUS].[Aggr_Private_Market_IDP_OPB_Pending_Positions] (
    [Effective_Date]     DATE             NOT NULL,
    [Asset_Class_Code]   VARCHAR (255)    NULL,
    [Acc_Portfolio_Code] VARCHAR (100)    NOT NULL,
    [MellonID]           VARCHAR (100)    NOT NULL,
    [Issue_Name]         VARCHAR (255)    NULL,
    [Market_Value]       NUMERIC (28, 12) NULL,
    [IPS_Strategy]       VARCHAR (100)    NULL,
    [Load_DTS]           DATETIME2 (7)    NOT NULL,
    [Hash_Diff]          VARCHAR (64)     NULL,
    [ETL_Load_Key]       BIGINT           NOT NULL,
    [Is_Src_Deleted]     BIT              NULL,
    CONSTRAINT [Cnstr_Aggr_Private_Market_IDP_OPB_Pending_Position_PK] PRIMARY KEY NONCLUSTERED ([Effective_Date] ASC, [Acc_Portfolio_Code] ASC, [MellonID] ASC, [Load_DTS] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

