﻿CREATE TABLE [EDW_BUS].[Aggr_FX_Infra_Pool_FX_Exposure] (
    [Effective_Date]                DATE         NULL,
    [Analysis_Date]                 DATE         NULL,
    [Custody_Code]                  VARCHAR (50) NULL,
    [Trade_Currency]                VARCHAR (10) NULL,
    [FX_Rate]                       FLOAT (53)   NULL,
    [Client_Id]                     VARCHAR (50) NULL,
    [IPS_Strategy]                  VARCHAR (50) NULL,
    [Portfolio_Id]                  VARCHAR (50) NULL,
    [Entity_Name]                   VARCHAR (50) NULL,
    [Client_No_Of_Units]            FLOAT (53)   NULL,
    [Total_No_Of_Units]             FLOAT (53)   NULL,
    [Client_Allocation]             FLOAT (53)   NULL,
    [Strategic_Hedge_Ratio]         FLOAT (53)   NULL,
    [FX_Forward_Value_Date]         DATE         NULL,
    [Local_Net_FX_Position]         FLOAT (53)   NULL,
    [Underlying_MV_By_Currency]     FLOAT (53)   NULL,
    [Local_Exposure_By_Currency]    FLOAT (53)   NULL,
    [Underlying_Hedgeable_Exposure] FLOAT (53)   NULL,
    [Exposure_and_Net_Position]     FLOAT (53)   NULL,
    [Hedge_Status]                  VARCHAR (50) NULL,
    [Load_DTS]                      DATETIME     NULL,
    [ETL_Load_Key]                  INT          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

