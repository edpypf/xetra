﻿CREATE TABLE [EDW_BUS].[Aggr_Private_Market_Dynamo_Old_Record] (
    [Effective_Date]     DATE             NOT NULL,
    [Asset_Class]        VARCHAR (255)    NULL,
    [Dynamo_Fund_ID]     VARCHAR (100)    NOT NULL,
    [Dynamo_Fund_Name]   VARCHAR (100)    NULL,
    [Dynamo_CUSIP_1]     VARCHAR (100)    NULL,
    [Dynamo_CUSIP_2]     VARCHAR (100)    NULL,
    [Dynamo_Mellon_ID]   VARCHAR (100)    NULL,
    [PRIMARY_ASSET_ID]   VARCHAR (100)    NOT NULL,
    [Dynamo_Asset_Name]  VARCHAR (255)    NOT NULL,
    [Market_Value]       NUMERIC (28, 12) NULL,
    [Local_Market_Value] NUMERIC (28, 12) NULL,
    [Currency_Fund]      VARCHAR (3)      NULL,
    [Leverage]           VARCHAR (255)    NULL,
    [Sector]             VARCHAR (255)    NULL,
    [Region]             VARCHAR (255)    NULL,
    [Revenue_Source]     VARCHAR (255)    NULL,
    [Risk_Strategy]      VARCHAR (255)    NULL,
    [Partner]            VARCHAR (255)    NULL,
    [Country_Of_Risk]    VARCHAR (20)     NULL,
    [Load_DTS]           DATETIME2 (7)    NOT NULL,
    [Hash_Diff]          VARCHAR (64)     NULL,
    [ETL_Load_Key]       BIGINT           NOT NULL,
    [Is_Src_Deleted]     BIT              NULL,
    CONSTRAINT [Cnstr_Aggr_Private_Market_Dynamo_Old_Record_PK] PRIMARY KEY NONCLUSTERED ([Effective_Date] ASC, [Dynamo_Fund_ID] ASC, [PRIMARY_ASSET_ID] ASC, [Dynamo_Asset_Name] ASC, [Load_DTS] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

