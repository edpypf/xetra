﻿CREATE VIEW [EDW_BUS].[Risk_Cone_Chart_NVA] AS with 
	number_list as
	(
		Select ROW_NUMBER () OVER (ORDER BY column_id) AS Number from sys.columns
	),
	months as
	(
		select top (datediff(month,'2020-01-01','2024-12-31')+1) 
			[Month] = dateadd(month, row_number() over (order by number) -1, '2020-01-01')
		, Effective_Date = dateadd(day,-1,dateadd(month, row_number() over (order by number), '2020-01-01'))
		from number_list
		order by [Month]
	),
	weights as
	(
		select			
				sma.client_id
			,	sma.strategy_id
			,	eomonth(dd.[Date]) as effective_date
			,	case 
					when sma.strategy_id in ('Active Asset Allocation','Dynamic FX') and dd.[date] >='2020-07-01' and sma.client_id like 'WSIB%' 
						then 1
					when sma.strategy_id in ('Active Asset Allocation','Dynamic FX') and sma.client_id like 'OPB' 
						then 1
					else sma.weight
				end as adjusted_weight
			, smr.target_excess_return as target_return
			, row_number() Over (Partition By sma.client_id, sma.strategy_id, sma.SAA_Date Order By  dd.[Date] desc ) rn
	     	from [EDW_Common].[V_Fact_Manual_Client_Strategy_SAA_Weight] sma
			inner join [PSA].[V_Manual_Risk_Policy_Limits] smr	on sma.strategy_ID = smr.IPS_Strategy
			inner join [EDW_Common].[Dim_Date] dd on sma.[Dim_Date_Key] = dd.[Dim_Date_Key]
			inner join [EDW_Common].[Dim_SAA_Weight_Type] wt  on sma.[Dim_SAA_Weight_Type_Key] = wt.[Dim_SAA_Weight_Type_Key]

		where dd.[Date] between  smr.start_date and 
			case when smr.end_date is null then '9999-12-31'
				else smr.end_date
			end
			and wt.SAA_weight_type = 'Adjusted Interim SAA Prelim'

	),
	target_nva_cal as
	(
		select client_id, effective_date, 
			sum(adjusted_weight * target_return) as target_nva
		from weights w
		where rn = 1
		group by client_id, effective_date
	),
	/*
	manual_override as (
		Select Client_Id, Effective_Date, target_nva
		From [EDW_Raw].[V_File_Override_Cone_Chart_RPT]
		Where target_nva is not null 
	),
	*/
	target_nva as (
		Select 
			c.client_id,
			c.effective_date,
			-- coalesce(m.target_nva, c.target_nva) target_nva,
			c.target_nva,
			row_number() over (partition by c.client_id order by c.effective_date) as rn
		From target_nva_cal c
		-- left join manual_override m on c.client_Id = m.client_id and c.effective_Date = m.effective_date
	),
	latest_data as
	(
		select n.client_id, n.effective_date, n.target_nva
		from target_nva n
			inner join 
				(
					select client_id, max(effective_date) as effective_date
					from target_nva
					group by client_id
				) m
			on m.effective_date = n.effective_date
				and m.client_id = n.client_id
	),
	client_list as
	(
		select distinct client_id
		from target_nva
	),
	date_list as
	(
		select c.client_id, m.effective_date
		from client_list c
			cross join months m
	),
	forward_filled_nva as
	(
		select coalesce(d.client_id, n.client_id) as client_id, coalesce(d.effective_date, n.effective_date) as effective_date, coalesce(n.target_nva, l.target_nva) as target_nva,
			row_number() over (partition by d.client_id order by d.effective_date) as rn
		from target_nva n
		right outer join date_list d
			on n.client_id = d.client_id 
			and n.effective_date = d.effective_date
		right outer join latest_data l
			on l.client_id = d.client_id 
	),
	expected_nva as
	(
		select client_id, effective_date, target_nva, rn, target_nva/12.0  as expected_nva
		from forward_filled_nva
	),
	cumulative_expected_nva as
	(
		select client_id, effective_date, target_nva, expected_nva,
			SUM(expected_nva) OVER(PARTITION BY client_id ORDER BY effective_date ROWS UNBOUNDED PRECEDING) AS expected_nva_cumulative
		from expected_nva
	)
	select 
		 client_id
		 , effective_date
		 , target_nva
		 , expected_nva_cumulative as expected_nva 
	from cumulative_expected_nva e;