﻿CREATE VIEW [EDW_BUS].[V_Versioned_Drifting_SAA_Weight] AS Select   T.Client_Id
		,T.Strategy_Id
		,T.SAA_Weight_Type
		,T.Load_DTS
		,T.SAA_Date
		,Benchmark_MTD
		,Initial_Weight
		,End_Drifting_Weight
		,Rescaled_Drifting_Weight
		,T.Version_Effective_Date
		,T.Version_Expiry_Date
		,D.Version_Number
  From (  -- Get list of all versions of individual records, and calculate effective/expiry dates
        Select	  c.Client_Id
				 ,sm.Strategy_Id
				 ,wt.SAA_Weight_Type
				 ,w.Load_DTS  
				 ,w.SAA_Date
				 ,w.Daily_Portfolio_Return as Benchmark_MTD
				 ,w.Initial_Weight
				 ,w.End_Drifting_Weight
				 ,w.Rescaled_Drifting_Weight
				 ,w.Last_Update_DTS  as Version_Effective_Date
				 ,dateadd(minute, -1,lead(w.Last_Update_DTS, 1, '99991231 00:01:00' ) 
							over(partition by c.Client_Id, sm.Strategy_Id, wt.SAA_Weight_Type, w.SAA_Date order by w.Last_Update_DTS)) as Version_Expiry_Date
		  From	  [EDW_Common].[Fact_Aggr_Drifting_SAA_Weight] w
				  Join EDW_Common.Dim_Client c on w.Dim_Client_Key = c.Dim_Client_Key
				  Join EDW_Common.Dim_Strategy s on w.Dim_Strategy_Key = s.Dim_Strategy_Key
				  Join EDW_Common.Dim_SAA_Weight_Type wt on w.Dim_SAA_Weight_Type_Key = wt.Dim_SAA_Weight_Type_Key
				  Join [EDW_BUS].[TPM_Strategy_Map] sm on s.Strategy_Id = sm.Org_Strategy_Id and w.SAA_Date between sm.Record_Start_DTS and sm.Record_End_DTS 
		  Where Initial_weight <> 0
       ) T 
	   Inner Join (   Select SAA_Date
							,Client_id
							,SAA_Weight_Type
							,Load_DTS
							,row_number() over(partition by SAA_Date, Client_id, SAA_Weight_Type order by Load_DTS) as Version_Number
					  From (  Select Distinct --Get distinct list of SAA_Dates and Updates
									 w.SAA_Date
									,c.Client_id
									,wt.SAA_Weight_Type
									,w.Last_Update_DTS as Load_DTS
							  From  [EDW_Common].[Fact_Aggr_Drifting_SAA_Weight] w
							  Join EDW_Common.Dim_Client c on w.Dim_Client_Key = c.Dim_Client_Key
							  Join EDW_Common.Dim_SAA_Weight_Type wt on w.Dim_SAA_Weight_Type_Key = wt.Dim_SAA_Weight_Type_Key
							  Join EDW_Common.Dim_Strategy s on w.Dim_Strategy_Key = s.Dim_Strategy_Key
							  Join [EDW_BUS].[TPM_Strategy_Map] sm on s.Strategy_Id = sm.Org_Strategy_Id 
										and w.SAA_Date between sm.Record_Start_DTS and sm.Record_End_DTS 
						   ) V
				 ) D On D.SAA_Date  = T.SAA_Date 
						and T.Client_Id = D.Client_Id
						and T.SAA_Weight_Type = D.SAA_Weight_Type
						and D.Load_DTS  between T.Version_Effective_Date and T.Version_Expiry_Date;