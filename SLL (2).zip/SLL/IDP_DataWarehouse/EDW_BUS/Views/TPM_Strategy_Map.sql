﻿Create VIEW [EDW_BUS].[TPM_Strategy_Map]
AS Select s2.Dim_Strategy_Key Dim_Strategy_Key, s.Strategy_id Org_Strategy_Id, s2.Strategy_Id Strategy_Id, 
				min(s2.Record_Start_DTS) Record_Start_DTS, max(coalesce(s2.Record_End_DTS,'9999-12-31')) Record_End_DTS
		From edw_common.dim_strategy s
		join (
			Select Dim_strategy_Key, Strategy_id, Src_Strategy_Id, Record_Start_DTS, Record_End_DTS, 
			Row_number() Over (Partition By Strategy_id, Src_Strategy_Id, Record_Start_DTS, Record_End_DTS Order By Record_Is_Current_Flag Desc) rn
			From edw_common.dim_strategy
			Where Is_Src_Deleted_Flag = 0
		) s2 on s.Strategy_id = s2.Src_Strategy_Id 
		where s.Is_Src_Deleted_Flag = 0 and s2.rn = 1
		Group By s.Strategy_id, s2.Strategy_Id, s2.Dim_strategy_Key