﻿CREATE VIEW [EDW_BUS].[V_Versioned_WSIB_Drifting_Benchmark]
AS Select T.Client_Id
     , T.Strategy_Id
     , T.Load_DTS
     , T.SAA_Date
    , Benchmark_MTD
    , Initial_Weight
	, Benchmark_Drifting_Weight
	, Rescaled_BM_Drifting_Weight
	, T.Version_Effective_Date
     , T.Version_Expiry_Date
     , D.Version_Number
  From (-- Get list of all versions of individual records, and calculate effective/expiry dates
        Select c.Client_Id
		     , sm.Strategy_Id
             , w.Load_DTS  
             , w.SAA_Date
             , w.Benchmark_MTD
             , w.Initial_Weight
			 , w.Benchmark_Drifting_Weight
			 , w.Rescaled_BM_Drifting_Weight
             , w.Load_DTS  as Version_Effective_Date
             , dateadd(minute, -1,
                       lead(w.Load_DTS, 1, '99991231 00:01:00' ) over(partition by c.Client_Id, sm.Strategy_Id, w.SAA_Date order by w.Load_DTS)) as Version_Expiry_Date
          From [EDW_BUS].[Aggr_WSIB_Benchmark_Drifting_SAA_Weight] w
		  Join EDW_Common.Dim_Client c on w.Dim_Client_Key = c.Dim_Client_Key
		  Join EDW_Common.Dim_Strategy s on w.Dim_Strategy_Key = s.Dim_Strategy_Key
		  Join [EDW_BUS].[TPM_Strategy_Map] sm on s.Strategy_Id = sm.Org_Strategy_Id and w.SAA_Date between sm.Record_Start_DTS and sm.Record_End_DTS 
		   where Initial_weight <> 0
       ) T
       Inner Join
       (-- Get distinct list of available versions, based on Load_DTS, for each SAA_Date
        Select SAA_Date
		     -- , Strategy_Id
		     , Load_DTS
             , row_number() over(partition by SAA_Date order by Load_DTS) as Version_Number
          From (Select Distinct --Get distinct list of SAA_Dates and Updates
                       w.SAA_Date
					--  , sm.Strategy_Id
                     , w.Load_DTS
                  From  [EDW_BUS].[Aggr_WSIB_Benchmark_Drifting_SAA_Weight] w
                  Join EDW_Common.Dim_Strategy s on w.Dim_Strategy_Key = s.Dim_Strategy_Key
				  Join [EDW_BUS].[TPM_Strategy_Map] sm on s.Strategy_Id = sm.Org_Strategy_Id and w.SAA_Date between sm.Record_Start_DTS and sm.Record_End_DTS 
			 ) V
        ) D On D.SAA_Date            = T.SAA_Date 
		   -- and D.Strategy_Id = T.Strategy_Id 
           -- Cause any unchanged base records, or base records with differing version dates, to be replicated for all versioned records to which they apply
           and D.Load_DTS   between T.Version_Effective_Date and T.Version_Expiry_Date