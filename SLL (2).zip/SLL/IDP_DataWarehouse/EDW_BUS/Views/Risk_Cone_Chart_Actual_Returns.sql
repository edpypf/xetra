﻿CREATE VIEW [EDW_BUS].[Risk_Cone_Chart_Actual_Returns] AS with number_list as
	(
		Select ROW_NUMBER () OVER (ORDER BY column_id) AS Number from sys.columns
	),
	months as
	(
		select top (datediff(month,'2020-01-01','2024-12-31')+1) 
		  [Month] = dateadd(month, row_number() over (order by number) -1, '2020-01-01')
		, Effective_Date = dateadd(day,-1,dateadd(month, row_number() over (order by number), '2020-01-01'))
		, 1 dummy_col
	  from number_list
	  order by [Month]
	),
	actual_return_cal as (
		select 
			c.Client_Id
			,	s.Strategy_Id
			,	dd.Date AS effective_date
			,	pp.Report_freq_Return/100 - f.Monthly_Fee as Portfolio_Net_Return
			,	ip.Report_Freq_Return/100 as Benchmark_Return 
			,	((pp.Report_freq_Return - ip.Report_Freq_Return)/100  - f.Monthly_Fee) as Actual_NVA 
	FROM [EDW_Common].[V_Fact_Eagle_Total_Portfolio_Performance] pp
		inner join [EDW_Common].[Bridge_Portfolio_Mapping] bpm	on pp.dim_portfolio_key = bpm.dim_portfolio_key	and pp.dim_date_key	=bpm.dim_date_key and bpm.Is_Src_Deleted = 0 
		inner join [EDW_Common].[Bridge_Portfolio_Group] bpg	on pp.dim_portfolio_key = bpg.dim_portfolio_key	and pp.[Dim_Date_Key] = bpg.[Dim_Date_Key] and bpg.Is_Src_Deleted = 0 
		inner join  [EDW_Common].[Dim_Portfolio_Group] pg	on bpg.[Dim_Portfolio_Group_Key] = pg.[Dim_Portfolio_Group_Key]
		inner join  [EDW_Common].[Dim_Portfolio] dp	on pp.dim_portfolio_key = dp.dim_portfolio_key
		inner join  [EDW_Common].[Dim_Strategy] s	on bpm.dim_Strategy_key = s.dim_Strategy_key 
		inner join  [EDW_Common].[Dim_Client] c		on c.dim_client_key		= bpm.Dim_client_key
		inner join [PSA].[V_Manual_Risk_Monthly_Client_Fees] f	on f.Client_ID = c.Client_ID
		inner join [PSA].[V_Manual_Risk_Policy_Limits] pl	on pl.IPS_Strategy = s.Strategy_ID 
		inner join [EDW_Common].[Bridge_Portfolio_Index] pi	on  pi.portfolio_id = dp.portfolio_id and pi.Record_Is_Current_Flag = 1
		inner join EDW_Common.V_Fact_Eagle_Total_Index_Performance ip	on pi.Index_Id  = ip.Index_Id and pp.Dim_date_Key = ip.dim_date_key
		inner join [EDW_Common].[Dim_Date] dd	on dd.Dim_Date_Key = pp.Dim_Date_Key
	Where pp.report_freq_code = 'M'
		and ip.report_Freq = 'M'
		and s.strategy_id = 'Total Plan'
		and pg.portfolio_group_name = 'RISK CONE CHART'
		and pi.benchmark_purpose = 'Primary Comparison Index'
		and ip.Blend_Type = 'Default'
		and c.Client_id = 'OPB'

	union

	select 
			c.Client_Id
			,	s.Strategy_Id
			,	dd.Date AS effective_date 
			,  (pp.Fund_MTD/100 - f.Monthly_Fee) as Portfolio_Net_Return
			,  pp.Benchmark_MTD/100 as Benchmark_Return
			,  pp.Excess_MTD/100 - f.Monthly_Fee as Actual_NVA
	FROM [EDW_Common].[V_Fact_StateStreet_Total_Portfolio_Performance] pp
		inner join [EDW_Common].[Bridge_Portfolio_Mapping] bpm	on pp.dim_portfolio_key = bpm.dim_portfolio_key	and pp.dim_date_key	=bpm.dim_date_key and bpm.Is_Src_Deleted = 0 
		inner join [EDW_Common].[Bridge_Portfolio_Group] bpg	on pp.dim_portfolio_key = bpg.dim_portfolio_key	and pp.[Dim_Date_Key] = bpg.[Dim_Date_Key] and bpg.Is_Src_Deleted = 0 
		inner join  [EDW_Common].[Dim_Portfolio_Group] pg	on bpg.[Dim_Portfolio_Group_Key] = pg.[Dim_Portfolio_Group_Key]
		inner join  [EDW_Common].[Dim_Portfolio] dp	on pp.dim_portfolio_key = dp.dim_portfolio_key
		inner join  [EDW_Common].[Dim_Strategy] s	on bpm.dim_Strategy_key = s.dim_Strategy_key 
		inner join  [EDW_Common].[Dim_Client] c		on c.dim_client_key		= bpm.Dim_client_key
		inner join [PSA].[V_Manual_Risk_Monthly_Client_Fees] f	on f.Client_ID = c.Client_ID
		inner join [EDW_Common].[Dim_Date] dd	on dd.Dim_Date_Key = pp.Dim_Date_Key
	Where dd.Date = eomonth(dd.Date)
		and s.strategy_id = 'Total Plan'
		and pg.portfolio_group_name = 'RISK CONE CHART'
	),
	/*
	manual_override as (
		Select Client_Id, Effective_Date, Actual_NVA
		From [EDW_Raw].[V_File_Override_Cone_Chart_RPT]
		Where Actual_NVA is not null 
	),
	*/
	actual_return as (
		Select 
			c.client_id,
			c.effective_date,
			Portfolio_Net_Return,
			Benchmark_Return,
			-- coalesce(m.actual_nva, c.actual_nva) actual_nva,
			c.actual_nva,
			row_number() over (partition by c.client_id order by c.effective_date) as rn
		From actual_return_cal c
		-- left join manual_override m on c.client_Id = m.client_id and c.effective_Date = m.effective_date

	),
	client_list as (
		select 1 dummy_col, Client_Id, Portfolio_Net_Return, Benchmark_Return, actual_nva, effective_date,
		row_number() over (partition by Client_Id order by effective_date desc) rn
		from actual_return
	),
	client_dates as (
		select a.Client_Id,  a.Portfolio_Net_Return, a.Benchmark_Return, a.actual_nva, m.effective_date
		from client_list a
		join months m on a.dummy_col = m.dummy_col
		where rn =1 and m.effective_date > a.effective_date
	),
	combined_actual_return as (
		select Client_Id, Portfolio_Net_Return, Benchmark_Return, actual_nva, effective_date	
		from actual_return
		union
		select Client_Id, null, null, null, effective_date	
		from client_dates
	)
	select	
		client_id, effective_date, 
		cast(portfolio_net_return as float) as portfolio_net_return, 
		cast(benchmark_return as float) as benchmark_return,
		cast(actual_nva as float) as actual_nva,
		case
			when actual_nva is not null then
				exp(sum(log(1 + cast(actual_nva as float))) OVER (partition by client_id ORDER BY effective_date)) - 1 
			else
				null
		end as cumulative_nva
	from combined_actual_return
	where cast(actual_nva as float) > -1;