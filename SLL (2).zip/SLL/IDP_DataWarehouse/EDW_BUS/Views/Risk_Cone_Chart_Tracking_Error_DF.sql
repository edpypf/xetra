﻿CREATE VIEW [EDW_BUS].[Risk_Cone_Chart_Tracking_Error_DF] AS with number_list as
	(
		Select ROW_NUMBER () OVER (ORDER BY column_id) AS Number from sys.columns
	),
	months as
	(
		select top (datediff(month,'2020-01-01','2024-12-31')+1) 
		  [Month] = dateadd(month, row_number() over (order by number) -1, '2020-01-01')
		, Effective_Date = dateadd(day,-1,dateadd(month, row_number() over (order by number), '2020-01-01'))
	  from number_list
	  order by [Month]
	),
	psa_tracking_error as
	(
		select 
			effective_date, c.client_Id client, sum(cast(total_te_contr_limit_1 as float)) as Tracking_Error,
			DATEADD(month, DATEDIFF(month, 0, effective_date), 0) AS StartOfMonth,
			row_number() over (partition by c.client_Id, year(effective_date), month(effective_date) order by effective_date) as rn
			FROM PSA.[V_RiskManual_Tracking_Error_Decomposition] f
			join EDW_Common.Dim_Client c on f.client = c.Src_Client_Id and c.Record_Is_Current_Flag = 1
		group by effective_date, c.client_Id
	
	),
	holiday_count as
	(
		select effective_date, client, count(*) as holiday_counter
		from psa_tracking_error p
			left outer join [EDW_ETL].[User_Holiday_Calendar] u
				on u.holiday_date between p.StartOfMonth and p.effective_date
		where u.holiday_date is not null
		group by effective_date, client
	),
	psa_tracking_error_bd as
	(
		select
			p.effective_date, p.client, tracking_error,
			(DATEDIFF(dd, StartOfMonth, p.effective_date) + 1)
			- (DATEDIFF(wk, StartOfMonth, p.effective_date) * 2)
			- (CASE WHEN DATENAME(dw, p.effective_date) = 'Saturday' THEN 1 ELSE 0 END)
			- (CASE WHEN DATENAME(dw, StartOfMonth) = 'Sunday' THEN 1 ELSE 0 END) 
			- coalesce(holiday_counter, 0) as business_days,
			rn
		from psa_tracking_error p
			left outer join holiday_count h
				on h.effective_date = p.effective_date
				and h.client = p.client
	),
	te as
	(
		select 
			1 as dummy_col,
			client as Client_ID,
			EOMonth(Effective_Date) as Effective_Date, 
			Tracking_Error,
			row_number() over (partition by client order by effective_date) as rn
		from psa_tracking_error_bd b
		where 
			(
				rn = 1
				and effective_date <= '2021-07-31'
			)
			or
			(
				effective_date > '2021-07-31'
				and business_days = 5
			)
	),
	wsib as (
		Select * from te
		where Client_ID = 'WSIB' and effective_date between '2020-01-01' and '2020-07-01'
				
	),
	wsib_other as (
		Select distinct dummy_col, Client_ID
		from te 
		Where client_ID <> 'WSIB' and Client_ID like 'WSIB%'
	),
	tracking_error_cal as (
		Select Client_ID, effective_date, Tracking_Error
		from te 
		where client_ID not like 'WSIB%' or (client_ID <> 'WSIB' and Client_ID like 'WSIB%' and effective_date >= '2020-07-01')
		union 
		Select wsib_other.client_ID, wsib.effective_date, wsib.Tracking_Error
		from wsib_other
		join wsib on wsib_other.dummy_col = wsib.dummy_col
	),
	/*
	manual_override as (
		Select Client_Id, Effective_Date, Te_Ex_Ante Tracking_Error
		From [EDW_Raw].[V_File_Override_Cone_Chart_RPT]
		Where Te_Ex_Ante is not null 
	),
	*/
	tracking_error as (
		Select 	c.client_id,
			    c.effective_date,
				-- coalesce(m.Tracking_Error, c.Tracking_Error) Tracking_Error
				c.Tracking_Error
		From tracking_error_cal c
		-- left join manual_override m on c.client_Id = m.client_id and c.effective_Date = m.effective_date
	),
	latest_data as
	(
		select t.client_id, t.effective_date, t.tracking_error
		from tracking_error t
			inner join 
				(
					select client_id, max(effective_date) as effective_date
					from tracking_error
					group by client_id
				) m
			on m.effective_date = t.effective_date
				and m.client_id = t.client_id
	),

	client_list as
	(
		select distinct client_id
		from tracking_error
	),
	date_list as
	(
		select  client_id, effective_date
		from client_list
			cross join months
	)
	select coalesce(d.client_id, t.client_id) as client_id, coalesce(d.effective_date, t.effective_date) as effective_date, coalesce(t.tracking_error, l.tracking_error) as tracking_error,
		row_number() over (partition by d.client_id order by d.effective_date) as rn
	from tracking_error t
		right outer join date_list d
			on t.client_Id = d.client_Id
			and t.effective_date = d.effective_date
		right outer join latest_data l
			on l.client_Id = d.client_Id;