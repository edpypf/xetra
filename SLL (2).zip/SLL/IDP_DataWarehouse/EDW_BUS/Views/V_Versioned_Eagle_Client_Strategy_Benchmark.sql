﻿CREATE VIEW [EDW_BUS].[V_Versioned_Eagle_Client_Strategy_Benchmark] AS with saa as (
			Select c.Client_Id
				 , s.Strategy_Id
				 , d.Date SAA_Date
				 , Begin_Drifting_Weight
				 , Gross_Return
				 , Load_DTS
				 , Src_Update_DTS  
				 , Src_Update_Source 
			  From [EDW_Common].[Fact_Ealge_Client_Strategy_SAA_Weight] w
			  Join EDW_Common.Dim_Date d on w.SAA_Dim_Date_Key = d.Dim_Date_Key
			  Join EDW_Common.Dim_Client c on w.Dim_Client_Key = c.Dim_Client_Key
			  Join EDW_Common.Dim_Strategy s on w.Dim_Strategy_Key = s.Dim_Strategy_Key
			  Join EDW_Common.Dim_SAA_Weight_Type wt on w.Dim_SAA_Weight_Type_Key = wt.Dim_SAA_Weight_Type_Key
			  Where wt.SAA_Weight_Type = 'Benchmark Drifting SAA'
)

Select  
	 T.Dim_Client_Key
     , T.Dim_Strategy_Key
	 , T.Client_Id
	 , T.Strategy_Id
     , T.Load_DTS
     , T.SAA_Date
     , T.Begin_Drifting_Weight
     , T.Gross_Return
     , T.Version_Effective_Date
     , T.Version_Expiry_Date
     , D.Src_Update_DTS UPDATE_DATE
     , D.Version_Number
     , T.UPDATE_SOURCE

            
  From (-- Get list of all versions of individual records, and calculate effective/expiry dates
        Select 
			  c.Dim_Client_Key
			 , s.Dim_Strategy_Key
			 , saa.Client_Id
			 , s.Strategy_Id
			 , saa.Load_DTS
			 , saa.SAA_Date
			 , saa.Begin_Drifting_Weight
			 , saa.Gross_Return			
			 , saa.Src_Update_DTS  as Version_Effective_Date
			 , saa.Src_Update_Source Update_Source
               , dateadd(minute, -1,
                       lead(saa.Src_Update_DTS, 1, '99991231 00:01:00' ) over(partition by saa.Client_Id, s.Strategy_Id, saa.SAA_Date order by Load_DTS)) as Version_Expiry_Date
		From saa
		Join EDW_Common.Dim_Client c on saa.Client_Id = c.Src_Client_Id and c.Record_is_Current_Flag = 1
		-- Join EDW_Common.Dim_Strategy s on saa.Strategy_Id = s.Src_Strategy_Id and s.Record_is_Current_Flag = 1
		Join [EDW_BUS].[TPM_Strategy_Map] s on saa.Strategy_Id = s.Org_Strategy_Id and saa.SAA_Date between s.Record_Start_DTS and s.Record_End_DTS 

       ) T
	   
       Inner Join
       (-- Get distinct list of available versions, based on Update_Date, for each SAA_Date
        Select SAA_Date
		     , Src_Update_DTS
             , Load_DTS
             , row_number() over(partition by SAA_Date order by Src_Update_DTS, Load_DTS) as Version_Number
          From (Select Distinct --Get distinct list of SAA_Dates and Updates
                       SAA_Date
                     , Load_DTS
					 , Src_Update_DTS
                  From saa
				) V
        ) D On D.SAA_Date            = T.SAA_Date
               -- Cause any unchanged base records, or base records with differing version dates, to be replicated for all versioned records to which they apply
           and D.Src_Update_DTS   between T.Version_Effective_Date and T.Version_Expiry_Date;