﻿CREATE VIEW [EDW_Bus].[Risk_Cone_Chart_Tracking_Error_Cumulative]
AS with base as 
	(
		select
			Client_ID,
			Effective_Date,
			Tracking_Error,
			rn
		from EDW_Bus.[Risk_Cone_Chart_Tracking_Error_DF]
	),
	pre as 
	(
		Select Client_id, effective_date, power(cast(tracking_error as float), 2)*1.0/12 Tracking_Error_LTE, rn
		from base
	),
	cur as 
	(
		Select Client_id, effective_date, power(cast(tracking_error as float), 2)*1.0/12 Tracking_Error_LTE, rn-1 rn
		from base
	),
	cumulative as 
	(
		Select Pre.client_id, cur.effective_date, pre.Tracking_Error_LTE pre_Tracking_Error_LTE, cur.Tracking_Error_LTE cur_Tracking_Error_LTE, cur.rn + 1 rec_group
		From pre
			Join cur 
				on pre.client_Id = cur.client_Id and pre.rn <= cur.rn
	),
	running_total as
	(
		select client_id, effective_date, 
		sqrt(sum(cast(pre_Tracking_Error_LTE as float)) + max(cast(cur_Tracking_Error_LTE as float))) as cummulative_TE
		From cumulative
		Group by client_id, effective_date
	)
	select b.client_id, t.effective_date, b.tracking_error, t.cummulative_TE
	from running_total t
		inner join base b on 
			b.client_Id = t.client_Id
			and b.effective_date = t.effective_date
	union 

	Select client_id, effective_date, tracking_error, sqrt(power(cast(tracking_error as float), 2)*1.0/12) as cummulative_TE
	from base b
	where rn = 1;