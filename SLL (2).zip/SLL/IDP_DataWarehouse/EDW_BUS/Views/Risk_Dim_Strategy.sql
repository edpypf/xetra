﻿CREATE VIEW [EDW_BUS].[Risk_Dim_Strategy]
AS Select distinct s.Dim_Strategy_Key, s.Strategy_Id as Org_Strategy_Id, s2.Strategy_Id, 
	      s2.Dim_Strategy_Key Mapped_Dim_Strategy_Key, s2.Strategy_Order, s2.Strategy_Group_Order, s2.Strategy_In_Group_Order
	From edw_common.dim_strategy s
	join edw_common.dim_strategy s2 on s.Strategy_id = s2.Src_Strategy_Id and s2.Record_Is_Current_Flag = 1