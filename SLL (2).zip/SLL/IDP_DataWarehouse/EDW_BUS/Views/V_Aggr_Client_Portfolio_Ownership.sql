﻿Create View [EDW_Bus].[V_Aggr_Client_Portfolio_Ownership]
as 
Select 
	  [Dim_Date_Key]
      ,[Dim_Client_Key]
      ,[Dim_Strategy_Key]
      ,[Dim_Portfolio_Key]
      ,[Load_DTS]
      ,[Percent_Portfolio_Owned]
      ,[Percent_Portfolio_Represents]
      ,[Market_Value_Portfolio]
      ,[Market_Value_Client]
      ,[Market_Value_Portfolio_Owned]
      ,[Hash_Diff]
	  ,Client_Id
	  ,Strategy_Id
      ,Portfolio_Id
From (
		Select 
			  [Dim_Date_Key]
			  ,tgt.[Dim_Client_Key]
			  ,tgt.[Dim_Strategy_Key]
			  ,tgt.[Dim_Portfolio_Key]
			  ,tgt.[Load_DTS]
			  ,[Percent_Portfolio_Owned]
			  ,[Percent_Portfolio_Represents]
			  ,[Market_Value_Portfolio]
			  ,[Market_Value_Client]
			  ,[Market_Value_Portfolio_Owned]
			  ,tgt.[Other_Info]
			  ,tgt.[Hash_Diff]
			  ,tgt.[Is_Src_Deleted]
			  ,c.Client_Id
			  ,s.Strategy_Id
			  ,p.Portfolio_Id
			  ,Row_number() Over (Partition By tgt.[Dim_Date_Key], c.client_Id, s.Strategy_Id, p.Portfolio_Id Order By Load_DTS desc) rn
		From [EDW_BUS].[Aggr_Client_Portfolio_Ownership] tgt
		Join EDW_Common.Dim_Client c on tgt.Dim_Client_Key = c.Dim_Client_Key
		Join EDW_Common.Dim_Strategy s on tgt.Dim_Strategy_Key = s.Dim_Strategy_Key
		Join EDW_Common.Dim_Portfolio p on tgt.Dim_Portfolio_Key = p.Dim_Portfolio_Key
) f
Where rn = 1 and coalesce([Is_Src_Deleted],0) = 0