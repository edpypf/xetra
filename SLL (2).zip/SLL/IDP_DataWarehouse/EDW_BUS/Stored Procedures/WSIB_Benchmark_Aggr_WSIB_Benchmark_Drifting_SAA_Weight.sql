﻿CREATE PROC [EDW_BUS].[WSIB_Benchmark_Aggr_WSIB_Benchmark_Drifting_SAA_Weight] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS 
BEGIN

BEGIN TRY
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@beginOfMonth date

	declare @Effective_Date Date


	set @Effective_Date = @Batch_DTS;
	set @beginOfMonth = DATEADD(mm, DATEDIFF(mm,0,@Effective_Date), 0);

	IF OBJECT_ID('tempdb..#temp_wsib_benchmark_records') IS NOT NULL
	BEGIN
		DROP TABLE #temp_wsib_benchmark_records
	END

	IF OBJECT_ID('tempdb..#temp_opb_index_benchmark_MTD') IS NOT NULL
	BEGIN
		DROP TABLE #temp_opb_index_benchmark_MTD
	END
	
	
	/* create a temp table for log function in synase */
    Create table #temp_opb_index_benchmark_MTD 
    WITH
    (
            DISTRIBUTION = Round_Robin
    ) as 
	Select i.Index_Id, @Effective_Date Effective_Date, (EXP(SUM(LOG(1 + tip.Report_Freq_Return /100)))-1)*100 AS Benchmark_MTD, coalesce(cc.Client_Id, c.Client_Id) Client_Id, s.Strategy_Id
	From EDW_Common.[V_Fact_Eagle_Total_Index_Performance]  tip
	Join EDW_Common.Dim_Index i on tip.Dim_Index_Key = i.Dim_Index_Key
	Join EDW_Common.Dim_Date D on tip.Dim_Date_Key = D.Dim_Date_Key
	Join EDW_Common.Bridge_Index_Mapping bim on tip.Dim_Date_Key = bim.Dim_Date_Key and tip.Dim_Index_Key = bim.Dim_Index_Key and bim.Is_Src_Deleted = 0
	Join EDW_Common.Dim_Client c on bim.Dim_Client_Key = c.Dim_Client_Key
	Left Join (
			Select Distinct Client_Id, Parent_Client_Id
			From EDW_Common.Dim_Client
			where Record_Is_Current_Flag = 1
			and Parent_Client_Id is not null 
	) cc on c.Client_Id = cc.Parent_Client_Id
	Join EDW_Common.Dim_Strategy s on bim.Dim_Strategy_Key = s.Dim_Strategy_Key
	Join EDW_Common.Bridge_Index_Group bpg  on tip.Dim_Date_Key = bpg.Dim_Date_Key and tip.Dim_Index_Key = bpg.Dim_Index_Key and bpg.Is_Src_Deleted = 0
	Join EDW_Common.Dim_Portfolio_Group pg on bpg.Dim_Portfolio_Group_Key = pg.Dim_Portfolio_Group_Key
	where pg.portfolio_group_name = 'WSIB Benchmark Drifting SAA'
	and D.Date between @beginOfMonth and @Effective_Date
	and tip.SRC_INTFC_INST = 4 and tip.Report_Freq = 'D' and tip.[PERF_ROLLUP_RETURNS_ID]=  1
	Group By i.Index_Id, coalesce(cc.Client_Id, c.Client_Id), s.Strategy_Id


	Create Table #temp_wsib_benchmark_records
	WITH (
		DISTRIBUTION = ROUND_ROBIN
	) as 

	with SAA as (
			SELECT saa.Dim_Client_Key
					,saa.Dim_Strategy_Key
					,saa.Load_DTS
					,c.Client_Id
					,s.Strategy_Id
					,ds.Date [SAA_Date]
					,de.Date [Effective_Date]
					,wt.[SAA_Weight_Type] Weight_Type
					,saa.[Weight]
					,Rank() over(partition by saa.Dim_Date_Key, saa.SAA_Dim_Date_Key, c.Client_Id, wt.SAA_Weight_Type order by Load_DTS desc) as rn
			FROM [EDW_Common].Fact_Sharepoint_Client_SAA  saa
			Join EDW_Common.Dim_Client c on saa.Dim_Client_Key = c.Dim_Client_Key
			Join EDW_Common.Dim_Strategy s on saa.Dim_Strategy_Key = s.Dim_Strategy_Key
			Join EDW_Common.Dim_SAA_Weight_Type wt on saa.Dim_SAA_Weight_Type_Key = wt.Dim_SAA_Weight_Type_Key
			Join EDW_Common.Dim_Date de on saa.Dim_Date_Key = de.Dim_Date_Key
			Join EDW_Common.Dim_Date ds on saa.SAA_Dim_Date_Key = ds.Dim_Date_Key
			WHERE wt.SAA_Weight_Type IN (
				  select portfolio_id from psa.v_manual_portfolio_groups
				  where group_name = 'WSIB Benchmark Drifting SAA Weight Type'
					and @Effective_Date between start_date and end_date
			)
	),
	LatestInterimSAA As
	(SELECT    Client_ID, 
			SAA_Date,
			MAX(Effective_Date) Max_EffectiveDate
			FROM SAA
			WHERE rn = 1 and Effective_Date <= @Effective_Date
			AND SAA_Date = DATEADD(month, DATEDIFF(month, 0, @Effective_Date), 0)
			GROUP BY Client_Id, 
						SAA_Date
	) 
	SELECT  convert(int, replace(convert(varchar(15), @Effective_Date, 102),'.',''))      Dim_Date_Key,
			SAA.Dim_Client_Key,
	        SAA.Dim_Strategy_Key,
			SAA.Client_Id,
			SAA.Strategy_Id,
	        SAA.Load_DTS,
			@Effective_Date  SAA_Date,
			FM.Benchmark_MTD,
			SAA.Weight Initial_Weight, 
			SAA.Weight * (1+(FM.Benchmark_MTD/100)) Benchmark_Drifting_Weight,
			CAST ((SAA.Weight * (1+(FM.Benchmark_MTD/100))) AS NUMERIC (38,18)) /  CAST ((SUM(SAA.Weight * (1+(FM.Benchmark_MTD/100))) OVER (PARTITION BY SAA.Client_Id,SAA.Effective_Date)) AS NUMERIC (38,18)) Rescaled_BM_Drifting_Weight
	FROM SAA 
	INNER JOIN LatestInterimSAA SA2 ON SAA.Client_ID = SA2.Client_ID AND SAA.SAA_Date = SA2.SAA_Date AND SAA.Effective_Date = SA2.Max_EffectiveDate
	LEFT JOIN 
	(	    
			Select Distinct p.Portfolio_Id, D.Date Effective_Date, PF.Benchmark_MTD, coalesce(cc.Client_Id, c.Client_Id) Client_Id, s.Strategy_Id
			From EDW_Common.[V_Fact_Statestreet_Total_Portfolio_Performance]  PF
			Join EDW_Common.Dim_Portfolio p on PF.Dim_Portfolio_Key = p.Dim_Portfolio_Key
			Join EDW_Common.Dim_Date D on PF.Dim_Date_Key = D.Dim_Date_Key
			Join EDW_Common.Bridge_Portfolio_Mapping bpm on PF.Dim_Date_Key = bpm.Dim_Date_Key and PF.Dim_Portfolio_Key = bpm.Dim_Portfolio_Key and bpm.Is_Src_Deleted = 0
			Join EDW_Common.Dim_Client c on bpm.Dim_Client_Key = c.Dim_Client_Key
			Left Join (
					Select Distinct Client_Id, Parent_Client_Id
					From EDW_Common.Dim_Client
					where Record_Is_Current_Flag = 1
					and Parent_Client_Id is not null 
			) cc on c.Client_Id = cc.Parent_Client_Id
			Join EDW_Common.Dim_Strategy s on bpm.Dim_Strategy_Key = s.Dim_Strategy_Key
			Join EDW_Common.Bridge_Portfolio_Group bpg  on PF.Dim_Date_Key = bpg.Dim_Date_Key and PF.Dim_Portfolio_Key = bpg.Dim_Portfolio_Key and bpg.Is_Src_Deleted = 0
			Join EDW_Common.Dim_Portfolio_Group pg on bpg.Dim_Portfolio_Group_Key = pg.Dim_Portfolio_Group_Key
			where pg.portfolio_group_name = 'WSIB Benchmark Drifting SAA' and Datediff(d, D.Date, @Effective_Date) = 0

			Union

			Select Index_Id Portfolio_Id, Effective_Date, Benchmark_MTD, Client_Id, Strategy_Id
			From #temp_opb_index_benchmark_MTD

	) FM ON SAA.Client_ID = FM.Client_ID and SAA.Strategy_ID = FM.Strategy_ID 
	WHERE SAA.Client_ID in ( 'WSIBINS','WSIBLRI','WSIBPEN') and SAA.rn = 1
	-- AND SAA.Weight <> 0



			INSERT INTO [EDW_BUS].[Aggr_WSIB_Benchmark_Drifting_SAA_Weight]
			   ([Dim_Date_Key]
			   ,[Dim_Client_Key]
			   ,[Dim_Strategy_Key]
			   ,[Load_DTS]
			   ,[SAA_Date]
			   ,[Benchmark_MTD]
			   ,[Initial_Weight]
			   ,[Benchmark_Drifting_Weight]
			   ,[Rescaled_BM_Drifting_Weight]
			   ,[Other_Info]
			   ,[Last_Update_DTS]
			   ,[Hash_Diff]
			   ,[ETL_Load_Key]
			)
			Select 
				Dim_Date_Key,
				Dim_Client_Key,
				Dim_Strategy_Key,
				Load_DTS,
				SAA_Date,
				Benchmark_MTD,
				Initial_Weight, 
				Benchmark_Drifting_Weight,
				Rescaled_BM_Drifting_Weight,
				null,
				@today,
				src.Hash_Diff,
				@ETL_Load_Key
			From (
				Select 
					Dim_Date_Key,
					Dim_Client_Key,
					Dim_Strategy_Key,
					Client_Id,
					Strategy_Id,
					Load_DTS,
					SAA_Date,
					Benchmark_MTD,
					Initial_Weight, 
					Benchmark_Drifting_Weight,
					Rescaled_BM_Drifting_Weight,
					CONVERT(VARCHAR(64), hashbytes('SHA1', coalesce(concat(Benchmark_MTD, '|', Initial_Weight, '|', Benchmark_Drifting_Weight, '|', Rescaled_BM_Drifting_Weight ),'')), 2) as Hash_Diff
				From #temp_wsib_benchmark_records 
			) src
			where not exists (
				Select 1
				From [EDW_BUS].[Aggr_WSIB_Benchmark_Drifting_SAA_Weight] tgt
				Join EDW_Common.Dim_Client c on tgt.Dim_Client_Key = c.Dim_Client_Key
				Join EDW_Common.Dim_Strategy s on tgt.Dim_Strategy_Key = s.Dim_Strategy_Key
				where tgt.Dim_Date_Key = src.Dim_Date_Key and c.Client_Id = src.Client_Id 
				and src.Load_DTS = tgt.Load_DTS
				-- and s.Strategy_Id = src.Strategy_Id 
				 	  and tgt.Hash_Diff = src.Hash_Diff
			)


			Select @rowsInserted = Count(*) 
			From EDW_BUS.Aggr_WSIB_Benchmark_Drifting_SAA_Weight
			Where Last_Update_DTS = @today

			Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_WSIB_Benchmark_Drifting_SAA_Weight', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_WSIB_Benchmark_Drifting_SAA_Weight', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END