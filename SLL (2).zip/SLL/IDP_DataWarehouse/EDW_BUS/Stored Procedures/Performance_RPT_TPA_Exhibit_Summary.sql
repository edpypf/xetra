﻿CREATE PROC [EDW_BUS].[Performance_RPT_TPA_Exhibit_Summary] @ETL_LOAD_KEY [INT],@Load_Type [VARCHAR](100),@Batch_DTS [DATETIME2] AS
Begin

Begin try 

Declare @Debug as int =0

Declare @today as date
Set @today=cast(dateadd(hour,-4,getdate()) as date)


Declare @effective_Date as date
declare @Latest_Date_TPA_Mapping as date
declare @Latest_Date_Measure_override as date

--Declare @ETL_LOAD_KEY as int=123134
--Declare @Load_Type as varchar(500)='11'
--Declare @Batch_DTS as datetime='2022-06-30'














Declare @Date_Count as int =0

Select @Latest_Date_TPA_Mapping=cast(max(load_dts) as date) from [PSA].[Manual_Performance_Report_TPA_Mapping]


 

select @Latest_Date_Measure_override=cast(max(date_Created) as date) from [Config_Link].[Performance_User_Report_Measure_Override]
where Entity_id in ('OPBC0005','WSA02','WSA01','WSA59','PJBC0004')
and OLAP_Measure_Name in
('Gross Return D'
,'BM Gross Return D'
,'WTD Gross Return'
,'BM WTD Gross Return D'
,'MTD Gross Return'
,'BM MTD Gross Return D'
,'QTD Gross Return D'
,'BM QTD Gross Return D'
,'YTD Gross Return D'
,'BM YTD Gross Return D')




IF Convert(date,@Batch_DTS) = '1900-01-01'
		BEGIN
			-- get effective date (previous business date) to check
			Set @Effective_Date = CASE DATEPART(weekday, @today) 
							WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
							WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
							ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
							END
		End
		Else 
		Begin
		set @Effective_Date =  Convert(date,@Batch_DTS)
		END 




--	DECLARE @rowsInserted INT = 0,
--			@rowsCount INT = 0,
--			@today datetime2 = getdate(),
--			@rows int,
----			@Business_Area varchar(255)= 'P',
--			@Affected_Source_System varchar(255)= 'SFTP_Eagle_Perf_Summary'



 



--Declare @Effective_Date as date ='2022-06-30'
if object_id('Tempdb..#TPA_Daily') is not null
drop table Tempdb..#TPA_Daily


if object_id('Tempdb..#TPA_Summary') is not null
drop table Tempdb..#TPA_Summary

if object_id('Tempdb..#TPA_monthly') is not null
drop table Tempdb..#TPA_Monthly
if object_id('Tempdb..#MTD') is not null
drop table Tempdb..#MTD
if object_id('Tempdb..#QTD_YTD') is not null
drop table Tempdb..#QTD_YTD


if object_id('Tempdb..#Daily') is not null
drop table Tempdb..#Daily

if object_id('Tempdb..#WTD') is not null
drop table Tempdb..#WTD


if object_id('Tempdb..#MTD_Daily') is not null
drop table Tempdb..#MTD_Daily

if object_id('Tempdb..#QTD_YTD_Daily') is not null
drop table Tempdb..#QTD_YTD_Daily

if object_id('Tempdb..#All_Dates') is not null
drop table Tempdb..#All_Dates


if object_id('Tempdb..#All_EOM_Dates') is not null
drop table Tempdb..#All_EOM_Dates

--Select distinct date_value from [EDW_Common].[V_Fact_Eagle_TPA_Weights_Monthly]




Select distinct Date_Value into #All_Dates from [EDW_Common].[V_Fact_Eagle_TPA_Weights_daily]
where date_Value=Case when (@latest_date_tpa_mapping=@today or @latest_date_measure_override=@today or @Load_Type='Full_Refresh') then date_Value else @effective_Date End

Select distinct a.Date_Value into #All_EOM_Dates from [EDW_Common].[V_Fact_Eagle_TPA_Weights_Monthly] a
INNER JOIN [EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily] b on a.date_value=b.date_value
where a.date_Value=Case when (@latest_date_tpa_mapping=@today or @latest_date_measure_override=@today or @Load_Type='Full_Refresh') then a.date_Value else @effective_Date End

Select @Date_Count=count(*) from #All_EOM_Dates

--Select @effective_Date,@latest_date_tpa_mapping,@latest_date_measure_override,@today,@date_count

IF @DEBUG=1 Set @Latest_Date_Measure_override=cast(dateadd(hour,-4,getdate()) as date)

If     @date_Count>0 
Begin 




Select * into #tpa_Monthly from [EDW_Common].[V_Fact_Eagle_TPA_Weights_Monthly]
where date_value in (Select date_value from #All_EOM_Dates)

Select * into #tpa_daily from [EDW_Common].[V_Fact_Eagle_TPA_Weights_daily]
where date_value in (Select date_value from #All_EOM_Dates)



Select  * into #tpa_summary from [EDW_Mart].[Performance_RPT_TPA_Summary]
where effective_date in (Select date_value from #All_EOM_Dates)
and IPS='Total Published Return'




create table #MTD
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
With MTD_TPA_Daily_Exhibit AS
(
SELECT
	  Entity_id
	  ,Decomposition_Name=	Case	when IPS='Foreign Exchange Hedging'		THEN 'Dynamic Foreign Exchange Account'
									when IPS='Active Asset Allocation'		THEN 'Rebalancing Account'
							End


	  ,MTD_Value=MTD_Bf_S_TotalAttrib 
	  ,effective_Date=date_value
  From #tpa_daily d
  JOIN  
			[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
			ON	d.entity_id=m1.entity
			and m1.Decomposition_Name=	Case	when IPS='Foreign Exchange Hedging'		THEN 'Dynamic Foreign Exchange Account'
										when IPS='Active Asset Allocation'				THEN 'Rebalancing Account'
										End
--			and m1.effective_Date=d.date_Value
			and year(m1.effective_date)=Year(d.date_Value)	
			and Month(m1.effective_date)=Month(d.date_Value)
			and m1.last_active='Y'
  where
		IPS IN ('Foreign Exchange Hedging','Active Asset Allocation')
),MTD_Real_Estate AS
(SELECT
	  Entity_id
	  ,Decomposition_Name='Real Estate Finance MTM Adjustment'
	  ,MTD_Value=MTD_BfM_Allocation 
	  ,Effective_Date=date_value
  From #tpa_Monthly d
  JOIN  
			[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
			ON	d.entity_id=m1.entity
			and m1.Decomposition_Name='Real Estate Finance MTM Adjustment'
--			and m1.effective_Date=d.date_Value
			and year(m1.effective_date)=Year(d.date_Value)	
			and Month(m1.effective_date)=Month(d.date_Value)

			and m1.last_active='Y'
  where
		IPS = 'REF MTM'
)



,MTD_Benchmark_Reset
as 
	(
	 Select Entity_id=entity
			,Decomposition_Name
			,MTD_Value=Value
			,Effective_Date
	 From [EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] d
	 Where 1=1
	 and Effective_Date IN (Select date_Value from #All_EOM_Dates)
	 And   Decomposition_Name='Benchmark Reset Residual'
	 and   Last_Active='Y'
	 )
,MTD_Revaluations
as 
	(
	 Select Entity_id=entity
			,Decomposition_Name
			,MTD_Value=Value
			,Effective_Date--=@Effective_Date
	 From  [EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] d
	 Where 1=1
	 and Effective_Date in  (Select date_Value from #All_EOM_Dates)
	 And   Decomposition_Name='Revaluations Residual'
	 and   Last_Active='Y'
	 ),MTD_Allocation AS
(
	 
	 SELECT 
	   p.Entity_id
	  ,MTD_Value = Sum ( case when sub=1 then MTD_Value else -1*MTD_Value End)
	  ,Decomposition_Name='Allocation/Interaction from Strategic Accounts'
	  ,p.Effective_date
	  From
			( 
				SELECT  entity_ID
						,Sub=1
						,MTD_Value=isnull(MTD_BfM_Allocation,0)+isnull(MTD_BfM_Interaction,0)
						,Effective_Date=Date_Value
				From   #tpa_Monthly  C1
				Where IPS in (Entity_ID,'NA')
				UNION ALL 
				SELECT  entity_ID
						,Sub=2
						,MTD_Value=Sum(isnull(MTD_BfM_Allocation,0)+isnull(MTD_BfM_Interaction,0))
						,Effective_Date=Date_Value
				From   #tpa_Monthly C2
				Where  IPS in  ('Active Asset Allocation','Foreign Exchange Hedging')
				Group by Entity_ID,	Date_Value 
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=3
					,MTD_Value
					,Effective_Date
				FROM MTD_Benchmark_Reset				C3
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=4
					,MTD_Value
					,Effective_Date
				FROM MTD_Revaluations					C4
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=5
					,MTD_Value
					,Effective_Date
				FROM  MTD_Real_Estate					c5
				) P
				 JOIN  
				[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
				ON	p.entity_id=m1.entity
				and m1.Decomposition_Name='Allocation/Interaction from Strategic Accounts'
				and m1.effective_Date=p.effective_Date
				and m1.last_active='Y'
--				Where p.effective_Date
				Group by p.Entity_ID,p.Effective_Date
),MTD_Total_Rebalancing AS
(
     Select
	 Entity_ID
	 ,Decomposition_name='Total Rebalancing (Rebalancing Account + Allocation/Interaction from Strategic Accounts)'
	 ,MTD_Value=Sum(d1.MTD_Value)
	 ,d1.Effective_Date
	 From 
	 (Select Entity_ID
			,MTD_Value
			,Effective_Date
	   FROM  MTD_TPA_Daily_Exhibit				
	where Decomposition_Name='Rebalancing Account'
	
	   UNION All
	   Select Entity_ID
			,MTD_Value
			,Effective_Date
	   From MTD_Allocation
	   ) d1
	   group by Entity_ID,Effective_Date
),MTD_Total_Rebalancing_DFX as
		(
		Select
		 Entity_ID
		 ,Decomposition_name='Total Rebalancing/DFX'
		 ,MTD_Value=Sum(d1.MTD_Value)
		 ,d1.Effective_Date
		 From 
		 (Select Entity_ID
				,MTD_Value
				,Effective_Date
		   From MTD_TPA_Daily_Exhibit
		   Where Decomposition_Name= 'Dynamic Foreign Exchange Account'
		   UNION All
		   Select Entity_ID
				,MTD_Value
				,Effective_Date
		   From MTD_Total_Rebalancing

	   ) d1
	   group by Entity_ID,Effective_Date
	   )
,MTD_strategic as
(
				Select 
						Entity_ID
						,Decomposition_Name='Strategy Selection'
						,Effective_Date=Date_Value
						,MTD_Value= Sum 
										(	Case  when (IPS=Entity_ID or IPS='NA') then isnull(MTD_Bf_S_Selection,0)
												When IPS in ('Active Asset Allocation','Foreign Exchange Hedging') then -1*isnull(MTD_Bf_S_Selection,0)
												Else 0
											End
										)
				From #tpa_daily 
				GROUP BY Entity_ID
						,Date_value
	
		
)
,MTD_Residual AS
(
	 
	 SELECT 
	   Entity_id
	  ,MTD_Value = Sum ( case when sub=1 then MTD_Value else -1*MTD_Value End)
	  ,Decomposition_Name='Residual'
	  ,Effective_date
	  From
			( 
				SELECT  entity_ID
						,Sub=1
						,MTD_Value=isnull(MTD_Published_Tot_Attribution*100,0)
						,Effective_Date
				From   #tpa_summary  C1
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=2
					,MTD_Value
					,Effective_Date
				FROM MTD_Total_Rebalancing_DFX				C2
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=3
					,MTD_Value
					,Effective_Date
				FROM MTD_strategic							C3
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=4
					,MTD_Value
					,Effective_Date
				FROM MTD_Benchmark_Reset					C4
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=5
					,MTD_Value
					,Effective_Date
				FROM MTD_Revaluations					C5
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=6
					,MTD_Value
					,Effective_Date
				FROM MTD_Real_Estate C6
				) P
				Group by Entity_ID,Effective_Date
)


		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=CASE		WHEN Decomposition_Name='Dynamic Foreign Exchange Account' then 1
											WHEN Decomposition_Name='Rebalancing Account'then 2
									END
				,Decomposition_Name
				,MTD_Value
		From 	MTD_TPA_Daily_Exhibit
		UNION ALL
				Select	Entity_id
				,Effective_Date
				,Decomposition_ID=10
				,Decomposition_Name
				,MTD_Value
		From 	MTD_Real_Estate
		UNION ALL
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=3
				,Decomposition_Name
				,MTD_Value
		From 	MTD_Allocation
		UNION ALL
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=9
				,Decomposition_Name
				,MTD_Value
		From 	MTD_Revaluations
		UNION ALL
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=8
				,Decomposition_Name
				,MTD_Value
		From 	MTD_Benchmark_Reset
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=4
				,Decomposition_Name
				,MTD_Value
		From 	MTD_Total_Rebalancing
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=5
				,Decomposition_Name
				,MTD_Value
		From 	MTD_Total_Rebalancing_DFX 
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=6
				,Decomposition_Name
				,MTD_Value
		From 	MTD_strategic
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=7
				,Decomposition_Name
				,MTD_Value
		From 	MTD_Residual


create table #QTD_YTD
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 

With QTD_YTD_Exhibit
as
(
SELECT 
		Entity_ID
		,Decomposition_Name
		,Effective_Date
		,YTD_Value=case when Actual_ytd_count=datediff(month,'01-01-'+cast(year(Effective_Date) as varchar),Effective_Date) +1 then YTD_Value else null end 
		,QTD_Value= case when Actual_QTD_Count=datediff(month, DATEADD(QUARTER,DATEDIFF(QUARTER,0,Effective_Date),0),Effective_Date)+1 then QTD_Value else Null End
		,Actual_ytd_count
		,Actual_Qtd_count
		,ytd_count=datediff(month,'01-01-'+cast(year(Effective_Date) as varchar),Effective_Date) +1
		,qtd_count=datediff(month, DATEADD(QUARTER,DATEDIFF(QUARTER,0,Effective_Date),0),Effective_Date)+1
From
	(
		Select d1.Entity_ID
			   ,d1.Decomposition_Name
			   ,d1.Effective_Date
			   ,YTD_Value=Sum(isnull(d1.MTD_Value,0)) over (partition by d1.Entity_ID,d1.Decomposition_Name,d1.year order by d1.Entity_id,d1.Decomposition_Name,d1.year,d1.month)
			   ,Actual_YTD_Count=Count(d1.MTD_Value) over (partition by d1.Entity_ID,d1.Decomposition_Name,d1.year order by d1.Entity_id,d1.Decomposition_Name,d1.year,d1.month)
				,QTD_Value=Sum(isnull(d1.MTD_Value,0)) over (partition by d1.Entity_ID,d1.Decomposition_Name,d1.year,datepart(q,d1.Effective_date) order by d1.Entity_id,d1.Decomposition_Name,d1.year,d1.month)
				,Actual_QTD_Count=Count(d1.MTD_Value) over (partition by d1.Entity_ID,d1.Decomposition_Name,d1.year,datepart(q,d1.Effective_date) order by d1.Entity_id,d1.Decomposition_Name,d1.year,d1.month)
        

			from 
						(
							Select 
									Entity_id=Entity
									,Decomposition_Name
									,MTD_Value= value
									,effective_date
									,quarter=datepart(quarter,effective_date)
									,year=datepart(year,effective_date)
									,month=datepart(month,effective_date)
									,Source='udm'
							From [PSA].[V_Manual_Performance_Report_TPA_Mapping] 
							Union All
							Select  Entity_id
								  ,d.Decomposition_Name
								  ,d.MTD_Value
								  ,d.effective_Date
								   ,quarter=datepart(quarter,d.effective_date)
								   ,year=datepart(year,d.effective_date)
								   ,month=datepart(month,d.effective_date)
								  ,Source='mtd'
							From  #MTD d
							Left join 
	 								[PSA].[V_Manual_Performance_Report_TPA_Mapping] m1
										ON	d.entity_id=m1.entity
										and m1.Decomposition_Name=d.decomposition_Name
										and m1.effective_date=d.effective_Date
							where 1=1
							and  m1.entity is  null 
						  ) d1
							   JOIN [EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] c1
									ON	d1.entity_id=c1.entity
									and d1.Decomposition_Name=c1.Decomposition_Name
									and d1.effective_Date=c1.Effective_Date
											and year(c1.effective_date)=Year(d1.Effective_Date)	
											and Month(c1.effective_date)=Month(d1.effective_Date)

									and c1.last_active='Y'

			) m
Where Effective_Date in (Select date_value from #All_EOM_Dates)
)
,Total_Rebalancing AS
(
	Select Entity_ID
			,Decomposition_Name='Total Rebalancing (Rebalancing Account + Allocation/Interaction from Strategic Accounts)'
			,effective_Date
			,YTD_Value= Sum(case when d1.decomposition_Name in ('Rebalancing Account','Allocation/Interaction from Strategic Accounts') then d1.YTD_Value End)
			,QTD_Value= Sum(case when d1.decomposition_Name in ('Rebalancing Account','Allocation/Interaction from Strategic Accounts') then d1.QTD_Value End)
    From	 QTD_YTD_Exhibit d1
	Group by  d1.Entity_ID,effective_Date
)
,Total_Rebalancing_DFX AS 
(
			Select Entity_ID
					,Decomposition_Name='Total Rebalancing/DFX'
					,Effective_Date
					,YTD_Value= Sum(YTD_Value)
					,QTD_Value= Sum(QTD_Value)
		From
		(
				Select Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit where Decomposition_Name='Dynamic Foreign Exchange Account'
				UNION ALL
				Select Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From Total_Rebalancing
		) P1
		Group by  Entity_ID,Effective_Date			
)
,Strategy as
(
	Select Entity_ID
			,Decomposition_Name='Strategy Selection'
			,Effective_Date=Date_Value
			,YTD_Value=Sum (Case when (IPS=Entity_ID or IPS='NA') then YTD_Bf_S_Selection else -1*YTD_Bf_S_Selection End)
			,QTD_Value=Sum (Case when (IPS=Entity_ID or IPS='NA') then QTD_Bf_S_Selection else -1*QTD_Bf_S_Selection End)
    From	#tpa_daily
	Where	 IPS in (Entity_ID,'NA','Active Asset Allocation','Foreign Exchange Hedging')
	Group by Entity_ID,Date_Value
)	
Select Decomposition_ID=1,Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit Where  Decomposition_Name='Dynamic Foreign Exchange Account'
UNION ALL 
Select Decomposition_ID=2,Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit Where  Decomposition_Name='Rebalancing Account'
UNION ALL 
Select Decomposition_ID=3,Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit Where  Decomposition_Name='Allocation/Interaction from Strategic Accounts'
UNION ALL 
Select Decomposition_ID=4,Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From Total_Rebalancing --Where  Decomposition_Name='Total Rebalancing (Rebalancing Account + Allocation/Interaction from Strategic Accounts)'
UNION ALL 
Select Decomposition_ID=5,Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From Total_Rebalancing_DFX --Where  Decomposition_Name='Total Rebalancing/DFX'
UNION ALL 
Select Decomposition_ID=6,Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From Strategy --Where  Decomposition_Name='Strategy Selection'
UNION ALL
Select 
		 Decomposition_ID=7,
		 Decomposition_Name='Residual'
		 ,Entity_ID
		 ,Effective_Date
		,YTD_Value=Sum(Case when Decomposition_Name='Total Published Return' then YTD_Value else -1*YTD_Value End)
		,QTD_Value=Sum(Case when Decomposition_Name='Total Published Return' then QTD_Value else -1*QTD_Value End)

From    (
		Select Decomposition_Name='Total Published Return',Entity_ID,Effective_Date,YTD_Value=isnull(YTD_Published_Tot_Attribution*100,0),QTD_Value=isnull(QTD_Published_Tot_Attribution*100,0) From #tpa_summary 
		UNION ALL
		Select Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From Total_Rebalancing_DFX
		UNION ALL
		Select Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From Strategy
		UNION ALL
		Select Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit Where  Decomposition_Name='Benchmark Reset Residual'
		UNION ALL
		Select Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit Where  Decomposition_Name='Revaluations Residual'
		UNION ALL
		Select Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit Where  Decomposition_Name='Real Estate Finance MTM Adjustment'
		) d1
Group by Entity_ID,Effective_Date


UNION ALL 
Select Decomposition_ID=8,Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit Where  Decomposition_Name='Benchmark Reset Residual'
UNION ALL 
Select Decomposition_ID=9,Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit Where  Decomposition_Name='Revaluations Residual'
UNION ALL 
Select Decomposition_ID=10,Decomposition_Name,Entity_ID,Effective_Date,YTD_Value,QTD_Value From QTD_YTD_Exhibit Where  Decomposition_Name='Real Estate Finance MTM Adjustment';











delete from [EDW_BUS].[Aggr_Performance_RPT_TPA_Exhibit_Summary]
where effective_date in (Select date_value from #All_EOM_Dates)
and report_number in (15,16,17,18)




Insert into [EDW_BUS].[Aggr_Performance_RPT_TPA_Exhibit_Summary]
(
[Report_Number]
      ,[Client_ID]
      ,[Entity_ID]
      ,[Effective_Date]
      ,[Decomposition_Name]
      ,[Sort_Order]
      ,[YTD_value]
      ,[MTD_Value]
      ,[QTD_Value]
      ,[Batch_DTS]
      ,[ETL_Load_Key]
      ,[Daily_Value]
      ,[WTD_Value]
      ,[MTD_Daily_Value]
	  ,[type]
	  ,updated_Datetime
)


Select Report_Number
		,Client_ID
		,Entity_ID
		,Effective_Date
		,Decomposition_Name
		,Sort_Order
		,YTD_value=cast(Sum(YTD_Value) as numeric(38,14))  /100.00 
		,MTD_Value=cast(Sum(MTD_Value) as numeric(38,14))/100.00
		,QTD_Value=cast(Sum(QTD_Value) as numeric(38,14)) /100.00
		,Effective_Date
		,@ETL_Load_Key
		,Daily_Value=Null
		,WTD_Value=Null
		,MTD_Daily_Value=Null
		,[Type]='1'
		,getdate()

From (

Select	lu1.Report_Number
				,lu1.Client_ID
				,p1.Entity_ID
				,Effective_Date
				,p1.Decomposition_Name
				,lu2.Sort_Order
				,p1.YTD_Value
				,p1.QTD_Value
				,MTD_Value=Null
				,Daily_Value=Null
				,WTD_Value=Null
				,MTD_Daily_Value=Null
				,Type='EOM'

		from #QTD_YTD p1
		JOIN 
				(Select distinct Report_Number,Client_ID,Portfolio_ID from [PSA].V_Manual_Performance_Report_Portfolio_Mapping rpm
				 JOIN	[PSA].[V_Manual_Performance_Config_Report] cr			ON cr.Report_Group=rpm.Report_Group
				where cr.Report_number in (15,16,17,18)) lu1
				ON p1.Entity_ID=lu1.Portfolio_ID
		JOIN EDW_BUS.Performance_Reporting_TPA_Decomposition_Name_List lu2
				ON p1.Decomposition_ID=lu2.Sort_Order

		UNION ALL 
				
				Select	
				lu1.Report_Number
				,lu1.Client_ID
				,p1.Entity_ID
				,Effective_Date
				,p1.Decomposition_Name
				,lu2.Sort_Order
				,YTD_Value=Null
				,QTD_Value=Null
				,p1.MTD_Value
				,Daily_Value=Null
				,WTD_Value=Null
				,MTD_Daily_Value=Null
				,Type='EOM'
		from #MTD p1
		JOIN 
				(Select distinct Report_Number,Client_ID,Portfolio_ID from [PSA].V_Manual_Performance_Report_Portfolio_Mapping rpm
				 JOIN	[PSA].[V_Manual_Performance_Config_Report] cr			ON cr.Report_Group=rpm.Report_Group
				where cr.Report_number in (15,16,17,18)) lu1
				ON p1.Entity_ID=lu1.Portfolio_ID
		JOIN EDW_BUS.Performance_Reporting_TPA_Decomposition_Name_List lu2
				ON p1.Decomposition_ID=lu2.Sort_Order

) a

Group by 
		Report_Number
		,Client_ID
		,Entity_ID
		,Effective_Date
		,Decomposition_Name
		,Sort_Order



drop table #tpa_daily
drop table #tpa_monthly
drop table #tpa_summary














End








If  @effective_date<>'1900-01-01' or ( @latest_date_tpa_mapping=@today or @latest_date_measure_override=@today ) 
Begin 


--Print 'All'


Select * into #tpa_Monthly from [EDW_Common].[V_Fact_Eagle_TPA_Weights_Monthly]
where date_value in (Select date_value from #All_EOM_Dates)
and IPS = 'REF MTM'
and Entity_ID in ('OPBC0005','PJBC0004')


Select * into #tpa_daily from [EDW_Common].[V_Fact_Eagle_TPA_Weights_daily]
where date_value in (Select date_value from #All_Dates)
and Entity_ID in ('OPBC0005','PJBC0004')



Select  * into #tpa_summary from [EDW_Mart].[Performance_RPT_TPA_Summary]
where effective_date in (Select date_value from #All_Dates)
and Entity_ID in ('OPBC0005','PJBC0004')
and IPS='Total Published Return'
and Report_Number in (11,21)


create table #MTD_Daily 
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
With MTD_TPA_Daily_Exhibit AS
(
SELECT
	  Entity_id
	  ,Decomposition_Name=	Case	when IPS='Foreign Exchange Hedging'		THEN 'Dynamic Foreign Exchange Account'
									when IPS='Active Asset Allocation'		THEN 'Rebalancing Account'
							End


	  ,MTD_Value=MTD_Bf_S_TotalAttrib 
	  ,Daily_Value= [1D_BF_S_TotalAttrib]
	  ,WTD_Value= [WTD_BF_S_TotalAttrib]
	  ,effective_Date=date_value
  From #tpa_daily d
  JOIN  
			[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
			ON	d.entity_id=m1.entity
			and m1.Decomposition_Name=	Case	when IPS='Foreign Exchange Hedging'		THEN 'Dynamic Foreign Exchange Account'
										when IPS='Active Asset Allocation'				THEN 'Rebalancing Account'
										End
			--and m1.effective_Date=d.date_Value
			and year(m1.effective_date)=Year(d.date_value)	
			and Month(m1.effective_date)=Month(d.date_value)
			and m1.last_active='Y'
  where
		IPS IN ('Foreign Exchange Hedging','Active Asset Allocation')

),MTD_Real_Estate AS
(
			 Select Entity_id=entity
			,Decomposition_Name
			,MTD_Value=0.00
			,Daily_Value=0.00
			,WTD_Value=0.00
			,Effective_Date=ad.date_Value
	 From [EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] d
	 JOIN #All_Dates ad
		on 	 year(d.effective_date)=Year(ad.date_value)	
			and Month(d.effective_date)=Month(ad.date_value)
 
		--d.effective_Date= ad.Date_Value

	 Where 1=1
	 And   Decomposition_Name='Real Estate Finance MTM Adjustment'
	 and   Last_Active='Y'


/*
SELECT
	  Entity_id
	  ,Decomposition_Name='Real Estate Finance MTM Adjustment'
	  ,MTD_Value=0.00
	  ,Daily_Value=0.00
	  ,WTD_Value=0.00
	  ,Effective_Date=ad.Date_Value
  From #tpa_Monthly d
  JOIN #All_Dates ad
		on d.date_Value= ad.Date_Value
  JOIN  
			[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
			ON	d.entity_id=m1.entity
			and m1.Decomposition_Name='Real Estate Finance MTM Adjustment'
			and year(m1.effective_date)=Year(d.date_value)	
			and Month(m1.effective_date)=Month(d.date_value)
--			and m1.effective_Date=d.date_Value
			and m1.last_active='Y'
  where
		IPS = 'REF MTM'
*/

),MTD_Benchmark_Reset
as 
	(
		 Select Entity_id=entity
			,Decomposition_Name
			,MTD_Value=0.00
			,Daily_Value=0.00
			,WTD_Value=0.00
			,Effective_Date=ad.date_Value
	 From [EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] d
	 JOIN #All_Dates ad
		on 	 year(d.effective_date)=Year(ad.date_value)	
			and Month(d.effective_date)=Month(ad.date_value)
 
		--d.effective_Date= ad.Date_Value

	 Where 1=1
	 And   Decomposition_Name='Benchmark Reset Residual'
	 and   Last_Active='Y'

	 
	 
	 
	 )

,MTD_Revaluations
as 
	(
	
		 Select Entity_id=entity
			,Decomposition_Name
			,MTD_Value=0.00
			,Daily_Value=0.00
			,WTD_Value=0.00
			,Effective_Date=ad.date_Value
	 From [EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] d
	 JOIN #All_Dates ad
     		on 	 year(d.effective_date)=Year(ad.date_value)	
			and Month(d.effective_date)=Month(ad.date_value)
 
		--d.effective_Date= ad.Date_Value

	 Where 1=1
	 And   Decomposition_Name='Revaluations Residual'
	 and   Last_Active='Y'

 ),MTD_Allocation AS
(
	 
	 SELECT 
	   p.Entity_id
	  ,MTD_Value = Sum ( case when sub=1 then MTD_Value else -1*MTD_Value End)
	  ,Daily_Value = Sum ( case when sub=1 then Daily_Value else -1*Daily_Value End)
	  ,WTD_Value = Sum ( case when sub=1 then WTD_Value else -1*WTD_Value End)
	  ,Decomposition_Name='Allocation/Interaction from Strategic Accounts'
	  ,p.Effective_date
	  From
			( 
				SELECT  entity_ID
						,Sub=1
						,MTD_Value=isnull(MTD_Bf_S_Allocation,0)+isnull(MTD_Bf_S_Interaction,0)
						,Daily_Value=isnull([1D_BF_S_Allocation],0)+isnull([1D_BF_S_Interaction],0)
						,WTD_Value=isnull([WTD_BF_S_Allocation],0)+isnull([WTD_BF_S_Interaction],0)
						,Effective_Date=Date_Value
				From   #tpa_Daily  C1
				Where IPS in (Entity_ID,'NA' )
				UNION ALL 
				SELECT  entity_ID
						,Sub=2
						,MTD_Value=Sum(isnull(MTD_Bf_S_Allocation,0)+isnull(MTD_Bf_S_Interaction,0))
						,Daily_Value=Sum(isnull([1D_BF_S_Allocation],0)+isnull([1D_BF_S_Interaction],0))
					   ,WTD_Value=SUM(isnull([WTD_BF_S_Allocation],0)+isnull([WTD_BF_S_Interaction],0))
						,Effective_Date=Date_Value
				From   #tpa_Daily C2
				Where  IPS in  ('Active Asset Allocation','Foreign Exchange Hedging')
				Group by Entity_ID,	Date_Value 
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=3
					,MTD_Value
					,Daily_Value
					,WTD_Value
					,Effective_Date
				FROM MTD_Benchmark_Reset				C3
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=4
					,MTD_Value
					,Daily_Value
					,WTD_Value
					,Effective_Date
				FROM MTD_Revaluations					C4
				--UNION ALL 
				--SELECT 
				--	Entity_ID
				--	,Sub=5
				--	,MTD_Value
				--	,Effective_Date
				--FROM  MTD_Real_Estate					c5
				) P
				 JOIN  
				[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
				ON	p.entity_id=m1.entity
				and m1.Decomposition_Name='Allocation/Interaction from Strategic Accounts'
				--and m1.effective_Date=p.effective_Date
				AND 	 year(m1.effective_date)=Year(p.effective_Date)	
				and	Month(m1.effective_date)=Month(p.effective_Date)
 
		--d.effective_Date= ad.Date_Value

				and m1.last_active='Y'
--				Where p.effective_Date
				Group by p.Entity_ID,p.Effective_Date
),MTD_Total_Rebalancing AS
(
     Select
	 Entity_ID
	 ,Decomposition_name='Total Rebalancing (Rebalancing Account + Allocation/Interaction from Strategic Accounts)'
	 ,MTD_Value=Sum(d1.MTD_Value)
	 ,Daily_Value=Sum(d1.Daily_Value)
	 ,WTD_Value=Sum(d1.WTD_Value)
	 ,d1.Effective_Date
	 From 
	 (Select Entity_ID
			,MTD_Value
			,Daily_Value
			,WTD_Value
			,Effective_Date
	   FROM  MTD_TPA_Daily_Exhibit				
	where Decomposition_Name='Rebalancing Account'
	
	   UNION All
	   Select Entity_ID
			,MTD_Value
			,Daily_Value
			,WTD_Value
			,Effective_Date
	   From MTD_Allocation
	   ) d1
	   group by Entity_ID,Effective_Date
),MTD_Total_Rebalancing_DFX as
		(
		Select
		 Entity_ID
		 ,Decomposition_name='Total Rebalancing/DFX'
		 ,MTD_Value=Sum(d1.MTD_Value)
		 ,Daily_Value=Sum(d1.Daily_Value)
	     ,WTD_Value=Sum(d1.WTD_Value)
		 ,d1.Effective_Date
		 From 
		 (Select Entity_ID
				,MTD_Value
				,Daily_Value
				,WTD_Value
				,Effective_Date
		   From MTD_TPA_Daily_Exhibit
		   Where Decomposition_Name= 'Dynamic Foreign Exchange Account'
		   UNION All
		   Select Entity_ID
				,MTD_Value
				,Daily_Value
				,WTD_Value
				,Effective_Date
		   From MTD_Total_Rebalancing

	   ) d1
	   group by Entity_ID,Effective_Date
	   )
,MTD_strategic as
(
				Select 
						Entity_ID
						,Decomposition_Name='Strategy Selection'
						,Effective_Date=Date_Value
						,MTD_Value= Sum 
										(	Case  when IPS in (Entity_ID,'NA') then isnull(MTD_Bf_S_Selection,0)
												When IPS in ('Active Asset Allocation','Foreign Exchange Hedging') then -1*isnull(MTD_Bf_S_Selection,0)
												Else 0
											End
										)
						,Daily_Value= Sum 
										(	Case  when IPS in (Entity_ID,'NA') then isnull([1D_Bf_S_Selection],0)
												When IPS in ('Active Asset Allocation','Foreign Exchange Hedging') then -1*isnull([1D_Bf_S_Selection],0)
												Else 0
											End
										)
						,WTD_Value= Sum 
										(	Case  when IPS in (Entity_ID,'NA') then isnull([WTD_Bf_S_Selection],0)
												When IPS in ('Active Asset Allocation','Foreign Exchange Hedging') then -1*isnull(WTD_Bf_S_Selection,0)
												Else 0
											End
										)
				From #tpa_daily 
				GROUP BY Entity_ID
						,Date_value
	
		
)
,MTD_Residual AS
(
	 
	 SELECT 
	   Entity_id
	  ,MTD_Value = Sum ( case when sub=1 then MTD_Value else -1*MTD_Value End)
	  ,Daily_Value = Sum ( case when sub=1 then Daily_Value else -1*Daily_Value End)
	  ,WTD_Value = Sum ( case when sub=1 then WTD_Value else -1*WTD_Value End)
	  ,Decomposition_Name='Residual'
	  ,Effective_date
	  From
			( 
				SELECT  entity_ID
						,Sub=1
						,MTD_Value=isnull(MTD_Published_Tot_Attribution*100,0)
						,Daily_Value=isnull(Daily_Published_Tot_Attribution*100,0)
						,WTD_Value=isnull(WTD_Published_Tot_Attribution*100,0)
						,Effective_Date
				From   #tpa_summary  C1
				Where ips='Total Published Return'
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=2
					,MTD_Value
					,Daily_Value
					,WTD_Value
					,Effective_Date
				FROM MTD_Total_Rebalancing_DFX				C2
				UNION ALL 
				SELECT 
					Entity_ID
					,Sub=3
					,MTD_Value
					,Daily_Value
					,WTD_Value
					,Effective_Date
				FROM MTD_strategic							C3
	
				) P
				Group by Entity_ID,Effective_Date
)


		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=CASE		WHEN Decomposition_Name='Dynamic Foreign Exchange Account' then 1
											WHEN Decomposition_Name='Rebalancing Account'then 2
									END
				,Decomposition_Name
				,MTD_Value
				,Daily_Value
				,WTD_Value
		From 	MTD_TPA_Daily_Exhibit
		UNION ALL
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=3
				,Decomposition_Name
				,MTD_Value
				,Daily_Value
				,WTD_Value

		From 	MTD_Allocation
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=4
				,Decomposition_Name
				,MTD_Value
				,Daily_Value
				,WTD_Value

		From 	MTD_Total_Rebalancing
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=5
				,Decomposition_Name
				,MTD_Value
				,Daily_Value
				,WTD_Value

		From 	MTD_Total_Rebalancing_DFX 
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=6
				,Decomposition_Name
				,MTD_Value
				,Daily_Value
				,WTD_Value

		From 	MTD_strategic
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=7
				,Decomposition_Name
				,MTD_Value
				,Daily_Value
				,WTD_Value

		From 	MTD_Residual
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=10
				,Decomposition_Name
				,MTD_Value
				,Daily_Value
				,WTD_Value

		From 	MTD_Real_Estate
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=8
				,Decomposition_Name
				,MTD_Value
				,Daily_Value
				,WTD_Value

		From 	MTD_Benchmark_Reset
		UNION ALL 
		Select	Entity_id
				,Effective_Date
				,Decomposition_ID=9
				,Decomposition_Name
				,MTD_Value
				,Daily_Value
				,WTD_Value

		From 	MTD_Revaluations



create table #QTD_YTD_Daily 
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
With QTD_YTD_Daily 
as
(
		Select				d1.Entity_ID
						   ,d1.Decomposition_Name
						   ,d1.Effective_Date
						   ,YTD_Daily_Value=case when Count(d1.QTD_YTD_Date)=datediff(month,'01-01-'+cast(year(d1.Effective_Date) as varchar),d1.Effective_Date) + 1 then Sum(d1.MTD_Value) else null end 
						   ,QTD_Daily_Value= case when Sum ( case when datepart(q,d1.QTD_YTD_Date)=datepart(q,d1.Effective_Date) then 1 else 0 End)=datediff(month, DATEADD(QUARTER,DATEDIFF(QUARTER,0,d1.Effective_Date),0),d1.Effective_Date)+1 
											then Sum ( case when datepart(q,d1.QTD_YTD_Date)=datepart(q,d1.Effective_Date) then d1.MTD_Value else 0 End) else Null End
					from 
								(
									Select 
											Entity_id=Entity
											,Decomposition_Name
											,MTD_Value= value
											,QTD_YTD_Date=effective_date
											,effective_date=ad.date_Value
											,quarter=datepart(quarter,effective_date)
											,year=datepart(year,effective_date)
											,month=datepart(month,effective_date)
											,Source='udm'
									From [PSA].[V_Manual_Performance_Report_TPA_Mapping] m
									Join #All_Dates ad on	m.effective_date<ad.date_Value 
															and year(m.effective_Date)=Year(ad.date_Value)
									where Decomposition_Name in ('Dynamic Foreign Exchange Account','Rebalancing Account','Allocation/Interaction from Strategic Accounts')
						--			and Entity='OPBC0005'

									--order by Decomposition_Name,ad.date_Value dESC

				
									Union All
									Select  Entity_id
										  ,d.Decomposition_Name
										  ,d.MTD_Value
										  ,QTD_YRD_Date=d.effective_Date
										  ,d.effective_Date
										   ,quarter=datepart(quarter,d.effective_date)
										   ,year=datepart(year,d.effective_date)
										   ,month=datepart(month,d.effective_date)
										  ,Source='mtd'
									From  #MTD_Daily d
									where Decomposition_Name in ('Dynamic Foreign Exchange Account','Rebalancing Account','Allocation/Interaction from Strategic Accounts')
					
								  ) d1
								  JOIN [EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] c1
											ON	d1.entity_id=c1.entity
											and d1.Decomposition_Name=c1.Decomposition_Name
--											and d1.effective_Date=c1.Effective_Date
											and  year(c1.effective_date)=Year(d1.effective_Date)	
											and	Month(c1.effective_date)=Month(d1.effective_Date)

											and c1.last_active='Y'

		group by d1.Entity_ID,d1.Decomposition_Name,d1.Effective_Date

)
Select  Entity_ID
		,Decomposition_Name
		,Effective_Date
		,QTD_Daily_Value
		,YTD_Daily_Value
From	QTD_YTD_Daily

UNION ALL

   Select
	 Entity_ID
	 ,Decomposition_name='Total Rebalancing (Rebalancing Account + Allocation/Interaction from Strategic Accounts)'
	 ,Effective_Date
	 ,QTD_Daily_value=Sum(a.qtd_daily_value)
	 ,YTD_Daily_Value=sum(a.YTD_Daily_Value)
	 From 
	 (Select Entity_ID
			,QTD_Daily_Value
			,YTD_Daily_Value
			,Effective_Date
	   FROM  QTD_YTD_Daily				
	where Decomposition_Name='Rebalancing Account'
	
	   UNION All
	   Select Entity_ID
			,QTD_Daily_Value
			,YTD_Daily_Value
			,Effective_Date
	   FROM  QTD_YTD_Daily				
	where Decomposition_Name='Allocation/Interaction from Strategic Accounts'
	   ) a
Group by Entity_ID,Effective_Date








create table #Daily
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
		Select	
				a.Entity_ID
				,a.Effective_Date
				,a.Decomposition_ID
				,a.Decomposition_Name
				,a.MTD_Value
				,a.Daily_Value
				,a.WTD_Value
				,QTD_Daily_Value=b.QTD_Daily_Value
				,YTD_Daily_Value=b.YTD_Daily_Value
				,Type=case when b.decomposition_Name is not null then '3' else '2' End 

		from #MTD_Daily a 
		left join #QTD_YTD_Daily b
					on a.Entity_ID=b.Entity_ID
					and a.Effective_Date=b.Effective_Date
					and a.Decomposition_Name=b.Decomposition_Name
		
		









delete from [EDW_BUS].[Aggr_Performance_RPT_TPA_Exhibit_Summary]
where effective_date in (Select date_value from #All_Dates)
and report_number in (11,21)












Insert into [EDW_BUS].[Aggr_Performance_RPT_TPA_Exhibit_Summary]
(
[Report_Number]
      ,[Client_ID]
      ,[Entity_ID]
      ,[Effective_Date]
      ,[Decomposition_Name]
      ,[Sort_Order]
      ,[Batch_DTS]
      ,[ETL_Load_Key]
      ,[Daily_Value]
      ,[WTD_Value]
      ,[MTD_Daily_Value]
	  ,QTD_Daily_Value
	  ,YTD_Daily_Value
	  ,[type]
	  ,updated_datetime
)


Select Report_Number
		,Client_ID
		,Entity_ID
		,Effective_Date
		,Decomposition_Name
		,Sort_Order
		,Effective_Date
		,@ETL_Load_Key
		,Daily_Value=cast(Sum(Daily_Value) as numeric(38,14))  /100.00 
		,WTD_Value=cast(Sum(WTD_Value) as numeric(38,14))  /100.00 
		,MTD_Daily_Value=cast(Sum(MTD_Daily_Value) as numeric(38,14))  /100.00 
		,QTD_Daily_Value=cast(Sum(QTD_Daily_Value) as numeric(38,14))  /100.00 
		,YTD_Daily_Value=cast(Sum(YTD_Daily_Value) as numeric(38,14))  /100.00 
		,[Type]
		,getdatE()

From (


				Select	
				lu1.Report_Number
				,lu1.Client_ID
				,p1.Entity_ID
				,Effective_Date
				,p1.Decomposition_Name
				,lu2.Sort_Order
				,Daily_Value=p1.Daily_Value
				,WTD_Value=p1.WTD_Value
				,MTD_Daily_Value=P1.MTD_Value
				,p1.QTD_Daily_Value
				,p1.YTD_Daily_Value
				,p1.Type
		from #Daily p1
		JOIN 
				(Select distinct Report_Number,Client_ID,Portfolio_ID from [PSA].V_Manual_Performance_Report_Portfolio_Mapping rpm
				 JOIN	[PSA].[V_Manual_Performance_Config_Report] cr			ON cr.Report_Group=rpm.Report_Group
				where cr.Report_number in (11,21)) lu1
				ON p1.Entity_ID=lu1.Portfolio_ID
		JOIN EDW_BUS.Performance_Reporting_TPA_Decomposition_Name_List lu2
				ON p1.Decomposition_ID=lu2.Sort_Order


) a
Group by 
		Report_Number
		,Client_ID
		,Entity_ID
		,Effective_Date
		,Decomposition_Name
		,Sort_Order
		,type

End 
























	END TRY 

		BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.Performance_RPT_TPA_Exhibit_Summary', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState
		
	END CATCH


End