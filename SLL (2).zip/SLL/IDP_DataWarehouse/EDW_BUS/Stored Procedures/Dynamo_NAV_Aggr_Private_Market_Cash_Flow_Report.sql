﻿CREATE PROC [EDW_BUS].[Dynamo_NAV_Aggr_Private_Market_Cash_Flow_Report] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS

BEGIN
	Declare @today datetime2 = getdate()
	
	
	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@Effective_Date date,
			@updateFlag int,
			@loadLoadedDTS datetime2,
			@updatedRecords int,
			@srcLoadDTS datetime2


    Declare     @moving_Avg_Fx decimal(38,8),
		        @roc_Avg_Fx decimal(38,8),
				@effDateIndx int,
				@totalEffDates int,
				@totalFunds int,
				@fundIndx int,
				@curFundId varchar(255)

	BEGIN TRY

			-- set initial update flag
			Select @updateFlag = 0

			IF @Load_Type = 'DELTA_AUTO_TRIGGER'
			BEGIN
				TRUNCATE TABLE [EDW_BUS].[Aggr_Private_Market_Cash_Flow_Report];
			END

			IF OBJECT_ID('tempdb..#temp_eff_dates') IS NOT NULL
			BEGIN
				DROP TABLE #temp_eff_dates
			END

			IF OBJECT_ID('tempdb..#temp_eagle_change_dates') IS NOT NULL
			BEGIN
				DROP TABLE #temp_eagle_change_dates
			END

			create table #temp_eff_dates
			(Effective_Date datetime2, As_Of_Date datetime2)
			WITH
			(
					DISTRIBUTION = Round_Robin
			) 

			-- get latest month-end date in fact table and compare current run date
			if @Load_Type in ('ADHOC', 'ONDEMAND') 
			Begin
					-- Select @Effective_Date = @Batch_DTS
					Insert Into #temp_eff_dates (Effective_Date, As_Of_Date)
					Select Last_Day_of_Month Effective_Date, Date As_Of_Date
					From EDW_Common.Dim_Date
					Where datediff(d, Date, @Batch_DTS) = 0  

					Select @updateFlag = 1

				Select @srcLoadDTS = max(Load_DTS)
				From (
					Select max(f.dim_date_key) dim_Date_Key, Max(Load_DTS) Load_DTS
					From EDW_Common.Fact_Eagle_Position f
					Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
					Where  d.Date = @Batch_DTS

					union 

					Select max(f.dim_date_key) dim_Date_Key, max(Load_DTS) Load_DTS
					From EDW_Common.Fact_Eagle_Cash_Activity f
					Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
					Where  d.Date <= @Batch_DTS
				) f
				where Dim_Date_key is not null

			End
			else
			Begin
			
				-- get last updated DTS in target table
				Select @loadLoadedDTS = coalesce(max(aggr.Load_DTS), '1900-01-01')
				From EDW_Bus.Aggr_Private_Market_Cash_Flow_Report aggr

				/* check any update and the effective date list from Eagle */
				create table #temp_eagle_change_dates
				WITH
				(
						DISTRIBUTION = Round_Robin
				) AS
				Select d.Last_Day_Of_Month Effective_Date, 
					   Case when datediff(m, d.Date, @Batch_DTS) > 0 then d.Last_Day_Of_Month
					   else @Batch_DTS End As_Of_Date,
					   f.Load_DTS
				From EDW_Common.Fact_Eagle_Position f
				Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
				Where f.Load_DTS > @loadLoadedDTS 

				union 

				Select d.Last_Day_Of_Month Effective_Date, 
					   Case when datediff(m, d.Date, @Batch_DTS) > 0 then d.Last_Day_Of_Month
					   else @Batch_DTS End As_Of_Date,
					   f.Load_DTS
				From EDW_Common.Fact_Eagle_Cash_Activity f
				Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
				Where  f.Load_DTS > @loadLoadedDTS


				Select @updatedRecords = count(*), @srcLoadDTS = max(Load_DTS)
				From (
					Select max(As_Of_Date) As_Of_Date, Max(Load_DTS) Load_DTS
					From #temp_eagle_change_dates
				) f
				where As_Of_Date is not null

				if @updatedRecords > 0 and @srcLoadDTS is not null 
				Begin
					-- changes from Eagle, get all following month end dates and current month
					insert into #temp_eff_dates (Effective_Date, As_Of_Date)
					select Distinct d.Last_Day_Of_Month,  Case when datediff(m, d.Date, @Batch_DTS) > 0 then d.Last_Day_Of_Month
					   else @Batch_DTS End As_Of_Date
					From edw_common.Dim_Date d
					Join (
						Select min(Effective_Date) Effective_Date
						From #temp_eagle_change_dates
					) cd on d.Last_Day_Of_Month >= cd.Effective_Date
					Where d.Date <= @Batch_DTS

					union

					Select Last_Day_of_Month Effective_Date, Date As_Of_Date
					From EDW_Common.Dim_Date
					Where datediff(d, Date, @Batch_DTS) = 0  


					Select @updateFlag = 1
				End
			End

			if @updateFlag > 0 
			Begin
				-- delete the current run effective date in the aggregate table

				Delete f  
				from EDW_Bus.Aggr_Private_Market_Cash_Flow_Report f
				join EDW_Common.Dim_Date d on f.Dim_Report_date_key = d.Dim_Date_Key
				Where d.date in (Select  Effective_Date From #temp_eff_dates) -- datediff(d, d.date,  @Effective_Date) = 0

				IF OBJECT_ID('tempdb..#temp_dynamo_position_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_position_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_position_summary') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_position_summary
				END
				
				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_summary') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_summary
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_flow') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_Cash_Flow
				END

------------------------------------------------------------------------------------------------------------
				create table #temp_dynamo_position_records
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				SELECT  
					pd.Portfolio_Id Fund_Id,
					sd.Security_Id,
					d.Date Effective_Date,
					max(pdc.Reporting_Currency) Currency,
					Rtrim(pdc.BANK_BRANCH_CODE) Asset_Class,
					Sum(ISNULL(p.MARKET_VALUE_INCOME_LOCAL,0)) as Market_Value_Income_Local,
					Sum(ISNULL(p.MARKET_VALUE_INCOME,0)) as Market_Value_Income_Base
				FROM EDW_Common.V_Fact_Eagle_Position p
				join EDW_Common.Dim_Eagle_Portfolio_Detail pd on p.Dim_Eagle_Portfolio_Detail_Key = pd.Dim_Eagle_Portfolio_Detail_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pdc on pd.Portfolio_Id = pdc.Portfolio_Id and pdc.Record_Is_Current_Flag = 1
				Join EDW_Common.Dim_Eagle_Security_Detail sd on p.Dim_Eagle_Security_Detail_Key = sd.Dim_Eagle_Security_Detail_Key
				Join EDW_Common.Dim_Eagle_Interface i on p.Dim_Eagle_Interface_Key = i.Dim_Eagle_Interface_Key 
				Join EDW_Common.Dim_Date d on p.Dim_Date_Key = d.Dim_Date_Key
				--Join EDW_Common.Dim_Currency c on p.dim_local_currency_key = c.Dim_Currency_Key
				WHERE  Rtrim(i.Interface_Name) = 'DYNAMO'
				and Rtrim(pdc.BANK_BRANCH_CODE)  in ('GLOBAL CREDIT', 'GLOBAL CREDIT - PRIV', 'INFRASTRUCTURE', 'PRIVATE DEBT', 'PRIVATE EQUITY', 'REAL ESTATE')
				and d.Date in (Select  As_Of_Date From #temp_eff_dates) -- = @Effective_Date
				Group By pd.Portfolio_Id, sd.Security_Id, d.Date, Rtrim(pdc.BANK_BRANCH_CODE)

				create table #temp_dynamo_position_summary
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 

				SELECT  
					Fund_Id,
					Effective_Date,
					Asset_Class,
					Sum(Market_Value_Income_Local) Market_Value_Income_Local,
					Sum(Market_Value_Income_Base) Market_Value_Income_Base
				FROM #temp_dynamo_position_records
				Group By Fund_Id,
					     Effective_Date,
					     Asset_Class
				

				create table #temp_dynamo_cash_activity_records
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
  
				SELECT        
					   pd.Portfolio_Id Fund_Id,  
					   sd.Security_Id,
					   ted.As_Of_Date Effective_Date, -- @Effective_Date Effective_Date,
					   Rtrim(pdc.BANK_BRANCH_CODE) Asset_Class,
					   max(pdc.Reporting_Currency) Currency,
					   ---------------------------------------- Local -------------------------------------
					    sum(case when trans_type in  ('6','7', '8','30','31','54') then ca.local_total_flow else 0 end ) as Unrealized_Cost_Local,
						sum(case when trans_type in  ('12') then ca.local_total_flow else 0 end ) as Investee_Total_Commitments_Local,  
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('6','7','35','36','44','46','49') then ca.local_total_flow
						         when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('48') then -1*ca.local_total_flow 
								 else 0 end ) as Total_Contribution_Inside_Commitment_Local,
						sum(case when trans_type in  ('6','7','35','36','44','46','49') then ca.local_total_flow
						         when trans_type in  ('48') then -1*ca.local_total_flow 
								 else 0 end ) as Total_Contribution_Inside_Commitment_Local_SI,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('28','29','30','64') 
						   then ca.local_total_flow else 0 end ) as Recallable_Distribution_Local,	
						sum(case when trans_type in  ('28','29','30','64')  then ca.local_total_flow else 0 end ) as Recallable_Distribution_Local_SI,	
						sum(case when trans_type in  ('6','7','35','36','44','46','49','28','29','30','64') then ca.local_total_flow 
						         when trans_type in ('48') then -1*ca.local_total_flow else 0 end ) as Funded_Commitments_Local,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('6') then ca.local_total_flow else 0 end ) as Contribution_Investments_Capital_Call_Local,						
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('7','34','49','50','51','44','45','46','47') then ca.local_total_flow else 0 end ) as Total_Fees_Expense_Local,					
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('30','31') then ca.local_total_flow else 0 end ) as Return_Capital_Local,						
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('26','27','28','29') then ca.local_total_flow else 0 end ) as Realized_Gain_Loss_Local,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('17','18','20','21') then ca.local_total_flow else 0 end ) as Dividend_Local,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('22','23','64','74') then ca.local_total_flow else 0 end ) as Other_Income_Local,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('38','39') then ca.local_total_flow else 0 end ) as Carried_Interest_Local,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('79') then ca.local_total_flow else 0 end ) as Total_Withholding_Tax_Local,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('44','45','46','47') then ca.local_total_flow else 0 end ) as Net_Mgt_fees_Local,
						------------------------------------ Base ------------------------------------------
						sum(case when trans_type in  ('6','7','8','30','31','54') then ca.Base_total_flow else 0 end ) as Unrealized_Cost_Base,
						sum(case when trans_type in  ('12') then ca.Base_total_flow else 0 end ) as Investee_Total_Commitments_Base,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('6','7','35', '36', '44','46','49') then ca.Base_total_flow 
						         when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('48') then -1*ca.Base_total_flow 
							else 0 end ) as Total_Contribution_Inside_Commitment_Base,
						sum(case when trans_type in  ('6','7','35','36','44','46','49') then ca.Base_total_flow 
						         when trans_type in  ('48') then -1*ca.Base_total_flow 
							else 0 end ) as Total_Contribution_Inside_Commitment_Base_SI,

						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('28','29','30','64') 
						    then ca.Base_total_flow else 0 end ) as Recallable_Distribution_Base,
						sum(case when trans_type in  ('28','29','30','64') then ca.Base_total_flow else 0 end ) as Recallable_Distribution_Base_SI,
						sum(case when trans_type in  ('6','7','35','36','44','46','49','28','29','30','64') then ca.Base_total_flow 
						         when trans_type in  ('48') then -1*ca.Base_total_flow else 0 end ) as Funded_Commitments_Base,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and  trans_type in  ('6') then ca.Base_total_flow else 0 end ) as Contribution_Investments_Capital_Call_Base,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('7','34','49','50','51','44','45','46','47') then ca.Base_total_flow else 0 end ) as Total_Fees_Expense_Base,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('30','31') then ca.Base_total_flow else 0 end ) as Return_Capital_Base, 
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('26','27','28','29') then ca.Base_total_flow else 0 end ) as Realized_Gain_Loss_Base, 
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('17','18','20','21') then ca.Base_total_flow else 0 end ) as Dividend_Base,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('22','23','64','74') then ca.Base_total_flow else 0 end ) as Other_Income_Base,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('38','39') then ca.Base_total_flow else 0 end ) as Carried_Interest_Base, 
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('79') then ca.Base_total_flow else 0 end ) as Total_Withholding_Tax_Base,
						sum(case when d.Last_Day_Of_Month = ted.Effective_Date and trans_type in  ('44','45','46','47') then ca.Base_total_flow else 0 end ) as Net_Mgt_fees_Base

				FROM EDW_Common.v_Fact_Eagle_Cash_Activity  ca   
				Join (
					Select Dim_Transaction_Type_key, replace(Transaction_Type_Code, 'Eagle_','') Trans_Type
					From EDW_Common.Dim_Transaction_Type
				) tt on ca.Dim_Transaction_Type_Key = tt.Dim_Transaction_Type_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pd on ca.Dim_Eagle_Portfolio_Detail_Key = pd.Dim_Eagle_Portfolio_Detail_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pdc on pd.Portfolio_Id = pdc.Portfolio_Id and pdc.Record_Is_Current_Flag = 1
				Join EDW_Common.Dim_Eagle_Security_Detail sd on ca.Dim_Eagle_Security_Detail_Key = sd.Dim_Eagle_Security_Detail_Key 
				join EDW_Common.Dim_Date d on ca.Dim_Date_Key = d.Dim_Date_Key
				Join EDW_Common.Dim_Eagle_Interface i on ca.Dim_Eagle_Interface_Key = i.Dim_Eagle_Interface_Key 
				join #temp_eff_dates ted on 1= 1 
				WHERE Rtrim(i.Interface_Name) = 'DYNAMO'
				and Rtrim(pdc.BANK_BRANCH_CODE)  in ('GLOBAL CREDIT', 'GLOBAL CREDIT - PRIV', 'INFRASTRUCTURE', 'PRIVATE DEBT', 'PRIVATE EQUITY', 'REAL ESTATE')
				AND d.Date <= ted.As_Of_Date --  @Effective_Date 
				GROUP BY pd.Portfolio_Id, sd.Security_Id, ted.As_Of_Date, Rtrim(pdc.BANK_BRANCH_CODE)

			
				create table #temp_dynamo_cash_flow
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
					Select coalesce(tp.Fund_Id, c.Fund_Id) Fund_Id
						  ,coalesce(tp.Security_Id, c.Security_Id) Security_Id
						  ,coalesce(tp.Effective_Date, c.Effective_Date) Effective_Date
	 					  ,coalesce(tp.Currency,c.Currency) Currency
						  ,coalesce(tp.Market_Value_Income_Local,0) Market_Value_Income_Local
						  ,coalesce(tp.Market_Value_Income_Base,0) Market_Value_Income_Base

							,c.Unrealized_Cost_Local
							,c.Investee_Total_Commitments_Local
							,c.Total_Contribution_Inside_Commitment_Local
							,c.Total_Contribution_Inside_Commitment_Local_SI
							,c.Recallable_Distribution_Local
							,c.Recallable_Distribution_Local_SI
							,c.Funded_Commitments_Local
							,c.Contribution_Investments_Capital_Call_Local
							,c.Total_Fees_Expense_Local
							,c.Return_Capital_Local
							,c.Realized_Gain_Loss_Local
							,c.Dividend_Local
							,c.Other_Income_Local
							,c.Carried_Interest_Local
							,c.Total_Withholding_Tax_Local
							,c.Net_Mgt_fees_Local	
					  
							,c.Unrealized_Cost_Base
							,c.Investee_Total_Commitments_Base
							,c.Total_Contribution_Inside_Commitment_Base
							,c.Total_Contribution_Inside_Commitment_Base_SI
							,c.Recallable_Distribution_Base
							,c.Recallable_Distribution_Base_SI
							,c.Funded_Commitments_Base
							,c.Contribution_Investments_Capital_Call_Base
							,c.Total_Fees_Expense_Base
							,c.Return_Capital_Base
							,c.Realized_Gain_Loss_Base
							,c.Dividend_Base
							,c.Other_Income_Base
							,c.Carried_Interest_Base
							,c.Total_Withholding_Tax_Base
							,c.Net_Mgt_fees_Base	

					From #temp_dynamo_position_records tp
					full Join #temp_dynamo_cash_activity_records c on tp.Effective_Date = c.Effective_Date and tp.Security_Id = c.Security_Id and tp.Fund_Id = c.Fund_Id
			
			----------------------------------------------------------------------------------------------------
				INSERT INTO [EDW_BUS].[Aggr_Private_Market_Cash_Flow_Report]
				(
				[Dim_Date_Key]
				,[Dim_Report_Date_Key]
				,[Dim_Portfolio_Key]
				,[Dim_Eagle_Portfolio_Detail_Key]
				,[Dim_Security_Key]
				,[Dim_Eagle_Security_Detail_Key]
				,[Dim_Currency_Key]

				,[GL_Value_Local]
				,[Unrealized_Cost_Local]
				,[Investee_Total_Commitments_Local]
				,[Total_Contribution_Inside_Commitment_Local]
				,[Total_Contribution_Inside_Commitment_Local_SI]
				,[Recallable_Distribution_Local]
				,Recallable_Distribution_Local_SI
				,[Funded_Commitments_Local]
				,[Contribution_Investments_Capital_Call_Local]
				,[Total_Fees_Expense_Local]
				,[Return_Capital_Local]
				,[Realized_Gain_Loss_Local]
				,[Dividend_Local]
				,[Other_Income_Local]
				,[Carried_Interest_Local]
				,[Total_Withholding_Tax_Local]
				,[Net_Mgt_fees_Local]

			    ,[GL_Value_Base]
                ,[Unrealized_Cost_Base]
				,[Investee_Total_Commitments_Base]
				,[Total_Contribution_Inside_Commitment_Base]
				,[Total_Contribution_Inside_Commitment_Base_SI]
				,[Recallable_Distribution_Base]
				,[Recallable_Distribution_Base_SI]
				,[Funded_Commitments_Base]
				,[Contribution_Investments_Capital_Call_Base]
				,[Total_Fees_Expense_Base]
				,[Return_Capital_Base]
				,[Realized_Gain_Loss_Base]
				,[Dividend_Base]
				,[Other_Income_Base]
				,[Carried_Interest_Base]
				,[Total_Withholding_Tax_Base]
				,[Net_Mgt_fees_Base]

				,Load_DTS
				,[Last_Update_DTS]
				,[ETL_Load_Key]
				)
				Select
					convert(int, convert(varchar(15), td.Effective_Date, 112)) [Dim_Report_Date_Key]
					,convert(int, convert(varchar(15), td.As_of_Date, 112)) [Dim_Date_Key]
					,coalesce(p.[Dim_Portfolio_Key],-1) [Dim_Portfolio_Key]
					,coalesce(pd.[Dim_Eagle_Portfolio_Detail_Key],-1) [Dim_Eagle_Portfolio_Detail_Key]
					,coalesce(sec.[Dim_Security_Key], -1) [Dim_Security_Key]
					,coalesce(secd.[Dim_Eagle_Security_Detail_Key], -1) [Dim_Eagle_Security_Detail_Key]
					,coalesce(c.[Dim_Currency_Key], -1) [Dim_Currency_Key]

					,Market_Value_Income_Local
					,Unrealized_Cost_Local
					,Investee_Total_Commitments_Local
					,Total_Contribution_Inside_Commitment_Local
					,Total_Contribution_Inside_Commitment_Local_SI
					,Recallable_Distribution_Local
					,Recallable_Distribution_Local_SI
					,Funded_Commitments_Local
					,Contribution_Investments_Capital_Call_Local
					,Total_Fees_Expense_Local
					,Return_Capital_Local
					,Realized_Gain_Loss_Local
					,Dividend_Local
					,Other_Income_Local
					,Carried_Interest_Local
					,Total_Withholding_Tax_Local
					,Net_Mgt_fees_Local

					,Market_Value_Income_Base
					,Unrealized_Cost_Base
					,Investee_Total_Commitments_Base
					,Total_Contribution_Inside_Commitment_Base
					,Total_Contribution_Inside_Commitment_Base_SI
					,Recallable_Distribution_Base
					,Recallable_Distribution_Base_SI
					,Funded_Commitments_Base
					,Contribution_Investments_Capital_Call_Base
					,Total_Fees_Expense_Base
					,Return_Capital_Base
					,Realized_Gain_Loss_Base
					,Dividend_Base
					,Other_Income_Base
					,Carried_Interest_Base
					,Total_Withholding_Tax_Base
					,Net_Mgt_fees_Base
				
					,@srcLoadDTS
					,@today
					,@ETL_Load_Key

				From #temp_dynamo_cash_flow src
				Join #temp_eff_dates td on src.Effective_Date = td.As_Of_Date
				--Dim_Portfolio_Key
				Left Join EDW_Common.Dim_Portfolio p on src.Fund_Id = p.Portfolio_Id and p.Record_Is_Current_Flag = 1

				Left Join EDW_Common.Dim_Eagle_Portfolio_Detail pd on src.Fund_Id = pd.Portfolio_Id and pd.Record_Is_Current_Flag = 1

				--Dim_Security_Key
				Left Join EDW_Common.Dim_Security sec on 'Eagle_' + src.Security_Id = sec.Src_Security_Id and sec.Record_Is_Current_Flag = 1

				Left Join EDW_Common.Dim_Eagle_Security_Detail secd on src.Security_Id = secd.Security_Id and secd.Record_Is_Current_Flag = 1
				Left Join EDW_Common.Dim_Currency c on src.Currency = c.Currency and c.Record_Is_Current_Flag = 1


				Select @rowsInserted = Count(*) 
				From [EDW_BUS].Aggr_Private_Market_Cash_Flow_Report
				Where Last_Update_DTS = @today

				Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_Cash_Flow_Report', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

				/* cleanup temp tables */
				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

		End

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_Cash_Flow_Report', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END