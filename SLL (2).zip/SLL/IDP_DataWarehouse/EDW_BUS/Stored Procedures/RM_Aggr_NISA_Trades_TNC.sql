﻿CREATE PROC [EDW_BUS].[RM_Aggr_NISA_Trades_TNC] @ETL_LOAD_KEY [INT],@Load_Type [VARCHAR],@Batch_DTS [DATETIME2] AS


BEGIN 
	

BEGIN TRY
	
    DECLARE @effectiveDate DATE
	SET  @effectiveDate = @Batch_DTS

	DECLARE @rowsInserted INT = 0,
			@rowsCount INT = 0,
			@today datetime2 = getdate(),
			@rows int,
			@Business_Area varchar(255)= 'RISK',
			@Affected_Source_System varchar(255)= 'SQL_RISK_ETL'


		--Set effective date to T-1 or last business day
		IF @effectiveDate IS NOT NULL AND DATEDIFF(day, '1900-01-01', @effectiveDate) <> 0
		BEGIN
			SELECT @effectiveDate  = @effectiveDate 
		END
		ELSE
		BEGIN
			
			SELECT @effectiveDate = CASE DATEPART(WEEKDAY, GETDATE()) WHEN 2 THEN DATEADD(DAY, -3 , GETDATE()) ELSE DATEADD(DAY, -1 , GETDATE()) END

			SELECT @rows = count(Holiday_Date) FROM [EDW_ETL].[User_Holiday_Calendar]
			WHERE DATEDIFF(day, Holiday_Date, @effectiveDate) = 0
				AND Business_Area = @Business_Area and Affected_System = @Affected_Source_System

			WHILE @rows > 0
			BEGIN
				-- get previous business date
				SELECT @effectiveDate = CASE DATEPART(WEEKDAY, @effectiveDate) WHEN 2 THEN DATEADD(DAY, -3 , @effectiveDate) ELSE DATEADD(DAY, -1 , @effectiveDate) END

				SELECT @rows = count(Holiday_Date) FROM EDW_ETL.User_Holiday_Calendar
				WHERE DATEDIFF(day, Holiday_Date, @effectiveDate) = 0
					AND Business_Area = @Business_Area and Affected_System = @Affected_Source_System

			END
		END


	--Clean up consolidated view if holding date already exists 	
	SELECT @rowsCount = COUNT(1) FROM [EDW_BUS].[Agg_WSIB_NISA_Trades_TNC]
	WHERE HOLDING_DATE =@effectiveDate

	IF @rowsCount>1
	BEGIN
		DELETE FROM [EDW_BUS].[Agg_WSIB_NISA_Trades_TNC] WHERE HOLDING_DATE =@effectiveDate
	END

	


	;WITH REPOTRADE_EXCLUSION AS
    (
		SELECT DISTINCT REPO_CUSIP
		FROM EDW_Raw.V_WSIB_Nisa_Trades NT
		WHERE UPPER(TRIM(NT.REPO_TYPE)) IN ('REVERSE REPO','REPO')
		AND UPPER(TRIM(NT.TRANS_TYPE) )IN ( 'CANCEL' , 'RESIZE','MATURITY') 
		AND @EffectiveDate >= TRADE_DATE     -- parameter
		AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) IN (SELECT Portfolio_ID FROM [PSA].[V_Manual_Portfolio_Groups] where group_name = 'WSIB Accounting Position Split' and @EffectiveDate between start_date and end_Date) --parameter
     ),
	 final AS
	 (
		SELECT 
		 @effectiveDate AS [HOLDING_DATE]
        ,'Repo' AS [ASSET_CLASS]
        ,'Repo' AS [ASSET_TYPE]
        , CONCAT(CASE WHEN UPPER(TRIM(NT.REPO_TYPE)) = 'REVERSE REPO' THEN  'RREPO' ELSE 'REPO' END,'_',TRIM(NT.UNDERLYING_CUSIP),'_',NT.PAR_AMOUNT) AS [ASSET_NAME]
        , CONCAT(TRIM(NT.REPO_CUSIP),'-Repo-WSIB') AS [PRIMARY_ASSET_ID]
        ,'LOCALID' AS [PRIMARY_ASSET_ID_TYPE]
        , NULL AS [ASSET_PRICE]
        , NULL AS [ASSET_PRICE_CURRENCY]
        , NULL AS [STRIKE_PRICE]
        , 1  AS [CONTRACT_SIZE]
        , NT.Currency AS [CURRENCY]
        , CASE WHEN NT.Currency='GBP' THEN 'GBR' 
				WHEN NT.Currency='USD' THEN 'USA'
				ELSE 'CAN' END AS [COUNTRY]
        , NULL AS [UNDERLIER_ID]
        , NULL AS [UNDERLIER_ID_TYPE]
        , NULL AS [RATE_TERM]
        , NT.REAL_SETTLE_MONEY AS [AMOUNT_ISSUED]
        , NULL AS [COUPON_TYPE]
        , NULL AS [ACCRUAL_BASIS]
        , NULL AS [POS_TYPE]
        , NULL AS [COLLATERAL]
        , 'CLASSIC' AS [REPO_TYPE]
        , NT.Repo_Rate AS [REPO_RATE]	
        , 100 AS [SALE_PRICE]
		, CONVERT(VARCHAR,NT.Trade_Date, 112) AS [SALE_DATE]
        , NULL AS [REPURCHASE_PRICE]
		, CONVERT(VARCHAR,NT.TERMINATION_Date, 112) AS [REPURCHASE_DATE]
        , 0 AS [HAIRCUT]
        ,NULL AS [ASSET_PRIORITY]
		FROM EDW_Raw.V_WSIB_Nisa_Trades NT
		WHERE UPPER(TRIM(NT.REPO_TYPE)) IN ('REVERSE REPO','REPO')
			AND UPPER(TRIM(NT.TRANS_TYPE) )= 'INITIATION'  
			AND @EffectiveDate >= NT.TRADE_DATE     -- parameter
			AND @EffectiveDate < NT.TERMINATION_DATE -- parameter
			AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) IN (SELECT Portfolio_ID FROM [PSA].[V_Manual_Portfolio_Groups] where group_name = 'WSIB Accounting Position Split' and @EffectiveDate between start_date and end_Date) --parameter
			AND NT.REPO_CUSIP NOT IN (SELECT REPO_CUSIP FROM REPOTRADE_EXCLUSION)
	 )
	 INSERT INTO [EDW_BUS].[Agg_WSIB_NISA_Trades_TNC]
	 (
		 [HOLDING_DATE]
		,[ASSET_CLASS]
		,[ASSET_TYPE]
		,[ASSET_NAME]
		,[PRIMARY_ASSET_ID]
		,[PRIMARY_ASSET_ID_TYPE]
		,[ASSET_PRICE]
		,[ASSET_PRICE_CURRENCY]
		,[STRIKE_PRICE]
		,[CONTRACT_SIZE]
		,[CURRENCY]
		,[COUNTRY]
		,[UNDERLIER_ID]
		,[UNDERLIER_ID_TYPE]
		,[RATE_TERM]
		,[AMOUNT_ISSUED]
		,[COUPON_TYPE]
		,[ACCRUAL_BASIS]
		,[POS_TYPE]
		,[COLLATERAL]
		,[REPO_TYPE]
		,[REPO_RATE]
		,[SALE_PRICE]
		,[SALE_DATE]
		,[REPURCHASE_PRICE]
		,[REPURCHASE_DATE]
		,[HAIRCUT]
		,[ASSET_PRIORITY]
		,[Load_DTS]
		,[Hash_Diff]
		,[ETL_Load_Key]
		,[Source_Deleted_Flag]
	 )
	 SELECT 
		 [HOLDING_DATE]
		,[ASSET_CLASS]
		,[ASSET_TYPE]
		,[ASSET_NAME]
		,[PRIMARY_ASSET_ID]
		,[PRIMARY_ASSET_ID_TYPE]
		,[ASSET_PRICE]
		,[ASSET_PRICE_CURRENCY]
		,[STRIKE_PRICE]
		,[CONTRACT_SIZE]
		,[CURRENCY]
		,[COUNTRY]
		,[UNDERLIER_ID]
		,[UNDERLIER_ID_TYPE]
		,[RATE_TERM]
		,[AMOUNT_ISSUED]
		,[COUPON_TYPE]
		,[ACCRUAL_BASIS]
		,[POS_TYPE]
		,[COLLATERAL]
		,[REPO_TYPE]
		,[REPO_RATE]
		,[SALE_PRICE]
		,[SALE_DATE]
		,[REPURCHASE_PRICE]
		,[REPURCHASE_DATE]
		,[HAIRCUT]
		,[ASSET_PRIORITY]
		,@today
		, CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' , [ASSET_CLASS], '|' , [ASSET_TYPE], '|' , [ASSET_NAME], '|' , [PRIMARY_ASSET_ID], '|' 
								, [PRIMARY_ASSET_ID_TYPE], '|' , [ASSET_PRICE], '|' , [ASSET_PRICE_CURRENCY], '|' , [STRIKE_PRICE], '|' , [CONTRACT_SIZE], '|' , [CURRENCY], '|' 
								, [COUNTRY], '|' , [UNDERLIER_ID], '|' , [UNDERLIER_ID_TYPE], '|' , [RATE_TERM], '|' , [AMOUNT_ISSUED], '|' , [COUPON_TYPE], '|' , [ACCRUAL_BASIS], '|' 
								, [POS_TYPE], '|' , [COLLATERAL], '|' , [REPO_TYPE], '|' , [REPO_RATE], '|' , [SALE_PRICE], '|' , [SALE_DATE], '|' , [REPURCHASE_PRICE], '|' 
								, [REPURCHASE_DATE], '|' , [HAIRCUT], '|' , [ASSET_PRIORITY], '|' ))), 2) 
		,@ETL_LOAD_KEY 
		,0 
		From Final

	 SELECT @rowsInserted = COUNT(*) 
		FROM [EDW_BUS].[Agg_WSIB_NISA_Trades_TNC]
		WHERE [Load_dts] = @today and [Source_Deleted_Flag] = 0

		EXEC [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.Agg_WSIB_NISA_Trades_TNC', @rowsInserted, 0, 0, 'Completed', null

	END TRY 

		BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.Agg_WSIB_NISA_Trades_TNC', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState
		
	END CATCH
END