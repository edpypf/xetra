﻿CREATE PROC [EDW_BUS].[Private_Market_Position_Tag] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2	,
			@Effective_Date date
			
			--,@ETL_Load_Key int = 1				--UNCOMMENT FOR DEBUGGING
			--,@Batch_DTS date = '2022-03-31'		--UNCOMMENT FOR DEBUGGING

	IF Convert(date,@Batch_DTS) = '1900-01-01'
	BEGIN
		-- get effective date (previous business date) to check
		Set @Effective_Date = CASE DATEPART(weekday, @today) 
						WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
						WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
						ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
						END
	END 
	ELSE 
	BEGIN
		set @Effective_Date = @Batch_DTS
	END;

	
	BEGIN TRY

			IF OBJECT_ID('tempdb..#temp_dynamo') IS NOT NULL
			BEGIN
				DROP TABLE #temp_dynamo
			END

			create table #temp_dynamo
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as 

			SELECT	 cast(P.EFFECTIVE_DATE as date) as EFFECTIVE_DATE
					,P.POSITION_ID
					,PD.POSITION_DETAIL_ID
					,PD.SECURITY_ALIAS
					,PD.LOCAL_CURRENCY 
					,PD.MARKET_VALUE
					,PD.LOCAL_MARKET_VALUE
					,TRIM(P.ENTITY_ID) ENTITY_ID
					,P.SRC_INTFC_INST
			FROM	PSA.V_Eagle_POSITION P
					INNER JOIN PSA.V_Eagle_POSITION_DETAIL PD ON P.POSITION_ID = PD.POSITION_ID
			WHERE	P.Is_Src_Deleted = 0 and PD.Is_Src_Deleted = 0
					and P.EFFECTIVE_DATE = @Effective_Date					
					--AND P.EFFECTIVE_DATE = '20220331'


	
			IF OBJECT_ID('tempdb..#private_position_tag') IS NOT NULL
			BEGIN
				DROP TABLE #private_position_tag
			END

			-- load everything from source
			create table #private_position_tag
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as 

			WITH Private_prep as
			(
			SELECT	 D.Effective_Date
					,trim(E.ENTITY_ID)  Fund_ID
					,trim(E.ENTITY_NAME) Fund_Name
					,D.POSITION_ID
					,D.POSITION_DETAIL_ID
					,E.USER_FIELD21  OPB_Mellon_ID
					,E.USER_FIELD19  SS_CUSIP_1
					,E.USER_FIELD22  SS_CUSIP_2
					,trim(SM.PRIMARY_ASSET_ID) PRIMARY_ASSET_ID
					,trim(SM.PRIMARY_ASSET_ID_TYPE) PRIMARY_ASSET_ID_TYPE
					,D.SECURITY_ALIAS
					,SMD.USER_GROUP_DESC15  ASSET_CLASS
					,SM.ISSUE_NAME  Private_Mkt_Asset_Name
					,SMD.USER_GROUP_CHAR11  Private_Mkt_Region
					,SMD.USER_GROUP_CHAR10  Private_Mkt_Sector
					,SMD.USER_GROUP_DESC17  Private_Mkt_Asset_Type
					,SMD.USER_GROUP_CHAR14  Private_Mkt_Revenue_Source
					,SMD.USER_GROUP_DESC18  Private_Mkt_Risk_Strategy
					,SMD.USER_GROUP_FLOAT5  Private_Mkt_Leverage
					,E.ENTITY_NAME  Private_Mkt_Fund_Name
					,SMD.COUNTRY_OF_RISK IMCO_Country
					,D.LOCAL_CURRENCY Accounting_Currency
					,trim(SM.CURRENCY_CODE) CURRENCY
					,SM.INVESTMENT_TYPE
					,SM.PROCESS_SEC_TYPE
					,SM.ISSUE_DESCRIPTION
					,D.MARKET_VALUE
					,D.LOCAL_MARKET_VALUE
					,SME.GICS_INDUSTRY_GROUP
					,E.ANALYSIS_CODE [PARTNER]
					,SMD.USER_GROUP_CHAR13

			FROM	PSA.V_Eagle_ENTITY E
					INNER JOIN #temp_dynamo D ON D.ENTITY_ID = E.ENTITY_ID
					INNER JOIN PSA.V_Eagle_SECURITY_MASTER SM ON D.SECURITY_ALIAS = SM.SECURITY_ALIAS 
					LEFT JOIN PSA.V_Eagle_SECURITY_MASTER_DETAIL SMD ON SM.SECURITY_ALIAS = SMD.SECURITY_ALIAS
					LEFT JOIN PSA.V_Eagle_secmaster_DETAIL_ext SME on smd.security_alias = sme.security_alias

			WHERE	D.SRC_INTFC_INST = ( SELECT INSTANCE FROM PSA.V_Eagle_INTERFACES WHERE SHORT_DESC ='DYNAMO' and Is_Src_Deleted = 0 )
					and SMD.USER_GROUP_DESC15 <> 'Real Estate' 
					and E.Is_Src_Deleted = 0
					and SM.ISSUE_NAME NOT LIKE '%FUND FEES AND EXPENSES%'

			union

			SELECT	D.Effective_Date
					,trim(E.ENTITY_ID)  Fund_ID
					,trim(E.ENTITY_NAME) Fund_Name
					,D.POSITION_ID
					,D.POSITION_DETAIL_ID
					,E.USER_FIELD21  OPB_Mellon_ID
					,E.USER_FIELD19  SS_CUSIP_1
					,NULL  SS_CUSIP_2
					,trim(SM.PRIMARY_ASSET_ID) PRIMARY_ASSET_ID
					,trim(SM.PRIMARY_ASSET_ID_TYPE) PRIMARY_ASSET_ID_TYPE
					,D.SECURITY_ALIAS
					,SMD.USER_GROUP_DESC15  ASSET_CLASS
					,SM.ISSUE_NAME  Private_Mkt_Asset_Name
					,SMD.USER_GROUP_CHAR11  Private_Mkt_Region
					,SMD.USER_GROUP_CHAR10  Private_Mkt_Sector
					,SMD.USER_GROUP_DESC17  Private_Mkt_Asset_Type
					,SMD.USER_GROUP_CHAR14  Private_Mkt_Revenue_Source
					,SMD.USER_GROUP_DESC18  Private_Mkt_Risk_Strategy
					,SMD.USER_GROUP_FLOAT5  Private_Mkt_Leverage
					,E.ENTITY_NAME  Private_Mkt_Fund_Name
					,SMD.COUNTRY_OF_RISK IMCO_Country
					,D.LOCAL_CURRENCY Accounting_Currency
					,trim(SM.CURRENCY_CODE) CURRENCY
					,SM.INVESTMENT_TYPE
					,SM.PROCESS_SEC_TYPE
					,SM.ISSUE_DESCRIPTION
					,D.MARKET_VALUE
					,D.LOCAL_MARKET_VALUE
					,SME.GICS_INDUSTRY_GROUP
					,E.ANALYSIS_CODE [PARTNER]
					,SMD.USER_GROUP_CHAR13

			FROM	PSA.V_Eagle_ENTITY E
					INNER JOIN #temp_dynamo D ON D.ENTITY_ID = E.ENTITY_ID
					INNER JOIN PSA.V_Eagle_SECURITY_MASTER SM ON D.SECURITY_ALIAS = SM.SECURITY_ALIAS 
					LEFT JOIN PSA.V_Eagle_SECURITY_MASTER_DETAIL SMD ON SM.SECURITY_ALIAS = SMD.SECURITY_ALIAS
					LEFT JOIN PSA.V_Eagle_secmaster_DETAIL_ext SME on smd.security_alias = sme.security_alias

			WHERE	D.SRC_INTFC_INST = ( SELECT INSTANCE FROM PSA.V_Eagle_INTERFACES WHERE SHORT_DESC ='DYNAMO' and Is_Src_Deleted = 0 )
					and E.USER_FIELD19 is not null
					and SMD.USER_GROUP_DESC15 = 'Real Estate' 
					and E.Is_Src_Deleted = 0 
					and SM.ISSUE_NAME NOT LIKE '%FUND FEES AND EXPENSES%'

			union

			SELECT	D.Effective_Date
					,trim(E.ENTITY_ID)  Fund_ID
					,trim(E.ENTITY_NAME) Fund_Name
					,D.POSITION_ID
					,D.POSITION_DETAIL_ID
					,E.USER_FIELD21  OPB_Mellon_ID
					,E.USER_FIELD22  SS_CUSIP_1
					,NULL  SS_CUSIP_2
					,trim(SM.PRIMARY_ASSET_ID) PRIMARY_ASSET_ID
					,trim(SM.PRIMARY_ASSET_ID_TYPE) PRIMARY_ASSET_ID_TYPE
					,D.SECURITY_ALIAS
					,SMD.USER_GROUP_DESC15  ASSET_CLASS
					,SM.ISSUE_NAME  Private_Mkt_Asset_Name
					,SMD.USER_GROUP_CHAR11  Private_Mkt_Region
					,SMD.USER_GROUP_CHAR10  Private_Mkt_Sector
					,SMD.USER_GROUP_DESC17  Private_Mkt_Asset_Type
					,SMD.USER_GROUP_CHAR14  Private_Mkt_Revenue_Source
					,SMD.USER_GROUP_DESC18  Private_Mkt_Risk_Strategy
					,SMD.USER_GROUP_FLOAT5  Private_Mkt_Leverage
					,E.ENTITY_NAME  Private_Mkt_Fund_Name
					,SMD.COUNTRY_OF_RISK IMCO_Country
					,D.LOCAL_CURRENCY Accounting_Currency
					,trim(SM.CURRENCY_CODE) CURRENCY
					,SM.INVESTMENT_TYPE
					,SM.PROCESS_SEC_TYPE
					,SM.ISSUE_DESCRIPTION
					,D.MARKET_VALUE
					,D.LOCAL_MARKET_VALUE
					,SME.GICS_INDUSTRY_GROUP
					,E.ANALYSIS_CODE [PARTNER]
					,SMD.USER_GROUP_CHAR13

			FROM	PSA.V_Eagle_ENTITY E
					INNER JOIN #temp_dynamo D ON D.ENTITY_ID = E.ENTITY_ID
					INNER JOIN PSA.V_Eagle_SECURITY_MASTER SM ON D.SECURITY_ALIAS = SM.SECURITY_ALIAS 
					LEFT JOIN PSA.V_Eagle_SECURITY_MASTER_DETAIL SMD ON SM.SECURITY_ALIAS = SMD.SECURITY_ALIAS
					LEFT JOIN PSA.V_Eagle_secmaster_DETAIL_ext SME on smd.security_alias = sme.security_alias

			WHERE	D.SRC_INTFC_INST = ( SELECT INSTANCE FROM PSA.V_Eagle_INTERFACES WHERE SHORT_DESC ='DYNAMO' and Is_Src_Deleted = 0 )
					and E.USER_FIELD22 is not null
					and SMD.USER_GROUP_DESC15 = 'Real Estate' 
					and E.Is_Src_Deleted= 0 
					and SM.ISSUE_NAME NOT LIKE '%FUND FEES AND EXPENSES%'

			union

			SELECT	D.Effective_Date
					,trim(E.ENTITY_ID)  Fund_ID
					,trim(E.ENTITY_NAME) Fund_Name
					,D.POSITION_ID
					,D.POSITION_DETAIL_ID
					,E.USER_FIELD21  OPB_Mellon_ID
					,E.USER_FIELD19  SS_CUSIP_1
					,USER_FIELD22  SS_CUSIP_2
					,trim(SM.PRIMARY_ASSET_ID) PRIMARY_ASSET_ID
					,trim(SM.PRIMARY_ASSET_ID_TYPE) PRIMARY_ASSET_ID_TYPE
					,D.SECURITY_ALIAS
					,SMD.USER_GROUP_DESC15  ASSET_CLASS
					,SM.ISSUE_NAME  Private_Mkt_Asset_Name
					,SMD.USER_GROUP_CHAR11  Private_Mkt_Region
					,SMD.USER_GROUP_CHAR10  Private_Mkt_Sector
					,SMD.USER_GROUP_DESC17  Private_Mkt_Asset_Type
					,SMD.USER_GROUP_CHAR14  Private_Mkt_Revenue_Source
					,SMD.USER_GROUP_DESC18  Private_Mkt_Risk_Strategy
					,SMD.USER_GROUP_FLOAT5  Private_Mkt_Leverage
					,E.ENTITY_NAME  Private_Mkt_Fund_Name
					,SMD.COUNTRY_OF_RISK IMCO_Country
					,D.LOCAL_CURRENCY Accounting_Currency
					,trim(SM.CURRENCY_CODE) CURRENCY
					,SM.INVESTMENT_TYPE
					,SM.PROCESS_SEC_TYPE
					,SM.ISSUE_DESCRIPTION
					,D.MARKET_VALUE
					,D.LOCAL_MARKET_VALUE
					,SME.GICS_INDUSTRY_GROUP
					,E.ANALYSIS_CODE [PARTNER]
					,SMD.USER_GROUP_CHAR13

			FROM	PSA.V_Eagle_ENTITY E
					INNER JOIN #temp_dynamo D ON D.ENTITY_ID = E.ENTITY_ID
					INNER JOIN PSA.V_Eagle_SECURITY_MASTER SM ON D.SECURITY_ALIAS = SM.SECURITY_ALIAS 
					LEFT JOIN PSA.V_Eagle_SECURITY_MASTER_DETAIL SMD ON SM.SECURITY_ALIAS = SMD.SECURITY_ALIAS
					LEFT JOIN PSA.V_Eagle_secmaster_DETAIL_ext SME on smd.security_alias = sme.security_alias

			WHERE	D.SRC_INTFC_INST = ( SELECT INSTANCE FROM PSA.V_Eagle_INTERFACES WHERE SHORT_DESC ='DYNAMO' and Is_Src_Deleted = 0 )
					and coalesce(E.USER_FIELD19,E.USER_FIELD22,'') = ''
					and SMD.USER_GROUP_DESC15 = 'Real Estate' 
					and E.Is_Src_Deleted = 0 
					and SM.ISSUE_NAME NOT LIKE '%FUND FEES AND EXPENSES%'
			),

			OPB_Positions as 
			(
			SELECT  distinct                                                         
					trim(xr.xref_security_id) as MellonID,
					trim(x.xref_security_id) as Dynamo_CMS_ID,
					TRIM(D.ENTITY_ID) as acc_portfolio_code,
					cast(D.EFFECTIVE_DATE as date) as EFFECTIVE_DATE,
					TRIM(SM.USER_GROUP_SECTOR14) ASSET_CLASS_CODE,
					TRIM(SMD.USER_GROUP_DESC16) as INVESTMENT_STRUCTURE
			FROM	#temp_dynamo D                                                                          
					LEFT OUTER JOIN PSA.V_Eagle_SECURITY_MASTER SM ON D.SECURITY_ALIAS = SM.SECURITY_ALIAS                                                                       
					LEFT OUTER JOIN PSA.V_Eagle_SECMASTER_DETAIL_EXT SDE ON SDE.SECURITY_ALIAS = SM.SECURITY_ALIAS   
					LEFT JOIN PSA.V_Eagle_SECURITY_MASTER_DETAIL SMD ON SM.SECURITY_ALIAS = SMD.SECURITY_ALIAS
					INNER JOIN PSA.V_Eagle_xreference xr on xr.security_alias = SM.security_alias and xr.xref_type = 'CMS_ID'
					LEFT JOIN PSA.V_Eagle_Xreference x on sm.security_alias =x.security_alias AND x.xref_security_id like 'IMCO%'
			WHERE	TRIM(D.ENTITY_ID) IN ( SELECT TRIM(CODE_VALUE) CODE_VALUE FROM PSA.V_Eagle_ENTITY_LIST WHERE ENTITY_ID ='OPBL0015' )                                                                           
					AND D.SRC_INTFC_INST IN ( select instance from PSA.V_Eagle_interfaces where short_desc in ('BNYM','BNYM_ME') and Is_Src_Deleted = 0 )                                                                                         
					AND SM.USER_GROUP_SECTOR14 IN ('007', '005')
			),

			WSIB_Positions as
			(
			SELECT  distinct
					trim(CUSIP_Number) CUSIP_Number,
					Security_long_name,
					Fund_name,
					trim(Fund) Fund,
					cast(EFFECTIVE_DATE as date) as EFFECTIVE_DATE
			FROM	PSA.V_StateStreet_Accounting_Positions
			where	CUSIP_Number is not null
					AND Investment_Type_Name <> 'FOREIGN CURRENCY'
					--and EFFECTIVE_DATE = '20220331' 
					and EFFECTIVE_DATE = @Effective_Date
			),

			FX_Rate AS
			( 
			select	fx.effective_date,
					trim(sm.nra_tax_country) nra_tax_country, 
					trim(sm.currency_code) currency_code, 
					trim(sm2.currency_code) as base_currency, 
					fx.spot_rate

			from	PSA.V_Eagle_fx_rates fx 
					inner join PSA.V_Eagle_security_master sm on sm.security_alias=fx.from_secalias
					inner join PSA.V_Eagle_security_master sm2 on sm2.security_alias=fx.security_alias
			where	fx.EFFECTIVE_DATE = @Effective_Date
					--fx.effective_date = '20220331'
			),

			Manual_Position_Tag As
			(
			select	distinct
					dd.date as Effective_Date,
					Client,
					Portfolio_ID,
					Accounting_Fund_ID,
					Dynamo_Fund_ID,
					PRIMARY_ASSET_ID,
					PRIMARY_ASSET_ID_TYPE,
					Private_Mkt_Asset_ID,
					Private_Mkt_Fund,
					Private_Mkt_Fund_Name,
					Private_Mkt_Asset_Class,
					Private_Mkt_Asset_Name,
					Private_Mkt_Investment_Vehicle,
					Private_Mkt_Region,
					Private_Mkt_Asset_Type,
					Private_Mkt_Sector,
					Private_Mkt_Revenue_Source,
					Private_Mkt_Risk_Strategy,
					Private_Mkt_Partner,
					cast(Private_Mkt_Leverage as decimal(28,12)) as Private_Mkt_Leverage,
					Issuer_Name,
					cast(Country_Risk as varchar(20)) Country_Risk,
					cast(Currency_Risk as varchar(3)) Currency_Risk,
					cast(Currency_Fund as varchar(3)) Currency_Fund,
					GICS_INDUSTRY_GROUP,
					cast(Market_Value as decimal(28,12)) as Market_Value,
					cast(Market_Value_Local as decimal(28,12)) as Market_Value_Local,
					cast(Market_Value_Currency_Risk as decimal(28,12)) as Market_Value_Currency_Risk,
					Sector_2,
					IMCO_Instrument,
					Private_Mkt_Country,
					Private_Mkt_Currency,
					Exposure_Scalar,
					Income_Risk_Exposure_Scalar,
					Metro_Area,
					Number_of_Assets,
					Property_Subtype,
					Property_Type_and_Region,
					Specific_Risk_Scalar,
					Instrument_Type,
					PE_Common_Factor_Risk_Scalar,
					PE_Investment_Type,
					PE_Public_Proxy,
					Proxy_Identifier,
					Proxy_Identifier_Type,
					Price_Proxy,
					Proxy_Notional,
					Start_Date,
					End_Date

			from	[EDW_Common].[Fact_Manual_Private_Position_Tag] bt
					Inner Join EDW_Common.Dim_date dd on dd.Dim_Date_Key= bt.Dim_Date_Key 

			WHERE	Is_Src_Deleted = 0
					--and dd.date = '20220331'
					and dd.date = @Effective_Date
			),

			Deletes as 
			(
			select	distinct
					Portfolio_ID,
					Accounting_Fund_ID,
					PRIMARY_ASSET_ID

			from	[EDW_Common].[Fact_Manual_Private_Position_Tag]
			where	end_date < @Effective_Date
					--end_date < '20220331'
					and Is_Src_Deleted = 0
					and concat(Portfolio_ID,Accounting_Fund_ID,primary_asset_id) not in ( select distinct concat(Portfolio_ID,Accounting_Fund_ID,primary_asset_id) from Manual_Position_Tag ) --include previously end-dated asset	
			)

			--GET OPB POSITIONS
			select  cast(PP.Effective_Date as date) as Effective_Date
					,OP.acc_portfolio_code as Portfolio_ID
					,PP.Fund_ID as Dynamo_Fund_ID
					,CASE WHEN OPB_Mellon_ID like 'IMCO%' 
						THEN OP.MellonID
					 ELSE coalesce(OPB_Mellon_ID, SS_CUSIP_1, SS_CUSIP_2) END as Accounting_Fund_ID
					--,coalesce(OPB_Mellon_ID, SS_CUSIP_1, SS_CUSIP_2) as Accounting_Fund_ID
					,coalesce(PT.Accounting_Fund_ID, OPB_Mellon_ID, SS_CUSIP_1, SS_CUSIP_2) as Private_Mkt_Fund
					,PP.Fund_Name as Dynamo_Fund_Name
					,coalesce(PT.Private_Mkt_Fund_Name, PP.Fund_Name) as Private_Mkt_Fund_Name
					,PP.POSITION_ID
					,PP.POSITION_DETAIL_ID as Position_Underlying_ID				
					,PP.PRIMARY_ASSET_ID
					,PP.PRIMARY_ASSET_ID_TYPE
					,coalesce(PT.Private_Mkt_Asset_ID, PP.PRIMARY_ASSET_ID) as Private_Mkt_Asset_ID
					,PP.SECURITY_ALIAS as Accounting_Asset_ID
					,dbo.ToProperCase(PP.ASSET_CLASS) as Asset_Class
					,OP.Investment_Structure
					,coalesce(PT.Private_Mkt_Investment_Vehicle, OP.Investment_Structure) as Private_Mkt_Investment_Vehicle
					,CASE 
					  --WHEN OP.ASSET_CLASS_CODE = 'INFR' 
						--THEN 'Infrastructure' 
					  WHEN OP.ASSET_CLASS_CODE = '007' AND OP.INVESTMENT_STRUCTURE IN ('CO-INVESTMENT','DIRECT OR JOINT VENTURE') 
						THEN 'Private Equity Directs' 
					  WHEN OP.ASSET_CLASS_CODE = '007' AND COALESCE(OP.INVESTMENT_STRUCTURE,'1') NOT IN ('CO-INVESTMENT','DIRECT OR JOINT VENTURE') 
						THEN 'Private Equity Funds' 
					  --WHEN OP.ASSET_CLASS_CODE = 'PVTDEBT' AND OP.INVESTMENT_STRUCTURE IN ('CO-INVESTMENT','DIRECT OR JOINT VENTURE') 
						--THEN 'Private Debt Directs' 
					 -- WHEN OP.ASSET_CLASS_CODE = 'PVTDEBT' AND OP.INVESTMENT_STRUCTURE IN ('FUNDS','PRIMARY FUND','SECONDARY FUND') 
						--THEN 'Private Debt Funds' 
					  WHEN OP.ASSET_CLASS_CODE = '005' AND OP.INVESTMENT_STRUCTURE IN ('CO-INVESTMENT','DIRECT OR JOINT VENTURE','PRIMARY FUND','SECONDARY FUND') 
						THEN 'Real Estate Assets' 
					  WHEN OP.ASSET_CLASS_CODE IN ('005','007') 
						THEN 'Private Unknown' END AS Asset_Class_Accounting
					,dbo.ToProperCase(PP.Private_Mkt_Asset_Type) as Asset_Type
					,dbo.ToProperCase(coalesce(PT.Private_Mkt_Asset_Type, PP.Private_Mkt_Asset_Type)) as Private_Mkt_Asset_Type
					,PP.Private_Mkt_Asset_Name as Asset_Name
					,coalesce(PT.Private_Mkt_Asset_Name, PP.Private_Mkt_Asset_Name) as Private_Mkt_Asset_Name
					,PT.Issuer_Name
					,dbo.ToProperCase(PP.Private_Mkt_Region) as Region
					,dbo.ToProperCase(coalesce(pt.Private_Mkt_Region, PP.Private_Mkt_Region)) as Private_Mkt_Region
					,dbo.ToProperCase(PP.Private_Mkt_Sector) as Sector_1
					,dbo.ToProperCase(coalesce(pt.Private_Mkt_Sector, PP.Private_Mkt_Sector)) as Private_Mkt_Sector
					--,PP.IMCO_Country as Country_Risk
					,coalesce(PT.Country_Risk, PP.IMCO_Country) as Country_Risk
					,coalesce(PT.Currency_Risk, FX.currency_code) as Currency_Risk
					--,PP.Accounting_Currency as Currency_Fund
					,coalesce(PT.Currency_Fund, PP.Accounting_Currency) as Currency_Fund
					,dbo.ToProperCase(PP.Private_Mkt_Revenue_Source) as Revenue_Source
					,dbo.ToProperCase(coalesce(pt.Private_Mkt_Revenue_Source, PP.Private_Mkt_Revenue_Source)) as Private_Mkt_Revenue_Source
					,dbo.ToProperCase(PP.Private_Mkt_Risk_Strategy) as Risk_Strategy
					,dbo.ToProperCase(coalesce(pt.Private_Mkt_Risk_Strategy, PP.Private_Mkt_Risk_Strategy)) as Private_Mkt_Risk_Strategy
					,PP.[Partner] as [Partner]
					,coalesce(PT.Private_Mkt_Partner, PP.[Partner]) as Private_Mkt_Partner
					,PP.Private_Mkt_Leverage as Leverage
					,coalesce(PT.Private_Mkt_Leverage, PP.Private_Mkt_Leverage) as Private_Mkt_Leverage
					,PT.Sector_2
					,PT.IMCO_Instrument
					,PP.Market_Value
					,PP.Local_Market_Value as Market_Value_Local
					--,PP.GICS_INDUSTRY_GROUP
					,coalesce(PT.GICS_INDUSTRY_GROUP, PP.GICS_INDUSTRY_GROUP) as GICS_INDUSTRY_GROUP
					,case when coalesce(PT.Currency_Risk, FX.currency_code) = PP.Accounting_Currency
						then PP.Local_Market_Value
						else PP.Market_Value*fx2.spot_rate end as Market_Value_Currency_Risk
					--,PT.Private_Mkt_Country
					,coalesce(PT.Private_Mkt_Country,PP.IMCO_Country) as Private_Mkt_Country
					--,PT.Private_Mkt_Currency
					,coalesce(PT.Private_Mkt_Currency, FX.currency_code) as Private_Mkt_Currency
					,PT.Exposure_Scalar 
					,PT.Income_Risk_Exposure_Scalar 
					,PT.Metro_Area
					,PT.Number_of_Assets
					,PT.Property_Subtype
					,PT.Property_Type_and_Region
					,PT.Specific_Risk_Scalar 
					,PT.Instrument_Type
					,PT.PE_Common_Factor_Risk_Scalar
					,PT.PE_Investment_Type
					,PT.PE_Public_Proxy
					,PT.Proxy_Identifier
					,PT.Proxy_Identifier_Type
					,PT.Price_Proxy
					,PT.Proxy_Notional

			FROM	Private_prep PP 	
					INNER JOIN OPB_Positions OP on rtrim(PP.OPB_Mellon_ID) = case when OP.Dynamo_CMS_ID like 'IMCO%' then rtrim(OP.Dynamo_CMS_ID) else rtrim(OP.mellonid) end
								AND PP.EFFECTIVE_DATE = OP.EFFECTIVE_DATE					
					--UPDATES
					LEFT JOIN Manual_Position_Tag PT on rtrim(OP.acc_portfolio_code) = rtrim(PT.Portfolio_ID) 
								AND PP.PRIMARY_ASSET_ID = PT.PRIMARY_ASSET_ID
								AND PP.Fund_ID = PT.Dynamo_Fund_ID
								AND PP.EFFECTIVE_DATE = PT.Effective_Date
					LEFT JOIN FX_Rate FX ON PP.EFFECTIVE_DATE = FX.EFFECTIVE_DATE
								AND PP.IMCO_Country = FX.nra_tax_country
					LEFT JOIN FX_Rate FX2 ON PP.EFFECTIVE_DATE = FX2.EFFECTIVE_DATE
								AND coalesce(PT.Currency_Risk, FX.currency_code) = FX2.currency_code
					--DELETES
					LEFT JOIN Deletes del ON PP.PRIMARY_ASSET_ID = del.PRIMARY_ASSET_ID
								AND rtrim(OP.acc_portfolio_code) = rtrim(del.Portfolio_ID) 
								AND CASE WHEN OPB_Mellon_ID like 'IMCO%' 
										THEN OP.MellonID
									ELSE coalesce(OPB_Mellon_ID, SS_CUSIP_1, SS_CUSIP_2) END = del.Accounting_Fund_ID
			where	del.PRIMARY_ASSET_ID is null      --this excludes delete records

			union

			--GET WSIB POSITIONS
			select  cast(PP.Effective_Date as date) as Effective_Date
					,WS.Fund as Portfolio_ID
					,PP.Fund_ID as Dynamo_Fund_ID
					,CASE WHEN PP.ASSET_CLASS = 'Real Estate' AND SS_CUSIP_1 IS NOT NULL
						THEN SS_CUSIP_1
					 ELSE coalesce(OPB_Mellon_ID, SS_CUSIP_1, SS_CUSIP_2) END as Accounting_Fund_ID
					,coalesce(PT.Accounting_Fund_ID, OPB_Mellon_ID, SS_CUSIP_1, SS_CUSIP_2) as Private_Mkt_Fund
					,PP.Fund_Name as Dynamo_Fund_Name
					,coalesce(PT.Private_Mkt_Fund_Name, PP.Fund_Name) as Private_Mkt_Fund_Name
					,PP.POSITION_ID
					,PP.POSITION_DETAIL_ID as Position_Underlying_ID
					,PP.PRIMARY_ASSET_ID
					,PP.PRIMARY_ASSET_ID_TYPE
					,coalesce(PT.Private_Mkt_Asset_ID, PP.PRIMARY_ASSET_ID) as Private_Mkt_Asset_ID
					,PP.SECURITY_ALIAS as Accounting_Asset_ID
					,dbo.ToProperCase(PP.ASSET_CLASS) as Asset_Class
					,NULL as Investment_Structure
					,PT.Private_Mkt_Investment_Vehicle
					,NULL as Asset_Class_Accounting
					,dbo.ToProperCase(PP.Private_Mkt_Asset_Type) as Asset_Type
					,dbo.ToProperCase(coalesce(PT.Private_Mkt_Asset_Type, PP.Private_Mkt_Asset_Type)) as Private_Mkt_Asset_Type
					,PP.Private_Mkt_Asset_Name as Asset_Name
					,coalesce(PT.Private_Mkt_Asset_Name, PP.Private_Mkt_Asset_Name) as Private_Mkt_Asset_Name
					,PT.Issuer_Name
					,dbo.ToProperCase(PP.Private_Mkt_Region) as Region
					,dbo.ToProperCase(coalesce(pt.Private_Mkt_Region, PP.Private_Mkt_Region)) as Private_Mkt_Region
					,dbo.ToProperCase(PP.Private_Mkt_Sector) as Sector_1
					,dbo.ToProperCase(coalesce(pt.Private_Mkt_Sector, PP.Private_Mkt_Sector)) as Private_Mkt_Sector
					--,PP.IMCO_Country as Country_Risk
					,coalesce(PT.Country_Risk, PP.IMCO_Country) as Country_Risk
					,coalesce(PT.Currency_Risk, FX.currency_code) as Currency_Risk
					--,PP.Accounting_Currency as Currency_Fund
					,coalesce(PT.Currency_Fund, PP.Accounting_Currency) as Currency_Fund
					,dbo.ToProperCase(PP.Private_Mkt_Revenue_Source) as Revenue_Source
					,dbo.ToProperCase(coalesce(pt.Private_Mkt_Revenue_Source, PP.Private_Mkt_Revenue_Source)) as Private_Mkt_Revenue_Source
					,dbo.ToProperCase(PP.Private_Mkt_Risk_Strategy) as Risk_Strategy
					,dbo.ToProperCase(coalesce(pt.Private_Mkt_Risk_Strategy, PP.Private_Mkt_Risk_Strategy)) as Private_Mkt_Risk_Strategy
					,PP.[Partner]
					,coalesce(PT.Private_Mkt_Partner, PP.[Partner]) as Private_Mkt_Partner
					,PP.Private_Mkt_Leverage as Leverage
					,coalesce(PT.Private_Mkt_Leverage, PP.Private_Mkt_Leverage) as Private_Mkt_Leverage
					,PT.Sector_2
					,PT.IMCO_Instrument
					,PP.Market_Value
					,PP.Local_Market_Value as Market_Value_Local
					--,PP.GICS_INDUSTRY_GROUP
					,coalesce(PT.GICS_INDUSTRY_GROUP, PP.GICS_INDUSTRY_GROUP) as GICS_INDUSTRY_GROUP
					,case when coalesce(PT.Currency_Risk, FX.currency_code) = PP.Accounting_Currency
						then PP.Local_Market_Value
					else PP.Market_Value*fx2.spot_rate end as Market_Value_Currency_Risk
					--,PT.Private_Mkt_Country
					,coalesce(PT.Private_Mkt_Country,PP.IMCO_Country) as Private_Mkt_Country
					--,PT.Private_Mkt_Currency
					,coalesce(PT.Private_Mkt_Currency, FX.currency_code) as Private_Mkt_Currency
					,PT.Exposure_Scalar 
					,PT.Income_Risk_Exposure_Scalar 
					,PT.Metro_Area
					,PT.Number_of_Assets
					,PT.Property_Subtype
					,PT.Property_Type_and_Region
					,PT.Specific_Risk_Scalar 
					,PT.Instrument_Type
					,PT.PE_Common_Factor_Risk_Scalar
					,PT.PE_Investment_Type
					,PT.PE_Public_Proxy
					,PT.Proxy_Identifier
					,PT.Proxy_Identifier_Type
					,PT.Price_Proxy
					,PT.Proxy_Notional

			FROM	Private_prep PP 
					INNER JOIN WSIB_Positions WS on rtrim(coalesce(PP.SS_CUSIP_1,PP.SS_CUSIP_2)) = rtrim(WS.CUSIP_Number)
							AND PP.EFFECTIVE_DATE = WS.EFFECTIVE_DATE 
					--UPDATES
					LEFT JOIN Manual_Position_Tag PT on rtrim(WS.Fund) = rtrim(PT.Portfolio_ID) 
								AND PP.PRIMARY_ASSET_ID = PT.PRIMARY_ASSET_ID
								AND PP.Fund_ID = PT.Dynamo_Fund_ID
								AND PP.EFFECTIVE_DATE = PT.Effective_Date
					LEFT JOIN FX_Rate FX ON PP.EFFECTIVE_DATE = FX.EFFECTIVE_DATE
								AND PP.IMCO_Country = FX.nra_tax_country
					LEFT JOIN FX_Rate FX2 ON PP.EFFECTIVE_DATE = FX2.EFFECTIVE_DATE
								AND coalesce(PT.Currency_Risk, FX.currency_code) = FX2.currency_code
					--DELETES
					LEFT JOIN Deletes del ON PP.primary_asset_id = del.primary_asset_id
								AND rtrim(WS.Fund) = rtrim(del.Portfolio_ID) 
								AND CASE WHEN PP.ASSET_CLASS = 'Real Estate' AND SS_CUSIP_1 IS NOT NULL
									THEN SS_CUSIP_1
									ELSE coalesce(OPB_Mellon_ID, SS_CUSIP_1, SS_CUSIP_2) END = del.Accounting_Fund_ID
			where	del.PRIMARY_ASSET_ID is null     --this excludes delete records

			union

			select	 Effective_Date
					,Portfolio_ID
					,Dynamo_Fund_ID
					,Accounting_Fund_ID
					,Private_Mkt_Fund
					,NULL as Dynamo_Fund_Name
					,Private_Mkt_Fund_Name
					,NULL as POSITION_ID
					,NULL as Position_Underlying_ID
					,PRIMARY_ASSET_ID
					,PRIMARY_ASSET_ID_TYPE
					,Private_Mkt_Asset_ID
					,NULL as Accounting_Asset_ID
					,Private_Mkt_Asset_Class as Asset_Class
					,NULL as Investment_Structure
					,Private_Mkt_Investment_Vehicle
					,NULL as Asset_Class_Accounting
					,NULL as Asset_Type
					,Private_Mkt_Asset_Type
					,Private_Mkt_Asset_Name as Asset_Name
					,Private_Mkt_Asset_Name
					,Issuer_Name
					,NULL as Region
					,Private_Mkt_Region
					,NULL as Sector_1
					,Private_Mkt_Sector
					,Country_Risk
					,Currency_Risk
					,Currency_Fund
					,NULL as Revenue_Source
					,Private_Mkt_Revenue_Source
					,NULL as Risk_Strategy
					,Private_Mkt_Risk_Strategy
					,NULL as Partner
					,Private_Mkt_Partner
					,NULL as Leverage
					,Private_Mkt_Leverage
					,Sector_2
					,IMCO_Instrument
					,Market_Value
					,Market_Value_Local
					,GICS_INDUSTRY_GROUP
					,Market_Value_Currency_Risk
					,Private_Mkt_Country
					,Private_Mkt_Currency
					,Exposure_Scalar
					,Income_Risk_Exposure_Scalar
					,Metro_Area
					,Number_of_Assets
					,Property_Subtype
					,Property_Type_and_Region
					,Specific_Risk_Scalar
					,Instrument_Type
					,PE_Common_Factor_Risk_Scalar
					,PE_Investment_Type
					,PE_Public_Proxy
					,Proxy_Identifier
					,Proxy_Identifier_Type
					,Price_Proxy
					,Proxy_Notional

			from	Manual_Position_Tag
			where	PRIMARY_ASSET_ID_TYPE = 'USER'


			--delete existing aggregate
			delete from [EDW_BUS].[Aggr_Private_Market_Position_Tag]
			where Effective_Date = CONVERT(CHAR(8), @Effective_Date, 112);

			
			--insert new records
			INSERT INTO [EDW_BUS].[Aggr_Private_Market_Position_Tag]
			   (
				 Effective_Date
				,Portfolio_ID
				,Dynamo_Fund_ID
				,Accounting_Fund_ID
				,Private_Mkt_Fund
				,Dynamo_Fund_Name
				,Private_Mkt_Fund_Name
				,POSITION_ID
				,Position_Underlying_ID
				,PRIMARY_ASSET_ID
				,PRIMARY_ASSET_ID_TYPE
				,Private_Mkt_Asset_ID
				,Accounting_Asset_ID
				,Asset_Class
				,Investment_Structure
				,Private_Mkt_Investment_Vehicle
				,Asset_Class_Accounting
				,Asset_Type
				,Private_Mkt_Asset_Type
				,Asset_Name
				,Private_Mkt_Asset_Name
				,Issuer_Name
				,Region
				,Private_Mkt_Region
				,Sector_1
				,Private_Mkt_Sector
				,Country_Risk
				,Currency_Risk
				,Currency_Fund
				,Revenue_Source
				,Private_Mkt_Revenue_Source
				,Risk_Strategy
				,Private_Mkt_Risk_Strategy
				,Partner
				,Private_Mkt_Partner
				,Leverage
				,Private_Mkt_Leverage
				,Sector_2
				,IMCO_Instrument
				,Market_Value
				,Market_Value_Local
				,GICS_INDUSTRY_GROUP
				,Market_Value_Currency_Risk

				,IMCO_Country
				,Currency
				,Exposure_Scalar
				,Income_Risk_Exposure_Scalar
				,Metro_Area
				,Number_of_Assets
				,Property_Subtype
				,Property_Type_and_Region
				,Specific_Risk_Scalar
				,Instrument_Type
				,PE_Common_Factor_Risk_Scalar
				,PE_Investment_Type
				,PE_Public_Proxy
				,Proxy_Identifier
				,Proxy_Identifier_Type
				,Price_Proxy
				,Proxy_Notional

			   --,[Other_Info]
			   ,Load_DTS
			   ,[Hash_Diff]
			   ,[ETL_Load_Key]
			   ,Is_Src_Deleted
			   )

			 Select	 Effective_Date
					,Portfolio_ID
					,Dynamo_Fund_ID
					,Accounting_Fund_ID
					,Private_Mkt_Fund
					,Dynamo_Fund_Name
					,Private_Mkt_Fund_Name
					,POSITION_ID
					,Position_Underlying_ID
					,PRIMARY_ASSET_ID
					,PRIMARY_ASSET_ID_TYPE
					,Private_Mkt_Asset_ID
					,Accounting_Asset_ID
					,Asset_Class
					,Investment_Structure
					,Private_Mkt_Investment_Vehicle
					,Asset_Class_Accounting
					,Asset_Type
					,Private_Mkt_Asset_Type
					,Asset_Name
					,Private_Mkt_Asset_Name
					,Issuer_Name
					,Region
					,Private_Mkt_Region
					,Sector_1
					,Private_Mkt_Sector
					,Country_Risk
					,Currency_Risk
					,Currency_Fund
					,Revenue_Source
					,Private_Mkt_Revenue_Source
					,Risk_Strategy
					,Private_Mkt_Risk_Strategy
					,Partner
					,Private_Mkt_Partner
					,Leverage
					,Private_Mkt_Leverage
					,Sector_2
					,IMCO_Instrument
					,Market_Value
					,Market_Value_Local
					,GICS_INDUSTRY_GROUP
					,cast(Market_Value_Currency_Risk as decimal(28,12))
					,Private_Mkt_Country as IMCO_Country
					,Private_Mkt_Currency as Currency
					,Exposure_Scalar
					,Income_Risk_Exposure_Scalar
					,Metro_Area
					,Number_of_Assets
					,Property_Subtype
					,Property_Type_and_Region
					,Specific_Risk_Scalar
					,Instrument_Type
					,PE_Common_Factor_Risk_Scalar
					,PE_Investment_Type
					,PE_Public_Proxy
					,Proxy_Identifier
					,Proxy_Identifier_Type
					,Price_Proxy
					,Proxy_Notional
					,@today
					,Null Hash_Diff
					,@ETL_Load_Key
					,0

			From	#private_position_tag


			Select @rowsInserted = Count(*) 
			From [EDW_BUS].[Aggr_Private_Market_Position_Tag]
			Where Load_DTS = @today and Is_Src_Deleted = 0



			Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, '[EDW_BUS].[Aggr_Private_Market_Position_Tag]', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, '[EDW_BUS].[Aggr_Private_Market_Position_Tag]', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END