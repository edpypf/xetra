﻿CREATE PROC [EDW_BUS].[Factset_TrueValue_All_sub_Category_Score] @ETL_LOAD_KEY [INT],@Load_Type [VARCHAR],@Batch_DTS [DATETIME2] AS 

BEGIN

	--commented this line for CDC
   --DELETE FROM [EDW_BUS].[Aggr_Factset_TruValue_All_Sub_Category_Score]
   --where convert(date,[Effective_Date]) >= Convert(date,DATEADD(MM,-3,GETDATE()))

   --Variable declaration
   DECLARE @indx INT,
	    @totalRows INT,
		@indxCursor INT,
		@indxColumn VARCHAR(255),
		@hashDiffSubString VARCHAR(max),
		@SQL_HashDiff VARCHAR(MAX),
		@SQL_Query NVARCHAR(MAX),
		@SQL_Insert NVARCHAR(MAX),
		@SQL_Update NVARCHAR(MAX),
		@today datetime2 = getdate(),
		@columns VARCHAR(max)
	-- Variable declaration End

	DECLARE @rowsInserted INT = 0,
			@rowsUpdated INT = 0,
			@rowsExpired INT = 0


	BEGIN TRY

   --Temp table to store column names
   IF OBJECT_ID('tempdb..#temp_hash_diff_columns') IS NOT NULL DROP TABLE #temp_hash_diff_columns
   CREATE TABLE #temp_hash_diff_columns
   WITH
   (
		HEAP,  
		DISTRIBUTION = ROUND_ROBIN
	)
	AS 

	SELECT column_Name, ROW_NUMBER() OVER (ORDER BY column_Name) rn
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE TABLE_NAME = N'Aggr_Factset_TruValue_All_Sub_Category_Score'
	   AND TABLE_SCHEMA='EDW_BUS' AND column_Name NOT IN ('Load_dts' ,'Hash_Diff' ,'Is_Src_Deleted','ETL_Load_Key')


	--Create column string for hash key
	
	SELECT @totalRows = COUNT(*) FROM #temp_hash_diff_columns
	
	SELECT @indx = 1, @indxCursor = 0
	
	SELECT @SQL_HashDiff = ''

	IF @totalRows > 0
	BEGIN
	WHILE @indx <=  @totalRows
	BEGIN
		
		SELECT @hashDiffSubString = 'UPPER(CONCAT(' + STRING_AGG(Column_Name, ', ''|'' ,') + '))',
	           @columns = STRING_AGG(Column_Name, ',')
		FROM #temp_hash_diff_columns
		WHERE rn >=@indx AND rn < @indx + 100 
		
		SELECT @indx = @indx + 100
		

			IF @SQL_HashDiff = ''
				SELECT @SQL_HashDiff = @hashDiffSubString
			ELSE
				SELECT @SQL_HashDiff =@SQL_HashDiff + ',' +  @hashDiffSubString

			SELECT @indxCursor = @indxCursor + 1

		END

		IF @indxCursor > 1 
		SELECT @SQL_HashDiff = 'CONCAT( ' + @SQL_HashDiff + ')'
	END

	
	--Temporary table to stage Aggr_Factset_TruValue_All_Sub_Category_Score

	IF OBJECT_ID('tempdb..#temp_Aggr_Factset_TruValue_All_Sub_Category_Score') IS NOT NULL 
	DROP TABLE #temp_Aggr_Factset_TruValue_All_Sub_Category_Score
  

	SELECT DISTINCT 
		-- effective date --
		p.tv_date AS effective_date, 

		-- key identifier to link with MSCI ACWI Constituents --
		isin.isin AS isin, 
        
		-- Pulse all category score --
		ROUND(p.all_categories_pulse, 2) AS pulse_all_categories_score

		-- Pulse Sub Category Scores START --
		,ROUND(p.[materiality_pulse], 2) AS pulse_materiality
		,ROUND(p.[access_afford_pulse], 2) AS  pulse_access_afford
		,ROUND(p.[air_quality_pulse], 2) AS pulse_air_quality
		,ROUND(p.[business_ethics_pulse], 2) AS pulse_business_ethics
		,ROUND(p.[business_model_pulse], 2) AS pulse_business_model
		,ROUND(p.[competitive_pulse], 2) AS pulse_competitive
		,ROUND(p.[critical_risk_pulse], 2) AS pulse_critical_risk
		,ROUND(p.[customer_priv_pulse], 2) AS pulse_customer_priv
		,ROUND(p.[customer_welfare_pulse], 2) AS pulse_customer_welfare
		,ROUND(p.[data_security_pulse], 2) AS pulse_data_security
		,ROUND(p.[ecological_pulse], 2) AS pulse_ecological
		,ROUND(p.[employee_engagement_pulse], 2) AS pulse_employee_engagement
		,ROUND(p.[employee_health_pulse], 2) AS pulse_employee_health
		,ROUND(p.[energy_pulse], 2) AS pulse_energy
		,ROUND(p.[ghg_emissions_pulse], 2) AS pulse_ghg_emissions
		,ROUND(p.[human_rights_pulse], 2) AS pulse_human_rights
		,ROUND(p.[labor_practices_pulse], 2) AS pulse_labor_practices
		,ROUND(p.[legal_regulation_pulse], 2) AS pulse_legal_regulation
		,ROUND(p.[material_sourcing_pulse], 2) AS pulse_material_sourcing
		,ROUND(p.[climate_change_pulse], 2) AS pulse_climate_change
		,ROUND(p.[product_lifecycle_pulse], 2) AS pulse_product_lifecycle
		,ROUND(p.[product_quality_pulse], 2) AS pulse_product_quality
		,ROUND(p.[selling_practices_pulse], 2) AS pulse_selling_practices
		,ROUND(p.[supply_chain_pulse], 2) AS pulse_supply_chain
		,ROUND(p.[systematic_risk_pulse], 2) AS pulse_systematic_risk
		,ROUND(p.[hazardous_materials_pulse], 2) AS pulse_hazardous_materials
		,ROUND(p.[water_wastewater_pulse], 2) AS pulse_water_wastewater
		-- Pulse Sub Category Scores END --

		-- ESG Rank Table START --
		,ROUND(esg.all_categories_adj_insight, 2) AS esg_rank_all_categories_adjusted_insight_score

		,ROUND(esg.all_categories_ind_pctl, 2) AS esg_rank_all_categories_ind_pctl
		,esg.all_categories_esg_rank AS esg_rank_all_categories_esg_rank
		,ROUND(esg.materiality_adj_insight, 2) AS esg_rank_materiality_adj_insight
		,ROUND(esg.materiality_ind_pctl, 2) AS esg_rank_materiality_ind_pctl
		,esg.materiality_esg_rank AS esg_rank_materiality_esg_rank
		-- ESG Rank Table END --

		-- Momentum All Category Scores START --
		,ROUND(m.all_categories_momentum, 2) AS momentum_all_categories_score
		-- Momentum All Category Scores END --

		-- Momentum Sub Category Scores START --
		,ROUND(m.materiality_momentum, 2) AS momentum_materiality
		,ROUND(m.access_afford_momentum, 2) AS momentum_access_afford
		,ROUND(m.air_quality_momentum, 2) AS momentum_air_quality
		,ROUND(m.business_ethics_momentum, 2) AS momentum_business_ethics
		,ROUND(m.business_model_momentum, 2) AS momentum_business_model
		,ROUND(m.competitive_momentum, 2) AS momentum_competitive
		,ROUND(m.critical_risk_momentum, 2) AS momentum_critical_risk
		,ROUND(m.customer_priv_momentum, 2) AS momentum_customer_priv
		,ROUND(m.customer_welfare_momentum, 2) AS momentum_customer_welfare
		,ROUND(m.data_security_momentum, 2) AS momentum_data_security
		,ROUND(m.ecological_momentum, 2) AS momentum_ecological
		,ROUND(m.employee_engagement_momentum, 2) AS momentum_employee_engagement
		,ROUND(m.employee_health_momentum, 2) AS momentum_employee_health
		,ROUND(m.energy_momentum, 2) AS momentum_energy
		,ROUND(m.ghg_emissions_momentum, 2) AS momentum_ghg_emissions
		,ROUND(m.human_rights_momentum, 2) AS momentum_human_rights
		,ROUND(m.labor_practices_momentum, 2) AS momentum_labor_practices
		,ROUND(m.legal_regulation_momentum, 2) AS momentum_legal_regulation
		,ROUND(m.material_sourcing_momentum, 2) AS momentum_material_sourcing
		,ROUND(m.climate_change_momentum, 2) AS momentum_climate_change
		,ROUND(m.product_lifecycle_momentum, 2) AS momentum_product_lifecycle
		,ROUND(m.product_quality_momentum, 2) AS momentum_product_quality
		,ROUND(m.selling_practices_momentum, 2) AS momentum_selling_practices
		,ROUND(m.supply_chain_momentum, 2) AS momentum_supply_chain
		,ROUND(m.systematic_risk_momentum, 2) AS momentum_systematic_risk
		,ROUND(m.hazardous_materials_momentum, 2) AS momentum_hazardous_materials
		,ROUND(m.water_wastewater_momentum, 2) AS momentum_water_wastewater
		-- Momentum Sub Category Scores END --

		-- Volume All Category Scores START --
		,v.all_categories_articlevol AS volume_all_categories_article_volume 
		-- Volume All Category Scores END --


		-- Volume Sub Category Scores START --
		,v.materiality_catvol AS volume_materiality_category_volume
		,v.materiality_articlevol AS volume_materiality_article_volume
		,v.access_afford_catvol AS volume_access_afford_category_volume
		,v.air_quality_catvol AS volume_air_quality_category_volume
		,v.business_ethics_catvol AS volume_business_ethics_category_volume
		,v.business_model_catvol AS volume_business_model_category_volume
		,v.competitive_catvol AS volume_competitive_category_volume
		,v.critical_risk_catvol AS volume_critical_risk_category_volume
		,v.customer_priv_catvol AS volume_customer_priv_category_volume
		,v.customer_welfare_catvol AS volume_customer_welfare_category_volume
		,v.data_security_catvol AS volume_data_security_category_volume
		,v.ecological_catvol AS volume_ecological_category_volume
		,v.employee_engagement_catvol AS volume_employee_engagement_category_volume
		,v.employee_health_catvol AS volume_employee_health_category_volume
		,v.energy_catvol AS volume_energy_category_volume
		,v.ghg_emissions_catvol AS volume_ghg_emissions_category_volume
		,v.human_rights_catvol AS volume_human_rights_category_volume
		,v.labor_practices_catvol AS volume_labor_practices_category_volume
		,v.legal_regulation_catvol AS volume_legal_regulation_category_volume
		,v.material_sourcing_catvol AS volume_material_sourcing_category_volume
		,v.climate_change_catvol AS volume_climate_change_category_volume
		,v.product_lifecycle_catvol AS volume_product_lifecycle_category_volume
		,v.product_quality_catvol AS volume_product_quality_category_volume
		,v.selling_practices_catvol AS volume_selling_practices_category_volume
		,v.supply_chain_catvol AS volume_supply_chain_category_volume
		,v.systematic_risk_catvol AS volume_systematic_risk_category_volume
		,v.hazardous_materials_catvol AS volume_hazardous_materials_category_volume
		,v.water_wastewater_catvol AS volume_water_wastewater_category_volume
		-- Volume Sub Category Scores END --
		INTO #temp_Aggr_Factset_TruValue_All_Sub_Category_Score
		FROM 
			-- standard joins between symbology tables and truvalue tables
			[PSA].[V_Factset_Sym_Isin] AS isin 
			JOIN [PSA].[V_Factset_Sym_Coverage] AS cov ON isin.fsym_id = cov.fsym_id 
			JOIN [PSA].[V_Factset_Tv_Sec_Entity_Hist] AS id ON id.fsym_id = cov.fsym_security_id 
			JOIN [PSA].[V_Factset_Tv_Factset_Id_Map] AS idm ON idm.factset_id = id.factset_entity_id 
		
			-- linking with pulse, insight, momentum and volume tables:
			JOIN  (SELECT * FROM [PSA].[V_Factset_Tv_Pulse] WHERE CONVERT(DATE,tv_date) >= CONVERT(DATE,DATEADD(DAY,-14,GETDATE()))
				AND  CONVERT(DATE,tv_date)< CONVERT(DATE,GETDATE()) ) AS p ON p.tv_org_id = idm.provider_id 
			JOIN  [PSA].[V_Factset_Tv_Esg_Ranks] esg ON esg.tv_org_id = idm.provider_id AND esg.tv_date = p.tv_date 
			JOIN  [PSA].[V_Factset_Tv_Momentum] AS m ON m.tv_org_id = idm.provider_id AND m.tv_date = p.tv_date 
			JOIN  [PSA].[V_Factset_Tv_Volume] AS v on v.tv_org_id = idm.provider_id AND v.tv_date = p.tv_date 

		WHERE  
			(
			-- make sure get the latest/valid/live ISINs:
			(id.end_date is null and p.tv_date >= id.start_date)
			-- or include any expired/old ISIN for the period when the ISINs were still live:
			or (id.end_date is not null and p.tv_date <= id.end_date and p.tv_date >= id.start_date ) 
			) 
		

		--CDC
		SELECT @SQL_Insert = 'INSERT INTO EDW_BUS.Aggr_Factset_TruValue_All_Sub_Category_Score ('+@columns+', Load_dts ,Hash_Diff ,Is_Src_Deleted, ETL_Load_Key)'
		+' SELECT '+@columns+', Load_DTS , Hash_Diff , Is_Src_Deleted , ETL_Load_Key FROM '+
		' (' +'SELECT ' + @columns +  ' , ' +''''+ CAST(@today AS VARCHAR(15)) +''' AS Load_DTS,' + 
			'CONVERT(VARCHAR(64), HASHBYTES(''SHA1'', '+@SQL_HashDiff+'), 2) Hash_Diff'+','+' 0 AS Is_Src_Deleted,'+''''+ CAST(@ETL_LOAD_KEY AS VARCHAR(30)) + ''' AS ETL_Load_Key  
			FROM #temp_Aggr_Factset_TruValue_All_Sub_Category_Score  ) STG 
				WHERE NOT EXISTS ( SELECT 1 FROM EDW_BUS.Aggr_Factset_TruValue_All_Sub_Category_Score TGT
					   WHERE STG.Hash_Diff = TGT.Hash_Diff AND TGT.Is_Src_Deleted = 0 )
		
		UPDATE tgt
			SET Is_Src_Deleted = 1,
			Load_dts = '+''''+ CAST(@today AS VARCHAR(15)) + '''  ,
			ETL_Load_Key = '+''''+ CAST(@ETL_LOAD_KEY AS VARCHAR(30)) + ''' 
		FROM EDW_BUS.Aggr_Factset_TruValue_All_Sub_Category_Score tgt
		WHERE NOT EXISTS
		 (SELECT 1 FROM #temp_Aggr_Factset_TruValue_All_Sub_Category_Score  WHERE effective_date = tgt.effective_date 
		   AND COALESCE(CONVERT(VARCHAR(64), HASHBYTES(''SHA1'', '+@SQL_HashDiff+'), 2),'''') = COALESCE(tgt.Hash_Diff,'''') 	  
		  )
		  AND tgt.effective_date >= Convert(date,DATEADD(DAY,-14,GETDATE())) AND tgt.Is_Src_Deleted = 0 
		 '
		 
		-- Execute CDC Select statement
		EXEC sp_executesql @SQL_Insert


		SELECT @rowsInserted = COUNT(*) 
		FROM [EDW_BUS].[Aggr_Factset_TruValue_All_Sub_Category_Score]
		WHERE [Load_dts] = @today and [Is_Src_Deleted] = 0

		SELECT @rowsExpired = COUNT(*)
		FROM [EDW_BUS].[Aggr_Factset_TruValue_All_Sub_Category_Score]
		WHERE [Load_dts] = @today and [Is_Src_Deleted] = 1

		SELECT @rowsUpdated = @rowsExpired

		EXEC [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.Factset_TrueValue_All_sub_Category_Score', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		--Drop temporary table created
		DROP TABLE #temp_hash_diff_columns

		END TRY 

		BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.Factset_TrueValue_All_sub_Category_Score', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState
		
	END CATCH

END