﻿CREATE PROC [EDW_BUS].[AIM_Aggr_Trade_History_Report] @ETL_Load_Key [bigint],@Load_Type [VARCHAR](200),@Batch_DTS [VARCHAR](100) AS


-- EXEC [EDW_BUS].[AIM_Aggr_Trade_History_Report] 1,NULL,'2023-02-24'
-- DECLARE @Batch_DTS [VARCHAR](100) = '1900-01-01'

IF CONVERT(DATE,@Batch_DTS) = '1900-01-01'
BEGIN
	Set @Batch_DTS = CASE DATEPART(weekday, CONVERT(DATE,GETDATE(),23)) 
					WHEN 1 THEN Dateadd(day, -2 , CONVERT(DATE,GETDATE(),23)) -- Sunday > Friday
					WHEN 2 THEN Dateadd(day, -3 , CONVERT(DATE,GETDATE(),23)) -- Monday > Friday
					ELSE Dateadd(day, -1 , CONVERT(DATE,GETDATE(),23)) -- Tuesday - Saturday 
					END
END;

DECLARE @Next_Working_Day DATE;

SET @Next_Working_Day = CASE DATEPART(weekday, CONVERT(DATE,@Batch_DTS,23)) 
					WHEN 6 THEN Dateadd(day, 3 , CONVERT(DATE,@Batch_DTS,23)) -- Friday > Next Monday
					WHEN 7 THEN Dateadd(day, 2 , CONVERT(DATE,@Batch_DTS,23)) -- Saturday > Next Monday
					ELSE Dateadd(day, 1 , CONVERT(DATE,@Batch_DTS,23)) -- Sunday - Thursday 
					END;

-- SELECT * FROM EDW_BUS.Aggr_AIM_Repo_Exposure WHERE [ExtractDate] = '2023-02-24'
DELETE FROM EDW_BUS.Aggr_AIM_Repo_Exposure
WHERE [ExtractDate] = @Batch_DTS;

WITH CTE_1 AS (
SELECT *
FROM EDW_RAW.V_AIM_Trade_History_Report A
WHERE [TBLT] IN  ('RT','CRT')
AND TrdDt =  @Next_Working_Day
),
CTE_2 AS (
SELECT * 
FROM EDW_RAW.V_AIM_Bond_Position_Feed B
WHERE B.ExtractDate = @Batch_DTS
),
CTE_3 AS (
SELECT [Dealer], [ShortName], [TicketNumber], [MasterTk], [TBLT], [Cusip], [AmountPennies], [TrdDt], [StlDate], [TrmDate], [RepoRt], [Price], [Haircut], [CRCY], Accrued4Repo = ISNULL(Accrued4Repo,0), [Trader], [LoanAmount], [UnadjTermMoney], [AccrInt], [RepurchaseAgre], [LongDescription], [Tra],AsOfDt
,MarketPrice = B.MarketValue/B.ParAmountOfPosition --Calculation 1
,DirtyMarketPrice = (B.MarketValue + B.AccruedInterestAmount)/ParAmountOfPosition --Calculation 2
,[SecurityIdentifierFlag], [SecurityIdentifierCUSIP], [BondIssueDate], [BondMaturityDate], [BondCouponRate], [AIMAccount], [ParAmountOfPosition], [MarketValue], [BidPrice], [SecurityDescription], [AccruedInterestFactor], [AccruedInterestAmount], [ISIN], [FIGI],ExtractDate,A.[ETL_Load_Key],A.[Last_Update_DT]
FROM CTE_1 A
LEFT OUTER JOIN CTE_2 B ON A.Cusip = B.SecurityIdentifierCUSIP
)
--SELECT * FROM CTE_3
INSERT INTO EDW_BUS.Aggr_AIM_Repo_Exposure
SELECT [Dealer], [ShortName], [TicketNumber], [MasterTk], [TBLT], [Cusip], [AmountPennies], [TrdDt], [StlDate], [TrmDate], [RepoRt], [Price], [Haircut], [CRCY], [Accrued4Repo]                        , [Trader], [LoanAmount], [UnadjTermMoney], [AccrInt], [RepurchaseAgre], [LongDescription], [Tra],AsOfDt
	, MarketPrice
	, DirtyMarketPrice

	, UnderlyingCollateralMV = CASE WHEN [Haircut] IS NOT NULL THEN AmountPennies*DirtyMarketPrice*(100-Haircut)/100
									WHEN [Haircut] IS     NULL THEN AmountPennies*DirtyMarketPrice
									END -- Calculation 3

	, NetMV = NULL 
	, NetMVMarginCCY = NULL
	,[SecurityIdentifierFlag], [SecurityIdentifierCUSIP], [BondIssueDate], [BondMaturityDate], [BondCouponRate], [AIMAccount], [ParAmountOfPosition], [MarketValue], [BidPrice], [SecurityDescription], [AccruedInterestFactor], [AccruedInterestAmount], [ISIN], [FIGI]
	, RepoCUSIP = NULL
	,ExtractDate= @Batch_DTS
	,RepoMoney = LoanAmount
	,RepoTerminationAmount = UnadjTermMoney
	,MVwithFinancingAccrual =  LoanAmount + Accrued4Repo
	,[ETL_Load_Key]
	,[Last_Update_DT]
FROM CTE_3;

-- Calculation 4
UPDATE EDW_BUS.Aggr_AIM_Repo_Exposure SET 
NetMV = CASE 
	WHEN Tra = 'RP' THEN UnderlyingCollateralMV - (LoanAmount + Accrued4Repo)
	WHEN Tra = 'RR' THEN (LoanAmount + Accrued4Repo) - UnderlyingCollateralMV
	ELSE 0
	END
WHERE ExtractDate = @Batch_DTS;

--Calculation 5
UPDATE EDW_BUS.Aggr_AIM_Repo_Exposure SET 
NetMVMarginCCY = CASE
	WHEN Crcy = 'CAD' THEN NetMV
	WHEN Crcy = 'USD' THEN NetMV / SPOT_RATE
	ELSE 0
	END
-- SELECT *
FROM EDW_BUS.Aggr_AIM_Repo_Exposure A
JOIN 
(
SELECT EFFECTIVE_DATE, SPOT_RATE 
FROM [PSA].[V_Eagle_FX_Rates]
WHERE SECURITY_ALIAS =  27 -- CAD 
AND FROM_SECALIAS = 153 -- USD
) B ON B.EFFECTIVE_DATE = CASE WHEN A.TrdDt > ExtractDate THEN A.ExtractDate
								ELSE A.TrdDt END
AND A.[ExtractDate] = @Batch_DTS

-- Calculation 6
UPDATE EDW_BUS.Aggr_AIM_Repo_Exposure SET RepoCUSIP = b.Cusip
FROM EDW_BUS.Aggr_AIM_Repo_Exposure a
JOIN EDW_RAW.AIM_Trade_History_Report b on a.MasterTk = b.[TicketNumber]
WHERE b.TBLT IN ('ARC','CAR')
AND a.TBLT IN ('RT','CRT')
AND [ExtractDate] = @Batch_DTS;

-- SELECT * FROM [EDW_Mart].[AIM_Treasury_Repo_Exposure_Report] where ExtractDate = '2023-02-22'