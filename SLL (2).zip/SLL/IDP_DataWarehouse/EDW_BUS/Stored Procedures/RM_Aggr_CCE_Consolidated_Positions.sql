﻿CREATE PROC [EDW_BUS].[RM_Aggr_CCE_Consolidated_Positions] @ETL_LOAD_KEY [INT],@Load_Type [VARCHAR],@Batch_DTS [DATETIME2] AS
BEGIN



	DECLARE @effectiveDate DATE
	SET  @effectiveDate = @Batch_DTS

	DECLARE @rowsInserted INT = 0,
			@rowsCount INT = 0,
			@today datetime2 = getdate(),
			@rows int,
			@Business_Area varchar(255)= 'RISK',
			@Affected_Source_System varchar(255)= 'SQL_RISK_ETL'

 BEGIN TRY

		--Set effective date to T-1 or last business day
		IF @effectiveDate IS NOT NULL AND DATEDIFF(day, '1900-01-01', @effectiveDate) <> 0
		BEGIN
			SELECT @effectiveDate  = @effectiveDate 
		END
		ELSE
		BEGIN
			
			SELECT @effectiveDate = CASE DATEPART(WEEKDAY, GETDATE()) WHEN 2 THEN DATEADD(DAY, -3 , GETDATE()) ELSE DATEADD(DAY, -1 , GETDATE()) END

			SELECT @rows = count(Holiday_Date) FROM [EDW_ETL].[User_Holiday_Calendar]
			WHERE DATEDIFF(day, Holiday_Date, @effectiveDate) = 0
				AND Business_Area = @Business_Area and Affected_System = @Affected_Source_System

			WHILE @rows > 0
			BEGIN
				-- get previous business date
				SELECT @effectiveDate = CASE DATEPART(WEEKDAY, @effectiveDate) WHEN 2 THEN DATEADD(DAY, -3 , @effectiveDate) ELSE DATEADD(DAY, -1 , @effectiveDate) END

				SELECT @rows = count(Holiday_Date) FROM EDW_ETL.User_Holiday_Calendar
				WHERE DATEDIFF(day, Holiday_Date, @effectiveDate) = 0
					AND Business_Area = @Business_Area and Affected_System = @Affected_Source_System

			END
		END


	--Clean up consolidated view if holding date already exists 	
	SELECT @rowsCount = COUNT(1) FROM [EDW_BUS].[Aggr_RM_CCE_Consolidated_Positions]
	WHERE HOLDING_DATE =@effectiveDate

	IF @rowsCount>1
	BEGIN
		DELETE FROM [EDW_BUS].[Aggr_RM_CCE_Consolidated_Positions] WHERE HOLDING_DATE =@effectiveDate
	END

	--OPB_FXForward
	;WITH HairCut As
	(
		SELECT mc.Netting_Set,SUM((1/Col1.Haircut)*ABS(Col1.Shares_Par_Value))/SUM(ABS(Col1.Shares_Par_Value)) AS Haircut 
		FROM EDW_RAW.V_OTC_Counterparty_Exposure_Collateral_Mapping_Data Col1
		, PSA.V_Manual_Collateral_Mapping mc 
		WHERE Col1.Agreement=MC.Agreement 
			AND MC.Type='COLLATERAL'		
			AND Col1.As_Of_Date BETWEEN mc.START_DT AND isnull (mc.END_DT,Col1.As_Of_Date) 
			AND Col1.As_Of_Date=@effectiveDate
			AND Collateral_Linked_Instrument_Category='OTC Derivatives' GROUP BY mc.Netting_Set
	),
	VALUATION_ENTITY AS
	(
		SELECT  DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME
				, gm.Account_Number AS ACCOUNT_NUMBER
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm
			INNER JOIN [EDW_Raw].[V_OTC_Counterparty_Exposure_FXForward] fd ON gm.Account_Number = fd.Account_Number 
				AND fd.effective_date BETWEEN GM.START_DT AND ISNULL(gm.end_dt,fd.effective_date) 
		WHERE fd.effective_date= @effectiveDate
	),
	OPB_FXForward AS 
	(
		SELECT DISTINCT FORMAT(c.effective_date,'yyyyMMdd') AS HOLDING_DATE
			, CONCAT(c.Account_Number,'_CCE') AS ACCOUNT_ID         
			, c.ACCOUNT_NAME AS  ACCOUNT_DESCRIPTION       
			, c.Base_Currency_Code AS ACCOUNT_BASE_CURRENCY              
			, 'FX Forward' AS ASSET_CLASS
			, 'FX Forward' AS ASSET_TYPE
			, CONCAT(c.Paybl_CCY,'2',c.Rcvbl_CCY,'_FWD_',FORMAT(c.Contractual_Settlement_date,'yyyyMMdd'))  AS ASSET_NAME
			, c.Lot_ID AS PRIMARY_ASSET_ID
			, 'LOCALID' AS PRIMARY_ASSET_ID_TYPE
			, Rcvbl_Units  AS NUMBER_OF_SHARES
			, Rcvbl_Units AS NOTIONAL_AMOUNT
			, (c.PayBL_BASE_UNREAL_GAIN_LOSS + c.RCVBL_BASE_UNREAL_GAIN_LOSS) AS BASE_MARKET_VALUE
			, (c.PayBL_BASE_UNREAL_GAIN_LOSS + c.RCVBL_BASE_UNREAL_GAIN_LOSS) AS BASE_NET_ASSET_VALUE  			
			, NULL AS LOCAL_MARKET_VALUE
			, NULL AS LOCAL_NET_ASSET_VALUE  
			, 'CAD' AS BASE_MARKET_VALUE_CURRENCY			
			, c.Rcvbl_CCY AS LOCAL_MARKET_VALUE_CURRENCY   
			, NULL AS ASSET_PRICE_DATE
			, NULL AS ASSET_PRICE
			, NULL AS ASSET_PRICE_CURRENCY
			, NULL AS SEDOL
			, NULL AS CUSIP
			, NULL AS ISIN
			, NULL AS TICKER
			, NULL AS SECCDPRMY 
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE 
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE 
			, NULL AS DP_ASSET_TYPE 
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',cpty_mapping.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cpty_mapping.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				';CCEPositionID;',C.Account_Number,
				'-',C.Lot_ID,
				'-FXFwd;CDMS_MarginingHaircut;',(1-HC.Haircut)) AS  BUCKET_LIST
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cpty_mapping.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cpty_mapping.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cpty_mapping.IMCO_Counterparty_Name,
				'-',GM.Grouping) AS TRANSACTION_TERM
			, NULL AS START_DATE
			, FORMAT(c.Contractual_Settlement_date,'yyyyMMdd') AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, 1 AS CONTRACT_SIZE
			, -1*c.Trade_Price AS EXCHANGE_RATE
			, c.Paybl_CCY AS QUOTE_CURRENCY
			, c.Rcvbl_CCY AS CURRENCY
			, NULL AS UNDERLIER_ID
			, NULL AS UNDERLIER_ID_TYPE
			, NULL AS AMOUNT_ISSUED
			, NULL AS REPO_TYPE
			, NULL AS REPO_RATE
			, NULL AS SALE_DATE
			, NULL AS REPURCHASE_DATE
			, NULL AS [COUNTRY]
			, NULL AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cpty_mapping.IMCO_Counterparty_Name+gm.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, NULL AS ISCOLLATERAL
		FROM [EDW_Raw].[V_OTC_Counterparty_Exposure_FXForward] c        
			LEFT JOIN  [PSA].[V_Manual_Counterparty_Mapping] cpty_mapping ON c.executing_broker_code = cpty_mapping.broker_code 
					AND cpty_mapping.INVESTMENT_TYPE = 'FWD' 
					AND UPPER(cpty_mapping.CLIENT)= 'OPB' 
					AND c.effective_date BETWEEN cpty_mapping.START_DT AND ISNULL(cpty_mapping.END_DT,c.Effective_Date)
					AND c.executing_broker_code IS NOT NULL
			LEFT JOIN VALUATION_ENTITY VE ON VE.Account_Number = c.Account_Number
			LEFT JOIN [PSA].[V_Manual_GroupingNS_Mapping] gm ON gm.COUNTERPARTY_ENTITY=cpty_mapping.IMCO_Counterparty_Name			
					AND gm.Type='FWD' 
					AND gm.ACCOUNT_Number = c.Account_Number 
					AND VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME = gm.Valuation_Entity 
					AND c.effective_date BETWEEN gm.START_DT AND ISNULL(gm.end_dt,c.Effective_Date)
			LEFT JOIN HairCut HC ON HC.Netting_set = CONCAT(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,'-',cpty_mapping.IMCO_Counterparty_Name,'-',GM.Grouping)
			WHERE c.effective_date = @effectiveDate
				 AND (DATEDIFF(DAY,trade_date , contractual_settlement_date)+1 -  DATEDIFF(WEEK,trade_date,contractual_settlement_date)*2) >3	
	),
	--OPB_SecLending
	VALUATION_ENTITY_SECLANDING_OPB AS
	(	
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME, s.CustodyAcctNumber 
		FROM  [PSA].[V_Manual_GroupingNS_Mapping] gm, 
			[EDW_Raw].[V_Security_Lending_Detail_Collateral_by_Manager_Data] S,
			[PSA].[V_Eagle_Entity_Xreference] RE 
		WHERE S.ReportDate BETWEEN GM.START_DT AND ISNULL (GM.END_DT,S.ReportDate) 
			AND S.ReportDate=@effectiveDate 
			AND s.CustodyAcctNumber = RE.xref_account_id
			AND RE.ENTITY_ID=GM.Account_Number

	),
	OPB_SecLending AS
	(	SELECT DISTINCT 
			FORMAT(sl.ReportDate,'yyyyMMdd') AS HOLDING_DATE   
			,CONCAT((SELECT ref.Entity_Id FROM [PSA].[V_Eagle_ENTITY_XREFERENCE] ref 
					WHERE ref.Entity_Id = XREF.ENTITY_ID AND ref.Xref_Account_Id_Type = 'STAR'),'_CCE') AS  ACCOUNT_ID
			, sl.CustodyAcctName as ACCOUNT_DESCRIPTION
			, 'CAD' AS ACCOUNT_BASE_CURRENCY
			, 'Sec Lending' AS ASSET_CLASS
			, 'Sec Lending' AS ASSET_TYPE
			, sl.SecurityDescription  AS ASSET_NAME
			, CONCAT(sl.IsinNum,'-Sec Lending-OPB') AS PRIMARY_ASSET_ID 
			, 'ISIN' AS PRIMARY_ASSET_ID_TYPE
			, sl.LoanQuantity AS NUMBER_OF_SHARES
			, sl.LoanQuantity AS NOTIONAL_AMOUNT
			, NULL AS BASE_MARKET_VALUE
			, NULL AS BASE_NET_ASSET_VALUE
			, NULL AS LOCAL_MARKET_VALUE 
			, NULL AS LOCAL_NET_ASSET_VALUE 
			, NULL AS BASE_MARKET_VALUE_CURRENCY 
			, NULL AS LOCAL_MARKET_VALUE_CURRENCY		   
			, NULL AS ASSET_PRICE_DATE		
			, NULL AS ASSET_PRICE		
			, NULL AS ASSET_PRICE_CURRENCY		
			, NULL AS SEDOL
			, NULL AS CUSIP
			, sl.IsinNum AS ISIN
			, NULL AS TICKER	
			, NULL AS SECCDPRMY		
			, NULL AS WEIGHT		
			, NULL AS BASE_ACCRUED_INCOME_VALUE		
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE		
			, NULL AS DP_ASSET_TYPE		
			, NULL AS RIC
			, NULL AS RED_CODE		
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				';CCEPositionID;',(SELECT REF.Entity_Id FROM [PSA].[V_Eagle_Entity_Xreference] REF WHERE REF.Entity_Id = XREF.ENTITY_ID AND REF.Xref_Account_Id_Type = 'STAR'),
				'-',SL.SecurityID,
				'_',LoanID,'-SecLend;CDMS_MarginingHaircut;-0.05') AS BUCKET_LIST
			,CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cm.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				CASE WHEN ISNULL(SL.TermDate,'') ='' THEN '' ELSE CONCAT(';MaturityDate^',ISNULL(FORMAT(SL.TermDate,'yyyyMMdd'),'')) END ) AS TRANSACTION_TERM			
			, NULL AS START_DATE
			, NULL AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, NULL AS CONTRACT_SIZE
			, NULL AS EXCHANGE_RATE
			, NULL AS QUOTE_CURRENCY
			, NULL AS CURRENCY
			, NULL AS UNDERLIER_ID
			, NULL AS UNDERLIER_ID_TYPE
			, NULL AS AMOUNT_ISSUED
			, NULL AS REPO_TYPE
			, NULL AS REPO_RATE
			, NULL AS SALE_DATE
			, NULL AS REPURCHASE_DATE
			, NULL AS [COUNTRY]
			, NULL AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cm.IMCO_Counterparty_Name+GM.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, NULL AS ISCOLLATERAL
		FROM [EDW_Raw].[V_Security_Lending_Detail_Collateral_by_Manager_Data]  sl 
			INNER JOIN [PSA].[V_Eagle_ENTITY_XREFERENCE] xref on sl.CustodyAcctNumber = xref.xref_account_id
			LEFT JOIN [PSA].[V_Manual_Counterparty_Mapping] cm on cm.INVESTMENT_TYPE = 'SEC LENDING' 
				AND cm.Client='OPB' 
				AND sl.ReportDate BETWEEN cm.START_DT AND ISNULL (cm.END_DT,SL.ReportDate)
			LEFT JOIN VALUATION_ENTITY_SECLANDING_OPB ve on VE.CustodyAcctNumber=sl.CustodyAcctNumber
			LEFT JOIN [PSA].[V_Manual_GroupingNS_Mapping] gm on gm.COUNTERPARTY_ENTITY=cm.IMCO_Counterparty_Name 
				AND gm.Type='SecLend' 
				AND GM.Account_Number IN (SELECT REF.Entity_Id FROM [PSA].[V_Eagle_ENTITY_XREFERENCE] REF WHERE REF.Entity_Id = XREF.ENTITY_ID AND REF.Xref_Account_Id_Type = 'STAR')
				AND ve.TRANSACTION_TERMS_VALUATION_ENTITY_NAME=gm.Valuation_Entity 
				AND sl.ReportDate between gm.START_DT and isnull (gm.END_DT,SL.ReportDate)
		WHERE sl.LoanQuantity <> 0   
			AND sl.ReportDate = @effectiveDate
	),
	--OPB_Repo
	VALUATION_ENTITY_REPO AS
	(
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME
			, gm.Account_Number AS ACCOUNT_NUMBER
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm
		INNER JOIN [EDW_Raw].[V_OTC_Counterparty_Exposure_Repo] rd ON gm.Account_Number = rd.Account_Number 
			AND rd.effective_date BETWEEN gm.START_DT AND ISNULL(gm.END_DT,rd.Effective_Date) 
			AND rd.effective_date = @effectiveDate
	),
	OPB_Repo AS
	(
		SELECT DISTINCT 
			FORMAT(r.Effective_Date,'yyyyMMdd') AS HOLDING_DATE   
			, CONCAT(r.Account_Number,'_CCE') AS  ACCOUNT_ID
			, r.Account_Name AS ACCOUNT_DESCRIPTION
			, r.Base_Currency_Code AS ACCOUNT_BASE_CURRENCY
			, 'Repo' AS ASSET_CLASS
			, 'Repo' AS ASSET_TYPE
			, r.Security_Description  AS ASSET_NAME
			,CONCAT(r.Primary_Security_ID,'-Repo-OPB') AS PRIMARY_ASSET_ID 
			, 'CUSIP' AS PRIMARY_ASSET_ID_TYPE 			
			, CASE WHEN r.Security_Description  LIKE 'RREPO%' THEN -1 ELSE 1 END AS NUMBER_OF_SHARES
			, CASE WHEN r.Security_Description  LIKE 'RREPO%' THEN -1 ELSE 1 END AS NOTIONAL_AMOUNT
			, Market_Value_Base AS BASE_MARKET_VALUE
			, Market_Value_Base AS BASE_NET_ASSET_VALUE
			, Market_Value_Local AS LOCAL_MARKET_VALUE
			, Market_Value_Local AS LOCAL_NET_ASSET_VALUE
			, CASE WHEN BASE_CURRENCY_CODE = NULL THEN 'CAD' ELSE BASE_CURRENCY_CODE END AS BASE_MARKET_VALUE_CURRENCY
			, CASE WHEN BASE_CURRENCY_CODE = NULL THEN 'CAD' ELSE BASE_CURRENCY_CODE END AS LOCAL_MARKET_VALUE_CURRENCY 
			, NULL AS ASSET_PRICE_DATE
			, NULL AS ASSET_PRICE
			, NULL AS ASSET_PRICE_CURRENCY
			, NULL AS SEDOL
			, NULL AS CUSIP
			, NULL AS ISIN
			, NULL AS TICKER
			, NULL AS SECCDPRMY
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE
			, NULL AS DP_ASSET_TYPE
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,';CCEPositionID;',
				CONCAT(r.Account_Number,'-',r.Primary_Security_ID,'-Repo;CDMS_MarginingHaircut;',(1-HC.Haircut))) AS  BUCKET_LIST
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cm.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping) as TRANSACTION_TERM
			, NULL AS START_DATE
			, FORMAT(r.Maturity_Date,'yyyyMMdd') AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, 1 AS CONTRACT_SIZE
			, NULL AS EXCHANGE_RATE
			, NULL AS QUOTE_CURRENCY
			, r.local_Currency_Code	AS CURRENCY
			, SUBSTRING(r.Security_Description,
					 CHARINDEX('_', r.Security_Description)+1,
					 CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)-CHARINDEX('_', r.Security_Description)-1) AS UNDERLIER_ID
			, 'CUSIP' AS UNDERLIER_ID_TYPE
			, ABS (r.Shares_Par)  AS AMOUNT_ISSUED
			, 'CLASSIC' AS	REPO_TYPE
			, r.Coupon_Rate AS REPO_RATE
			, r.Issue_Date AS SALE_DATE
			, FORMAT(r.Maturity_Date,'yyyyMMdd') AS REPURCHASE_DATE
			, CASE WHEN r.local_Currency_Code='CAD' THEN 'CAN' 
				WHEN r.local_Currency_Code='USD' THEN 'USA' 
				ELSE NULL END AS [COUNTRY]
			, 100 AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cm.IMCO_Counterparty_Name+GM.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, NULL AS ISCOLLATERAL
		FROM [EDW_Raw].[V_OTC_Counterparty_Exposure_Repo] r 
			LEFT JOIN [PSA].[V_Manual_Counterparty_Mapping] cm ON TRIM(r.Executing_Broker_Code) = TRIM(cm.BROKER_CODE) 
					AND cm.Investment_Type = 'REPO' 
					AND upper(cm.CLIENT)= 'OPB' 
					AND (r.effective_date BETWEEN cm.START_DT AND ISNULL(cm.END_DT,r.effective_date))
			LEFT JOIN VALUATION_ENTITY_REPO ve on ve.Account_Number=r.Account_Number
			LEFT JOIN [PSA].[V_Manual_GroupingNS_Mapping] gm ON gm.COUNTERPARTY_ENTITY=cm.IMCO_Counterparty_Name 
					AND gm.Type='Repo' 
					AND gm.Account_Number=r.Account_Number 
					AND ve.TRANSACTION_TERMS_VALUATION_ENTITY_NAME=gm.Valuation_Entity
					AND (r.effective_date BETWEEN gm.START_DT AND ISNULL(gm.END_DT,r.effective_date))
			LEFT JOIN HairCut HC ON HC.Netting_set=CONCAT(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,'-',cm.IMCO_Counterparty_Name,'-',GM.Grouping)
		WHERE r.Shares_Par <> 0 AND UPPER(r.security_type) = 'REPO' AND r.effective_date=@effectiveDate
	),	
	--OPB_ILB
	VALUATION_ENTITY_OPB_ILB AS
	(
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME
			, gm.Account_Number AS ACCOUNT_NUMBER 
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm
		INNER JOIN [EDW_Raw].[V_OTC_Counterparty_Exposure_Repo] rd ON gm.Account_Number = rd.Account_Number 
			AND rd.effective_date BETWEEN gm.START_DT AND ISNULL (gm.END_DT,rd.Effective_Date) 
			AND rd.Effective_Date=@effectiveDate
	),
	OPB_ILB AS
	(
		SELECT  DISTINCT 
			FORMAT(r.Effective_Date,'yyyyMMdd')  as HOLDING_DATE   
			, CONCAT(r.Account_Number,'_CCE') as  ACCOUNT_ID
			, r.Account_Name as ACCOUNT_DESCRIPTION
			, r.Base_Currency_Code AS ACCOUNT_BASE_CURRENCY
			, 'Fixed Income' AS ASSET_CLASS
			, 'Fixed Income' AS ASSET_TYPE
			,SUBSTRING(r.Security_Description,
                 CHARINDEX('_', r.Security_Description)+1,
                 CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)-CHARINDEX('_', r.Security_Description)-1)  AS ASSET_NAME
			, CONCAT(SUBSTRING(r.Security_Description,
                 CHARINDEX('_', r.Security_Description)+1,
                 CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)-CHARINDEX('_', r.Security_Description)-1),'-Fixed Income-OPB') AS PRIMARY_ASSET_ID 
			, 'CUSIP' AS PRIMARY_ASSET_ID_TYPE 
			,  CASE WHEN Security_Description Like 'RREPO%' THEN SUBSTRING(r.Security_Description,
																CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)+1,
																LEN(r.Security_Description)-CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1))
				   ELSE 
				   -1*convert(int,SUBSTRING(r.Security_Description,CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)+1,
							LEN(r.Security_Description)-CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)))
				    END
				   AS NUMBER_OF_SHARES
			, CASE WHEN Security_Description Like 'RREPO%' THEN SUBSTRING(r.Security_Description,CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)+1,
																LEN(r.Security_Description)-CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)) 
					 ELSE 
					 -1*convert(int,SUBSTRING(r.Security_Description,
					 CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)+1,
					 LEN(r.Security_Description)-CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)))
					 END AS NOTIONAL_AMOUNT				
			, NULL AS BASE_MARKET_VALUE	
			, NULL AS BASE_NET_ASSET_VALUE		
			, NULL AS LOCAL_MARKET_VALUE		
			, NULL AS LOCAL_NET_ASSET_VALUE		
			, CASE WHEN BASE_CURRENCY_CODE = NULL THEN 'CAD' ELSE BASE_CURRENCY_CODE END AS BASE_MARKET_VALUE_CURRENCY 
			, CASE WHEN LOCAL_CURRENCY_CODE = NULL THEN 'CAD' ELSE LOCAL_CURRENCY_CODE END AS LOCAL_MARKET_VALUE_CURRENCY
			, NULL AS ASSET_PRICE_DATE
			, NULL AS ASSET_PRICE
			, NULL AS ASSET_PRICE_CURRENCY
			, NULL AS SEDOL
			, SUBSTRING(r.Security_Description,
                 CHARINDEX('_', r.Security_Description)+1,
                 CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)-CHARINDEX('_', r.Security_Description)-1) AS CUSIP
			, NULL AS ISIN
			, NULL AS TICKER
			, NULL AS SECCDPRMY
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE
			, NULL AS DP_ASSET_TYPE
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				';CCEPositionID;',CONCAT(r.Account_Number,'-',SUBSTRING(r.Security_Description, CHARINDEX('_', r.Security_Description)+1,
					CHARINDEX('_', r.Security_Description,CHARINDEX('_', r.Security_Description)+1)-CHARINDEX('_', r.Security_Description)-1),
				'_',r.Primary_Security_ID,
				'-Repo;CDMS_MarginingHaircut;',(1-HC.Haircut)))  AS BUCKET_LIST		
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cm.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				CASE WHEN ISNULL(r.Maturity_Date,'') ='' THEN '' ELSE CONCAT(';MaturityDate^',FORMAT(r.Maturity_Date,'yyyyMMdd')) END) AS TRANSACTION_TERM			
			, NULL AS START_DATE
			, NULL AS MATURITY_DATE	
			, NULL AS STRIKE_PRICE	
			, NULL AS CONTRACT_SIZE
			, NULL AS EXCHANGE_RATE
			, NULL AS QUOTE_CURRENCY		
			, NULL AS CURRENCY		
			, NULL AS UNDERLIER_ID		
			, NULL AS UNDERLIER_ID_TYPE		
			, NULL AS AMOUNT_ISSUED		
			, NULL AS REPO_TYPE		
			, NULL AS REPO_RATE		
			, NULL AS SALE_DATE		
			, NULL AS REPURCHASE_DATE
			, NULL AS [COUNTRY]
			, NULL AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cm.IMCO_Counterparty_Name+GM.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, NULL AS ISCOLLATERAL
		FROM [EDW_Raw].[V_OTC_Counterparty_Exposure_Repo] r 
			LEFT JOIN [PSA].[V_Manual_Counterparty_Mapping] cm ON TRIM(r.Executing_Broker_Code) = TRIM(cm.BROKER_CODE) 
				AND cm.Investment_Type = 'REPO' 
				AND UPPER(cm.CLIENT)= 'OPB'
				AND (r.effective_date BETWEEN cm.START_DT AND ISNULL(cm.END_DT,r.effective_date))
			LEFT JOIN  VALUATION_ENTITY_OPB_ILB ve ON ve.Account_Number=r.Account_Number
			LEFT JOIN  [PSA].[V_Manual_GroupingNS_Mapping] gm ON gm.COUNTERPARTY_ENTITY=cm.IMCO_Counterparty_Name 
				AND gm.Type='Repo' 
				AND gm.Account_Number=r.Account_Number 
				AND ve.TRANSACTION_TERMS_VALUATION_ENTITY_NAME=gm.Valuation_Entity
			LEFT JOIN HairCut HC ON HC.Netting_set=CONCAT(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,'-',cm.IMCO_Counterparty_Name,'-',GM.Grouping)
		WHERE r.Shares_Par <> 0 
			AND UPPER(r.security_type) = 'REPO' 
			AND r.effective_date=@effectiveDate
	),	
	--OPB_OTC_Collateral
	VALUATION_ENTITY_OTC_COLLATERAL AS
	(
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME
			, gm.Account_Number AS ACCOUNT_NUMBER
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm
			INNER JOIN [EDW_Raw].[V_OTC_Counterparty_Exposure_Collateral_Mapping_Data] rd ON gm.Account_Number = rd.Account 
				AND rd.As_of_date BETWEEN GM.START_DT AND ISNULL(gm.END_DT,rd.As_of_date) 
				AND rd.As_of_date=@effectiveDate
	),
	--Account description added as per the request from DM on 2023-06-05
	Account_Desc AS
	(
		SELECT DISTINCT Account_Number, Account_Name AS Account_Description 
			FROM [EDW_Raw].[V_OTC_Counterparty_Exposure_FXForward] WHERE effective_date = @effectiveDate AND DATEDIFF(dd,trade_date , contractual_settlement_date)+1 -  DATEDIFF(wk,trade_date , contractual_settlement_date)*2 > 3
		UNION
		SELECT DISTINCT (SELECT REF.Entity_Id FROM [PSA].[Eagle_Entity_Xreference] REF WHERE REF.Entity_Id = XREF.ENTITY_ID AND REF.Xref_Account_Id_Type = 'STAR') AS Account_Number, SL.CustodyAcctName as Account_Description 
			FROM [EDW_Raw].[V_Security_Lending_Detail_Collateral_by_Manager_Data] SL
			INNER JOIN [PSA].[Eagle_Entity_Xreference] xref ON sl.CustodyAcctNumber = xref.xref_account_id WHERE SL.LoanQuantity <> 0 AND SL.ReportDate = @effectiveDate
		UNION
		SELECT DISTINCT Account_Number, Account_Name AS Account_Description 
			FROM [EDW_Raw].[V_OTC_Counterparty_Exposure_Repo] where Shares_Par <> 0 AND upper(security_type) = 'REPO' and effective_date=@effectiveDate
		UNION
		SELECT DISTINCT (SELECT REF.Entity_Id FROM [PSA].[Eagle_Entity_Xreference] REF WHERE REF.Entity_Id = XREF.ENTITY_ID AND REF.Xref_Account_Id_Type = 'STAR') AS Account_Number, sld.CustodyAcctName AS Account_Description 
			FROM [EDW_Raw].[V_OTC_Counterparty_Exposure_Collateral_Mapping_Data] cmd
			INNER JOIN [PSA].[Eagle_Entity_Xreference] xref ON cmd.Account = xref.xref_account_id
			LEFT JOIN [EDW_Raw].[V_Security_Lending_Detail_Collateral_by_Manager_Data] sld ON cmd.Account = sld.CustodyAcctNumber AND cmd.as_of_date = sld.ReportDate
				WHERE cmd.shares_par_value <> 0 AND cmd.as_of_date = @effectiveDate and UPPER(cmd.Collateral_Linked_Instrument_Category) = 'SEC LENDING'
		UNION
		SELECT DISTINCT Fund AS Account_Number, Fund_Name AS Account_Description 
			FROM PSA.V_StateStreet_FX_Forward_Report WHERE Effective_Date = @effectiveDate and fx_type='F'
		UNION
		SELECT DISTINCT Fund_Short_ID AS Account_Number, Fund_External_Name AS Account_Description 
			FROM [EDW_Raw].[V_WSIB_Sec_Lending_Daily_Loans_Earnings] WHERE CONVERT(DATE,As_Of_Date) = CONVERT(DATE,@effectiveDate)
		UNION
		SELECT DISTINCT BANK_ACCOUNT_NUMBER AS Account_Number, BANK_ACCOUNT_NUMBER AS Account_Description 
			FROM [EDW_Raw].[V_WSIB_Nisa_Trades] NT WHERE UPPER(TRIM(NT.TRANS_TYPE) )= 'INITIATION' AND @effectiveDate >= NT.TRADE_DATE     -- parameter
					AND @effectiveDate < NT.TERMINATION_DATE -- parameter
				AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) IN (SELECT Portfolio_ID FROM [PSA].[V_Manual_Portfolio_Groups] WHERE group_name = 'WSIB Accounting Position Split' AND @effectiveDate BETWEEN start_date and end_Date) --parameter
				AND NT.REPO_CUSIP NOT IN (SELECT DISTINCT REPO_CUSIP FROM EDW_Raw.V_WSIB_Nisa_Trades NT	WHERE UPPER(TRIM(NT.REPO_TYPE)) IN ('REVERSE REPO','REPO')
				AND UPPER(TRIM(NT.TRANS_TYPE) )IN ( 'CANCEL' , 'RESIZE','MATURITY')
				AND @effectiveDate >= TRADE_DATE     -- parameter
		AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) IN (SELECT Portfolio_ID FROM [PSA].[V_Manual_Portfolio_Groups] where group_name = 'WSIB Accounting Position Split' and @effectiveDate between start_date and end_Date))
		UNION
		SELECT DISTINCT Fund_Short_ID AS Account_Number, Fund_External_Name AS Account_Description 
			FROM [EDW_Raw].[V_WSIB_Detail_Non_Cash_Collateral] sl WHERE  sl.Record_Type ='COLLATERAL' AND CONVERT(date,sl.As_of_Date) = CONVERT(DATE,@effectiveDate)
	),
	OPB_OTC_Collateral AS
	(
		SELECT DISTINCT 
			FORMAT(cm.As_of_date,'yyyyMMdd')  AS HOLDING_DATE   
			, CONCAT(cm.Account,'_CCE') as  ACCOUNT_ID
			--, cm.[Account Description] as ACCOUNT_DESCRIPTION
			, COALESCE(ad.Account_Description,cm.Account) as ACCOUNT_DESCRIPTION
			, 'CAD' AS ACCOUNT_BASE_CURRENCY
			, 'Cash' AS ASSET_CLASS
			, 'Cash' AS ASSET_TYPE
			, cm.Security_Description AS ASSET_NAME
			, 'CAD' AS PRIMARY_ASSET_ID
			, 'LOCALID' AS PRIMARY_ASSET_ID_TYPE
			, -1*cm.Shares_Par_value AS NUMBER_OF_SHARES 
			, -1*cm.Shares_Par_value AS NOTIONAL_AMOUNT
			, cm.Shares_Par_value AS BASE_MARKET_VALUE
			, cm.Shares_Par_value AS BASE_NET_ASSET_VALUE
			, NULL AS LOCAL_MARKET_VALUE 
			, NULL AS LOCAL_NET_ASSET_VALUE 
			, 'CAD'	AS BASE_MARKET_VALUE_CURRENCY
			, 'CAD'	AS LOCAL_MARKET_VALUE_CURRENCY
			, NULL AS ASSET_PRICE_DATE
			, NULL AS ASSET_PRICE
			, NULL AS ASSET_PRICE_CURRENCY
			, NULL AS SEDOL
			, NULL AS CUSIP
			, NULL AS ISIN
			, NULL AS TICKER
			, NULL AS SECCDPRMY
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE
			, NULL AS DP_ASSET_TYPE
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME
			,';CounterpartyEntityName;',cpty_mapping.IMCO_Counterparty_Name,
			';NettingSetTermsName;',MCM.Netting_Set,
			';CCEPositionID;',CONCAT(cm.Account,'-',cm.CUSIP,'-',cm.Agreement,'-Coll')) AS BUCKET_LIST
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cpty_mapping.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cpty_mapping.IMCO_Counterparty_Name,
				';NettingSetTermsName^',MCM.Netting_Set) AS TRANSACTION_TERM
			, NULL AS START_DATE
			, NULL AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, NULL AS CONTRACT_SIZE
			, NULL AS EXCHANGE_RATE
			, NULL AS QUOTE_CURRENCY
			, NULL AS CURRENCY
			, NULL AS UNDERLIER_ID
			, NULL AS UNDERLIER_ID_TYPE
			, NULL AS AMOUNT_ISSUED
			, NULL AS REPO_TYPE
			, NULL AS REPO_RATE
			, NULL AS SALE_DATE
			, NULL AS REPURCHASE_DATE
			, NULL AS [COUNTRY]
			, NULL AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cpty_mapping.IMCO_Counterparty_Name+MCM.Netting_Set)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, 'TRUE' AS ISCOLLATERAL
		FROM [EDW_Raw].[V_OTC_Counterparty_Exposure_Collateral_Mapping_Data] cm
			LEFT JOIN  [PSA].[V_Manual_Counterparty_Mapping] cpty_mapping ON UPPER(cm.Broker) = UPPER(cpty_mapping.COUNTERPARTY_NAME) 
				AND cpty_mapping.INVESTMENT_TYPE = 'COLLATERAL' 
				AND upper(cpty_mapping.CLIENT)= 'OPB' 
				AND cm.as_of_date BETWEEN cpty_mapping.START_DT AND  ISNULL(cpty_mapping.END_DT,cm.as_of_date)
			LEFT JOIN   [EDW_Raw].[V_OTC_Counterparty_Exposure_Collateral_Data] cd ON cm.cusip = cd.Xref_Security_ID 
				AND cm.shares_par_value = cd.SharesPar_Custody  
				AND cm.as_of_date = cd.as_of_date 
			LEFT JOIN   VALUATION_ENTITY_OTC_COLLATERAL ve ON ve.Account_Number=cm.Account
			LEFT JOIN   [PSA].[V_Manual_Collateral_Mapping] mcm ON mcm.Agreement=cm.Agreement 
				AND mcm.Type='COLLATERAL' 
				AND cm.as_of_date BETWEEN mcm.START_DT and ISNULL (mcm.END_DT,cm.as_of_date)
			LEFT JOIN  Account_Desc ad on ad.Account_Number=cm.Account
		WHERE  cm.shares_par_value <> 0   
			AND cm.as_of_date = @effectiveDate
			AND UPPER(cm.Collateral_Linked_Instrument_Category)='OTC DERIVATIVES'
	),	
	--OPB_Recvd_Collateral
	VALUATION_ENTITY_COLLATERAL AS
	(			
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME, rd.Account 
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm, 
			[EDW_Raw].[V_OTC_Counterparty_Exposure_Collateral_Mapping_Data] rd, 
			[PSA].[V_Eagle_ENTITY_XREFERENCE] RE 
		WHERE gm.Account_Number = RE.Entity_ID 
			AND rd.As_of_date BETWEEN GM.START_DT AND isnull (GM.END_DT,rd.As_of_date) 
			AND rd.As_of_date=@effectiveDate
			AND RE.xref_account_id=rd.Account

	),
	OPB_Recvd_Collateral AS
	(
		SELECT DISTINCT 
			FORMAT(cmd.As_of_date,'yyyyMMdd') AS HOLDING_DATE   
			, CONCAT((SELECT REF.Entity_Id FROM [PSA].[V_Eagle_ENTITY_XREFERENCE] REF 
							WHERE REF.Entity_Id = XREF.ENTITY_ID AND REF.Xref_Account_Id_Type = 'STAR'),'_CCE') AS  ACCOUNT_ID
			, sld.CustodyAcctName as ACCOUNT_DESCRIPTION		
			, 'CAD' AS ACCOUNT_BASE_CURRENCY 
			, 'Received Collateral' AS ASSET_CLASS
			, 'Received Collateral' AS ASSET_TYPE
			, cmd.Security_Description  AS ASSET_NAME
			, CONCAT(cmd.ISIN,'-Received Collateral-OPB-',cmd.Security_Description) AS PRIMARY_ASSET_ID 
			, 'ISIN' AS PRIMARY_ASSET_ID_TYPE 
			, -1*cmd.Shares_Par_value AS NUMBER_OF_SHARES
			, -1*cmd.Shares_Par_value AS NOTIONAL_AMOUNT
			, -1*cmd.Shares_Par_value AS BASE_MARKET_VALUE
			, -1*cmd.Shares_Par_value  AS BASE_NET_ASSET_VALUE
			, NULL AS  LOCAL_MARKET_VALUE
			, NULL AS LOCAL_NET_ASSET_VALUE
			, 'CAD' AS BASE_MARKET_VALUE_CURRENCY 
			, NULL AS LOCAL_MARKET_VALUE_CURRENCY 
			, NULL AS ASSET_PRICE_DATE
			, NULL AS ASSET_PRICE
			, NULL AS ASSET_PRICE_CURRENCY
			, NULL AS SEDOL
			, NULL AS CUSIP
			, cmd.ISIN as ISIN
			, NULL AS TICKER
			, NULL AS SECCDPRMY
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE
			, NULL AS DP_ASSET_TYPE
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				';CCEPositionID;',CONCAT((SELECT REF.Entity_Id FROM [PSA].[V_Eagle_ENTITY_XREFERENCE] REF WHERE REF.Entity_Id = XREF.ENTITY_ID 
						AND REF.Xref_Account_Id_Type = 'STAR'),
				'-',cmd.ISIN,'-SLColl'))  AS BUCKET_LIST
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cm.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping) AS TRANSACTION_TERM
			, NULL AS START_DATE
			, NULL AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, NULL AS CONTRACT_SIZE
			, NULL AS EXCHANGE_RATE
			, NULL AS QUOTE_CURRENCY
			, NULL AS CURRENCY
			, NULL AS UNDERLIER_ID
			, NULL AS UNDERLIER_ID_TYPE
			, NULL AS AMOUNT_ISSUED
			, NULL AS REPO_TYPE
			, NULL AS REPO_RATE
			, NULL AS SALE_DATE
			, NULL AS REPURCHASE_DATE
			, NULL AS [COUNTRY]
			, NULL AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cm.IMCO_Counterparty_Name+GM.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, 'TRUE' AS ISCOLLATERAL
		FROM [EDW_Raw].[V_OTC_Counterparty_Exposure_Collateral_Mapping_Data] cmd
			INNER JOIN [PSA].[V_Eagle_ENTITY_XREFERENCE] xref ON cmd.Account = xref.xref_account_id 
			LEFT JOIN [EDW_Raw].[V_Security_Lending_Detail_Collateral_by_Manager_Data] sld ON cmd.Account = sld.CustodyAcctNumber 
				AND cmd.as_of_date = sld.ReportDate
			LEFT JOIN  [PSA].[V_Manual_Counterparty_Mapping] cm ON cm.INVESTMENT_TYPE = 'REC COLLATERAL' 
				AND upper(cm.CLIENT)= 'OPB' 
				AND (cmd.As_of_date BETWEEN cm.START_DT AND ISNULL(cm.END_DT,cmd.As_of_date))
			LEFT JOIN  VALUATION_ENTITY_COLLATERAL ve ON ve.Account=cmd.Account
			LEFT JOIN  [PSA].[V_Manual_GroupingNS_Mapping] gm ON GM.COUNTERPARTY_ENTITY=cm.IMCO_Counterparty_Name 
				AND gm.Type='REC COLLATERAL' 
				and GM.Account_Number IN (SELECT REF.Entity_Id FROM [PSA].[V_Eagle_ENTITY_XREFERENCE] REF WHERE REF.Entity_Id = XREF.ENTITY_ID AND REF.Xref_Account_Id_Type = 'STAR') 
				AND ve.TRANSACTION_TERMS_VALUATION_ENTITY_NAME=gm.Valuation_Entity
		WHERE cmd.shares_par_value <> 0   
			AND cmd.as_of_date = @effectiveDate
			AND UPPER(cmd.Collateral_Linked_Instrument_Category) = 'SEC LENDING'
	),
	--WSIB_FXForward
	VALUATION_ENTITY_FXFORWARD AS
	(
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME
			, gm.Account_Number AS ACCOUNT_NUMBER 
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm 
			INNER JOIN PSA.V_StateStreet_FX_Forward_Report rd ON  gm.Account_Number = rd.Fund 
				AND rd.effective_date BETWEEN gm.START_DT AND ISNULL(gm.END_DT,rd.Effective_Date) 
				AND rd.Effective_Date = @effectiveDate
	),
	WSIB_FXForward AS
	(
		SELECT DISTINCT 
			 FORMAT(ac.Effective_Date ,'yyyyMMdd') AS HOLDING_DATE   
			, CONCAT(Fund,'_CCE') AS  ACCOUNT_ID
			, fund_Name AS ACCOUNT_DESCRIPTION 
			, 'CAD' AS ACCOUNT_BASE_CURRENCY 
			, 'FX Forward' AS ASSET_CLASS 
			, 'FX Forward' AS ASSET_TYPE
			, CASE WHEN fx_buy_sell_ind ='B' THEN CONCAT('CAD','2',currency_bought,'_FWD_',FORMAT(Contractual_Settlement_Date,'yyyyMMdd'))  
				  ELSE CONCAT (currency_sold,'2','CAD','_FWD_',FORMAT(Contractual_Settlement_Date,'yyyyMMdd')) END AS  ASSET_NAME
			, Trade_ID AS PRIMARY_ASSET_ID 
			, 'LOCALID' AS PRIMARY_ASSET_ID_TYPE 
			, CASE WHEN fx_buy_sell_ind ='S' THEN Buy_Setup_Amount ELSE Amount_bought END AS  NUMBER_OF_SHARES 
			, CASE WHEN fx_buy_sell_ind ='S' THEN Buy_Setup_Amount ELSE Amount_bought END AS  NOTIONAL_AMOUNT
			, ISNULL(unrealized_gain_loss,0) AS BASE_MARKET_VALUE
			, ISNULL(unrealized_gain_loss,0) AS BASE_NET_ASSET_VALUE
			, NULL AS LOCAL_MARKET_VALUE
			, NULL AS LOCAL_NET_ASSET_VALUE
			, 'CAD' AS BASE_MARKET_VALUE_CURRENCY
			, CASE WHEN fx_buy_sell_ind ='B' THEN currency_bought ELSE currency_sold END AS LOCAL_MARKET_VALUE_CURRENCY
			, NULL AS ASSET_PRICE_DATE
			, NULL AS ASSET_PRICE
			, NULL AS ASSET_PRICE_CURRENCY
			, NULL AS SEDOL
			, NULL AS CUSIP
			, NULL AS ISIN
			, NULL AS TICKER
			, NULL AS SECCDPRMY
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE
			, NULL AS DP_ASSET_TYPE
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',cpty_mapping.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cpty_mapping.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				';CCEPositionID;',CONCAT(Fund,'-',Trade_ID,'-FXFwd;CDMS_MarginingHaircut;',(1-HC.Haircut))) AS BUCKET_LIST
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cpty_mapping.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cpty_mapping.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cpty_mapping.IMCO_Counterparty_Name,
				'-',GM.Grouping) AS TRANSACTION_TERM
			, NULL AS START_DATE
			, FORMAT(Contractual_Settlement_Date,'yyyyMMdd')  AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, 1 AS CONTRACT_SIZE
			, CASE WHEN FX_Buy_Sell_Ind = 'S' THEN Sell_Trade_Exchange_Rate ELSE 1/CAST(Buy_Trade_Exchange_Rate AS FLOAT) END AS EXCHANGE_RATE
			, Currency_Sold AS QUOTE_CURRENCY
			, Currency_Bought AS CURRENCY
			, NULL AS UNDERLIER_ID
			, NULL AS UNDERLIER_ID_TYPE
			, NULL AS AMOUNT_ISSUED
			, NULL AS REPO_TYPE
			, NULL AS REPO_RATE
			, NULL AS SALE_DATE
			, NULL AS REPURCHASE_DATE
			, NULL AS [COUNTRY]
			, NULL AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cpty_mapping.IMCO_Counterparty_Name+GM.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, NULL AS ISCOLLATERAL
		FROM PSA.V_StateStreet_FX_Forward_Report ac     
			LEFT JOIN  [PSA].[V_Manual_Counterparty_Mapping] cpty_mapping ON UPPER(ac.broker_name) = UPPER(cpty_mapping.COUNTERPARTY_NAME) 
				AND cpty_mapping.INVESTMENT_TYPE = 'FWD' 
				AND CLIENT ='WSIB'
				AND  CONVERT(VARCHAR, ac.Effective_Date, 112) BETWEEN  CONVERT(VARCHAR,cpty_mapping.START_DT , 112) AND ISNULL(CONVERT(VARCHAR,cpty_mapping.END_DT, 112) ,CONVERT(VARCHAR, ac.Effective_Date, 112))
			LEFT JOIN VALUATION_ENTITY_FXFORWARD ve ON ve.Account_Number=ac.Fund
			LEFT JOIN [PSA].[V_Manual_GroupingNS_Mapping] gm ON gm.COUNTERPARTY_ENTITY=cpty_mapping.IMCO_Counterparty_Name 
				AND gm.Type='FWD'
				AND gm.Account_Number=ac.Fund 
				AND ve.TRANSACTION_TERMS_VALUATION_ENTITY_NAME=gm.Valuation_Entity
			LEFT JOIN  HairCut HC ON HC.Netting_set=CONCAT(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,'-',cpty_mapping.IMCO_Counterparty_Name,'-',GM.Grouping)
		WHERE ac.Effective_Date = @effectiveDate
			AND ac.fx_type='F'
	),	
	--WSIB_SecLending
	VALUATION_ENTITY_SEC_LENDING_WSIB AS
	(
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME
			, gm.Account_Number AS ACCOUNT_NUMBER
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm
			INNER JOIN [EDW_Raw].[V_WSIB_Sec_Lending_Daily_Loans_Earnings] rd ON gm.Account_Number = rd.Fund_Short_ID 
				AND rd.As_Of_Date BETWEEN gm.START_DT AND ISNULL(gm.END_DT,rd.As_Of_Date) 
				AND rd.As_Of_Date = @effectiveDate
	),
	WSIB_SecLending AS
	(
		SELECT DISTINCT FORMAT(As_Of_Date,'yyyyMMdd') AS HOLDING_DATE
			, CONCAT(Fund_Short_ID,'_CCE') AS ACCOUNT_ID
			, Fund_External_Name AS ACCOUNT_DESCRIPTION 
			, 'CAD' AS ACCOUNT_BASE_CURRENCY
			, 'Sec Lending' AS ASSET_CLASS
			, 'Sec Lending' AS ASSET_TYPE
			, Security_Name AS ASSET_NAME
			, CONCAT(COALESCE([ISIN_ID],[CUSIP_ID],[SEDOL_ID],NULL),'-Sec Lending-WSIB')  AS PRIMARY_ASSET_ID
			, CASE WHEN [ISIN_ID] IS NOT NULL THEN 'ISIN'
					WHEN [CUSIP_ID] IS NOT NULL THEN 'CUSIP'
					WHEN [SEDOL_ID] IS NOT NULL THEN 'SEDOL'
					ELSE NULL END AS PRIMARY_ASSET_ID_TYPE 
			, ISNULL(Shares_on_Loan,0) AS NUMBER_OF_SHARES 
			, ISNULL(Shares_on_Loan,0) AS NOTIONAL_AMOUNT 
			, NULL AS BASE_MARKET_VALUE 
			, NULL AS BASE_NET_ASSET_VALUE 
			, NULL AS LOCAL_MARKET_VALUE 
			, NULL AS LOCAL_NET_ASSET_VALUE 
			,'CAD' AS BASE_MARKET_VALUE_CURRENCY
			, NULL AS LOCAL_MARKET_VALUE_CURRENCY 
			, NULL AS ASSET_PRICE_DATE 
			, NULL AS ASSET_PRICE 
			, NULL AS ASSET_PRICE_CURRENCY 
			, ISNULL([SEDOL_ID],'') AS SEDOL
			, ISNULL([CUSIP_ID],'') AS CUSIP
			, ISNULL([ISIN_ID],'') AS ISIN
			, NULL AS TICKER
			, NULL AS SECCDPRMY
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE
			, NULL AS DP_ASSET_TYPE
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				';CCEPositionID;',CONCAT(Fund_Short_ID,'-',COALESCE([ISIN_ID],[CUSIP_ID],[SEDOL_ID],NULL),
				'_',Loan_Alloc_Number,
				'-SecLend;CDMS_MarginingHaircut;-0.05')) AS BUCKET_LIST					
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cm.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping) AS TRANSACTION_TERM								
			, NULL AS START_DATE
			, NULL AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, NULL AS CONTRACT_SIZE
			, NULL AS EXCHANGE_RATE
			, NULL AS QUOTE_CURRENCY
			, NULL AS CURRENCY
			, NULL AS UNDERLIER_ID
			, NULL AS UNDERLIER_ID_TYPE
			, NULL AS AMOUNT_ISSUED
			, NULL AS REPO_TYPE
			, NULL AS REPO_RATE
			, NULL AS SALE_DATE
			, NULL AS REPURCHASE_DATE
			, NULL AS [COUNTRY]
			, NULL AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cm.IMCO_Counterparty_Name+GM.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, NULL AS ISCOLLATERAL
		FROM [EDW_Raw].[V_WSIB_Sec_Lending_Daily_Loans_Earnings] sl
			LEFT JOIN  [PSA].[V_Manual_Counterparty_Mapping] CM ON CM.INVESTMENT_TYPE = 'SEC LENDING' 
					AND CLIENT ='WSIB' 
					AND sl.as_of_date BETWEEN cm.START_DT AND ISNULL(cm.END_DT,sl.as_of_date)
			LEFT JOIN  VALUATION_ENTITY_SEC_LENDING_WSIB ve ON ve.Account_Number=sl.Fund_Short_ID
			LEFT JOIN  [PSA].[V_Manual_GroupingNS_Mapping] gm ON GM.COUNTERPARTY_ENTITY=cm.IMCO_Counterparty_Name 
				AND gm.Type='SecLend' 
				AND gm.Account_Number=SL.Fund_Short_ID 
				AND ve.TRANSACTION_TERMS_VALUATION_ENTITY_NAME=gm.Valuation_Entity
		WHERE CONVERT(DATE,sl.As_Of_Date) = CONVERT(DATE,@effectiveDate)
	),	
	--REPOTRADE_EXCLUSION_WSIB_REPO
	VALUATION_ENTITY_WSIB_REPO AS
	(
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME
			, gm.Account_Number  AS ACCOUNT_NUMBER
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm
			INNER JOIN  EDW_Raw.[V_WSIB_Nisa_Trades] rd ON gm.Account_Number = rd.BANK_ACCOUNT_NUMBER 
				AND @effectiveDate BETWEEN gm.START_DT AND ISNULL(gm.END_DT,@effectiveDate)
	),				
	REPOTRADE_EXCLUSION_WSIB_REPO AS
	(
			SELECT DISTINCT REPO_CUSIP
			FROM EDW_Raw.V_WSIB_Nisa_Trades NT
				WHERE UPPER(TRIM(NT.REPO_TYPE)) IN ('REVERSE REPO','REPO')
					AND UPPER(TRIM(NT.TRANS_TYPE) )IN ( 'CANCEL' , 'RESIZE','MATURITY') 
					AND @effectiveDate >= TRADE_DATE     
					AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) 
					IN (SELECT Portfolio_ID FROM [PSA].[V_Manual_Portfolio_Groups] 
							WHERE group_name = 'WSIB Accounting Position Split' AND @effectiveDate BETWEEN start_date AND end_Date) 
	),
	WSIB_REPO AS
	(
		SELECT DISTINCT  
			FORMAT(@effectiveDate,'yyyyMMdd')  AS HOLDING_DATE   
			, CONCAT(NT.BANK_ACCOUNT_NUMBER,'_CCE') AS  ACCOUNT_ID
			, NT.BANK_ACCOUNT_NUMBER AS ACCOUNT_DESCRIPTION
			, 'CAD' AS ACCOUNT_BASE_CURRENCY
			, 'Repo' AS ASSET_CLASS
			, 'Repo' AS ASSET_TYPE
			, CONCAT(CASE WHEN UPPER(TRIM(NT.REPO_TYPE)) = 'REVERSE REPO' THEN  'RREPO' ELSE 'REPO' END,'_',TRIM(NT.UNDERLYING_CUSIP),'_',NT.PAR_AMOUNT) AS ASSET_NAME
			, CONCAT(TRIM(NT.REPO_CUSIP),'-Repo-WSIB') AS PRIMARY_ASSET_ID
			, 'CUSIP' AS PRIMARY_ASSET_ID_TYPE
			, CASE WHEN REPO_TYPE='REVERSE REPO' THEN -1 ELSE 1  END AS NUMBER_OF_SHARES
			, CASE WHEN REPO_TYPE='REVERSE REPO' THEN -1 ELSE 1  END AS NOTIONAL_AMOUNT
			, NULL AS BASE_MARKET_VALUE
			, NULL AS BASE_NET_ASSET_VALUE
			, NULL AS LOCAL_MARKET_VALUE
			, NULL AS LOCAL_NET_ASSET_VALUE
			, 'CAD' AS BASE_MARKET_VALUE_CURRENCY 
			, NT.Currency AS LOCAL_MARKET_VALUE_CURRENCY
			, NULL AS ASSET_PRICE_DATE
			, NULL AS ASSET_PRICE
			, NULL AS ASSET_PRICE_CURRENCY
			, NULL AS SEDOL
			, NULL AS CUSIP
			, NULL AS ISIN
			, NULL AS TICKEr
			, NULL AS SECCDPRMY
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE
			, NULL AS DP_ASSET_TYPE
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				';CCEPositionID;',CONCAT(NT.BANK_ACCOUNT_NUMBER,'-',NT.REPO_CUSIP,'-Repo;CDMS_MarginingHaircut;',(1-HC.Haircut))) AS BUCKET_LIST	
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cm.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping) AS TRANSACTION_TERM 
			, NULL AS START_DATE
			, FORMAT(nt.TERMINATION_DATE,'yyyyMMdd') AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, 1  AS CONTRACT_SIZE
			, NULL AS EXCHANGE_RATE
			, NULL AS QUOTE_CURRENCY
			, nt.Currency AS CURRENCY
			, Underlying_CUSIP AS UNDERLIER_ID
			, 'CUSIP' AS UNDERLIER_ID_TYPE
			, ABS(Real_Settle_Money) AS AMOUNT_ISSUED
			, 'CLASSIC' AS Repo_Type
			, nt.Repo_Rate AS REPO_RATE
			, CASE WHEN Trans_Type='INITIATION' THEN FORMAT(Trade_Date,'yyyyMMdd')  ELSE '' END AS SALE_DATE
			, FORMAT(nt.Termination_Date,'yyyyMMdd') AS REPURCHASE_DATE
			, CASE WHEN Currency='CAD' THEN 'CAN'
					WHEN Currency='USD' THEN 'USA'
				ELSE NULL END  AS [COUNTRY]
			, 100 AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cm.IMCO_Counterparty_Name+GM.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, NULL AS ISCOLLATERAL
		FROM EDW_Raw.V_WSIB_Nisa_Trades NT  
			LEFT JOIN [PSA].[V_Manual_Counterparty_Mapping] CM ON NT.COUNTERPARTY = CM.COUNTERPARTY_NAME
					AND CM.Investment_Type = 'REPO'
					AND CM.Client ='WSIB'
					AND (@effectiveDate  BETWEEN CM.START_DT AND ISNULL(CM.END_DT,@effectiveDate))
			LEFT JOIN VALUATION_ENTITY_WSIB_REPO ve ON VE.Account_Number=NT.BANK_ACCOUNT_NUMBER
			LEFT JOIN [PSA].[V_Manual_GroupingNS_Mapping] gm ON GM.COUNTERPARTY_ENTITY=CM.IMCO_Counterparty_Name  
				AND gm.Type='REPO' 
				AND gm.Account_Number=NT.BANK_ACCOUNT_NUMBER 
				AND ve.TRANSACTION_TERMS_VALUATION_ENTITY_NAME = gm.Valuation_Entity
			LEFT JOIN HairCut HC on HC.Netting_set=Concat(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,'-',cm.IMCO_Counterparty_Name,'-',GM.Grouping)
		WHERE UPPER(TRIM(NT.Repo_Type)) IN ('REVERSE REPO','REPO')
			AND UPPER(TRIM(NT.TRANS_TYPE) )= 'INITIATION'  
			AND @effectiveDate >= NT.Trade_Date  
			AND @effectiveDate < NT.TERMINATION_DATE
			AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) IN (SELECT Portfolio_ID FROM [PSA].[V_Manual_Portfolio_Groups] 
					WHERE group_name = 'WSIB Accounting Position Split' AND @effectiveDate BETWEEN start_date AND end_Date)
			AND NT.REPO_CUSIP NOT IN (SELECT REPO_CUSIP FROM REPOTRADE_EXCLUSION_WSIB_REPO)
	),
	--REPOTRADE_EXCLUSION_WSIB_ILB
	VALUATION_ENTITY_WSIB_ILB AS
	(
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME
			, gm.Account_Number AS ACCOUNT_NUMBER
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm
		INNER JOIN EDW_Raw.[V_WSIB_Nisa_Trades] rd ON gm.Account_Number = rd.BANK_ACCOUNT_NUMBER 
			AND @effectiveDate BETWEEN gm.START_DT AND ISNULL(gm.END_DT,@effectiveDate)
	),				
	REPOTRADE_EXCLUSION_WSIB_ILB AS
	(
			SELECT DISTINCT REPO_CUSIP
			FROM EDW_Raw.V_WSIB_Nisa_Trades NT
				WHERE UPPER(TRIM(NT.REPO_TYPE)) IN ('REVERSE REPO','REPO')
				AND UPPER(TRIM(NT.TRANS_TYPE) )IN ( 'CANCEL' , 'RESIZE','MATURITY') 
				AND @effectiveDate >= TRADE_DATE    
				AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) IN (SELECT Portfolio_ID 
							FROM [PSA].[V_Manual_Portfolio_Groups] 
							WHERE group_name = 'WSIB Accounting Position Split' 
								AND @effectiveDate BETWEEN start_date AND end_Date) 
	 ),
	 WSIB_ILB AS
	 (
		SELECT DISTINCT 
			 FORMAT(@effectiveDate,'yyyyMMdd')  AS HOLDING_DATE   
			, CONCAT(NT.BANK_ACCOUNT_NUMBER ,'_CCE') AS  ACCOUNT_ID
			, NT.BANK_ACCOUNT_NUMBER AS ACCOUNT_DESCRIPTION
			, 'CAD' AS ACCOUNT_BASE_CURRENCY
			, 'Fixed Income' AS ASSET_CLASS
			, 'Fixed Income' AS ASSET_TYPE
			, TRIM(NT.UNDERLYING_CUSIP) AS ASSET_NAME
			, CONCAT(TRIM(NT.UNDERLYING_CUSIP),'-Fixed Income-WSIB')  AS PRIMARY_ASSET_ID
			, 'CUSIP' AS PRIMARY_ASSET_ID_TYPE
			, CASE WHEN REPO_TYPE='REVERSE REPO' Then NT.PAR_Amount Else -1*convert(int,NT.PAR_Amount) END AS NUMBER_OF_SHARES
			, CASE WHEN REPO_TYPE='REVERSE REPO' Then NT.PAR_Amount Else -1*convert(int,NT.PAR_Amount) END AS NOTIONAL_AMOUNT
			, NULL AS BASE_MARKET_VALUE
			, NULL AS BASE_NET_ASSET_VALUE
			, NULL AS LOCAL_MARKET_VALUE
			, NULL AS LOCAL_NET_ASSET_VALUE
			, 'CAD' AS BASE_MARKET_VALUE_CURRENCY 
			, nt.Currency AS LOCAL_MARKET_VALUE_CURRENCY 
			, NULL AS ASSET_PRICE_DATE	
			, NULL AS ASSET_PRICE
			, NULL AS ASSET_PRICE_CURRENCY
			, NULL AS SEDOL
			, nt.underlying_CUSIP AS CUSIP
			, NULL AS ISIN
			, NULL AS TICKER
			, NULL AS SECCDPRMY
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE
			, NULL AS DP_ASSET_TYPE
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,';CCEPositionID;',
				CONCAT(NT.BANK_ACCOUNT_NUMBER,'-',NT.Underlying_CUSIP,'_',NT.REPO_CUSIP,'-Repo;CDMS_MarginingHaircut;',(NT.Haircut/100)*(1-HC.Haircut))) AS BUCKET_LIST
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',cm.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',cm.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				CASE WHEN ISNULL(TERMINATION_DATE,'') ='' THEN '' ELSE CONCAT(';MaturityDate^',FORMAT(TERMINATION_DATE,'yyyyMMdd')) END)  AS TRANSACTION_TERM 		
			, NULL AS START_DATE
			, NULL AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, NULL AS CONTRACT_SIZE
			, NULL AS EXCHANGE_RATE
			, NULL AS QUOTE_CURRENCY
			, NULL AS CURRENCY
			, NULL AS UNDERLIER_ID
			, NULL AS UNDERLIER_ID_TYPE
			, NULL AS AMOUNT_ISSUED
			, NULL AS REPO_TYPE
			, NULL AS REPO_RATE
			, NULL AS SALE_DATE
			, NULL AS REPURCHASE_DATE
			, NULL AS [COUNTRY]
			, NULL AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cm.IMCO_Counterparty_Name+GM.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, NULL AS ISCOLLATERAL
		FROM EDW_Raw.V_WSIB_Nisa_Trades nt  
			LEFT JOIN [PSA].[V_Manual_Counterparty_Mapping] cm ON NT.COUNTERPARTY = cm.COUNTERPARTY_NAME
				AND cm.Investment_Type = 'REPO'
				AND cm.Client ='WSIB'
				AND (@effectiveDate BETWEEN cm.START_DT AND ISNULL(cm.END_DT,@effectiveDate))
			LEFT JOIN VALUATION_ENTITY_WSIB_ILB ve on ve.Account_Number = nt.BANK_ACCOUNT_NUMBER
			LEFT JOIN [PSA].[V_Manual_GroupingNS_Mapping] gm on gm.COUNTERPARTY_ENTITY=cm.IMCO_Counterparty_Name   
				AND gm.Type='REPO' 
				AND gm.Account_Number = nt.BANK_ACCOUNT_NUMBER
				AND ve.TRANSACTION_TERMS_VALUATION_ENTITY_NAME = gm.Valuation_Entity
			LEFT JOIN HairCut HC ON HC.Netting_set=Concat(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,'-',cm.IMCO_Counterparty_Name,'-',GM.Grouping)
			WHERE UPPER(TRIM(nt.REPO_TYPE)) IN ('REVERSE REPO','REPO')
				AND UPPER(TRIM(nt.TRANS_TYPE) )= 'INITIATION'  
				AND @effectiveDate >= nt.TRADE_DATE     
				AND @effectiveDate < nt.TERMINATION_DATE 
				AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) IN (SELECT Portfolio_ID 
								FROM [PSA].[V_Manual_Portfolio_Groups] 
									WHERE group_name = 'WSIB Accounting Position Split' 
									AND @effectiveDate BETWEEN start_date AND end_Date) 
			AND nt.REPO_CUSIP NOT IN (SELECT REPO_CUSIP FROM REPOTRADE_EXCLUSION_WSIB_ILB)
	 ),	 
	 --WSIB_RECVD_COLLATERAL
	 VALUATION_ENTITY_WSIB_RECVD_COLLATERAL AS
	(
		SELECT DISTINCT Valuation_Entity AS TRANSACTION_TERMS_VALUATION_ENTITY_NAME
			, gm.Account_Number AS ACCOUNT_NUMBER
		FROM [PSA].[V_Manual_GroupingNS_Mapping] gm
			INNER JOIN [EDW_Raw].[V_WSIB_Detail_Non_Cash_Collateral] rd ON gm.Account_Number = rd.Fund_Short_ID 
			AND rd.As_Of_Date BETWEEN gm.START_DT AND ISNULL(gm.END_DT,rd.As_Of_Date) 
			AND rd.As_Of_Date = @effectiveDate
	),
	WSIB_RECVD_COLLATERAL AS
	(
		SELECT DISTINCT FORMAT(sl.[As_of_Date],'yyyyMMdd') AS  HOLDING_DATE
			, CONCAT(sl.Fund_Short_ID,'_CCE') AS ACCOUNT_ID
			, Fund_External_Name AS ACCOUNT_DESCRIPTION
			,'CAD' AS ACCOUNT_BASE_CURRENCY
			,'Received Collateral' AS ASSET_CLASS
			,'Received Collateral' AS ASSET_TYPE
			, Security_Name AS ASSET_NAME
			, CONCAT(COALESCE(sl.[ISIN_ID],sl.[CUSIP_ID],sl.[SEDOL_ID],NULL),'-Received Collateral-WSIB-',sl.Borrower_Entity_External_Name) AS PRIMARY_ASSET_ID
			, CASE WHEN sl.[ISIN_ID] IS NOT NULL THEN 'ISIN'
					WHEN sl.[CUSIP_ID] IS NOT NULL THEN 'CUSIP'
					WHEN sl.[SEDOL_ID] IS NOT NULL THEN 'SEDOL'
					ELSE NULL END  AS PRIMARY_ASSET_ID_TYPE
			, ISNULL(-1*sl.[Share_Qnty],0) AS NUMBER_OF_SHARES 
			, ISNULL(-1*sl.[Share_Qnty],0) AS NOTIONAL_AMOUNT
			, NULL AS BASE_MARKET_VALUE
			, NULL AS BASE_NET_ASSET_VALUE
			, NULL AS LOCAL_MARKET_VALUE
			, NULL AS LOCAL_NET_ASSET_VALUE
			, 'CAD' AS BASE_MARKET_VALUE_CURRENCY
			, NULL AS LOCAL_MARKET_VALUE_CURRENCY
			, NULL AS ASSET_PRICE_DATE
			, NULL AS ASSET_PRICE
			, NULL AS ASSET_PRICE_CURRENCY
			, ISNULL(sl.[SEDOL_ID],'') AS SEDOL
			, ISNULL(sl.[CUSIP_ID],'') AS CUSIP
			, ISNULL(sl.[ISIN_ID],'') AS ISIN
			, NULL AS TICKER
			, NULL AS SECCDPRMY
			, NULL AS WEIGHT
			, NULL AS BASE_ACCRUED_INCOME_VALUE
			, NULL AS LOCAL_ACCRUED_INCOME_VALUE
			, NULL AS DP_ASSET_TYPE
			, NULL AS RIC
			, NULL AS RED_CODE
			, NULL AS LOAN_XID	
			, CONCAT('ValuationEntityName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName;',CM.IMCO_Counterparty_Name,
				';NettingSetTermsName;',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',CM.IMCO_Counterparty_Name,
				'-',GM.Grouping,
				';CCEPositionID;',CONCAT(sl.Fund_Short_ID,'-',COALESCE(sl.[ISIN_ID],sl.[CUSIP_ID],sl.[SEDOL_ID],NULL),'_',Loan_Number,'-SLColl')) AS BUCKET_LIST
			, CONCAT('ValuationEntityName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				';CounterpartyEntityName^',CM.IMCO_Counterparty_Name,
				';BilateralAgreementName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',CM.IMCO_Counterparty_Name,
				';NettingSetTermsName^',VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME,
				'-',CM.IMCO_Counterparty_Name,
				'-',GM.Grouping) AS TRANSACTION_TERM
			, NULL AS START_DATE
			, NULL AS MATURITY_DATE
			, NULL AS STRIKE_PRICE
			, NULL AS CONTRACT_SIZE
			, NULL AS EXCHANGE_RATE
			, NULL AS QUOTE_CURRENCY
			, NULL AS CURRENCY
			, NULL AS UNDERLIER_ID
			, NULL AS UNDERLIER_ID_TYPE
			, NULL AS AMOUNT_ISSUED
			, NULL AS REPO_TYPE
			, NULL AS REPO_RATE
			, NULL AS SALE_DATE
			, NULL AS REPURCHASE_DATE
			, NULL AS [COUNTRY]
			, NULL AS [SALE_PRICE]
			, CASE WHEN LEN(VE.TRANSACTION_TERMS_VALUATION_ENTITY_NAME+cm.IMCO_Counterparty_Name+GM.Grouping)>1 THEN 'NO'
				ELSE 'YES' END AS EMPTY_TAG
			, 'TRUE' AS ISCOLLATERAL
		FROM [EDW_Raw].[V_WSIB_Detail_Non_Cash_Collateral]  sl
			LEFT JOIN  [PSA].[V_Manual_Counterparty_Mapping] CM ON  cm.INVESTMENT_TYPE = 'Rec Collateral' 
				AND CLIENT ='WSIB' 
				AND (sl.[As_of_Date] BETWEEN cm.START_DT AND ISNULL(cm.END_DT,@effectiveDate))
			LEFT JOIN VALUATION_ENTITY_WSIB_RECVD_COLLATERAL ve on VE.Account_Number=sl.Fund_Short_ID
			LEFT JOIN [PSA].[V_Manual_GroupingNS_Mapping] gm on gm.COUNTERPARTY_ENTITY=CM.IMCO_Counterparty_Name 
				AND gm.Type='COLLATERAL' 
				AND gm.Account_Number=SL.Fund_Short_ID 
				AND ve.TRANSACTION_TERMS_VALUATION_ENTITY_NAME=gm.Valuation_Entity
			WHERE  sl.Record_Type ='COLLATERAL'
				AND CONVERT(DATE,sl.As_of_Date) = CONVERT(DATE,@effectiveDate)
	)


	--Insert into EDW_RAW.CCE_Aggr_Consolidated_Positions
	INSERT INTO [EDW_BUS].[Aggr_RM_CCE_Consolidated_Positions]
	SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , CASE WHEN PRIMARY_ASSET_ID_RANK>1 THEN CONCAT(PRIMARY_ASSET_ID,'-',PRIMARY_ASSET_ID_RANK) ELSE PRIMARY_ASSET_ID END AS PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE  
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , Load_DTS
		  , Hash_Diff
		  , ETL_Load_Key
		  , Source_Deleted_Flag
	FROM (
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE  
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today AS Load_DTS
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|' , [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		FROM OPB_FXForward
		UNION ALL
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  ,  @today AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|' , [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		FROM OPB_SecLending
		UNION ALL 
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|' , [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		 , @ETL_LOAD_KEY AS ETL_Load_Key
		 , 0 AS Source_Deleted_Flag
		 , RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		  FROM OPB_Repo
		UNION ALL 
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|' , [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		 FROM OPB_ILB
		UNION ALL
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|' , [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		FROM OPB_OTC_Collateral
		UNION ALL
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|' , [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		FROM OPB_Recvd_Collateral
		UNION ALL
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today  AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|' , [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY  AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		FROM WSIB_FXForward
		UNION ALL
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today  AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|' , [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY  AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		FROM WSIB_SecLending
		UNION ALL
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today  AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|' , [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY   AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		FROM WSIB_REPO
		UNION ALL
		SELECT CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		 , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today  AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|', [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY  AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		FROM WSIB_ILB
		UNION ALL
		SELECT  CONVERT(NCHAR(8),HOLDING_DATE,112) AS HOLDING_DATE
		  , ACCOUNT_ID
		  , ACCOUNT_DESCRIPTION
		  , ACCOUNT_BASE_CURRENCY
		  , ASSET_CLASS
		  , ASSET_TYPE
		  , ASSET_NAME
		  , PRIMARY_ASSET_ID
		  , PRIMARY_ASSET_ID_TYPE
		  , NUMBER_OF_SHARES
		  , NOTIONAL_AMOUNT
		  , BASE_MARKET_VALUE
		  , BASE_NET_ASSET_VALUE
		  , LOCAL_MARKET_VALUE
		  , LOCAL_NET_ASSET_VALUE
		  , BASE_MARKET_VALUE_CURRENCY
		  , LOCAL_MARKET_VALUE_CURRENCY
		  , CONVERT(NCHAR(8),ASSET_PRICE_DATE,112) AS ASSET_PRICE_DATE 
		  , ASSET_PRICE
		  , ASSET_PRICE_CURRENCY
		  , SEDOL
		  , CUSIP
		  , ISIN
		  , TICKER
		  , SECCDPRMY
		  , WEIGHT
		  , BASE_ACCRUED_INCOME_VALUE
		  , LOCAL_ACCRUED_INCOME_VALUE
		  , DP_ASSET_TYPE
		  , RIC
		  , RED_CODE
		  , LOAN_XID
		  , BUCKET_LIST
		  , TRANSACTION_TERM
		  , CONVERT(NCHAR(8),START_DATE,112) AS START_DATE 
		  , CONVERT(NCHAR(8),MATURITY_DATE,112) AS MATURITY_DATE  
		  , STRIKE_PRICE
		  , CONTRACT_SIZE
		  , EXCHANGE_RATE
		  , QUOTE_CURRENCY
		  , CURRENCY
		  , UNDERLIER_ID
		  , UNDERLIER_ID_TYPE
		  , AMOUNT_ISSUED
		  , REPO_TYPE
		  , REPO_RATE
		  , CONVERT(NCHAR(8),SALE_DATE,112) AS SALE_DATE 
		  , CONVERT(NCHAR(8),REPURCHASE_DATE,112) AS REPURCHASE_DATE
		  , [COUNTRY]
		  , [SALE_PRICE]
		  , EMPTY_TAG
		  , ISCOLLATERAL
		  , @today  AS Load_DTS 
		  , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT([HOLDING_DATE], '|' ,[ACCOUNT_ID], '|' ,[ACCOUNT_DESCRIPTION], '|' ,[ACCOUNT_BASE_CURRENCY], '|' ,[ASSET_CLASS], '|' ,
				[ASSET_TYPE], '|' ,[ASSET_NAME], '|' ,[PRIMARY_ASSET_ID], '|' ,[PRIMARY_ASSET_ID_TYPE], '|' ,[NUMBER_OF_SHARES], '|' ,[NOTIONAL_AMOUNT], '|' ,[BASE_MARKET_VALUE], '|' ,
				[BASE_NET_ASSET_VALUE], '|' ,[LOCAL_MARKET_VALUE], '|' ,[LOCAL_NET_ASSET_VALUE], '|' ,[BASE_MARKET_VALUE_CURRENCY], '|' ,[LOCAL_MARKET_VALUE_CURRENCY], '|' ,
				[ASSET_PRICE_DATE], '|' ,[ASSET_PRICE], '|' ,[ASSET_PRICE_CURRENCY], '|' ,[SEDOL], '|' ,[CUSIP], '|' ,[ISIN], '|' ,[TICKER], '|' ,[SECCDPRMY], '|' ,[WEIGHT], '|' ,
				[BASE_ACCRUED_INCOME_VALUE], '|' ,[LOCAL_ACCRUED_INCOME_VALUE], '|' ,[DP_ASSET_TYPE], '|' ,[RIC], '|' ,[RED_CODE], '|' ,[LOAN_XID], '|' ,[BUCKET_LIST], '|' ,[TRANSACTION_TERM], '|' ,
				[START_DATE], '|' ,[MATURITY_DATE], '|' ,[STRIKE_PRICE], '|' ,[CONTRACT_SIZE], '|' ,[EXCHANGE_RATE], '|' ,[QUOTE_CURRENCY], '|' ,[CURRENCY], '|' ,[UNDERLIER_ID], '|' ,
				[UNDERLIER_ID_TYPE], '|' ,[AMOUNT_ISSUED], '|' ,[REPO_TYPE], '|' ,[REPO_RATE], '|' ,[SALE_DATE], '|' ,[REPURCHASE_DATE ], '|', [COUNTRY], '|', [SALE_PRICE], '|', 
				EMPTY_TAG, '|', ISCOLLATERAL, '|'  ))), 2) AS Hash_Diff
		, @ETL_LOAD_KEY  AS ETL_Load_Key
		, 0 AS Source_Deleted_Flag
		, RANK() OVER(PARTITION BY PRIMARY_ASSET_ID ORDER BY ASSET_NAME, PRIMARY_ASSET_ID)  AS PRIMARY_ASSET_ID_RANK
		  FROM WSIB_RECVD_COLLATERAL
	)  AS stg WHERE NOT EXISTS 
		(
			SELECT Hash_Diff FROM  [EDW_BUS].[Aggr_RM_CCE_Consolidated_Positions] tgt WHERE coalesce(tgt.Hash_Diff,'') = coalesce(stg.Hash_Diff,'')
		)

	SELECT @rowsInserted = COUNT(*) 
		FROM [EDW_BUS].[Aggr_RM_CCE_Consolidated_Positions]
		WHERE [Load_dts] = @today and [Source_Deleted_Flag] = 0

	EXEC [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.RM_Aggr_CCE_Consolidated_Positions', @rowsInserted, 0, 0, 'Completed', null

	END TRY 

		BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.RM_Aggr_CCE_Consolidated_Positions', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState
		
	END CATCH
END
