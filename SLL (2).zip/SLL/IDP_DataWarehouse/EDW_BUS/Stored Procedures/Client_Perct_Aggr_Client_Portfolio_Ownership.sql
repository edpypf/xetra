﻿CREATE PROC [EDW_BUS].[Client_Perct_Aggr_Client_Portfolio_Ownership] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2


	BEGIN TRY

	
			IF OBJECT_ID('tempdb..#temp_client_perct_records') IS NOT NULL
			BEGIN
				DROP TABLE #temp_client_perct_records
			END

			-- load everything from source

			create table #temp_client_perct_records
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as 
			With 
			WSIB_Asset as (
				Select Distinct p.Portfolio_ID
				From EDW_Common.Bridge_Portfolio_Group bpg 
				Join EDW_Common.Dim_Portfolio p on bpg.Dim_Portfolio_Key = p.Dim_Portfolio_Key
				Join EDW_Common.Dim_Portfolio_Group pg on bpg.Dim_Portfolio_Group_Key = pg.Dim_Portfolio_Group_Key

				Where pg.Portfolio_Group_Name in ('WSIB ASSET MIX REPORTING') and bpg.Is_Src_Deleted = 0 and p.Portfolio_ID <> 'NA'

			),
			PM as (
				Select p.Dim_Portfolio_Key, p.Portfolio_ID, pp.Portfolio_Id Parent_Portfolio_Id, bpmi.Dim_Date_Key
					   
				From EDW_Common.Bridge_Portfolio_Mapping bpmi 
				Join EDW_Common.Dim_Portfolio p on bpmi.Dim_Portfolio_Key = p.Dim_Portfolio_Key
				Join EDW_Common.Dim_Portfolio pp on bpmi.Parent_Dim_Portfolio_Key = pp.Dim_Portfolio_Key
				Where bpmi.Is_Src_Deleted = 0
			),
			PD as (
				Select Coalesce(PC.Dim_Portfolio_Key,   L.Dim_Portfolio_Key)                          as Dim_Portfolio_Key
					 , Coalesce(PC.Portfolio_ID,   L.Portfolio_ID)                          as Portfolio_ID
					 , case when PC.Portfolio_ID is NULL then PP.Parent_Portfolio_Id Else L.Portfolio_ID End  as Parent_Portfolio_ID
					 , cl.Dim_Client_Key
					 , cl.Client_ID  
					 , bpm.Dim_Strategy_Key
					 , s.Strategy_Id
					 , L.Dim_Date_Key

				  From ( -- Get top level portfolios and composites
						Select bpg.Dim_Date_Key, p.Dim_Portfolio_Key, p.Portfolio_ID,  p.Portfolio_Name
						  From EDW_Common.Bridge_Portfolio_Group bpg 
						  Join EDW_Common.Dim_Portfolio p on bpg.Dim_Portfolio_Key = p.Dim_Portfolio_Key
						  Join EDW_Common.Dim_Portfolio_Group pg on bpg.Dim_Portfolio_Group_Key = pg.Dim_Portfolio_Group_Key

						 Where pg.Portfolio_Group_Name in ('OPB ASSET MIX REPORTING', 'PJPP ASSET MIX REPORTING') and bpg.Is_Src_Deleted = 0

						union

						Select Distinct bpm.Dim_Date_Key, bpm.Dim_Portfolio_Key, p1.Portfolio_Id, p1.Portfolio_Name 
						From EDW_Common.Bridge_Portfolio_Mapping bpm  
						Join EDW_Common.Dim_Portfolio p1 on bpm.Dim_Portfolio_Key = p1.Dim_Portfolio_Key
						Join EDW_Common.Dim_Portfolio pp1 on bpm.Parent_Dim_Portfolio_Key = pp1.Dim_Portfolio_Key
						Join WSIB_Asset pgp on pp1.Portfolio_Id = pgp.Portfolio_Id
						Where bpm.Is_Src_Deleted = 0


						union

						 -- Get top level portfolio for the portfolio with security associated with WSIB asset mix report group master portfoio
						Select Distinct bpm.Dim_Date_Key, bpm.Dim_Portfolio_Key, p1.Portfolio_Id, p1.Portfolio_Name 

						From EDW_Common.Bridge_Portfolio_Mapping bpm  
						Join EDW_Common.Dim_Security s on bpm.Dim_Security_Key = s.Dim_Security_Key 
						Join EDW_Common.Dim_Portfolio p1 on bpm.Dim_Portfolio_Key = p1.Dim_Portfolio_Key
						Join (
							Select Distinct s.Security_Id
							From [EDW_Common].[Fact_StateStreet_Account_Position] ap
							Join EDW_Common.Dim_Portfolio p on ap.Dim_Portfolio_Key = p.Dim_Portfolio_Key
							Join EDW_Common.Dim_Security s on ap.Dim_Security_Key = s.Dim_Security_Key 
							Join WSIB_Asset on p.Portfolio_id = WSIB_Asset.Portfolio_ID
						) ws on s.Security_id = ws.Security_id
						Where bpm.Is_Src_Deleted = 0 and bpm.Dim_Security_Key <> -1 and s.Security_Id <> 'NA'
					   )  L       
					   -- Pull in children of the portfolios if there are any
					   Left Join PM PC  on L.Portfolio_Id = PC.Parent_Portfolio_Id and L.Dim_Date_Key = PC.Dim_Date_Key
					   Left Join PM PP  on L.Portfolio_Id = PP.Portfolio_Id and L.Dim_Date_Key = PP.Dim_Date_Key
					   Left Join EDW_Common.Bridge_Portfolio_Mapping bpm on L.Dim_Date_Key = bpm.Dim_Date_Key and L.Dim_Portfolio_Key = bpm.Dim_Portfolio_Key and bpm.Is_Src_Deleted = 0
					   Left Join EDW_Common.Dim_Client cl on bpm.Dim_Client_Key = cl.Dim_Client_Key
					   Left Join EDW_Common.Dim_Strategy s on bpm.Dim_Strategy_Key = s.Dim_Strategy_Key
					   where cl.Client_Id is not null

			),
			Market_Value as 
			( 
					Select PD.Dim_Client_Key
						 , PD.Dim_Strategy_Key
						 , PD.Dim_Portfolio_Key
						 , PD.Portfolio_ID
						 , PD.Parent_Portfolio_ID
						 , PD.Client_ID
						 , PD.Strategy_Id
						 , SEP.Dim_Date_Key
						 , SEP.Ending_Market_Value
					From PD
					Inner join [EDW_Common].[V_Fact_Eagle_Total_Portfolio_Performance]  SEP on PD.Dim_Portfolio_Key      = SEP.Dim_Portfolio_Key
																									and PD.Client_ID not like 'WSIB%'  -- Eliminate duplicate WSIB performance coming from Eagle
																									and PD.Dim_Date_Key = SEP.Dim_Date_Key
					Where SEP.Ending_Market_Value is not null

					union all

					Select PD.Dim_Client_Key
						 , PD.Dim_Strategy_Key
						 , PD.Dim_Portfolio_Key
						 , PD.Portfolio_ID
						 , PD.Parent_Portfolio_ID
						 , PD.Client_ID
						 , PD.Strategy_Id
						 , SSP.Dim_Date_Key
						 , SSP.Ending_Market_Value

					  From PD
					  Inner join [EDW_Common].[V_Fact_StateStreet_Total_Portfolio_Performance] SSP on PD.Dim_Portfolio_Key      = SSP.Dim_Portfolio_Key 
										and PD.Dim_Date_Key = SSP.Dim_Date_Key 
					  Where SSP.Ending_Market_Value is not null
			),
			Pool_Ownership_Base_Detail as (
						Select distinct c.Dim_Client_Key, c.Client_Id,  p.Dim_Portfolio_Key Pool_Portfolio_Key, p.Portfolio_Id Pool_Portfolio_Id, S.Security_Id,
							   ap.Dim_Date_Key, ap.Base_Market_Value
						From  EDW_Common.Bridge_Portfolio_Mapping bpm  
						left Join EDW_Common.Dim_Security s on bpm.Dim_Security_Key = s.Dim_Security_Key
						left Join (
							Select sap.Dim_Date_key, sap.Security_Id, sap.Dim_Portfolio_Key, p.Portfolio_Id Pool_Portfolio_Id, sap.Base_Market_Value
							From EDW_Common.[V_Fact_StateStreet_Account_Position] sap
							Join EDW_Common.Dim_Portfolio p on sap.Dim_Portfolio_Key = p.Dim_Portfolio_Key
							
						) ap on s.Security_Id = ap.Security_Id and ap.Dim_Date_key = bpm.Dim_Date_Key
						Join EDW_Common.Dim_Portfolio p on bpm.Parent_Dim_Portfolio_Key = p.Dim_Portfolio_Key
						left Join (
							Select bpmi.Dim_Client_Key, bpmi.Dim_Date_key, p_i.Portfolio_Id Pool_Portfolio_Id
							From EDW_Common.Bridge_Portfolio_Mapping bpmi
							Join EDW_Common.Dim_Portfolio p_i on bpmi.Dim_Portfolio_Key = p_i.Dim_Portfolio_Key
						) bpm_p on ap.Pool_Portfolio_Id = bpm_p.Pool_Portfolio_Id and ap.Dim_Date_key = bpm_p.Dim_Date_key
						left Join EDW_Common.Dim_Client c on bpm_p.Dim_Client_Key = c.Dim_Client_Key
						where bpm.Is_Src_Deleted = 0 and bpm.Dim_Security_Key <> -1 
						
			),
			Pool_Ownership_Base as (
				Select Dim_Client_Key, Client_Id,  
					   Pool_Portfolio_Id, Security_Id, Dim_Date_Key, sum(Base_Market_Value) Base_Market_Value
				From Pool_Ownership_Base_Detail
				Group By Dim_Client_Key, Client_Id, Pool_Portfolio_Id, Security_Id, Dim_Date_Key
			),
			Pool_Ownership as (
				Select Distinct 
					   B.Dim_Client_Key,
					   B.Client_Id, 
					   B.Security_Id,
					   B.Pool_Portfolio_Id,
					   B.Dim_Date_Key,
					   case when ST.Base_Market_Value = 0 then null 
					   else 
					     cast(cast(B.Base_Market_Value as float)/ST.Base_Market_Value as decimal(38,12)) 
					   end Client_Percentage
				From Pool_Ownership_Base B 
				Join (
					Select Security_Id, Dim_Date_Key, sum(Base_Market_Value) Base_Market_Value
					From Pool_Ownership_Base
					Group By Security_Id, Dim_Date_Key
				) ST on B.Security_Id = ST.Security_Id and B.Dim_Date_Key = ST.Dim_Date_Key
			),
			Booking_Level_Ownership as (
						  Select PO.Dim_Client_Key, PO.Dim_Strategy_Key, PO.Pool_Portfolio_Id,  PO.Client_Id, PO.Strategy_Id, PC.Dim_Portfolio_Key, PC.Portfolio_ID, PC.Portfolio_Name,
							PO.Client_Percentage, PC.Ending_Market_Value Market_Value, PC.Dim_Date_Key
						  From (
							  Select  P.Dim_Portfolio_Key, P.Portfolio_ID, P.Portfolio_Name, SSP.Ending_Market_Value, SSP.Dim_Date_Key
							  From  EDW_Common.Dim_Portfolio P 
							  Join [EDW_Common].[V_Fact_StateStreet_Total_Portfolio_Performance]   SSP on P.Dim_Portfolio_Key = SSP.Dim_Portfolio_Key
						  ) PC
						  Inner Join (
							  Select PCT.Dim_Client_Key, HP.Dim_Strategy_Key, HP.Dim_Portfolio_Key, HP.Portfolio_Id, PCT.Pool_Portfolio_Id, PCT.Client_Id, HP.Strategy_Id, PCT.Client_Percentage, PCT.Dim_Date_Key
							  From (
									Select distinct p.Dim_Portfolio_Key, p.Portfolio_Id, pp.Portfolio_Id Parent_Portfolio_Id, Dim_Date_Key, s.Dim_Strategy_Key, s.Strategy_Id
									From  EDW_Common.Bridge_Portfolio_Mapping bpm  
									Join EDW_Common.Dim_Portfolio p on bpm.Dim_Portfolio_Key = p.Dim_Portfolio_Key
									Join EDW_Common.Dim_Portfolio pp on bpm.Parent_Dim_Portfolio_Key = pp.Dim_Portfolio_Key
									Join EDW_Common.Dim_Strategy s on bpm.Dim_Strategy_Key = s.Dim_Strategy_Key
									Where bpm.Parent_Dim_Portfolio_Key <> -1 and bpm.Is_Src_Deleted = 0
								) HP
								Inner Join Pool_Ownership PCT on HP.Parent_Portfolio_Id = PCT.Pool_Portfolio_Id and HP.Dim_Date_Key = PCT.Dim_Date_Key
						  ) PO on PC.Portfolio_Id = PO.Portfolio_Id and PC.Dim_Date_Key = PO.Dim_Date_Key

			),
			Perct as (
				Select Dim_Client_Key, Dim_Strategy_Key, Dim_Portfolio_Key, Client_Id, Strategy_Id, Portfolio_Id, Client_Percentage, Market_Value, Dim_Date_Key
				From Booking_Level_Ownership
				Union all
				Select Dim_Client_Key, Dim_Strategy_Key, Dim_Portfolio_Key, Client_Id, Strategy_Id, Portfolio_Id, 1 Client_Percentage, Ending_Market_Value Market_Value, Dim_Date_Key
				From Market_Value
			),
			Perc_client as (
				Select Client_Id, Dim_Date_Key, sum(Client_Percentage*Market_Value) Total_Client
				From Perct
				-- Where Dim_Strategy_Key <> -1
				Group BY Client_Id, Dim_Date_Key
			)
			Select p.Dim_Date_Key, Dim_Client_Key, Dim_Strategy_Key, Dim_Portfolio_Key,  
			       p.Client_Id, p.Strategy_Id, p.Portfolio_Id,
					Market_Value Market_Value_Portfolio, 
				   Client_Percentage*Market_Value Market_Value_Portfolio_Owned, 
				   pc.Total_Client Market_Value_Client,
				   Client_Percentage, 
				   case when pc.Total_Client = 0 then 0 else cast(cast(Client_Percentage*Market_Value as float)/pc.Total_Client as decimal(38,12)) end Client_Represent_Percentage
			From Perct p
			Join Perc_client pc on p.Client_Id = pc.Client_Id and p.Dim_Date_Key = pc.Dim_Date_Key


			INSERT INTO [EDW_BUS].[Aggr_Client_Portfolio_Ownership]
			   ([Dim_Date_Key]
			   ,[Dim_Client_Key]
			   ,[Dim_Strategy_Key]
			   ,[Dim_Portfolio_Key]
			   ,Load_DTS
			   ,[Percent_Portfolio_Owned]
			   ,[Percent_Portfolio_Represents]
			   ,[Market_Value_Portfolio]
			   ,[Market_Value_Client]
			   ,[Market_Value_Portfolio_Owned]
			   ,[Other_Info]
			   ,[Last_Update_DTS]
			   ,[Hash_Diff]
			   ,[ETL_Load_Key]
			   ,Is_Src_Deleted
			   )

			Select  Dim_Date_Key, 
					Dim_Client_Key, 
					Dim_Strategy_Key, 
					Dim_Portfolio_Key, 
					@today,
					Client_Percentage Percent_Portfolio_Owned, 
					Client_Represent_Percentage,
					Market_Value_Portfolio, 
					Market_Value_Client,
					Market_Value_Portfolio_Owned,
					null,
					@today,
					Hash_Diff,
					@ETL_Load_Key,
					0
			From (
				Select  Dim_Date_Key, 
					Dim_Client_Key, 
					Dim_Strategy_Key, 
					Dim_Portfolio_Key, 
					Client_Id,
					Strategy_Id, 
					Portfolio_Id,
					Client_Percentage, 
					Client_Represent_Percentage,
					Market_Value_Portfolio, 
					Market_Value_Client,
					Market_Value_Portfolio_Owned,
					CONVERT(VARCHAR(64), hashbytes('SHA1', coalesce(concat(Client_Percentage, '|', Client_Represent_Percentage, '|', Market_Value_Portfolio, '|', Market_Value_Client, '|', Market_Value_Portfolio_Owned ), '')), 2) as Hash_Diff
				From #temp_client_perct_records
				where Dim_Strategy_Key <> -1
			)  src
			where not exists (
				Select 1
				From [EDW_BUS].[V_Aggr_Client_Portfolio_Ownership] tgt
				where tgt.Dim_Date_Key = src.Dim_Date_Key and tgt.Client_Id = src.Client_Id and tgt.Strategy_Id = src.Strategy_Id and tgt.Portfolio_Id = src.Portfolio_Id
					  and tgt.Hash_Diff = src.Hash_Diff
			)

			Select @rowsInserted = Count(*) 
			From EDW_BUS.Aggr_Client_Portfolio_Ownership 
			Where Last_Update_DTS = @today and Is_Src_Deleted = 0

			Update  tgt
			Set Is_Src_Deleted = 1, Last_Update_DTS = getdate(), ETL_Load_Key = @ETL_Load_Key
			From EDW_BUS.Aggr_Client_Portfolio_Ownership tgt
			Join EDW_Common.Dim_Client c on tgt.Dim_Client_Key = c.Dim_Client_Key
			Join EDW_Common.Dim_Strategy s on tgt.Dim_Strategy_Key = s.Dim_Strategy_Key
			Join EDW_Common.Dim_Portfolio p on tgt.Dim_Portfolio_Key = p.Dim_Portfolio_Key
			where not exists (
					Select 1 from #temp_client_perct_records src 
					Where tgt.Dim_Date_Key = src.Dim_Date_Key and c.Client_Id = src.Client_Id and s.Strategy_Id = src.Strategy_Id and p.Portfolio_Id = src.Portfolio_Id
			) and coalesce(tgt.Is_Src_Deleted,0) = 0

			Select @rowsExpired = Count(*)
			From EDW_BUS.Aggr_Client_Portfolio_Ownership 
			Where Last_Update_DTS = @today and Is_Src_Deleted = 1

			Select @rowsUpdated = @rowsExpired

			Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Client_Portfolio_Ownership', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Client_Portfolio_Ownership', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END