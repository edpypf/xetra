﻿CREATE PROC [EDW_BUS].[Private_Market_IDP_WSIB_Pending_Positions_Check] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2	,
			@Effective_Date date
			
			--,@ETL_Load_Key int = 1				--UNCOMMENT FOR DEBUGGING
			--,@Batch_DTS date = '2023-03-31'		--UNCOMMENT FOR DEBUGGING

	IF Convert(date,@Batch_DTS) = '1900-01-01'
	BEGIN
		-- get effective date (previous business date) to check
		Set @Effective_Date = CASE DATEPART(weekday, @today) 
						WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
						WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
						ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
						END
	END 
	ELSE 
	BEGIN
		set @Effective_Date = @Batch_DTS
	END;

		
	BEGIN TRY

		WITH WSIB as
		(
		SELECT	p.effective_date, Fund, Fund_Name,Base_Market_Value, Security_Description, Security_Name, CUSIP_Number
		FROM	PSA.V_StateStreet_Accounting_Positions p 
				join [PSA].[V_Manual_Portfolio_Mapping] mapping on mapping.portfolio_id =p.fund and p.effective_date =@Effective_Date
					and mapping.client_id IN ('WSIB','WSIBPEN') 
					and mapping.portfolio_type ='PORT' and end_date > @Effective_Date
					and mapping.ips_strategy in ('Global Real Estate', 'Private Equity') 
					and cusip_number is not null and cusip_number not in ('USD','CAD','EUR')
					and p.cusip_number not in (select distinct accounting_fund_id FROM [EDW_Mart].[Private_Market_Position_Tag] where effective_date = @Effective_Date
					and portfolio_id like 'WS%' and asset_class in ('Private Equity','Real Estate')) 
					AND BASE_MARKET_VALUE <>0
		)

		insert into [EDW_BUS].[Aggr_Private_Market_IDP_WSIB_Pending_Positions]
		Select	 Effective_date
				,Fund
				,Fund_Name
				,Base_Market_Value
				,Security_Description
				,Security_Name
				,CUSIP_Number
				,@today
				,Null Hash_Diff
				,@ETL_Load_Key
				,0
		From	WSIB W 
		where	W.Fund IN ( SELECT [Portfolio_ID] FROM [EDW_Mart].[EPS_Portfolio_Hierarchy] where effective_date = @Effective_Date )



		Select @rowsInserted = Count(*) 
		From [EDW_BUS].[Aggr_Private_Market_IDP_WSIB_Pending_Positions]
		Where Load_DTS = @today and Is_Src_Deleted = 0


		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Private_Market_IDP_WSIB_Pending_Positions_Check', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Private_Market_IDP_WSIB_Pending_Positions_Check', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END