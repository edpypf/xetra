﻿CREATE PROC [EDW_BUS].[Dynamo_NAV_Aggr_Private_Market_Cash_Flow_Realized_FX] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS

BEGIN
	Declare @today datetime2 = getdate()
	
	
	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@Effective_Date date,
			@updateFlag int,
			@initialFlag int,
			@loadLoadedDTS datetime2,
			@updatedRecords int,
			@srcLoadDTS datetime2


    Declare     @moving_Avg_Fx decimal(38,8),
		        @roc_Avg_Fx decimal(38,8),
				@effDateIndx int,
				@totalEffDates int,
				@totalFunds int,
				@fundIndx int,
				@curFundId varchar(255)

	BEGIN TRY

			-- set initial update flag
			Select @updateFlag = 0

			IF @Load_Type = 'DELTA_AUTO_TRIGGER'
			BEGIN
				TRUNCATE TABLE [EDW_BUS].[Aggr_Private_Market_Cash_Flow_Realized_FX];
			END

			IF OBJECT_ID('tempdb..#temp_all_cash_activity') IS NOT NULL
			BEGIN
				DROP TABLE #temp_all_cash_activity
			END


			IF OBJECT_ID('tempdb..#temp_all_eff_dates') IS NOT NULL
			BEGIN
				DROP TABLE #temp_all_eff_dates
			END

			IF OBJECT_ID('tempdb..#temp_all_tgt_eff_dates') IS NOT NULL
			BEGIN
				DROP TABLE #temp_all_tgt_eff_dates
			END


			IF OBJECT_ID('tempdb..#temp_eff_dates') IS NOT NULL
			BEGIN
				DROP TABLE #temp_eff_dates
			END

			IF OBJECT_ID('tempdb..#temp_eagle_change_dates') IS NOT NULL
			BEGIN
				DROP TABLE #temp_eagle_change_dates
			END

			-- populate all cash activity records
			create table #temp_all_cash_activity 
			WITH
			(
					DISTRIBUTION = Round_Robin
			) AS 
			Select pd.Portfolio_Id Fund_Id, d.Date Effective_Date, tt.trans_type, 
					Sum(ca.Local_total_flow) Local_total_flow, Sum(ca.Base_total_flow) Base_total_flow, Max(Load_DTS) Load_DTS
			FROM EDW_Common.v_Fact_Eagle_Cash_Activity  ca   
			Join (
				Select Dim_Transaction_Type_key, replace(Transaction_Type_Code, 'Eagle_','') Trans_Type
				From EDW_Common.Dim_Transaction_Type
			) tt on ca.Dim_Transaction_Type_Key = tt.Dim_Transaction_Type_Key
			join EDW_Common.Dim_Eagle_Portfolio_Detail pd on ca.Dim_Eagle_Portfolio_Detail_Key = pd.Dim_Eagle_Portfolio_Detail_Key
			join EDW_Common.Dim_Eagle_Portfolio_Detail pdc on pd.Portfolio_Id = pdc.Portfolio_Id and pdc.Record_Is_Current_Flag = 1
			join EDW_Common.Dim_Date d on ca.Dim_Date_Key = d.Dim_Date_Key
			Join EDW_Common.Dim_Eagle_Interface i on ca.Dim_Eagle_Interface_Key = i.Dim_Eagle_Interface_Key 
			WHERE Rtrim(i.Interface_Name) = 'DYNAMO'
			and Rtrim(pdc.BANK_BRANCH_CODE)  in ('GLOBAL CREDIT', 'GLOBAL CREDIT - PRIV', 'INFRASTRUCTURE', 'PRIVATE DEBT', 'PRIVATE EQUITY', 'REAL ESTATE')
			AND tt.Trans_Type in ('30', '31', '6')
			and pdc.Reporting_Currency <> 'CAD'
			Group By pd.Portfolio_Id, tt.trans_type, d.Date



			-- prepopulate all effective dates
			create table #temp_all_eff_dates 
			WITH
			(
					DISTRIBUTION = Round_Robin
			)
			AS 
			Select Fund_Id, Effective_Date, 
				  max(Load_DTS) Load_DTS
			FROM #temp_all_cash_activity
			where Trans_Type in ('30', '31')
			Group By Fund_Id, Effective_Date


			create table #temp_all_tgt_eff_dates
			WITH
			(
					DISTRIBUTION = Round_Robin
			) AS
			Select d.Date Effective_Date, p.Portfolio_Id Fund_Id, max(f.Load_DTS) Load_DTS
			From [EDW_BUS].[Aggr_Private_Market_Cash_Flow_Realized_FX] f
			Join EDW_Common.Dim_Date d on f.Dim_Date_key = d.Dim_Date_Key
			Join EDW_Common.Dim_Portfolio p on f.Dim_Portfolio_Key = p.Dim_Portfolio_Key
			Group By d.Date, p.Portfolio_Id


			create table #temp_eff_dates
			(Fund_Id varchar(255), Effective_Date datetime2)
			WITH
			(
					DISTRIBUTION = Round_Robin
			) 

			-- get latest month-end date in fact table and compare current run date
			if @Load_Type in ('ADHOC', 'ONDEMAND') 
			Begin
					-- Select @Effective_Date = @Batch_DTS
					Insert Into #temp_eff_dates (Fund_Id, Effective_Date)
					Select src.Fund_Id, src.Effective_Date
					From #temp_all_eff_dates src
					Left Join #temp_all_tgt_eff_dates tgt on src.Fund_Id = tgt.Fund_Id and src.Effective_Date = tgt.Effective_Date
					Where tgt.Fund_Id is null and datediff(d, src.Effective_Date, @Batch_DTS) > 0
			
					union

					Select Fund_Id, Effective_Date
					From #temp_all_eff_dates
					Where datediff(d, Effective_Date, @Batch_DTS) = 0  


					Select @updateFlag = 1

					Select @srcLoadDTS = max(Load_DTS)
					From (
						Select max(Load_DTS) Load_DTS
						From #temp_all_eff_dates
						Where  Effective_Date <= @Batch_DTS
					) f
					where Load_DTS is not null

			End
			else
			Begin
			
				-- get last updated DTS in target table
				Select @loadLoadedDTS = coalesce(max(aggr.Load_DTS), '1900-01-01')
				From EDW_Bus.Aggr_Private_Market_Cash_Flow_Realized_FX aggr

				/* check any update and the effective date list from Eagle */
				create table #temp_eagle_change_dates
				WITH
				(
						DISTRIBUTION = Round_Robin
				) AS
				Select src.Fund_Id, src.Effective_Date, src.Load_DTS
				From #temp_all_eff_dates src
				Left Join #temp_all_tgt_eff_dates tgt on src.Fund_Id = tgt.Fund_Id and src.Effective_Date = tgt.Effective_Date
				Where tgt.Fund_Id is null or (src.Load_DTS > tgt.Load_DTS)


				Select @updatedRecords = count(*), @srcLoadDTS = max(Load_DTS)
				From (
					Select max(Effective_Date) Effective_Date, Max(Load_DTS) Load_DTS
					From #temp_eagle_change_dates
				) f
				where Effective_Date is not null

				if @updatedRecords > 0 and @srcLoadDTS is not null 
				Begin
					-- changes from Eagle, get month end dates and current month
					insert into #temp_eff_dates (Fund_Id, Effective_Date)
					Select ed.Fund_Id, ed.Effective_Date
					From  #temp_all_eff_dates ed
					join (Select Fund_Id, Min(Effective_Date) Effective_Date
						  From #temp_eagle_change_dates
						  Group By Fund_Id
					) cd on ed.Fund_Id = cd.Fund_Id and ed.Effective_Date >= cd.Effective_Date

					Select @updateFlag = 1
				End
			End

			if @updateFlag > 0 
			Begin
				-- delete the current run effective date in the aggregate table

				Delete f  
				from EDW_Bus.Aggr_Private_Market_Cash_Flow_Report f
				join EDW_Common.Dim_Date d on f.Dim_Report_date_key = d.Dim_Date_Key
				join EDW_Common.Dim_Portfolio p on f.Dim_portfolio_key = p.Dim_Portfolio_Key
				Join #temp_eff_dates ed on d.Date = ed.Effective_Date and p.Portfolio_Id = ed.Fund_Id
				-- Where d.date in (Select  Effective_Date From #temp_eff_dates) -- datediff(d, d.date,  @Effective_Date) = 0

			
				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_summary') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_summary
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_flow') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_Cash_Flow
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_flow_moving_avg_base') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_flow_moving_avg_base
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_flow_moving_avg') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_flow_moving_avg
				END

				IF OBJECT_ID('tempdb..#mov_avg_fund') IS NOT NULL
				BEGIN
					DROP TABLE #mov_avg_fund
				END
				
------------------------------------------------------------------------------------------------------------
			

				create table #temp_dynamo_cash_activity_records
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				With fx as (
					Select ca.Fund_Id, ca.Effective_Date, ca.trans_type, 
						   Sum(ca.Local_total_flow) Local_total_flow, Sum(ca.Base_total_flow) Base_total_flow
					FROM #temp_all_cash_activity ca
					Join #temp_eff_dates ed on ca.Fund_Id = ed.Fund_Id and ca.Effective_Date = ed.Effective_Date
					WHERE ca.Trans_Type in ('30', '31')
					Group By ca.Fund_Id, ca.Effective_Date, ca.trans_type

					Union

					Select ca.Fund_Id, ca.Effective_Date, ca.trans_type, 
						   Sum(ca.Local_total_flow) Local_total_flow, Sum(ca.Base_total_flow) Base_total_flow
					FROM #temp_all_cash_activity  ca   
					Join (
						Select Fund_Id, max(Effective_Date) Effective_Date
						from #temp_eff_dates
						Group By Fund_Id
					) ed on ca.Fund_Id = ed.Fund_Id and ca.Effective_Date <= ed.Effective_Date
					WHERE ca.Trans_Type in ('6')
					Group By ca.Fund_Id, ca.Effective_Date, ca.trans_type
				)
				select  fxr.Fund_Id, fxr.Effective_Date,
				        sum(case when fx.Effective_Date < fxr.Effective_Date and trans_type in  ('30', '31', '6') then fx.Local_total_flow else 0 end ) as Previou_Local_Total_FX,
						sum(case when fx.Effective_Date < fxr.Effective_Date and trans_type in  ('6') then fx.Base_total_flow else 0 end ) as Previou_Base_Total_FX,
						sum(case when fx.Effective_Date = fxr.Effective_Date and trans_type in  ('30', '31') then fx.Base_total_flow else 0 end ) as Current_Base_Total_FX,
						sum(case when fx.Effective_Date = fxr.Effective_Date and trans_type in  ('30', '31') then fx.Local_total_flow else 0 end ) as Current_Local_Total_FX,
						min(case when trans_type in  ('30', '31') then fx.Effective_Date else fxr.Effective_Date end ) as First_FX_Date

				from fx
				Join (Select Fund_Id, Effective_Date
					  From fx
					  Where trans_type in  ('30', '31') 
					  Group By Fund_Id, Effective_Date
				) fxr on fx.Fund_Id = fxr.Fund_Id and fx.Effective_Date <= fxr.Effective_Date
				Group By fxr.Fund_Id, fxr.Effective_Date




				/* prepare calculing moving avg for portfolio with currency with non-CAD */

				create table #temp_dynamo_cash_flow_moving_avg_base
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				Select 
						Fund_Id
						,Effective_Date
						,Previou_Local_Total_FX
						,Previou_Base_Total_FX
						,Current_Local_Total_FX
						,Current_Base_Total_FX
						,Moving_Avg_Fx
						,ROC_Avg_Fx
						,Row_Number() Over (Partition By Fund_Id Order by Effective_Date ) rn
				From (
					Select Fund_Id,  Effective_Date 
						,Previou_Local_Total_FX
						,Previou_Base_Total_FX
						,Current_Local_Total_FX
						,Current_Base_Total_FX
						,case when Previou_Local_Total_FX = 0 then 0
						 else 
							case when Effective_Date = First_FX_Date then Previou_Base_Total_FX/Previou_Local_Total_FX 
							else null end
						 End Moving_Avg_Fx,
						case when Previou_Local_Total_FX = 0 then 0
						else 
							case when Effective_Date = First_FX_Date then Current_Local_Total_FX * (Previou_Base_Total_FX/Previou_Local_Total_FX) 
							else null end
						end ROC_Avg_Fx
					From #temp_dynamo_cash_activity_records

					union

					Select p.Portfolio_Id Fund_Id
					    ,d.Date Effective_Date
						,f.Previou_Local_Total_FX
						,f.Previou_Base_Total_FX
						,f.Current_Local_Total_FX
						,f.Current_Base_Total_FX
						,f.Moving_Avg_Fx
						,f.ROC_Avg_Fx
					From [EDW_BUS].[Aggr_Private_Market_Cash_Flow_Realized_FX] f
					Join EDW_Common.Dim_Date d on f.Dim_Date_key = d.Dim_Date_Key
					Join EDW_Common.Dim_Portfolio p on f.Dim_Portfolio_Key = p.Dim_Portfolio_Key
					Join (Select Fund_Id, Min(Effective_Date) Effective_Date 
					      From #temp_eff_dates 
						  Group By Fund_Id 
					) ed on d.Date < ed.Effective_Date and p.Portfolio_Id = ed.Fund_Id
				) src

				create table #mov_avg_fund
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				Select Fund_Id, Row_Number() Over(Order By Fund_Id) rn
				From (
					Select Distinct Fund_Id
					From #temp_dynamo_cash_flow_moving_avg_base
				) f

				create table #temp_dynamo_cash_flow_moving_avg
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				Select Fund_Id,  Effective_Date 
					,Previou_Local_Total_FX
					,Previou_Base_Total_FX
					,Current_Local_Total_FX
					,Current_Base_Total_FX
					,Moving_Avg_Fx
					,ROC_Avg_Fx
					,rn
				From #temp_dynamo_cash_flow_moving_avg_base
				where rn = 1
				
				Select @totalFunds = count(*) From #mov_avg_fund
				Select @fundIndx = 1

				While @fundIndx <= @totalFunds Begin

					Select @curFundId = Fund_Id 
					From #mov_avg_fund 
					Where rn = @fundIndx

					Select @totalEffDates = count(*) 
					From #temp_dynamo_cash_flow_moving_avg_base
					Where Fund_Id = @curFundId


					Select @effDateIndx = 2

					while @effDateIndx <= @totalEffDates begin

						Select 
							   @moving_Avg_Fx = case when max(t.Previou_Local_Total_FX) = 0 then 0 else (sum(f.ROC_Avg_Fx) + max(t.Previou_Base_Total_FX))/max(t.Previou_Local_Total_FX) End
						From #temp_dynamo_cash_flow_moving_avg_base t
						join #temp_dynamo_cash_flow_moving_avg f on f.rn < t.rn and f.Fund_Id = t.Fund_Id 
						Where t.rn = @effDateIndx and t.Fund_Id = @curFundId

					    Insert Into #temp_dynamo_cash_flow_moving_avg (
								Fund_id,
								Effective_Date, 
								Previou_Local_Total_FX,
								Previou_Base_Total_FX,
								Current_Local_Total_FX,
								Current_Base_Total_FX,
								Moving_Avg_Fx,
								ROC_Avg_Fx, 
								rn
						)
						Select  Fund_id,
								Effective_Date, 
								Previou_Local_Total_FX,
								Previou_Base_Total_FX,
								Current_Local_Total_FX,
								Current_Base_Total_FX,
								@moving_Avg_Fx,
								Current_Local_Total_FX * @moving_Avg_Fx as ROC_Avg_Fx, 
								rn
						From #temp_dynamo_cash_flow_moving_avg_base
						Where rn = @effDateIndx and Fund_Id = @curFundId

						select @effDateIndx = @effDateIndx + 1
					end  -- end eff date

					Select @fundIndx = @fundIndx + 1
				End  -- End Fund

----------------------------------------------------------------------------------------------------
				INSERT INTO [EDW_BUS].Aggr_Private_Market_Cash_Flow_Realized_FX
				(
				[Dim_Date_Key]
				,[Dim_Portfolio_Key]
				,[Dim_Eagle_Portfolio_Detail_Key]

				,[Previou_Local_Total_FX]
				,[Previou_Base_Total_FX]
				,[Current_Local_Total_FX]
				,Current_Base_Total_FX
				,[Moving_Avg_Fx]
				,[ROC_Avg_Fx]
				,[Hash_Diff]

				,Load_DTS
				,[Last_Update_DTS]
				,[ETL_Load_Key]
				)
				Select
					convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Date_Key]
					,coalesce(p.[Dim_Portfolio_Key],-1) [Dim_Portfolio_Key]
					,coalesce(pd.[Dim_Eagle_Portfolio_Detail_Key],-1) [Dim_Eagle_Portfolio_Detail_Key]

					,Previou_Local_Total_FX
					,Previou_Base_Total_FX
					,Current_Local_Total_FX
					,Current_Base_Total_FX
					,Moving_Avg_Fx
					,ROC_Avg_Fx		
					
					,null [Hash_Diff]
					,@srcLoadDTS
					,@today
					,@ETL_Load_Key

				From #temp_dynamo_cash_flow_moving_avg src
				--Dim_Portfolio_Key
				Left Join EDW_Common.Dim_Portfolio p on src.Fund_Id = p.Portfolio_Id and p.Record_Is_Current_Flag = 1
				Left Join EDW_Common.Dim_Eagle_Portfolio_Detail pd on src.Fund_Id = pd.Portfolio_Id and pd.Record_Is_Current_Flag = 1

				Select @rowsInserted = Count(*) 
				From [EDW_BUS].Aggr_Private_Market_Cash_Flow_Report
				Where Last_Update_DTS = @today

				Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_Cash_Flow_Report', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

				/* cleanup temp tables */
				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

		End

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_Cash_Flow_Report', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END