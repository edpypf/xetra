﻿CREATE PROC [EDW_BUS].[Dynamo_NAV_Aggr_Private_Market_NAV_Bridge] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS

BEGIN
	Declare @today datetime2 = getdate()
	
	
	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@Effective_Date date,
			@PrevQuaterEnd date,
			@PrevYearEnd date,
			@BeginOfQuater date,
			@BeginOfYear date,
			@updateFlag int,
			@loadLoadedDTS datetime2,
			@lastLoadeEffDate datetime2,
			@updatedRecords int,
			@srcLoadDTS datetime2,
			@FundSize NUMERIC (38, 12) 

	BEGIN TRY

			-- set initial update flag
			Select @updateFlag = 0

			-- get latest month-end date in fact table and compare current run date
			if @Load_Type in ('ADHOC', 'ONDEMAND') 
			Begin
					Select @Effective_Date = @Batch_DTS
					Select @updateFlag = 1

					Select @srcLoadDTS = max(Load_DTS)
					From (
						Select  Max(Load_DTS) Load_DTS
						From EDW_Common.Fact_Eagle_Position f
						Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
						Where  d.Date = @Effective_Date 

						union 

						Select  max(Load_DTS) Load_DTS
						From EDW_Common.Fact_Eagle_Cash_Activity f
						Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
						Where  d.Date = @Effective_Date 
					) f

			End
			else
			Begin
			
				-- get latest month end date which has data in Eagle
				Select @Effective_Date = Max(d.Date) 
				From EDW_Common.Fact_Eagle_Position f
				Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
				where d.Date <= @Batch_DTS and d.Month_End_Flg = 1


				-- get last updated DTS in target table
				Select @loadLoadedDTS = max(aggr.Load_DTS)
				From EDW_Bus.Aggr_Private_Market_NAV_Report aggr
				Join EDW_Common.Dim_Date d on aggr.Dim_Date_Key = d.Dim_Date_Key
				Where d.Date = @Effective_Date


				/* check any update for last month end date from Eagle */
				Select @updatedRecords = count(*), @srcLoadDTS = max(Load_DTS)
				From (
					Select max(f.dim_date_key) dim_Date_Key, Max(Load_DTS) Load_DTS
					From EDW_Common.Fact_Eagle_Position f
					Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
					Where  d.Date = @Effective_Date and f.Load_DTS > @loadLoadedDTS

					union 

					Select max(f.dim_date_key) dim_Date_Key, max(Load_DTS) Load_DTS
					From EDW_Common.Fact_Eagle_Cash_Activity f
					Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
					Where  d.Date <= @Effective_Date and f.Load_DTS > @loadLoadedDTS
				) f
				where Dim_Date_key is not null

				if @updatedRecords > 0 and @srcLoadDTS is not null 
				Begin
					Select @updateFlag = 1
				End

			End

			if @updateFlag > 0 
			Begin

				-- set Begin of Quater, Begin of Year
				Select @BeginOfQuater = DATEADD(q, DATEDIFF(q, 0, @Effective_Date), 0)
				Select @BeginOfYear = DATEADD(yy, DATEDIFF(yy, 0, @Effective_Date), 0)
				Select @PrevQuaterEnd = DATEADD(q, DateDiff(q, 0, @Effective_Date), -1) 
				Select @PrevYearEnd = DATEADD(yy, DATEDIFF(yy, 0, @Effective_Date), -1)

				-- delete the current run effective date in the aggregate table

				Delete f  
				from EDW_Bus.Aggr_Private_Market_NAV_Bridge f
				join EDW_Common.Dim_Date d on f.Dim_date_key = d.Dim_Date_Key
				Where datediff(d, d.date,  @Effective_Date) = 0

				-- Get  fund size
				Select @FundSize = Ending_Market_Value
				from [EDW_Common].[V_Fact_Eagle_Total_Portfolio_Performance] pp
				Join EDW_Common.Dim_Date d on pp.Dim_Date_Key = d.Dim_Date_Key
				Join EDW_Common.Dim_Portfolio p on pp.Dim_Portfolio_Key = p.Dim_Portfolio_Key 
				where d.Date = @Effective_Date and Report_Freq_Code = 'D' and p.Portfolio_Id in ('OPBC0005','WSA02','WSA59','WSA01','IMTC0001')

				IF OBJECT_ID('tempdb..#temp_dynamo_position_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_position_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_summary') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_summary
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_nav_bridge') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_nav_bridge
				END

				create table #temp_dynamo_position_records
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				With FX_Rate as (
					Select d.Date Effective_Date, f.Dim_From_Currency_Key, SPOT_Rate FX_Rate
					From EDW_Common.Dim_Date d
					Join [EDW_Common].[Fact_Eagle_Currency_FX_Rate] f on f.Dim_Date_Key = d.Dim_Date_Key
				)
				SELECT  
					pd.Portfolio_Id Fund_Id,
					sd.Security_Id,
					@Effective_Date Effective_Date,
					Rtrim(pdc.BANK_BRANCH_CODE) Asset_Class,
					Max(pdc.Reporting_Currency) Local_Currency,
					Sum(Case when d.date = @Effective_Date then ISNULL(p.MARKET_VALUE_income,0) else 0 End) as Cur_Quater_Market_Value,  
					Sum(Case when d.date = @Effective_Date then ISNULL(p.MARKET_VALUE_income_Local,0) else 0 End) as Cur_Quater_Market_Value_Local, 
					
					Sum(Case when d.date = @PrevQuaterEnd then ISNULL(p.MARKET_VALUE_income,0) Else 0 End) as Prev_Quater_Base_Market_Value,  
					Sum(Case when d.date = @PrevQuaterEnd then ISNULL(p.MARKET_VALUE_income_Local,0) Else 0 End) as Prev_Quater_Base_Market_Value_Local, 

					Sum(Case when d.date = @PrevYearEnd then  ISNULL(p.MARKET_VALUE_income,0) Else 0 End) as Year_Begin_Base_Market_Value,  
					Sum(Case when d.date = @PrevYearEnd then  ISNULL(p.MARKET_VALUE_income_Local,0) Else 0 End) as Year_Begin_Base_Market_Value_Local,
					max(qtfx.FX_Rate) as Prev_Quater_End_FX,  -- Prev Quater End FX
					max(ytdfx.FX_Rate) as Prev_Year_End_FX            -- Prev Year End FX

				FROM EDW_Common.V_Fact_Eagle_Position p
				join EDW_Common.Dim_Eagle_Portfolio_Detail pd on p.Dim_Eagle_Portfolio_Detail_Key = pd.Dim_Eagle_Portfolio_Detail_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pdc on pd.Portfolio_Id = pdc.Portfolio_Id and pdc.record_Is_Current_Flag = 1
				Join EDW_Common.Dim_Eagle_Security_Detail sd on p.Dim_Eagle_Security_Detail_Key = sd.Dim_Eagle_Security_Detail_Key
				Join EDW_Common.Dim_Eagle_Interface i on p.Dim_Eagle_Interface_Key = i.Dim_Eagle_Interface_Key 
				--Join EDW_Common.Dim_Currency cr on p.Dim_Local_Currency_Key = cr.Dim_Currency_Key
				Join EDW_Common.Dim_Date d on p.Dim_Date_Key = d.Dim_Date_Key
				Left Join FX_Rate qtfx on @PrevQuaterEnd  = qtfx.Effective_Date and p.Dim_Local_Currency_Key = qtfx.Dim_From_Currency_Key
				Left Join FX_Rate ytdfx on @PrevYearEnd = ytdfx.Effective_Date and p.Dim_Local_Currency_Key = ytdfx.Dim_From_Currency_Key

				WHERE  Rtrim(i.Interface_Name) = 'DYNAMO'
				and Rtrim(pdc.BANK_BRANCH_CODE)  in ('GLOBAL CREDIT', 'GLOBAL CREDIT - PRIV', 'INFRASTRUCTURE', 'PRIVATE DEBT', 'PRIVATE EQUITY', 'REAL ESTATE')
				-- and datediff(d, d.Date, '2022-07-06') = 0
				and d.Date in (@Effective_Date, @PrevQuaterEnd, @PrevYearEnd)
				Group By pd.Portfolio_Id, sd.Security_Id, Rtrim(pdc.BANK_BRANCH_CODE)

				create table #temp_dynamo_cash_activity_records
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				SELECT        
					   pd.Portfolio_Id Fund_Id,  
					   sd.Security_Id, 
					   d.Date Effective_Date,

					   Rtrim(pdc.BANK_BRANCH_CODE) Asset_Class,
					   Max(pdc.Reporting_Currency) Local_Currency,

						sum(case when trans_type in  ('12') then ISNULL(ca.LOCAL_TOTAL_FLOW,0)    
						    else 0 end ) as Commitment_Local,  
						sum (case when trans_type in  ('6','7','64','28','29','30','35','36','44','46','49') then ISNULL(ca.LOCAL_TOTAL_FLOW,0)  
						          when trans_type IN   ('48') THEN -1*ca.local_total_flow else 0 end ) as Commitment_Drawn_Local,  
						sum(case when trans_type in  ('58', '60', '65', '69', '70', '72', '48') then  ISNULL(-1*ca.local_total_flow, 0)
								 when trans_type IN  ('4', '5', '6', '7', '35', '44', '49', '57', '28', '29', '30', '36', '46', '64', '76') THEN  Isnull(ca.local_total_flow, 0)  else 0 end ) as Commitment_Funded_Local,
						sum(case when trans_type in  ('12') then ISNULL(ca.Base_TOTAL_FLOW,0)    
						    else 0 end ) as Commitment_Base,  
						sum (case when trans_type in  ('6','7','64','28','29','30','35','36','44','46','49') then ISNULL(ca.Base_TOTAL_FLOW,0) 
						          when trans_type IN   ('48') THEN -1*ca.Base_TOTAL_FLOW else 0 end ) as Commitment_Drawn_Base,  
						sum(case when trans_type in  ('58', '60', '65', '69', '70', '72', '48') then  ISNULL(-1*ca.Base_TOTAL_FLOW, 0)
								 when trans_type IN  ('4', '5', '6', '7', '35', '44', '49', '57', '28', '29', '30', '36', '46', '64', '76') THEN  Isnull(ca.Base_TOTAL_FLOW, 0)  else 0 end ) as Commitment_Funded_Base,

						sum (case when trans_type in  ('6','7','34','44','45','46','47','49','50') then ISNULL(ca.base_total_flow,0) else 0 end ) as Capital_Call_Base, 
						sum (case when trans_type in  ('20','22','26','28','38','39','64','74','79') then ISNULL(ca.base_total_flow,0) else 0 end ) as Distribution_Base, 
						sum (case when trans_type in  ('30','31') then ISNULL(ca.base_total_flow,0) else 0 end ) as Return_of_Capital_Base, 
						sum (case when trans_type in  ('28','29','30','64') then ISNULL(ca.base_total_flow,0) else 0 end ) as Recallable_Distribution_Base, 

						sum(case when trans_type in  ('9','10','58','60','61','65','69','70','72','73') then  -1*ca.base_total_flow  
								 when trans_type in  ('1','4','5','6','7','8','11','34','35','40','41','44','45','46','47','49','50','51','52','57') then ca.base_total_flow else 0 end ) as MOIC_Capital_Called_Base,
						sum (case when trans_type in  ('28','29','30','64','64','76') then ISNULL(-1*ca.base_total_flow,0) else 0 end ) as MOIC_Recallable_Base,
						sum (case when trans_type in  ('15','31','53','54','66') then ISNULL(-1*ca.base_total_flow,0) else 0 end ) as MOIC_Return_of_capital_Base,
						sum (case when trans_type in  ('2', '13', '16', '17', '18', '19', '20', '21', '22', '23', '24', '26', '27', '32', '36', '37', '38', '39', '43', '56', '62', '63', '67', '74', '75', '79', '25', '68') then ISNULL(-1*ca.base_total_flow,0) else 0 end ) as MOIC_IncomeRealized_Base,

						sum (case when trans_type in  ('6','7','34','44','45','46','47','49','50') then ISNULL(ca.local_total_flow,0) else 0 end ) as Capital_Call_Local, 
						sum (case when trans_type in  ('20','22','26','28','38','39','64','74','79') then ISNULL(ca.local_total_flow,0) else 0 end ) as Distribution_Local, 
						sum (case when trans_type in  ('30','31') then ISNULL(ca.local_total_flow,0) else 0 end ) as Return_of_Capital_Local, 
						sum (case when trans_type in  ('28','29','30','64') then ISNULL(ca.local_total_flow,0) else 0 end ) as Recallable_Distribution_Local, 


						sum(case when trans_type in  ('9','10','58','60','61','65','69','70','72','73') then  -1*ca.local_total_flow  
								 when trans_type in  ('1','4','5','6','7','8','11','34','35','40','41','44','45','46','47','49','50','51','52','57') then ca.local_total_flow else 0 end ) as MOIC_Capital_Called_Local,
						sum (case when trans_type in  ('28','29','30','64','64','76') then ISNULL(-1*ca.local_total_flow,0) else 0 end ) as MOIC_Recallable_Local,
						sum (case when trans_type in  ('15','31','53','54','66') then ISNULL(-1*ca.local_total_flow,0) else 0 end ) as MOIC_Return_of_capital_Local,
						sum (case when trans_type in  ('2', '13', '16', '17', '18', '19', '20', '21', '22', '23', '24', '26', '27', '32', '36', '37', '38', '39', '43', '56', '62', '63', '67', '74', '75', '79', '25', '68') then ISNULL(-1*ca.local_total_flow,0) else 0 end ) as MOIC_IncomeRealized_Local

				FROM EDW_Common.v_Fact_Eagle_Cash_Activity  ca   
				Join (
					Select Dim_Transaction_Type_key, replace(Transaction_Type_Code, 'Eagle_','') Trans_Type
					From EDW_Common.Dim_Transaction_Type
				) tt on ca.Dim_Transaction_Type_Key = tt.Dim_Transaction_Type_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pd on ca.Dim_Eagle_Portfolio_Detail_Key = pd.Dim_Eagle_Portfolio_Detail_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pdc on pd.Portfolio_Id = pdc.Portfolio_Id and pdc.record_Is_Current_Flag = 1
				Join EDW_Common.Dim_Eagle_Security_Detail sd on ca.Dim_Eagle_Security_Detail_Key = sd.Dim_Eagle_Security_Detail_Key 
				join EDW_Common.Dim_Date d on ca.Dim_Date_Key = d.Dim_Date_Key
				Join EDW_Common.Dim_Eagle_Interface i on ca.Dim_Eagle_Interface_Key = i.Dim_Eagle_Interface_Key 

				WHERE Rtrim(i.Interface_Name) = 'DYNAMO'
				and Rtrim(pdc.BANK_BRANCH_CODE)  in ('GLOBAL CREDIT', 'GLOBAL CREDIT - PRIV', 'INFRASTRUCTURE', 'PRIVATE DEBT', 'PRIVATE EQUITY', 'REAL ESTATE')
				AND d.Date <=  @Effective_Date 
				GROUP BY sd.Security_Id , pd.Portfolio_Id, d.Date, Rtrim(pdc.BANK_BRANCH_CODE)

				create table #temp_dynamo_cash_activity_summary
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				With cur_q as (
				Select
						Fund_Id,  
						Security_Id, 
						coalesce(Local_Currency,'') Local_Currency,
						Sum(Commitment_Local) Cur_Quater_Commitment_Local,  
						Sum(Commitment_Drawn_Local) Cur_Quater_Commitment_Drawn_Local,  
						Sum(Commitment_Funded_Local) Cur_Quater_Commitment_Funded_Local,
						Sum(Commitment_Base) Cur_Quater_Commitment_Base,  
						Sum(Commitment_Drawn_Base) Cur_Quater_Commitment_Drawn_Base,  
						Sum(Commitment_Funded_Base) Cur_Quater_Commitment_Funded_Base,
						Sum(case when Effective_Date >= @BeginOfQuater Then Capital_Call_Base Else 0 End) Cur_Quater_Capital_Call_Base, 
						Sum(case when Effective_Date >= @BeginOfQuater Then Distribution_Base Else 0 End) Cur_Quater_Distribution_Base, 
						Sum(case when Effective_Date >= @BeginOfQuater Then Return_of_Capital_Base Else 0 End) Cur_Quater_Return_of_Capital_Base,
						Sum(case when Effective_Date >= @BeginOfQuater Then Recallable_Distribution_Base Else 0 End) Cur_Quater_Recallable_Distribution_Base,
						Sum(case when Effective_Date >= @BeginOfQuater Then Capital_Call_Local Else 0 End) Cur_Quater_Capital_Call_Local, 
						Sum(case when Effective_Date >= @BeginOfQuater Then Distribution_Local Else 0 End) Cur_Quater_Distribution_Local, 
						Sum(case when Effective_Date >= @BeginOfQuater Then Return_of_Capital_Local Else 0 End) Cur_Quater_Return_of_Capital_Local,
						Sum(case when Effective_Date >= @BeginOfQuater Then Recallable_Distribution_Local Else 0 End) Cur_Quater_Recallable_Distribution_Local,
						Sum(MOIC_Capital_Called_Local) Cur_Quater_MOIC_Capital_Called_Local,
						sum (MOIC_Recallable_Local) Cur_Quater_MOIC_Recallable_Local,
						sum (MOIC_Return_of_capital_Local) Cur_Quater_MOIC_Return_of_capital_Local,
						sum (MOIC_IncomeRealized_Local) Cur_Quater_MOIC_IncomeRealized_Local, 

						Sum(MOIC_Capital_Called_Base) Cur_Quater_MOIC_Capital_Called_Base,
						sum (MOIC_Recallable_Base) Cur_Quater_MOIC_Recallable_Base,
						sum (MOIC_Return_of_capital_Base) Cur_Quater_MOIC_Return_of_capital_Base,
						sum (MOIC_IncomeRealized_Base) Cur_Quater_MOIC_IncomeRealized_Base

				From #temp_dynamo_cash_activity_records
				Group By Security_Id , Fund_Id, coalesce(Local_Currency,'')
				), 
				ytd as (
				Select
						Fund_Id,  
						Security_Id, 
						coalesce(Local_Currency,'') Local_Currency,
						Sum(Capital_Call_Base) YTD_Capital_Call_Base, 
						Sum(Distribution_Base) YTD_Distribution_Base, 
						Sum(Return_of_Capital_Base) YTD_Return_of_Capital_Base,
						Sum(Recallable_Distribution_Base) YTD_Recallable_Distribution_Base,
						Sum(Capital_Call_Local) YTD_Capital_Call_Local, 
						Sum(Distribution_Local) YTD_Distribution_Local, 
						Sum(Return_of_Capital_Local) YTD_Return_of_Capital_Local,
						Sum(Recallable_Distribution_Local) YTD_Recallable_Distribution_Local
						



				From #temp_dynamo_cash_activity_records
				Where Effective_Date >= @BeginOfYear
				Group By Security_Id , Fund_Id, coalesce(Local_Currency,'')
				)
				Select
					  cur_q.Fund_Id  
					  ,cur_q.Security_Id
					  ,cur_q.Local_Currency
					  ,@Effective_Date Effective_Date

					  ,Cur_Quater_Commitment_Local
					  ,Cur_Quater_Commitment_Drawn_Local
					  ,Cur_Quater_Commitment_Funded_Local
					  ,Cur_Quater_Commitment_Base
					  ,Cur_Quater_Commitment_Drawn_Base
					  ,Cur_Quater_Commitment_Funded_Base

					  ,Cur_Quater_Capital_Call_Base
					  ,Cur_Quater_Distribution_Base
					  ,Cur_Quater_Return_of_Capital_Base
					  ,Cur_Quater_Recallable_Distribution_Base

					  ,Cur_Quater_Capital_Call_Local
					  ,Cur_Quater_Distribution_Local
					  ,Cur_Quater_Return_of_Capital_Local
					  ,Cur_Quater_Recallable_Distribution_Local

					  ,YTD_Capital_Call_Base
					  ,YTD_Distribution_Base
					  ,YTD_Return_of_Capital_Base
					  ,YTD_Recallable_Distribution_Base
					  ,YTD_Capital_Call_Local
					  ,YTD_Distribution_Local
					  ,YTD_Return_of_Capital_Local
					  ,YTD_Recallable_Distribution_Local

					  ,Cur_Quater_MOIC_Capital_Called_Local
					  ,Cur_Quater_MOIC_Recallable_Local
					  ,Cur_Quater_MOIC_Return_of_capital_Local
					  ,Cur_Quater_MOIC_IncomeRealized_Local

					  ,Cur_Quater_MOIC_Capital_Called_Base
					  ,Cur_Quater_MOIC_Recallable_Base
					  ,Cur_Quater_MOIC_Return_of_capital_Base
					  ,Cur_Quater_MOIC_IncomeRealized_Base

				From cur_q 
				left join ytd on cur_q.Security_Id = ytd.Security_Id and cur_q.Fund_Id = ytd.Fund_Id 

				create table #temp_dynamo_nav_bridge
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				Select
					  coalesce(p.Fund_Id, ca.Fund_Id) Fund_Id
					  ,coalesce(p.Security_Id,ca.Security_Id) Security_Id
					  ,coalesce(p.Local_Currency, ca.Local_Currency) Local_Currency
					  ,@Effective_Date Effective_Date
					  ,coalesce(p.Cur_Quater_Market_Value,0) Cur_Quater_Market_Value
					  ,coalesce(p.Cur_Quater_Market_Value_Local,0) Cur_Quater_Market_Value_Local
					  ,coalesce(p.Prev_Quater_Base_Market_Value,0) Prev_Quater_Base_Market_Value
					  ,coalesce(p.Prev_Quater_Base_Market_Value_Local,0) Prev_Quater_Base_Market_Value_Local
					  ,coalesce(p.Year_Begin_Base_Market_Value,0) Year_Begin_Base_Market_Value
					  ,coalesce(p.Year_Begin_Base_Market_Value_Local,0) Year_Begin_Base_Market_Value_Local

					  ,Cur_Quater_Commitment_Local 
					  ,Cur_Quater_Commitment_Drawn_Local  
					  ,Cur_Quater_Commitment_Funded_Local
					  ,Cur_Quater_Commitment_Base
					  ,Cur_Quater_Commitment_Drawn_Base  
					  ,Cur_Quater_Commitment_Funded_Base

					  ,Cur_Quater_Capital_Call_Local
					  ,Cur_Quater_Distribution_Local
					  ,Cur_Quater_Return_of_Capital_Local
					  ,Cur_Quater_Recallable_Distribution_Local
					  ,Cur_Quater_Capital_Call_Base
					  ,Cur_Quater_Distribution_Base
					  ,Cur_Quater_Return_of_Capital_Base
					  ,Cur_Quater_Recallable_Distribution_Base

					  ,Cur_Quater_MOIC_Capital_Called_Local
					  ,Cur_Quater_MOIC_Recallable_Local
					  ,Cur_Quater_MOIC_Return_of_capital_Local
					  ,Cur_Quater_MOIC_IncomeRealized_Local

					  ,Cur_Quater_MOIC_Capital_Called_Base
					  ,Cur_Quater_MOIC_Recallable_Base
					  ,Cur_Quater_MOIC_Return_of_capital_Base
					  ,Cur_Quater_MOIC_IncomeRealized_Base


					  ,case when isnull(Prev_Quater_End_FX,0) = 0 then 0 
					   else 
						 (coalesce(Cur_Quater_Market_Value_Local,0) - (coalesce(Prev_Quater_Base_Market_Value_Local,0) + Coalesce(Cur_Quater_Capital_Call_Local,0) + Coalesce(Cur_Quater_Distribution_Local,0) + Coalesce(Cur_Quater_Return_of_Capital_Local,0) )) / Prev_Quater_End_FX
					   end Cur_Quater_Appreciation_Base
					   
					   ,coalesce(Cur_Quater_Market_Value,0) - (coalesce(Prev_Quater_Base_Market_Value,0) + Coalesce(Cur_Quater_Capital_Call_Base,0) + Coalesce(Cur_Quater_Distribution_Base,0) + Coalesce(Cur_Quater_Return_of_Capital_Base,0)) - 
					   case when isnull(Prev_Quater_End_FX,0) = 0 then 0 
					   else 
						(coalesce(Cur_Quater_Market_Value_Local,0) - (coalesce(Prev_Quater_Base_Market_Value_Local,0) + Coalesce(Cur_Quater_Capital_Call_Local,0) + Coalesce(Cur_Quater_Distribution_Local,0) + Coalesce(Cur_Quater_Return_of_Capital_Local,0))) / Prev_Quater_End_FX
					   End Cur_Quater_FX_Impact
					  ,Prev_Quater_End_FX

					  ,YTD_Capital_Call_Local
					  ,YTD_Distribution_Local
					  ,YTD_Return_of_Capital_Local
					  ,YTD_Recallable_Distribution_Local
					  ,YTD_Capital_Call_Base
					  ,YTD_Distribution_Base
					  ,YTD_Return_of_Capital_Base
					  ,YTD_Recallable_Distribution_Base

					  ,case when isnull(Prev_Year_End_FX,0) = 0 then 0 
					   else 
						 (coalesce(Cur_Quater_Market_Value_Local,0) - (coalesce(Year_Begin_Base_Market_Value_Local,0) + Coalesce(YTD_Capital_Call_Local,0) + Coalesce(YTD_Distribution_Local,0) + Coalesce(YTD_Return_of_Capital_Local,0))) / Prev_Year_End_FX
					   end YTD_Appreciation_Base,
					   
					   coalesce(Cur_Quater_Market_Value,0) - (coalesce(Year_Begin_Base_Market_Value,0) + Coalesce(YTD_Capital_Call_Base,0) + Coalesce(YTD_Distribution_Base,0) + Coalesce(YTD_Return_of_Capital_Base,0)) - 
					   case when isnull(Prev_Quater_End_FX,0) = 0 then 0
					   else 
						(coalesce(Cur_Quater_Market_Value_Local,0) - (coalesce(Year_Begin_Base_Market_Value_Local,0) + coalesce(YTD_Capital_Call_Local,0) + coalesce(YTD_Distribution_Local,0) + Coalesce(YTD_Return_of_Capital_Local,0))) / Prev_Year_End_FX
					   End YTD_FX_Impact,
					   Prev_Year_End_FX

				From #temp_dynamo_position_records p
				full join #temp_dynamo_cash_activity_summary ca on p.Security_Id = ca.Security_Id and p.Fund_Id = ca.Fund_Id 
			    
				
				INSERT INTO [EDW_BUS].Aggr_Private_Market_NAV_Bridge
				(
				  [Dim_Date_Key]
				  ,[Dim_Portfolio_Key]
				  ,[Dim_Eagle_Portfolio_Detail_Key]
				  ,[Dim_Security_Key]
				  ,[Dim_Eagle_Security_Detail_Key]
				  ,Dim_Currency_Key

				  ,[Cur_Quarter_Nav_Base]
				  ,[Cur_Quarter_Nav_Local]
				  ,[Prev_Quarter_Nav_Base]
				  ,[Prev_Quarter_Nav_Local]
				  ,[Beginning_Of_Year_Nav_Base]
				  ,[Beginning_Of_Year_Nav_Local]

				  ,[Cur_Quarter_Capital_Called_Local]
				  ,[Cur_Quarter_Distribution_Local]
				  ,[Cur_Quarter_Return_of_Capital_Local]
				  ,Cur_Quarter_Recallable_Distribution_Local
				  ,[Cur_Quarter_Capital_Called_Base]
				  ,[Cur_Quarter_Distribution_Base]
				  ,[Cur_Quarter_Return_of_Capital_Base]
				  ,Cur_Quarter_Recallable_Distribution_Base

				  ,Cur_Quarter_MOIC_Capital_Called_Local
				  ,Cur_Quarter_MOIC_Recallable_Local
				  ,Cur_Quarter_MOIC_Return_of_capital_Local
				  ,Cur_Quarter_MOIC_IncomeRealized_Local

				  ,Cur_Quarter_MOIC_Capital_Called_Base
				  ,Cur_Quarter_MOIC_Recallable_Base
				  ,Cur_Quarter_MOIC_Return_of_capital_Base
				  ,Cur_Quarter_MOIC_IncomeRealized_Base

				  ,[Cur_Quarter_Appreciation]
				  ,[Cur_Quarter_FX_Impact]
				  ,[Prev_Quarter_End_FX_Rate]

				  ,[Net_Value_Added]

				  ,[YTD_Capital_Called_Local]
				  ,[YTD_Distribution_Local]
				  ,[YTD_Return_of_Capital_Local]
				  ,YTD_Recallable_Distribution_Local
				  ,[YTD_Capital_Called_Base]
				  ,[YTD_Distribution_Base]
				  ,[YTD_Return_of_Capital_Base]
				  ,YTD_Recallable_Distribution_Base
				  ,[YTD_Appreciation]
				  ,[YTD_FX_Impact]
				  ,[Prev_Year_End_FX_Rate]

				  ,[Commitment_Local]
				  ,[Drawn_Commitment_Local]
				  ,[Funded_Commitment_Local]
				  ,[Commitment_Base]
				  ,[Drawn_Commitment_Base]
				  ,[Funded_Commitment_Base]

				  ,[Fund_Size]

				  ,Other_Info
				  ,[Load_DTS]
				  ,[Last_Update_DTS]
				  ,[ETL_Load_Key]
	  )
				Select
					  convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Date_Key]
					  ,coalesce(p.[Dim_Portfolio_Key],-1) [Dim_Portfolio_Key]
					  ,coalesce(pd.[Dim_Eagle_Portfolio_Detail_Key],-1) [Dim_Eagle_Portfolio_Detail_Key]
					  ,coalesce(sec.[Dim_Security_Key], -1) [Dim_Security_Key]
					  ,coalesce(secd.[Dim_Eagle_Security_Detail_Key], -1) [Dim_Eagle_Security_Detail_Key]
					  ,coalesce(cr.Dim_Currency_Key, -1) [Dim_Local_Currency_Key]

					  ,Cur_Quater_Market_Value
					  ,Cur_Quater_Market_Value_Local
					  ,Prev_Quater_Base_Market_Value
					  ,Prev_Quater_Base_Market_Value_Local
					  ,Year_Begin_Base_Market_Value
					  ,Year_Begin_Base_Market_Value_Local

					  ,Cur_Quater_Capital_Call_Local
					  ,Cur_Quater_Distribution_Local
					  ,Cur_Quater_Return_of_Capital_Local
					  ,Cur_Quater_Recallable_Distribution_Local
					  ,Cur_Quater_Capital_Call_Base
					  ,Cur_Quater_Distribution_Base
					  ,Cur_Quater_Return_of_Capital_Base
					  ,Cur_Quater_Recallable_Distribution_Base

					  ,Cur_Quater_MOIC_Capital_Called_Local
					  ,Cur_Quater_MOIC_Recallable_Local
					  ,Cur_Quater_MOIC_Return_of_capital_Local
					  ,Cur_Quater_MOIC_IncomeRealized_Local

					  ,Cur_Quater_MOIC_Capital_Called_Base
					  ,Cur_Quater_MOIC_Recallable_Base
					  ,Cur_Quater_MOIC_Return_of_capital_Base
					  ,Cur_Quater_MOIC_IncomeRealized_Base

					  ,Cur_Quater_Appreciation_Base
					  ,Cur_Quater_FX_Impact
					  ,Prev_Quater_End_FX

					  ,null -- place holder for [Net_Value_Added]

					  ,YTD_Capital_Call_Local
					  ,YTD_Distribution_Local
					  ,YTD_Return_of_Capital_Local
					  ,YTD_Recallable_Distribution_Local
					  ,YTD_Capital_Call_Base
					  ,YTD_Distribution_Base
					  ,YTD_Return_of_Capital_Base
					  ,YTD_Recallable_Distribution_Base
					  ,YTD_Appreciation_Base
					  ,YTD_FX_Impact
					  ,Prev_Year_End_FX

					  ,Cur_Quater_Commitment_Local  
					  ,Cur_Quater_Commitment_Drawn_Local  
					  ,Cur_Quater_Commitment_Funded_Local
					  ,Cur_Quater_Commitment_Base
					  ,Cur_Quater_Commitment_Drawn_Base  
					  ,Cur_Quater_Commitment_Funded_Base

					  ,@FundSize

					  ,Case when cr.Dim_Currency_Key is null or p.Dim_Portfolio_key is null or sec.Dim_Security_Key is null Then
						  '{"Portfolio_Id": "' + src.Fund_Id + '"}' + 
						  '{"Fund_Id": "' + src.Security_Id + '"}' + 
						  '{"Local_Currency": "' + src.Local_Currency + '"}'
					  Else null End
					  ,@srcLoadDTS
					  ,@today
					  ,@ETL_Load_Key

				From #temp_dynamo_nav_bridge src
				--Dim_Portfolio_Key
				Left Join EDW_Common.Dim_Portfolio p on src.Fund_Id = p.Portfolio_Id and p.Record_Is_Current_Flag = 1

				Left Join EDW_Common.Dim_Eagle_Portfolio_Detail pd on src.Fund_Id = pd.Portfolio_Id and pd.Record_Is_Current_Flag = 1

				--Dim_Security_Key
				Left Join EDW_Common.Dim_Security sec on 'Eagle_' + src.Security_Id = sec.Src_Security_Id and sec.Record_Is_Current_Flag = 1

				Left Join EDW_Common.Dim_Eagle_Security_Detail secd on src.Security_Id = secd.Security_Id and secd.Record_Is_Current_Flag = 1
				
				Left Join EDW_Common.Dim_Currency cr on src.Local_Currency = cr.Currency and cr.Record_Is_Current_Flag = 1

				Select @rowsInserted = Count(*) 
				From [EDW_BUS].Aggr_Private_Market_NAV_Bridge
				Where Last_Update_DTS = @today

				Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_NAV_Bridge', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

				/* cleanup temp tables */

				IF OBJECT_ID('tempdb..#temp_dynamo_position_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_position_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_summary') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_summary
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_nav_bridge') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_nav_bridge
				END
		End

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_NAV_Bridge', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END