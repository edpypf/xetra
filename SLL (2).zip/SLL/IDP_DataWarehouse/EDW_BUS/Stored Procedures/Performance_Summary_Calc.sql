﻿CREATE PROC [EDW_BUS].[Performance_Summary_Calc] @ETL_LOAD_KEY [INT],@Load_Type [VARCHAR](30),@Batch_DTS [DATETIME2] AS
Begin

Begin try 

Declare @rec_count as int=0
Declare @Latest_Rebalancing_Date as date
declare @debug as int =0
Declare @Latest_Portfolio_Mapping_Date as date 
EXEC [EDW_BUS].[Performance_RPT_TPA_Rebalancing_Calc] @ETL_Load_Key,@Load_Type,@Batch_DTS




Select @Latest_Rebalancing_Date=max(cast(updated_datetime as date)) from [EDW_BUS].[Aggr_Performance_Summary_Rebalancing]

Select @rec_count=count(*) from [EDW_BUS].[Aggr_Performance_Summary_Prep]





Declare @today date
Set @today=cast(dateadd(hour,-4,getdate()) as date)
Declare @effective_Date as date

IF Convert(date,@Batch_DTS) = '1900-01-01'
		BEGIN
			-- get effective date (previous business date) to check
			Set @Effective_Date = CASE DATEPART(weekday, @today) 
							WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
							WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
							ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
							END
		End
		Else 
		Begin
		set @Effective_Date =  Convert(date,@Batch_DTS)
		END 
--Set @Batch_dts=cast(@Batch_DTS as date)




if object_id('Tempdb..#Dates') is not null
drop table Tempdb..#Dates
Create table #Dates (Effective_Date  date)



Select @Latest_Portfolio_Mapping_Date=max(cast(Load_DTS AS DATE)) from [PSA].[Manual_Performance_Report_Portfolio_Mapping]
iF @Latest_Portfolio_Mapping_Date=@Today Set @Rec_Count=0


if (@load_Type in ('Adhoc_Performance','Delta','ALL','Adhoc_TPA_Performance') and @Effective_Date<>'1900-01-01') or @rec_count=0  or (@Latest_Rebalancing_Date=@today)
Begin



--truncate table [EDW_BUS].[Aggr_Performance_Summary_Prep]
 
If @Latest_Rebalancing_Date=@today   and @rec_count<>0
Begin
	Insert into #dates (effective_Date)
	Select distinct effective_Date from [EDW_BUS].[Aggr_Performance_Summary_Rebalancing] where cast(updated_datetime as date)=@Latest_Rebalancing_Date
End 

if @Effective_Date<>'1900-01-01' and @rec_count<>0
Begin 
	Insert into #dates (effective_Date)
	Select @Effective_Date
End

if @rec_count=0 
Begin 
    Insert into #dates (effective_Date)
	Select distinct dd.Date from [EDW_Common].[Fact_Eagle_Performance_Summary] p
	JOIN	EDW_Common.Dim_Date dd on p.Dim_Date_Key=dd.Dim_Date_Key
End


delete from [EDW_BUS].[Aggr_Performance_Summary_Prep] where effective_Date in (select effective_date from #dates)






Insert into [EDW_BUS].[Aggr_Performance_Summary_Prep]
( 
	[Entity_ID]
      ,[Date_Value]
      ,[Report_Number]
      ,[Report_Name]
      ,[Report_Group]
      ,[Client_ID]
      ,[Parent_Gross_Return_D]
      ,[BenchMark_Name]
      ,[Parent_Composite_ID]
      ,[Group_Portfolio_ID]
      ,[Benchmark_ID]
      ,[IPS_Strtegy]
      ,[Mask_Flag]
      ,[Entity_Name]
      ,[Sort_Order]
      ,[Effective_Date]
      ,[AUM_Mil]
      ,[Gross_End_Market_Value_D]
      ,[Market_Value]
      ,[Leverage_Adj_Flag]
      ,[Leverage_Adj_Flag_BM]
      ,[group_flag]
      ,[WTD_Return]
      ,[MTD_Return]
      ,[QTD_Return]
      ,[YTD_Return]
      ,[Portfolio_Returns_1Yr_Gross_Return_M]
      ,[Portfolio_Returns_2Yr_Gross_Return_M]
      ,[Portfolio_Returns_3Yr_Gross_Return_M]
      ,[Portfolio_Returns_4Yr_Gross_Return_M]
      ,[Portfolio_Returns_5Yr_Gross_Return_M]
      ,[Portfolio_Returns_10Yr_Gross_Return_M]
      ,[Gross_Begin_Market_Value_D]
      ,[Gross_Total_Flows_D]
      ,[Gross_Gain_Loss_D]
      ,[Gross_Return_D]
      ,[WTD_Gross_Return]
      ,[MTD_Gross_Return]
      ,[Gross_Return_M]
      ,[QTD_Gross_Return_D]
      ,[YTD_Gross_Return_D]
      ,[3M_Gross_Return_M]
      ,[6M_Gross_Return_M]
      ,[9M_Gross_Return_M]
      ,[1Yr_Gross_Return_M]
      ,[2Yr_Ann_Gross_Return_M]
      ,[3Yr_Ann_Gross_Return_M]
      ,[4Yr_Annual_Gross_Return]
      ,[5Yr_Ann_Gross_Return_M]
      ,[10Yr_Ann_Gross_Return_M]
      ,[15Yr_Ann_Gross_Return_M]
      ,[ITD_Ann_Gross_Return_D]
      ,[IPS_ITD_Ann_Gross_Return]
      ,[IPS_ITD_Cumulative_Gross_Return]
      ,[IMCO_ITD_Ann_Gross_Return]
      ,[3Yr_Ann_Std_Dev_Gross_Return_M]
      ,[3Yr_Ann_Trkg_Err_Gross_Return_M]
      ,[3Yr_Sharpe_Gross_Return_M]
      ,[3Yr_Ann_Info_Ratio_Gross_Return_M]
      ,[4Yr_Ann_Std_Dev_Gross_Return_M]
      ,[4Yr_Ann_Trkg_Err_Gross_Return_M]
      ,[4Yr_Sharpe_Gross_Return_M]
      ,[4Yr_Ann_Info_Ratio_Gross_Return_M]
      ,[5Yr_Ann_Std_Dev_Gross_Return_M]
      ,[5Yr_Ann_Trkg_Err_Gross_Return]
      ,[5Yr_Sharpe_Gross_Return_M]
      ,[5Yr_Ann_Info_Gross_R_Return]
      ,[10Yr_Ann_Std_Dev_Gross_Return_M]
      ,[10Yr_Ann_Trkg_Rsk_Gross_Return]
      ,[10Yr_Sharpe_Gross_Return_M]
      ,[10Yr_Ann_Info_Gross_R_Return]
      ,[15Yr_Ann_Std_Dev_Gross_Return_M]
      ,[15Yr_Ann_Trkg_Rsk_Gross_Return]
      ,[15Yr_Sharpe_Gross_Return_M]
      ,[15Yr_Ann_Info_Gross_R_Return]
      ,[ITD_Ann_Std_Dev_Gross_Return]
      ,[ITD_Ann_Trkg_Rsk_Gross_Return]
      ,[ITD_Sharpe_Gross_Return]
      ,[ITD_Ann_Info_Gross_R_Return]
      ,[IPS_ITD_Standard_Deviation]
      ,[IPS_ITD_Tracking_Error]
      ,[IPS_ITD_Sharpe_Ratio]
      ,[IPS_ITD_Ann_Info_Ratio_Gross_M]
      ,[Local_End_Market_Value_D]
      ,[Local_Return_D]
      ,[WTD_Local_Return_D]
      ,[MTD_Local_Return_D]
      ,[QTD_Local_Return_D]
      ,[YTD_Local_Return_D]
      ,[1Yr_Local_Return_M]
      ,[2Yr_Ann_Local_Return_M]
      ,[3Yr_Ann_Local_Return_M]
      ,[4Yr_Ann_Local_Return_M]
      ,[5Yr_Ann_Local_Return_M]
      ,[10Yr_Ann_Local_Return_M]
      ,[15Yr_Ann_Local_Return_M]
      ,[ITD_Ann_Local_Return_D]
      ,[BM_Gross_Return_D]
      ,[BM_Gross_Return_M]
      ,[BM_WTD_Gross_Return_D]
      ,[BM_MTD_Gross_Return_D]
      ,[BM_QTD_Gross_Return_D]
      ,[BM_YTD_Gross_Return_D]
      ,[BM_3M_Gross_Return_M]
      ,[BM_6M_Gross_Return_M]
      ,[BM_9M_Gross_Return_M]
      ,[BM_1Yr_Gross_Return_M]
      ,[BM_2Yr_Ann_Gross_Return_M]
      ,[BM_3Yr_Ann_Gross_Return_M]
      ,[BM_4Yr_Annual_Gross_Return]
      ,[BM_5Yr_Ann_Gross_Return_M]
      ,[BM_10Yr_Ann_Gross_Return_M]
      ,[BM_15Yr_Ann_Gross_Return_M]
      ,[BM_ITD_Ann_Gross_Return_D]
      ,[IPS_BM_ITD_Ann_Gross_Return]
      ,[IPS_BM_ITD_Cumulative_Return]
      ,[IMCO_BM_ITD_Ann_Gross_Return]
      ,[BM_Local_Return_D]
      ,[BM_WTD_Local_Return_D]
      ,[BM_MTD_Local_Return_D]
      ,[BM_QTD_Local_Return_D]
      ,[BM_YTD_Local_Return_D]
      ,[BM_3M_Local_Return_D]
      ,[BM_6M_Local_Return_D]
      ,[BM_9M_Local_Return_D]
      ,[BM_1Yr_Local_Return_D]
      ,[BM_2Yr_Ann_Local_Return_D]
      ,[BM_3Yr_Ann_Local_Return_D]
      ,[BM_4Yr_Ann_Local_Return_D]
      ,[BM_5Yr_Ann_Local_Return_D]
      ,[BM_10Yr_Ann_Local_Return_D]
      ,[BM_15Yr_Ann_Local_Return_D]
      ,[BM_ITD_Ann_Local_Return_D]
      ,[ITD_Beta_Gross_Return]
      ,[ITD_Correl_Gross_Return]
      ,[ITD_Alpha_Gross_Return]
      ,[IPS_ITD_Correlation]
      ,[IPS_ITD_Beta]
      ,[IPS_ITD_Alpha_Gross_Return]
      ,[5Yr_Alpha_Gross_Return]
      ,[5Yr_Beta_Gross_Return]
      ,[5Yr_Correl_Gross_Return]
      ,[4Yr_Correl_Gross_Return]
      ,[4Yr_Beta_Gross_Return]
      ,[4Yr_Alpha_Gross_Return]
      ,[3Yr_Correl_Gross_Return_M]
      ,[3Yr_Beta_Gross_Return_M]
      ,[3Yr_Alpha_Gross_Return_M]
      ,[10Yr_Correl_Gross_Return]
      ,[10Yr_Beta_Gross_Return]
      ,[10Yr_Alpha_Gross_Return]
      ,[15Yr_Alpha_Gross_Return]
      ,[15Yr_Beta_Gross_Return]
      ,[15Yr_Correl_Gross_Return]
      ,[Calendar_Yr_Return_5Yrs_Prior]
      ,[Calendar_Yr_Return_4Yrs_Prior]
      ,[Calendar_Yr_Return_3Yrs_Prior]
      ,[Calendar_Yr_Return_2Yrs_Prior]
      ,[Calendar_Yr_Return_1Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_5Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_4Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_3Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_2Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_1Yrs_Prior]
      ,[ITD_Gross_Return_D]
      ,[BM_ITD_Gross_Return_D]
      ,[Client_Perf_Date_Internal]
      ,[1Yr_Ann_Std_Dev_Gross_Return_M]
      ,[Gross_Begin_Market_Value_W]
      ,[Gross_Total_Flows_W]
      ,[Gross_Gain_Loss_W]
      ,[BM_3Yr_Ann_Gross_Std_Dev_M]
      ,[BM_5Yr_Ann_Gross_Std_Dev_M]
	  ,Updated_Datetime 
)




Select 

	  ps.[Entity_ID]
      ,[Date_Value]
	   ,cr.Report_Number
	  ,cr.Report_Name
	  ,rpm.Report_Group
	  ,rpm.Client_ID
--	  ,Parent_Entity_ID=ltrim(rtrim(pm.Parent_Entity_ID))
--	  ,Parent_Gross_End_market_Value_D=pm.Gross_End_Market_Value_D
--	  ,AUM_Percent=	ps.Gross_End_Market_Value_D/pm.Gross_End_Market_Value_D
    	,Parent_Gross_Return_D=ps.Gross_Return_D/100
	  ,BenchMark_Name=rpm.BenchMark_Name
	  ,Parent_Entity_ID=Parent_Composite_ID
	  ,Group_Portfolio_ID=ltrim(rtrim(Group_Portfolio_ID))
	  ,Benchmark_ID
	   ,IPS_Strtegy
	   ,Mask_Flag
      ,[Entity_Name]=rpm.Portfolio_Name
	  ,Sort_Order
      ,[Effective_Date]=dd.Date
	,AUM_Mil=		ps.Gross_End_Market_Value_D/1000000

	,ps.Gross_End_Market_Value_D

	,Market_Value=ps.Gross_End_Market_Value_D
	,Leverage_Adj_Flag=rpm.Leverage_Adj_Flag_PF
	,rpm.Leverage_Adj_Flag_BM
	,group_flag=group_portfolio_flag
	,WTD_Return=	    Case when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=13
						then (CASE When Mask_Flag='N' then cast(rb.WTD_Value as numeric(38,14))/100.00 else Null End)
						Else 
						(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * (ps.WTD_Gross_Return/100)
						End
	,MTD_Return=
					 Case when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=13
						then (CASE When Mask_Flag='N' then cast(rb.MTD_Value as numeric(38,14))/100.00 else Null End)
						when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=14
						then (CASE When Mask_Flag='N' then cast(rb.Month1_Value  as numeric(38,14))/100.00 else Null End)
						Else 
						(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * (ps.MTD_Gross_Return/100)
						End
	,QTD_Return=   Case when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=13
						then (CASE When Mask_Flag='N' then cast(rb.QTD_Value  as numeric(38,14))/100.00 else Null End)
						when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=14
						then (CASE When Mask_Flag='N' then cast(rb.Month_QTD_Value  as numeric(38,14))/100.00 else Null End)
						Else 
						(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * (ps.QTD_Gross_Return_D/100)
						End
	,YTD_Return=    Case when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=13
						then (CASE When Mask_Flag='N' then cast(rb.YTD_Value  as numeric(38,14))/100.00 else Null End)
						when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=14
						then (CASE When Mask_Flag='N' then cast(rb.Month_YTD_Value  as numeric(38,14))/100.00 else Null End)
						Else 
						(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * (ps.YTD_Gross_Return_D/100)
						End
	

	,Portfolio_Returns_1Yr_Gross_Return_M=Case when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=13 then Null 
											when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=14
											then (CASE When Mask_Flag='N' then cast(rb.Month_12_Value  as numeric(38,14))/100.00 else Null End)
											else 
											(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * ([1Yr_Gross_Return_M]/100)
										  End 
	,Portfolio_Returns_2Yr_Gross_Return_M=(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * ([2Yr_Ann_Gross_Return_M]/100)
	
	,Portfolio_Returns_3Yr_Gross_Return_M=Case when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=13 then Null 
											when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=14
											then (CASE When Mask_Flag='N' then cast(rb.Month_36_Value  as numeric(38,14))/100.00 else Null End)
											else 
											(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * ([3Yr_Ann_Gross_Return_M]/100) 
								          End
	,Portfolio_Returns_4Yr_Gross_Return_M=(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * ([4Yr_Annual_Gross_Return]/100)
	
	,Portfolio_Returns_5Yr_Gross_Return_M= Case when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=13 then Null 
											when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=14
											then (CASE When Mask_Flag='N' then cast(rb.Month_60_Value  as numeric(38,14))/100.00 else Null End)
											else 
												(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * ([5Yr_Ann_Gross_Return_M]/100)
											End
	
	,Portfolio_Returns_10Yr_Gross_Return_M= Case when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=13 then Null 
											when rpm.Client_ID='OPB' and ltrim(rtrim(ps.[Entity_ID]))='IMAC120' and cr.Report_Number=14
											then (CASE When Mask_Flag='N' then cast(rb.Month_120_Value  as numeric(38,14))/100.00 else Null End)	
											Else
											(CASE WHEN rpm.Leverage_Adj_Flag_PF='Y' THEN -1.00 ELSE 1.00 END ) * ([10Yr_Ann_Gross_Return_M]/100)
											End



      ,[Gross_Begin_Market_Value_D]
      ,[Gross_Total_Flows_D]
      ,[Gross_Gain_Loss_D]
      ,[Gross_Return_D]
      ,[WTD_Gross_Return]
      ,[MTD_Gross_Return]
      ,[Gross_Return_M]
      ,[QTD_Gross_Return_D]
      ,[YTD_Gross_Return_D]
      ,[3M_Gross_Return_M]
      ,[6M_Gross_Return_M]
      ,[9M_Gross_Return_M]
      ,[1Yr_Gross_Return_M]
      ,[2Yr_Ann_Gross_Return_M]
      ,[3Yr_Ann_Gross_Return_M]
      ,[4Yr_Annual_Gross_Return]
      ,[5Yr_Ann_Gross_Return_M]
      ,[10Yr_Ann_Gross_Return_M]
      ,[15Yr_Ann_Gross_Return_M]
      ,[ITD_Ann_Gross_Return_D]
      ,[IPS_ITD_Ann_Gross_Return]
      ,[IPS_ITD_Cumulative_Gross_Return]
      ,[IMCO_ITD_Ann_Gross_Return]
      ,[3Yr_Ann_Std_Dev_Gross_Return_M]
      ,[3Yr_Ann_Trkg_Err_Gross_Return_M]
      ,[3Yr_Sharpe_Gross_Return_M]
      ,[3Yr_Ann_Info_Ratio_Gross_Return_M]
      ,[4Yr_Ann_Std_Dev_Gross_Return_M]
      ,[4Yr_Ann_Trkg_Err_Gross_Return_M]
      ,[4Yr_Sharpe_Gross_Return_M]
      ,[4Yr_Ann_Info_Ratio_Gross_Return_M]
      ,[5Yr_Ann_Std_Dev_Gross_Return_M]
      ,[5Yr_Ann_Trkg_Err_Gross_Return]
      ,[5Yr_Sharpe_Gross_Return_M]
      ,[5Yr_Ann_Info_Gross_R_Return]
      ,[10Yr_Ann_Std_Dev_Gross_Return_M]
      ,[10Yr_Ann_Trkg_Rsk_Gross_Return]
      ,[10Yr_Sharpe_Gross_Return_M]
      ,[10Yr_Ann_Info_Gross_R_Return]
      ,[15Yr_Ann_Std_Dev_Gross_Return_M]
      ,[15Yr_Ann_Trkg_Rsk_Gross_Return]
      ,[15Yr_Sharpe_Gross_Return_M]
      ,[15Yr_Ann_Info_Gross_R_Return]
      ,[ITD_Ann_Std_Dev_Gross_Return]
      ,[ITD_Ann_Trkg_Rsk_Gross_Return]
      ,[ITD_Sharpe_Gross_Return]
      ,[ITD_Ann_Info_Gross_R_Return]
      ,[IPS_ITD_Standard_Deviation]
      ,[IPS_ITD_Tracking_Error]
      ,[IPS_ITD_Sharpe_Ratio]
      ,[IPS_ITD_Ann_Info_Ratio_Gross_M]
      ,[Local_End_Market_Value_D]
      ,[Local_Return_D]
      ,[WTD_Local_Return_D]
      ,[MTD_Local_Return_D]
      ,[QTD_Local_Return_D]
      ,[YTD_Local_Return_D]
      ,[1Yr_Local_Return_M]
      ,[2Yr_Ann_Local_Return_M]
      ,[3Yr_Ann_Local_Return_M]
      ,[4Yr_Ann_Local_Return_M]
      ,[5Yr_Ann_Local_Return_M]
      ,[10Yr_Ann_Local_Return_M]
      ,[15Yr_Ann_Local_Return_M]
      ,[ITD_Ann_Local_Return_D]
      ,[BM_Gross_Return_D]
      ,[BM_Gross_Return_M]
      ,[BM_WTD_Gross_Return_D]
      ,[BM_MTD_Gross_Return_D]
      ,[BM_QTD_Gross_Return_D]
      ,[BM_YTD_Gross_Return_D]
      ,[BM_3M_Gross_Return_M]
      ,[BM_6M_Gross_Return_M]
      ,[BM_9M_Gross_Return_M]
      ,[BM_1Yr_Gross_Return_M]
      ,[BM_2Yr_Ann_Gross_Return_M]
      ,[BM_3Yr_Ann_Gross_Return_M]
      ,[BM_4Yr_Annual_Gross_Return]
      ,[BM_5Yr_Ann_Gross_Return_M]
      ,[BM_10Yr_Ann_Gross_Return_M]
      ,[BM_15Yr_Ann_Gross_Return_M]
      ,[BM_ITD_Ann_Gross_Return_D]
      ,[IPS_BM_ITD_Ann_Gross_Return]
      ,[IPS_BM_ITD_Cumulative_Return]
      ,[IMCO_BM_ITD_Ann_Gross_Return]
      ,[BM_Local_Return_D]
      ,[BM_WTD_Local_Return_D]
      ,[BM_MTD_Local_Return_D]
      ,[BM_QTD_Local_Return_D]
      ,[BM_YTD_Local_Return_D]
      ,[BM_3M_Local_Return_D]
      ,[BM_6M_Local_Return_D]
      ,[BM_9M_Local_Return_D]
      ,[BM_1Yr_Local_Return_D]
      ,[BM_2Yr_Ann_Local_Return_D]
      ,[BM_3Yr_Ann_Local_Return_D]
      ,[BM_4Yr_Ann_Local_Return_D]
      ,[BM_5Yr_Ann_Local_Return_D]
      ,[BM_10Yr_Ann_Local_Return_D]
      ,[BM_15Yr_Ann_Local_Return_D]
      ,[BM_ITD_Ann_Local_Return_D]
      ,[ITD_Beta_Gross_Return]
      ,[ITD_Correl_Gross_Return]
      ,[ITD_Alpha_Gross_Return]
      ,[IPS_ITD_Correlation]
      ,[IPS_ITD_Beta]
      ,[IPS_ITD_Alpha_Gross_Return]
      ,[5Yr_Alpha_Gross_Return]
      ,[5Yr_Beta_Gross_Return]
      ,[5Yr_Correl_Gross_Return]
      ,[4Yr_Correl_Gross_Return]
      ,[4Yr_Beta_Gross_Return]
      ,[4Yr_Alpha_Gross_Return]
      ,[3Yr_Correl_Gross_Return_M]
      ,[3Yr_Beta_Gross_Return_M]
      ,[3Yr_Alpha_Gross_Return_M]
      ,[10Yr_Correl_Gross_Return]
      ,[10Yr_Beta_Gross_Return]
      ,[10Yr_Alpha_Gross_Return]
      ,[15Yr_Alpha_Gross_Return]
      ,[15Yr_Beta_Gross_Return]
      ,[15Yr_Correl_Gross_Return]
      ,[Calendar_Yr_Return_5Yrs_Prior]
      ,[Calendar_Yr_Return_4Yrs_Prior]
      ,[Calendar_Yr_Return_3Yrs_Prior]
      ,[Calendar_Yr_Return_2Yrs_Prior]
      ,[Calendar_Yr_Return_1Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_5Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_4Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_3Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_2Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_1Yrs_Prior]
      ,[ITD_Gross_Return_D]
      ,[BM_ITD_Gross_Return_D]
      ,[Client_Perf_Date_Internal]
      ,[1Yr_Ann_Std_Dev_Gross_Return_M]
      ,[Gross_Begin_Market_Value_W]
      ,[Gross_Total_Flows_W]
      ,[Gross_Gain_Loss_W]
      ,[BM_3Yr_Ann_Gross_Std_Dev_M]
      ,[BM_5Yr_Ann_Gross_Std_Dev_M]
	  ,getdate()
	--Into EDW_BUS.Performance_Summary_Prep
	
	From (
SELECT [Dim_Date_Key]
      ,[Dim_Portfolio_Key]
      ,[Dim_Index_Key]
      ,[Dim_Eagle_Portfolio_Detail_Key]
      ,[Dim_Eagle_Index_Detail_Key]
      ,[Entity_ID]=ltrim(rtrim(Entity_ID))
      ,[Date_Value]=convert(date,cast(dim_Date_key as varchar))
      ,[Gross_Begin_Market_Value_D]
      ,[Gross_Total_Flows_D]
      ,[Gross_Gain_Loss_D]
      ,[Gross_End_Market_Value_D]
      ,[Gross_Return_D]
      ,[WTD_Gross_Return]
      ,[MTD_Gross_Return]
      ,[Gross_Return_M]
      ,[QTD_Gross_Return_D]
      ,[YTD_Gross_Return_D]
      ,[3M_Gross_Return_M]
      ,[6M_Gross_Return_M]
      ,[9M_Gross_Return_M]
      ,[1Yr_Gross_Return_M]
      ,[2Yr_Ann_Gross_Return_M]
      ,[3Yr_Ann_Gross_Return_M]
      ,[4Yr_Annual_Gross_Return]
      ,[5Yr_Ann_Gross_Return_M]
      ,[10Yr_Ann_Gross_Return_M]
      ,[15Yr_Ann_Gross_Return_M]
      ,[ITD_Ann_Gross_Return_D]
      ,[IPS_ITD_Ann_Gross_Return]
      ,[IPS_ITD_Cumulative_Gross_Return]
      ,[IMCO_ITD_Ann_Gross_Return]
      ,[3Yr_Ann_Std_Dev_Gross_Return_M]
      ,[3Yr_Ann_Trkg_Err_Gross_Return_M]
      ,[3Yr_Sharpe_Gross_Return_M]
      ,[3Yr_Ann_Info_Ratio_Gross_Return_M]
      ,[4Yr_Ann_Std_Dev_Gross_Return_M]
      ,[4Yr_Ann_Trkg_Err_Gross_Return_M]
      ,[4Yr_Sharpe_Gross_Return_M]
      ,[4Yr_Ann_Info_Ratio_Gross_Return_M]
      ,[5Yr_Ann_Std_Dev_Gross_Return_M]
      ,[5Yr_Ann_Trkg_Err_Gross_Return]
      ,[5Yr_Sharpe_Gross_Return_M]
      ,[5Yr_Ann_Info_Gross_R_Return]
      ,[10Yr_Ann_Std_Dev_Gross_Return_M]
      ,[10Yr_Ann_Trkg_Rsk_Gross_Return]
      ,[10Yr_Sharpe_Gross_Return_M]
      ,[10Yr_Ann_Info_Gross_R_Return]
      ,[15Yr_Ann_Std_Dev_Gross_Return_M]
      ,[15Yr_Ann_Trkg_Rsk_Gross_Return]
      ,[15Yr_Sharpe_Gross_Return_M]
      ,[15Yr_Ann_Info_Gross_R_Return]
      ,[ITD_Ann_Std_Dev_Gross_Return]
      ,[ITD_Ann_Trkg_Rsk_Gross_Return]
      ,[ITD_Sharpe_Gross_Return]
      ,[ITD_Ann_Info_Gross_R_Return]
      ,[IPS_ITD_Standard_Deviation]
      ,[IPS_ITD_Tracking_Error]
      ,[IPS_ITD_Sharpe_Ratio]
      ,[IPS_ITD_Ann_Info_Ratio_Gross_M]
      ,[Local_End_Market_Value_D]
      ,[Local_Return_D]
      ,[WTD_Local_Return_D]
      ,[MTD_Local_Return_D]
      ,[QTD_Local_Return_D]
      ,[YTD_Local_Return_D]
      ,[1Yr_Local_Return_M]
      ,[2Yr_Ann_Local_Return_M]
      ,[3Yr_Ann_Local_Return_M]
      ,[4Yr_Ann_Local_Return_M]
      ,[5Yr_Ann_Local_Return_M]
      ,[10Yr_Ann_Local_Return_M]
      ,[15Yr_Ann_Local_Return_M]
      ,[ITD_Ann_Local_Return_D]
      ,[BM_Gross_Return_D]
      ,[BM_Gross_Return_M]
      ,[BM_WTD_Gross_Return_D]
      ,[BM_MTD_Gross_Return_D]
      ,[BM_QTD_Gross_Return_D]
      ,[BM_YTD_Gross_Return_D]
      ,[BM_3M_Gross_Return_M]
      ,[BM_6M_Gross_Return_M]
      ,[BM_9M_Gross_Return_M]
      ,[BM_1Yr_Gross_Return_M]
      ,[BM_2Yr_Ann_Gross_Return_M]
      ,[BM_3Yr_Ann_Gross_Return_M]
      ,[BM_4Yr_Annual_Gross_Return]
      ,[BM_5Yr_Ann_Gross_Return_M]
      ,[BM_10Yr_Ann_Gross_Return_M]
      ,[BM_15Yr_Ann_Gross_Return_M]
      ,[BM_ITD_Ann_Gross_Return_D]
      ,[IPS_BM_ITD_Ann_Gross_Return]
      ,[IPS_BM_ITD_Cumulative_Return]
      ,[IMCO_BM_ITD_Ann_Gross_Return]
      ,[BM_Local_Return_D]
      ,[BM_WTD_Local_Return_D]
      ,[BM_MTD_Local_Return_D]
      ,[BM_QTD_Local_Return_D]
      ,[BM_YTD_Local_Return_D]
      ,[BM_3M_Local_Return_D]
      ,[BM_6M_Local_Return_D]
      ,[BM_9M_Local_Return_D]
      ,[BM_1Yr_Local_Return_D]
      ,[BM_2Yr_Ann_Local_Return_D]
      ,[BM_3Yr_Ann_Local_Return_D]
      ,[BM_4Yr_Ann_Local_Return_D]
      ,[BM_5Yr_Ann_Local_Return_D]
      ,[BM_10Yr_Ann_Local_Return_D]
      ,[BM_15Yr_Ann_Local_Return_D]
      ,[BM_ITD_Ann_Local_Return_D]
      ,[ITD_Beta_Gross_Return]
      ,[ITD_Correl_Gross_Return]
      ,[ITD_Alpha_Gross_Return]
      ,[IPS_ITD_Correlation]
      ,[IPS_ITD_Beta]
      ,[IPS_ITD_Alpha_Gross_Return]
      ,[5Yr_Alpha_Gross_Return]
      ,[5Yr_Beta_Gross_Return]
      ,[5Yr_Correl_Gross_Return]
      ,[4Yr_Correl_Gross_Return]
      ,[4Yr_Beta_Gross_Return]
      ,[4Yr_Alpha_Gross_Return]
      ,[3Yr_Correl_Gross_Return_M]
      ,[3Yr_Beta_Gross_Return_M]
      ,[3Yr_Alpha_Gross_Return_M]
      ,[10Yr_Correl_Gross_Return]
      ,[10Yr_Beta_Gross_Return]
      ,[10Yr_Alpha_Gross_Return]
      ,[15Yr_Alpha_Gross_Return]
      ,[15Yr_Beta_Gross_Return]
      ,[15Yr_Correl_Gross_Return]
      ,[Calendar_Yr_Return_5Yrs_Prior]
      ,[Calendar_Yr_Return_4Yrs_Prior]
      ,[Calendar_Yr_Return_3Yrs_Prior]
      ,[Calendar_Yr_Return_2Yrs_Prior]
      ,[Calendar_Yr_Return_1Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_5Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_4Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_3Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_2Yrs_Prior]
      ,[BM_Calendar_Yr_Rtn_1Yrs_Prior]
      ,[ITD_Gross_Return_D]
      ,[BM_ITD_Gross_Return_D]
      ,[Client_Perf_Date_Internal]
      ,[1Yr_Ann_Std_Dev_Gross_Return_M]
      ,[Gross_Begin_Market_Value_W]
      ,[Gross_Total_Flows_W]
      ,[Gross_Gain_Loss_W]
      ,[BM_3Yr_Ann_Gross_Std_Dev_M]
      ,[BM_5Yr_Ann_Gross_Std_Dev_M]
      ,[Other_Info]
      ,[Load_DTS]
      ,[Override_Flag]
      ,[Override_Date]
      ,[Last_Update_DTS]
      ,[Hash_Diff]
      ,[ETL_Load_Key]
      ,[Is_Src_Deleted]
  ,Row_Number() Over (Partition By f.Entity_Id,	[Dim_Date_Key] Order by f.Load_DTS Desc, f.Last_Update_DTS desc) rn
  
  FROM [EDW_Common].[Fact_Eagle_Performance_Summary] f
) ps
	
	JOIN	EDW_Common.Dim_Date dd	ON	dd.Dim_Date_Key=ps.Dim_Date_Key
	JOIN	[PSA].V_Manual_Performance_Report_Portfolio_Mapping rpm ON   ps.[Entity_ID]=ltrim(rtrim(rpm.[Portfolio_ID]))
																		AND dd.[Date] between rpm.[Start_Date] and rpm.[End_Date]
	JOIN	[PSA].[V_Manual_Performance_Config_Report] cr			ON cr.Report_Group=rpm.Report_Group
	JOIN	(Select distinct effective_Date from #Dates) d			ON ps.date_Value= isnull(d.effective_Date,ps.date_value)
	LEFT JOIN    [EDW_BUS].[Aggr_Performance_Summary_Rebalancing] rb		ON cr.Report_Number=rb.Report_Number
																		AND ps.Entity_ID=rb.Entity_ID
																		AND rpm.Client_ID=rb.Client_ID
																		AND dd.Date=rb.Effective_date
	
	
	
	Where rn = 1 and coalesce(Is_Src_Deleted,0) = 0  
--			and ps.date_value in (case when @rec_count=0 then ps.date_value else (Select effective_Date from #date) end)



--if @rec_count<>0 
--alter index ccitest_temp_cci on ccitest_temp reorganize


End




	END TRY 

		BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.Performance_Summary_Calc', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState
		
	END CATCH


End