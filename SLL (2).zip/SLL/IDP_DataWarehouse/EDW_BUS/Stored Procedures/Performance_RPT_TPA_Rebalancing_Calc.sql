﻿CREATE PROC [EDW_BUS].[Performance_RPT_TPA_Rebalancing_Calc] @ETL_LOAD_KEY [INT],@Load_Type [VARCHAR],@Batch_DTS [DATETIME2] AS
Begin

Begin try 

--Declare @batch_dts datetime ='1900-01-01'

Declare @debug as int =0
Declare @today as date
declare @Latest_Date_TPA_Mapping as date
declare @Latest_Date_TPA_Daily as date

Set @today=cast(dateadd(hour,-4,getdate()) as date)
Select @Latest_Date_TPA_Mapping=cast(max(load_dts) as date) from [PSA].[Manual_Performance_Report_TPA_Mapping]

Select @Latest_Date_TPA_Daily=cast(max(load_dts) as date) from [EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily]



DECLARE @effective_Date DATE
DECLARE @rec_count as int =0
	SET  @effective_Date = @Batch_DTS


if object_id('Tempdb..#Dates') is not null
drop table Tempdb..#Dates
Create table #Dates (Effective_Date  date)

if object_id('Tempdb..#Rebalancing') is not null
drop table Tempdb..#Rebalancing

If @debug=1  Set @latest_date_tpa_mapping=@today
If @debug=1  Set @latest_date_tpa_daily=@today

Insert into #Dates
Select distinct Date_Value from [EDW_Common].[V_Fact_Eagle_TPA_Weights_daily]
where date_Value=Case when @effective_date='1900-01-01' then date_Value else @effective_Date End
Union 
Select distinct effective_Date from EDW_Mart.Performance_Report_TPA_Mapping
where effective_date=Case when @effective_date='1900-01-01' then effective_date else @effective_Date End



Select @rec_count=count(*) from EDW_Bus.Aggr_Performance_Summary_Rebalancing

If   (@latest_date_tpa_mapping=@today ) 
or (@latest_date_tpa_Daily=@today)
or (@rec_count=0)
Begin 

--Select * into #tpa_daily from [EDW_Common].[V_Fact_Eagle_TPA_Weights_daily]
--where date_value in (Select date_value from #Dates)


create table #Rebalancing
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 

WITH IMAC120_WTD AS
(
SELECT
	   Report_Number=13
	   ,Client_ID='OPB'
	  ,Entity_id='IMAC120'
	  ,Decomposition_Name='Rebalancing Account'
	  ,WTD_Value=Sum(Case when part in (1,2) then WTD_Value else -1*WTD_Value end)
	  ,MTD_Value=Null
	  ,QTD_Value=Null
	  ,YTD_Value=Null
    	,Month1_Value=Null
		,Month_QTD_Value=Null
		,Month_YTD_Value=Null
		,Month_12_Value=Null
		,Month_36_Value=Null
		,Month_60_Value=Null
		,Month_120_Value=Null
	  ,c.Effective_Date


From 
(
 SELECT
	  WTD_Value=WTD_Bf_S_TotalAttrib 
	   ,part=1
	  ,effective_Date=date_value
  From [EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily] d
  where
		IPS = 'Active Asset Allocation'
		AND Entity_ID= 'OPBC0005'
		and Date_Value in (Select * from #Dates)
  UNION ALL 

  SELECT
	  WTD_Value=isnull(WTD_Bf_S_Allocation,0) + isnull(WTD_Bf_S_Interaction,0) 
	  ,part=2
	  ,effective_Date=date_value
  From [EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily] d
  where
		IPS in ('OPBC0005','NA')
		AND Entity_ID= 'OPBC0005'
		and Date_Value in (Select * from #Dates)
  UNION ALL 	

   SELECT
	  WTD_Value=Sum(isnull(WTD_Bf_S_Allocation,0) + isnull(WTD_Bf_S_Interaction,0))
	  ,part=3
	  ,effective_Date=date_value
  From [EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily] d
  where
		IPS IN ('Active Asset Allocation','Foreign Exchange Hedging') 
		AND Entity_ID= 'OPBC0005'
		and Date_Value in (Select * from #Dates)
  Group by date_Value
) c
  JOIN  
			[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
			ON	m1.entity='OPBC0005'
			and m1.Decomposition_Name='Rebalancing Account'
			and year(c.effective_Date)=year(m1.effective_Date)
			and month(c.effective_Date)=month(m1.effective_Date)
			and m1.last_active='Y'



group by c.effective_Date 

),IMAC120_MTD AS
(
SELECT
	  Report_Number=13
	   ,Client_ID='OPB'
	  ,Entity_id='IMAC120'
	  ,Decomposition_Name='Rebalancing Account'
	  ,WTD_Value=Null
	  ,MTD_Value=Sum(Case when part in (1,2) then MTD_Value else -1*MTD_Value end)
	  ,QTD_Value=Null
	  ,YTD_Value=Null
    	,Month1_Value=Null
		,Month_QTD_Value=Null
		,Month_YTD_Value=Null
		,Month_12_Value=Null
		,Month_36_Value=Null
		,Month_60_Value=Null
		,Month_120_Value=Null
	  ,c.Effective_Date
From 
(
 SELECT
	  MTD_Value=MTD_Bf_S_TotalAttrib 
	   ,part=1
	  ,effective_Date=date_value
  From [EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily] d
  where
		IPS = 'Active Asset Allocation'
		AND Entity_ID= 'OPBC0005'
		and Date_Value in (Select * from #Dates)
  UNION ALL 

  SELECT
	  MTD_Value=isnull(MTD_Bf_S_Allocation,0) + isnull(MTD_Bf_S_Interaction,0) 
	  ,part=2
	  ,effective_Date=date_value
  From [EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily] d
  where
		IPS in ('OPBC0005','NA')
		AND Entity_ID= 'OPBC0005'
		and Date_Value in (Select * from #Dates)
  UNION ALL 	

   SELECT
	  MTD_Value=Sum(isnull(MTD_Bf_S_Allocation,0) + isnull(MTD_Bf_S_Interaction,0))
	  ,part=3
	  ,effective_Date=date_value
  From [EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily] d
  where
		IPS IN ('Active Asset Allocation','Foreign Exchange Hedging') 
		AND Entity_ID= 'OPBC0005'
		and Date_Value in (Select * from #Dates)
  Group by date_Value
) c
  JOIN  
			[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
			ON	m1.entity='OPBC0005'
			and m1.Decomposition_Name='Rebalancing Account'
			and Month(m1.effective_date)=Month(c.effective_Date)
			and year(m1.effective_date)=Year(c.Effective_Date)
			and m1.last_active='Y'


group by c.effective_Date


),IMAC120_QTD AS
(

Select 
		
		  Report_Number=13
	   ,Client_ID='OPB'
	  ,Entity_id='IMAC120'
	  ,Decomposition_Name='Rebalancing Account'
	  ,WTD_Value=Null
	  ,MTD_Value=Null
	  ,QTD_Value=Case when Count(distinct All_Effective_Date)
							=datediff(month, DATEADD(QUARTER,DATEDIFF(QUARTER,0,qtd.Effective_Date),0),qtd.Effective_Date)+1 Then Sum(qtd_Value) else Null End
		
	  ,YTD_Value=Null
    	,Month1_Value=Null
		,Month_QTD_Value=Null
		,Month_YTD_Value=Null
		,Month_12_Value=Null
		,Month_36_Value=Null
		,Month_60_Value=Null
		,Month_120_Value=Null
	  ,qtd.Effective_Date


from 
			(
				Select 
						Entity_id
						,QTD_Value= MTD_Value
						,effective_date
						,All_Effective_Date=effective_date
						,Source='udm'
				From IMAC120_MTD --#temp1
				Union All
				Select  Entity_id='IMAC120'
					  ,QTD_Value=Value
					   ,Effective_Date=d.date_Value
					   ,All_Effective_Date=m1.Effective_Date
					  ,Source='mtd'
				From	[EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily] d
				JOIN 
						[PSA].[V_Manual_Performance_Report_TPA_Mapping] m1       
						ON d.Entity_ID=m1.Entity
						and d.date_value>m1.effective_date
						and datepart(quarter,d.date_value)=datepart(quarter,m1.effective_date)
						and datepart(year,d.date_value)=datepart(year,m1.effective_date)
						and Decomposition_Name in ('Rebalancing Account','Allocation/Interaction from Strategic Accounts')
--						and Orig_Effective_Date is not null
				Where  IPS in ('Active Asset Allocation','Allocation/Interaction from Strategic Accounts')
				AND Entity_ID= 'OPBC0005'
				And Active='Y'
				and d.Date_Value in (Select * from #Dates)

)  qtd

JOIN  
			[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
			ON	m1.entity='OPBC0005'
			and m1.Decomposition_Name='Rebalancing Account'
			and Month(m1.effective_date)=Month(qtd.effective_Date)
			and year(m1.effective_date)=Year(qtd.Effective_Date)
			and m1.last_active='Y'


group by 
		qtd.Entity_ID
	   ,qtd.Effective_Date

),IMAC120_ytd AS
(
Select 
			
	   Report_Number=13
	   ,Client_ID='OPB'
	  ,Entity_id='IMAC120'
	  ,Decomposition_Name='Rebalancing Account'
	  ,WTD_Value=Null
	  ,MTD_Value=Null
	  ,QTD_Value=Null
	  ,YTD_Value=Case when Count(distinct All_Effective_Date)
							=datediff(month,'01-01-'+cast(year(ytd.Effective_Date) as varchar),ytd.Effective_Date) +1 Then Sum(ytd_Value) else Null End

    	,Month1_Value=Null
		,Month_QTD_Value=Null
		,Month_YTD_Value=Null
		,Month_12_Value=Null
		,Month_36_Value=Null
		,Month_60_Value=Null
		,Month_120_Value=Null
	  ,ytd.Effective_Date


from 
			(
				Select 
						Entity_id
						,ytd_Value= MTD_Value
						,effective_date
						,All_Effective_Date=effective_date
						,Source='udm'
				From IMAC120_MTD --#temp1
				Union All
				Select Entity_id='IMAC120'
					  ,ytd_Value=Value
					   ,Effective_Date=d.date_Value
					   ,All_Effective_Date=m1.Effective_Date
					  ,Source='mtd'
				From	[EDW_Common].[V_Fact_Eagle_TPA_Weights_Daily] d
				JOIN 
						[PSA].[V_Manual_Performance_Report_TPA_Mapping] m1       
						ON d.Entity_ID=m1.Entity
						and d.date_value>m1.effective_date
						and datepart(year,d.date_value)=datepart(year,m1.effective_date)
						and Decomposition_Name in ('Rebalancing Account','Allocation/Interaction from Strategic Accounts')
--						and Orig_Effective_Date is not null
				Where  IPS in ('Active Asset Allocation','Allocation/Interaction from Strategic Accounts')
				AND Entity_ID= 'OPBC0005'
				and Date_Value in (Select * from #Dates)
--				and Date_Value='2022-06-30'
)  ytd
		
  JOIN  
			[EDW_Mart].[Performance_Report_TPA_Mapping_All_Periods] m1
			ON	m1.entity='OPBC0005'
			and m1.Decomposition_Name='Rebalancing Account'
			and m1.Month=Month(ytd.effective_Date)
			and m1.Year=Year(ytd.Effective_Date)
			and Month(m1.effective_date)=Month(ytd.effective_Date)
			and year(m1.effective_date)=Year(ytd.Effective_Date)

			and m1.last_active='Y'

group by 
		ytd.Entity_ID
	   ,ytd.Effective_Date

),IMAC120_Monthly_Base as
(
Select    Client_ID='OPB'
		,Entity_id='IMAC120'
		,effective_Date
		,TPA_Effective_Date=max(TPA_Effective_Date)
		,Month1_Value=Sum(case when Active='Y' then Value else Null End)
		,YTD_Months=max(YTD_Months)
		,QTD_Months=max(QTD_Months)
		,QTD_Start_Date=max(QTD_Start_Date)
	,YTD_Start_Date=max(YTD_Start_Date)
		,Active=max(Active)
		,Completness_Flag=max(Completness_Flag)
From EDW_Mart.Performance_Report_TPA_Mapping
Where Entity_ID='OPBC0005'
and Effective_Date=eomonth(Effective_Date)
and decomposition_Name in ('Allocation/Interaction from Strategic Accounts','Rebalancing Account')
--and @effective_Date='1900-01-01'
group by Effective_Date




),IMAC120_Monthly_1Month as
(

Select   Client_ID
		,Entity_id
		,Effective_Date
		,Month1_Value
	     ,Count_12=count(a.tpa_effective_Date) over (order by a.effective_date rows between 11 preceding and Current Row)	
		 ,Count_36=count(a.tpa_effective_Date) over (order by a.effective_date rows between 35 preceding and Current Row)	
		 ,Count_60=count(a.tpa_effective_Date) over (order by a.effective_date rows between 59 preceding and Current Row)	
		 ,Count_120=count(a.tpa_effective_Date) over (order by a.effective_date rows between 119 preceding and Current Row)	
		 ,QTD_Actual_Count=Count(a.tpa_Effective_Date) over ( partition by QTD_Start_Date order by Effective_Date asc)
		,QTD_Months
		,YTD_Actual_Count=Count(a.tpa_Effective_Date) over ( partition by YTD_Start_Date order by Effective_Date asc)
		,YTD_Months
		,YTD_Start_Date
		,a.tpa_effective_Date
		,Completness_Flag
		,Active
from IMAC120_Monthly_Base  a
),IMAC120_Monthly_Measures AS
(





Select Report_Number=14
	  ,Client_ID
	  ,Entity_id
	  ,Effective_Date
	  ,Decomposition_Name='Rebalancing Account'
	  ,WTD_Value=Null
	  ,MTD_Value=Null
	  ,QTD_Value=Null
	  ,YTD_Value=Null
    	,Month1_Value
		,Month_QTD_Value=case when isnull(QTD_Actual_Count,0)=0 or isnull(QTD_Months,0)<>isnull(QTD_Actual_Count,0) then Null else Month_QTD_Value End 
		,Month_YTD_Value=case when isnull(YTD_Actual_Count,0)=0 or isnull(YTD_Months,0)<>isnull(YTD_Actual_Count,0) then Null else Month_YTD_Value End 
		,Month_12_Value=case when Count_12<12 then Null else Month_12_Value End
		,Month_36_Value=case when count_36<36 then Null else (Power((cast(Month_36_Sum as numeric(30,9))/100.00)+1.00,Num_Days_36_powered)-1)*100  End
		,Month_60_Value=case when count_60<60 then Null else (Power((cast(Month_60_Sum as numeric(30,9))/100.00)+1.00,Num_Days_60_powered)-1)*100  End
		,Month_120_Value=case when count_120<120 then Null else (Power((cast(Month_120_Sum as numeric(30,9))/100.00)+1.00,Num_Days_120_powered)-1)*100  End
From (
		Select *
		,Month_YTD_Value=Sum(isnull(Month1_Value,0)) over (partition by year(effective_Date) order by Effective_Date)
		,Month_QTD_Value=Sum(isnull(Month1_Value,0)) over (partition by datepart(quarter,Effective_date),year(effective_Date) order by Effective_Date)
		,Month_12_Value=sum(Month1_Value) over (order by effective_date rows between 11 preceding and Current Row)
		,Month_36_Sum=Sum(Month1_Value) over (order by effective_date rows between 35 preceding and Current Row)
		,Month_60_Sum=Sum(Month1_Value) over (order by effective_date rows between 59 preceding and Current Row)
		,Month_120_Sum=Sum(Month1_Value) over (order by effective_date rows between 119 preceding and Current Row)
		,Num_Days_36_powered=365.00/(datediff(d,    dateadd(d,1,EOMonth(dateadd(month,-36,effective_Date)))      ,effective_Date)+1.00)
		,Num_Days_60_powered=365.00/(datediff(d,    dateadd(d,1,EOMonth(dateadd(month,-60,effective_Date)))      ,effective_Date)+1.00)
		,Num_Days_120_powered=365.00/(datediff(d,    dateadd(d,1,EOMonth(dateadd(month,-120,effective_Date)))      ,effective_Date)+1.00)
--		,Num_Days=datediff(d,    dateadd(d,1,EOMonth(dateadd(month,-36,effective_Date)))      ,effective_Date)

From IMAC120_Monthly_1Month		
--from #temp3 

	)  a
)

Select 
	    Report_Number
	   ,[Client_ID]
      ,[Entity_id]
      ,WTD_Value=Sum([WTD_Value])
      ,MTD_Value=Sum([MTD_Value])
      ,QTD_Value=Sum([QTD_Value])
      ,YTD_Value=Sum([YTD_Value])
      ,Month1_Value=Sum([Month1_Value])
      ,Month_QTD_Value=Sum([Month_QTD_Value])
      ,Month_YTD_Value=Sum([Month_YTD_Value])
      ,Month_12_Value=Sum([Month_12_Value])
      ,Month_36_Value=Sum([Month_36_Value])
      ,Month_60_Value=Sum([Month_60_Value])
      ,Month_120_Value=Sum([Month_120_Value])
      ,[Effective_Date]
From
(
Select 
 Report_Number
 ,[Client_ID]
      ,[Entity_id]
      ,[WTD_Value]
      ,[MTD_Value]
      ,[QTD_Value]
      ,[YTD_Value]
      ,[Month1_Value]
      ,[Month_QTD_Value]
      ,[Month_YTD_Value]
      ,[Month_12_Value]
      ,[Month_36_Value]
      ,[Month_60_Value]
      ,[Month_120_Value]
      ,[Effective_Date]
 From IMAC120_WTD
UNION ALL 
Select 
 Report_Number
 ,[Client_ID]
      ,[Entity_id]
      ,[WTD_Value]
      ,[MTD_Value]
      ,[QTD_Value]
      ,[YTD_Value]
      ,[Month1_Value]
      ,[Month_QTD_Value]
      ,[Month_YTD_Value]
      ,[Month_12_Value]
      ,[Month_36_Value]
      ,[Month_60_Value]
      ,[Month_120_Value]
      ,[Effective_Date]
 From IMAC120_MTD
 UNION ALL 
Select 
 Report_Number
 ,[Client_ID]
      ,[Entity_id]
      ,[WTD_Value]
      ,[MTD_Value]
      ,[QTD_Value]
      ,[YTD_Value]
      ,[Month1_Value]
      ,[Month_QTD_Value]
      ,[Month_YTD_Value]
      ,[Month_12_Value]
      ,[Month_36_Value]
      ,[Month_60_Value]
      ,[Month_120_Value]
      ,[Effective_Date]
 From IMAC120_QTD
 UNION ALL 
Select 
 Report_Number
 ,[Client_ID]
      ,[Entity_id]
      ,[WTD_Value]
      ,[MTD_Value]
      ,[QTD_Value]
      ,[YTD_Value]
      ,[Month1_Value]
      ,[Month_QTD_Value]
      ,[Month_YTD_Value]
      ,[Month_12_Value]
      ,[Month_36_Value]
      ,[Month_60_Value]
      ,[Month_120_Value]
      ,[Effective_Date]
 From IMAC120_YTD
 UNION ALL
 Select 
 Report_Number
 ,[Client_ID]
      ,[Entity_id]
      ,[WTD_Value]
      ,[MTD_Value]
      ,[QTD_Value]
      ,[YTD_Value]
      ,[Month1_Value]
      ,[Month_QTD_Value]
      ,[Month_YTD_Value]
      ,[Month_12_Value]
      ,[Month_36_Value]
      ,[Month_60_Value]
      ,[Month_120_Value]
      ,[Effective_Date]
 From IMAC120_Monthly_Measures
 ) a
 group by Report_number,client_id,entity_id,effective_date




 Delete from EDW_Bus.Aggr_Performance_Summary_Rebalancing
 where Effective_Date in (Select * from #Dates)

Insert into EDW_Bus.Aggr_Performance_Summary_Rebalancing
(
 Report_Number
 ,[Client_ID]
      ,[Entity_id]
      ,[WTD_Value]
      ,[MTD_Value]
      ,[QTD_Value]
      ,[YTD_Value]
      ,[Month1_Value]
      ,[Month_QTD_Value]
      ,[Month_YTD_Value]
      ,[Month_12_Value]
      ,[Month_36_Value]
      ,[Month_60_Value]
      ,[Month_120_Value]
      ,[Effective_Date]
      ,[Updated_DateTime]
)
Select Report_Number
 ,[Client_ID]
      ,[Entity_id]
      ,[WTD_Value]
      ,[MTD_Value]
      ,[QTD_Value]
      ,[YTD_Value]
      ,[Month1_Value]
      ,[Month_QTD_Value]
      ,[Month_YTD_Value]
      ,[Month_12_Value]
      ,[Month_36_Value]
      ,[Month_60_Value]
      ,[Month_120_Value]
      ,a.[Effective_Date]
	  ,getdate()
From #Rebalancing a
inner join  (Select distinct effective_date from #Dates) d on a.Effective_Date=isnull(d.Effective_Date,a.Effective_Date)
 
--delete from EDW_Bus.Aggr_Performance_Summary_Rebalancing
--where Effective_Date in (Select * from #dates)

--Insert into EDW_Bus.Aggr_Performance_Summary_Rebalancing
--Select 
--     	Report_Number
--		,Client_ID
--	  ,Entity_id
--	  ,WTD_Value
--	  ,MTD_Value
--	  ,QTD_Value
--	  ,YTD_Value
--    	,Month1_Value
--		,Month_QTD_Value
--		,Month_YTD_Value
--		,Month_12_Value
--		,Month_36_Value
--		,Month_60_Value
--		,Month_120_Value
--	  ,Effective_Date
--	  ,Updated_DateTime=getDate()
--From #Rebalancing




End




	END TRY 

		BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.Performance_TPA_Rebalancing_Calc', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState
		
	END CATCH


End