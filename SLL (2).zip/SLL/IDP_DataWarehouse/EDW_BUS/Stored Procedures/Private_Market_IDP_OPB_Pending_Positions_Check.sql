﻿CREATE PROC [EDW_BUS].[Private_Market_IDP_OPB_Pending_Positions_Check] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2	,
			@Effective_Date date
			
			--,@ETL_Load_Key int = 1				--UNCOMMENT FOR DEBUGGING
			--,@Batch_DTS date = '2022-03-31'		--UNCOMMENT FOR DEBUGGING

	IF Convert(date,@Batch_DTS) = '1900-01-01'
	BEGIN
		-- get effective date (previous business date) to check
		Set @Effective_Date = CASE DATEPART(weekday, @today) 
						WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
						WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
						ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
						END
	END 
	ELSE 
	BEGIN
		set @Effective_Date = @Batch_DTS
	END;

		
	BEGIN TRY

		WITH OPB as
		(
		SELECT  distinct
				P.EFFECTIVE_DATE,
				TRIM(SM.USER_GROUP_SECTOR14) ASSET_CLASS_CODE,
				TRIM(P.ENTITY_ID) as acc_portfolio_code,
				trim(xr.xref_security_id) as MellonID,
				SM.ISSUE_NAME,
				PD.MARKET_VALUE
				,EPS.IPS_Strategy
		FROM    PSA.V_Eagle_POSITION P 
				LEFT OUTER JOIN PSA.V_Eagle_POSITION_DETAIL PD ON P.POSITION_ID = PD.POSITION_ID                                                                          
				LEFT OUTER JOIN PSA.V_Eagle_SECURITY_MASTER SM ON PD.SECURITY_ALIAS = SM.SECURITY_ALIAS                                                                       
				LEFT OUTER JOIN PSA.V_Eagle_SECMASTER_DETAIL_EXT SDE ON SDE.SECURITY_ALIAS = SM.SECURITY_ALIAS   
				LEFT JOIN PSA.V_Eagle_SECURITY_MASTER_DETAIL SMD ON SM.SECURITY_ALIAS = SMD.SECURITY_ALIAS
				INNER JOIN PSA.V_Eagle_xreference xr on xr.security_alias = SM.security_alias and xr.xref_type = 'CMS_ID'
				LEFT JOIN PSA.V_Eagle_Xreference x on sm.security_alias =x.security_alias --AND x.xref_security_id like 'IMCO%'
				LEFT JOIN [EDW_Mart].[EPS_Portfolio_Hierarchy] EPS on EPS.portfolio_id =p.Entity_ID and p.effective_date =@Effective_Date and P.Effective_Date=EPS.Effective_Date
		WHERE    TRIM(P.ENTITY_ID) IN ( SELECT TRIM(CODE_VALUE) CODE_VALUE FROM PSA.V_Eagle_ENTITY_LIST WHERE ENTITY_ID ='OPBL0015' )                                                                           
				AND P.SRC_INTFC_INST IN ( select instance from PSA.V_Eagle_interfaces where short_desc in ('BNYM','BNYM_ME') and Is_Src_Deleted = 0 )                                                                                         
				AND P.EFFECTIVE_DATE = @Effective_Date
				and EPS.ips_strategy in ('Global Real Estate', 'Private Equity','Global Infrastructure') 
				and P.Is_Src_Deleted = 0 and PD.Is_Src_Deleted = 0
				and trim(xr.xref_security_id) not in (select distinct accounting_fund_id FROM [EDW_Mart].[Private_Market_Position_Tag] where effective_date =@Effective_Date and portfolio_id like 'IMA%' and asset_class in ('Private Equity','Real Estate','Private Infrastructure'))
				AND PD.MARKET_VALUE >1 and (sm.issue_name <>'FACTOR ENERGIA' and P.ENTITY_ID <>'IMAP860') --EXCLUDING FACTOR ENERGIA UNDER IMAP860.THE ACTUAL PORTFOLIO; ACTUAL PORTFOLIO FOR THIS ASSET IS IMAP510
		)

		insert into [EDW_BUS].[Aggr_Private_Market_IDP_OPB_Pending_Positions]
		Select   EFFECTIVE_DATE
				,ASSET_CLASS_CODE
				,acc_portfolio_code
				,MellonID
				,ISSUE_NAME
				,MARKET_VALUE
				,IPS_Strategy
				,@today
				,Null Hash_Diff
				,@ETL_Load_Key
				,0
		from	OPB O 
		where	O.acc_portfolio_code IN ( SELECT [Portfolio_ID] FROM [EDW_Mart].[EPS_Portfolio_Hierarchy] where	effective_date = @Effective_Date )



		Select @rowsInserted = Count(*) 
		From [EDW_BUS].[Aggr_Private_Market_IDP_OPB_Pending_Positions]
		Where Load_DTS = @today and Is_Src_Deleted = 0


		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Private_Market_IDP_OPB_Pending_Positions_Check', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Private_Market_IDP_OPB_Pending_Positions_Check', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END