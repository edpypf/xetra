﻿CREATE PROC [EDW_BUS].[Dynamo_NAV_Aggr_Private_Market_Commitment_Report] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS

BEGIN
	Declare @today datetime2 = getdate()
	
	
	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@Effective_Date date,
			@updateFlag int,
			@loadLoadedDTS datetime2,
			@firstLoadedEffDate datetime2,
			@updatedRecords int,
			@srcLoadDTS datetime2

	BEGIN TRY

			-- set initial update flag
			Select @updateFlag = 0

			IF OBJECT_ID('tempdb..#temp_eff_dates') IS NOT NULL
			BEGIN
				DROP TABLE #temp_eff_dates
			END

			IF OBJECT_ID('tempdb..#temp_eagle_change_dates') IS NOT NULL
			BEGIN
				DROP TABLE #temp_eagle_change_dates
			END

			create table #temp_eff_dates
			(Effective_Date datetime2, As_Of_Date datetime2)
			WITH
			(
					DISTRIBUTION = Round_Robin
			) 

			-- get latest month-end date in fact table and compare current run date
			if @Load_Type in ('ADHOC', 'ONDEMAND') 
			Begin
					-- Select @Effective_Date = @Batch_DTS
					Insert Into #temp_eff_dates (Effective_Date, As_Of_Date)
					Select Last_Day_of_Month Effective_Date, Date As_Of_Date
					From EDW_Common.Dim_Date
					Where datediff(d, Date, @Batch_DTS) = 0  

					Select @updateFlag = 1

				Select @srcLoadDTS = max(Load_DTS)
				From (
					Select max(f.dim_date_key) dim_Date_Key, Max(Load_DTS) Load_DTS
					From EDW_Common.Fact_Eagle_Position f
					Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
					Where  d.Date = @Batch_DTS

					union 

					Select max(f.dim_date_key) dim_Date_Key, max(Load_DTS) Load_DTS
					From EDW_Common.Fact_Eagle_Cash_Activity f
					Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
					Where  d.Date <= @Batch_DTS
				) f
				where Dim_Date_key is not null

			End
			else
			Begin
			
				-- get last updated DTS in target table
				Select @loadLoadedDTS = coalesce(max(aggr.Load_DTS), '1900-01-01'),
				       @firstLoadedEffDate = coalesce(min(d.date), '1900-01-01')
				From EDW_Bus.Aggr_Private_Market_Commitment_Report aggr
				join EDW_Common.Dim_Date d on aggr.dim_date_key = d.Dim_Date_Key

				/* check any update for with pervious month end date from Eagle */
				create table #temp_eagle_change_dates
				WITH
				(
						DISTRIBUTION = Round_Robin
				) AS
				Select d.Last_Day_Of_Month Effective_Date, 
					   Case when datediff(m, d.Date, @Batch_DTS) > 0 then d.Last_Day_Of_Month
					   else @Batch_DTS End As_Of_Date,
					   f.Load_DTS
				From EDW_Common.Fact_Eagle_Position f
				Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
				Where f.Load_DTS > @loadLoadedDTS 

				union 

				Select d.Last_Day_Of_Month Effective_Date, 
					   Case when datediff(m, d.Date, @Batch_DTS) > 0 then d.Last_Day_Of_Month
					   else @Batch_DTS End As_Of_Date,
					   f.Load_DTS
				From EDW_Common.Fact_Eagle_Cash_Activity f
				Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
				Where  f.Load_DTS > @loadLoadedDTS


				Select @updatedRecords = count(*), @srcLoadDTS = max(Load_DTS)
				From (
					Select max(As_Of_Date) As_Of_Date, Max(Load_DTS) Load_DTS
					From #temp_eagle_change_dates
				) f
				where As_Of_Date is not null and As_Of_Date >= @firstLoadedEffDate

				if @updatedRecords > 0 and @srcLoadDTS is not null 
				Begin
					-- changes from Eagle, get month end dates and current month
					insert into #temp_eff_dates (Effective_Date, As_Of_Date)
					Select Effective_Date, As_Of_Date
					From #temp_eagle_change_dates

					union

					Select Last_Day_of_Month Effective_Date, Date As_Of_Date
					From EDW_Common.Dim_Date
					Where datediff(d, Date, @Batch_DTS) = 0  


					Select @updateFlag = 1
				End
				Else Begin
					-- add back current month if there is not any data update for prevous month
					insert into #temp_eff_dates (Effective_Date, As_Of_Date)
					Select Last_Day_of_Month Effective_Date, Date As_Of_Date
					From EDW_Common.Dim_Date
					Where datediff(d, Date, @Batch_DTS) = 0  

					Select @srcLoadDTS = max(Load_DTS)
					From (
						Select max(f.dim_date_key) dim_Date_Key, Max(Load_DTS) Load_DTS
						From EDW_Common.Fact_Eagle_Position f
						Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
						Where  d.Date = @Batch_DTS

						union 

						Select max(f.dim_date_key) dim_Date_Key, max(Load_DTS) Load_DTS
						From EDW_Common.Fact_Eagle_Cash_Activity f
						Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
						Where  d.Date <= @Batch_DTS
					) f

					Select @updateFlag = 1
				End

			End

			if @updateFlag > 0 
			Begin
				-- delete the current run effective date in the aggregate table

				Delete f  
				from EDW_Bus.Aggr_Private_Market_Commitment_Report f
				join EDW_Common.Dim_Date d on f.Dim_Report_date_key = d.Dim_Date_Key
				Where d.date in (Select  Effective_Date From #temp_eff_dates) -- datediff(d, d.date,  @Effective_Date) = 0

				IF OBJECT_ID('tempdb..#temp_dynamo_position_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_position_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_position_summary') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_position_summary
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_summary') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_summary
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_commitment') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_commitment
				END

				create table #temp_dynamo_position_records
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				SELECT  
					pd.Portfolio_Id Fund_Id,
					sd.Security_Id,
					d.Date Effective_Date,
					max(pdc.Reporting_Currency) Currency,
					Rtrim(pdc.BANK_BRANCH_CODE) Asset_Class,
					Sum(ISNULL(p.MARKET_VALUE_income,0)) as Base_Market_Value  /*updated 04/30*/
				FROM EDW_Common.V_Fact_Eagle_Position p
				join EDW_Common.Dim_Eagle_Portfolio_Detail pd on p.Dim_Eagle_Portfolio_Detail_Key = pd.Dim_Eagle_Portfolio_Detail_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pdc on pd.Portfolio_Id = pdc.Portfolio_Id and pdc.Record_Is_Current_Flag = 1
				Join EDW_Common.Dim_Eagle_Security_Detail sd on p.Dim_Eagle_Security_Detail_Key = sd.Dim_Eagle_Security_Detail_Key
				Join EDW_Common.Dim_Eagle_Interface i on p.Dim_Eagle_Interface_Key = i.Dim_Eagle_Interface_Key 
				Join EDW_Common.Dim_Date d on p.Dim_Date_Key = d.Dim_Date_Key
				--Join EDW_Common.Dim_Currency c on p.dim_local_currency_key = c.Dim_Currency_Key
				WHERE  Rtrim(i.Interface_Name) = 'DYNAMO'
				and Rtrim(pdc.BANK_BRANCH_CODE)  in ('GLOBAL CREDIT', 'GLOBAL CREDIT - PRIV', 'INFRASTRUCTURE', 'PRIVATE DEBT', 'PRIVATE EQUITY', 'REAL ESTATE')
				and d.Date in (Select  As_Of_Date From #temp_eff_dates) -- = @Effective_Date
				Group By pd.Portfolio_Id, sd.Security_Id, d.Date, Rtrim(pdc.BANK_BRANCH_CODE)

				create table #temp_dynamo_position_summary
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 

				SELECT  
					Fund_Id,
					Effective_Date,
					Asset_Class,
					Sum(Base_Market_Value) Base_Market_Value  
				FROM #temp_dynamo_position_records
				Group By Fund_Id,
					     Effective_Date,
					     Asset_Class


				create table #temp_dynamo_cash_activity_records
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
  
				SELECT        
					   pd.Portfolio_Id Fund_Id,  
					   sd.Security_Id,
					   ted.As_Of_Date Effective_Date, -- @Effective_Date Effective_Date,
					   Rtrim(pdc.BANK_BRANCH_CODE) Asset_Class,
					   max(pdc.Reporting_Currency) Currency,
						sum(case when trans_type in  ('20','22','26','28','34','38','39','64','74','79') then ca.Base_total_flow else 0 end ) as Current_Distribution,  


						sum(case when trans_type in  ('12') then ca.local_total_flow else 0 end ) as Commitment_Local,  
						sum(case when trans_type IN   ('6','7','35','36','44','46','49') THEN ca.local_total_flow  
								 when trans_type IN   ('48') THEN -1*ca.local_total_flow	else 0 end ) Funded_Local,
						sum(case when trans_type IN   ('28','29','30','64') THEN ca.local_total_flow  else 0 end ) Recallable_Distribution_Local,
						sum(case when trans_type IN   ('48') THEN -1*ca.local_total_flow  else 0 end ) Adjustments_Local,
						sum(case when trans_type in  ('12') then ca.local_total_flow
						         when trans_type IN   ('6','7','35','36','44','46','49') THEN -1*ca.local_total_flow 
								 when trans_type IN   ('48') THEN ca.local_total_flow 
								 when trans_type IN   ('28','29','30','64') THEN -1*ca.local_total_flow else 0 end ) as Unfunded_Commitment_Local,  

						sum(case when trans_type in  ('12') then ca.base_total_flow else 0 end ) as Commitment_CAD,  
						sum(case when trans_type IN   ('6','7','35','36','44','46','49') THEN ca.base_total_flow
								 when trans_type IN   ('48') THEN -1*ca.base_total_flow	else 0 end ) Funded_CAD,
						sum(case when trans_type IN   ('28','29','30','64') THEN ca.base_total_flow  else 0 end ) Recallable_Distribution_CAD,
						sum(case when trans_type IN   ('48') THEN -1*ca.base_total_flow  else 0 end ) Adjustments_CAD,
						sum(case when trans_type in  ('12') then ca.base_total_flow 
						         when trans_type IN   ('6','7','35','36','44','46','49') THEN -1*ca.base_total_flow 
								 when trans_type IN   ('48') THEN ca.base_total_flow 
								 when trans_type IN   ('28','29','30','64') THEN -1*ca.base_total_flow else 0 end ) as Unfunded_Commitment_CAD

				FROM EDW_Common.v_Fact_Eagle_Cash_Activity  ca   
				Join (
					Select Dim_Transaction_Type_key, replace(Transaction_Type_Code, 'Eagle_','') Trans_Type
					From EDW_Common.Dim_Transaction_Type
				) tt on ca.Dim_Transaction_Type_Key = tt.Dim_Transaction_Type_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pd on ca.Dim_Eagle_Portfolio_Detail_Key = pd.Dim_Eagle_Portfolio_Detail_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pdc on pd.Portfolio_Id = pdc.Portfolio_Id and pdc.Record_Is_Current_Flag = 1
				Join EDW_Common.Dim_Eagle_Security_Detail sd on ca.Dim_Eagle_Security_Detail_Key = sd.Dim_Eagle_Security_Detail_Key 
				join EDW_Common.Dim_Date d on ca.Dim_Date_Key = d.Dim_Date_Key
				Join EDW_Common.Dim_Eagle_Interface i on ca.Dim_Eagle_Interface_Key = i.Dim_Eagle_Interface_Key 
				join #temp_eff_dates ted on 1= 1 
				WHERE Rtrim(i.Interface_Name) = 'DYNAMO'
				and Rtrim(pdc.BANK_BRANCH_CODE)  in ('GLOBAL CREDIT', 'GLOBAL CREDIT - PRIV', 'INFRASTRUCTURE', 'PRIVATE DEBT', 'PRIVATE EQUITY', 'REAL ESTATE')
				AND d.Date <= ted.As_Of_Date --  @Effective_Date 
				GROUP BY pd.Portfolio_Id, sd.Security_Id, ted.As_Of_Date, Rtrim(pdc.BANK_BRANCH_CODE)

				create table #temp_dynamo_cash_activity_summary
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				Select Fund_Id,  Effective_Date, Asset_Class,
					  Sum(Current_Distribution) Current_Distribution
					  ,Sum(Commitment_Local) Commitment_Local
					  ,Sum(Funded_Local) Funded_Local
					  ,Sum(Recallable_Distribution_Local) Recallable_Distribution_Local
					  ,Sum(Adjustments_Local) Adjustments_Local
					  ,Sum(Commitment_Local - Funded_Local - Recallable_Distribution_Local) Unfunded_Commitment_Local

					  ,Sum(Commitment_CAD) Commitment_CAD
					  ,Sum(Funded_CAD) Funded_CAD
					  ,Sum(Recallable_Distribution_CAD) Recallable_Distribution_CAD
					  ,Sum(Adjustments_CAD) Adjustments_CAD
				From #temp_dynamo_cash_activity_records
				Group By Fund_Id,  Effective_Date, Asset_Class


				create table #temp_dynamo_commitment
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				Select
					  p.Fund_Id
					  ,p.Security_Id
					  ,p.Effective_Date
					  ,p.Currency
					  ,p.Base_Market_Value
					  ,p.Current_Distribution
					  ,p.Commitment_Local  
					  ,p.Funded_Local
					  ,p.Recallable_Distribution_Local
					  ,p.Adjustments_Local
					  ,p.Unfunded_Commitment_Local

					  ,p.Funded_CAD + p.Recallable_Distribution_CAD + p.Unfunded_Commitment_Local/nullif(r.FX_Rate,0) Commitment_CAD
					  ,p.Funded_CAD
					  ,p.Recallable_Distribution_CAD
					  ,p.Adjustments_CAD
					  ,p.Unfunded_Commitment_Local/nullif(r.FX_Rate,0) Unfunded_Commitment_CAD
					  ,r.FX_Rate

					  ,coalesce(ps.Base_Market_Value,0) Portfolio_Base_Market_Value
					  ,cs.Current_Distribution Portfolio_Current_Distribution
					  ,cs.Commitment_Local Portfolio_Commitment_Local
					  ,cs.Funded_Local Portfolio_Funded_Local
					  ,cs.Recallable_Distribution_Local Portfolio_Recallable_Distribution_Local
					  ,cs.Adjustments_Local Portfolio_Adjustments_Local
					  ,cs.Unfunded_Commitment_Local  Portfolio_Unfunded_Commitment_Local
					   
					  ,cs.Funded_CAD + cs.Recallable_Distribution_CAD + cs.Unfunded_Commitment_Local/nullif(r.FX_Rate, 0) Portfolio_Commitment_CAD
					  ,cs.Funded_CAD Portfolio_Funded_CAD
					  ,cs.Recallable_Distribution_CAD Portfolio_Recallable_Distribution_CAD
					  ,cs.Adjustments_CAD Portfolio_Adjustments_CAD
					  ,cs.Unfunded_Commitment_Local/nullif(r.FX_Rate,0) Portfolio_Unfunded_Commitment_CAD

				From  (
					Select coalesce(tp.Fund_Id, c.Fund_Id) Fund_Id
						  ,coalesce(tp.Security_Id, c.Security_Id) Security_Id
						  ,coalesce(tp.Effective_Date, c.Effective_Date) Effective_Date
						  ,coalesce(tp.Currency,c.Currency) Currency
						  ,coalesce(tp.Base_Market_Value,0) Base_Market_Value
						  ,c.Current_Distribution
						  ,c.Commitment_Local  
						  ,c.Funded_Local
						  ,c.Recallable_Distribution_Local
						  ,c.Adjustments_Local
						  ,c.Commitment_Local - c.Funded_Local - c.Recallable_Distribution_Local Unfunded_Commitment_Local

						  ,c.Commitment_CAD
						  ,c.Funded_CAD
						  ,c.Recallable_Distribution_CAD
						  ,c.Adjustments_CAD

					From #temp_dynamo_position_records tp
					full Join #temp_dynamo_cash_activity_records c on tp.Effective_Date = c.Effective_Date and tp.Security_Id = c.Security_Id and tp.Fund_Id = c.Fund_Id
				) p
				Left Join #temp_dynamo_position_summary ps on p.Effective_Date = ps.Effective_Date and p.Fund_Id = ps.Fund_Id
				Left Join #temp_dynamo_cash_activity_summary cs on p.Effective_Date = cs.Effective_Date and p.Fund_Id = cs.Fund_Id
				Left Join (
					Select d.Date Effective_Date, cur.Currency Currency_code, fx.Spot_Rate FX_Rate
					From EDW_Common.Fact_Eagle_Currency_FX_Rate fx
					Join EDW_Common.Dim_Currency cur on fx.Dim_From_Currency_Key = cur.Dim_Currency_Key
					Join EDW_Common.Dim_Date d on fx.Dim_Date_Key = d.Dim_Date_Key
					where d.date in (Select  As_Of_Date From #temp_eff_dates)
				) r on p.Currency = r.Currency_code and p.Effective_Date = r.Effective_Date

				INSERT INTO [EDW_BUS].[Aggr_Private_Market_Commitment_Report]
				(
				  [Dim_Report_Date_Key]
				  ,[Dim_Date_Key]
				  ,[Dim_Portfolio_Key]
				  ,[Dim_Eagle_Portfolio_Detail_Key]
				  ,[Dim_Security_Key]
				  ,[Dim_Eagle_Security_Detail_Key]
				  ,Dim_Currency_Key
				  ,[Base_Market_Value]
				  ,Current_Distribution
					,Commitment_Local  
					,Funded_Local
					,Recallable_Distribution_Local
					,Adjustments_Local
					,Unfunded_Commitment_Local

					,Commitment_CAD
					,Funded_CAD
					,Recallable_Distribution_CAD
					,Adjustments_CAD
					,Unfunded_Commitment_CAD
					,FX_Rate

				  ,[Portfolio_Base_Market_Value]
				  ,[Portfolio_Current_Distribution]
				  ,[Portfolio_Commitment_Local]
				  ,[Portfolio_Funded_Local]
				  ,[Portfolio_Recallable_Distribution_Local]
				  ,[Portfolio_Adjustments_Local]
				  ,[Portfolio_Unfunded_Commitment_Local]
				  ,[Portfolio_Commitment_CAD]
				  ,[Portfolio_Funded_CAD]
				  ,[Portfolio_Recallable_Distribution_CAD]
				  ,[Portfolio_Adjustments_CAD]
				  ,[Portfolio_Unfunded_Commitment_CAD]

					,Other_Info

				  ,Load_DTS
				  ,[Last_Update_DTS]
				  ,[ETL_Load_Key]
				)
				Select
					  convert(int, convert(varchar(15), td.Effective_Date, 112)) [Dim_Report_Date_Key]
					  ,convert(int, convert(varchar(15), td.As_of_Date, 112)) [Dim_Date_Key]
					  ,coalesce(p.[Dim_Portfolio_Key],-1) [Dim_Portfolio_Key]
					  ,coalesce(pd.[Dim_Eagle_Portfolio_Detail_Key],-1) [Dim_Eagle_Portfolio_Detail_Key]
					  ,coalesce(sec.[Dim_Security_Key], -1) [Dim_Security_Key]
					  ,coalesce(secd.[Dim_Eagle_Security_Detail_Key], -1) [Dim_Eagle_Security_Detail_Key]
					  ,coalesce(c.[Dim_Currency_Key], -1) [Dim_Currency_Key]

					  ,Base_Market_Value
					  ,Current_Distribution

					,Commitment_Local  
					,Funded_Local
					,Recallable_Distribution_Local
					,Adjustments_Local
					,Unfunded_Commitment_Local

					,Commitment_CAD
					,Funded_CAD
					,Recallable_Distribution_CAD
					,Adjustments_CAD
					,Unfunded_Commitment_CAD
					,FX_Rate

				  ,[Portfolio_Base_Market_Value]
				  ,[Portfolio_Current_Distribution]
				  ,[Portfolio_Commitment_Local]
				  ,[Portfolio_Funded_Local]
				  ,[Portfolio_Recallable_Distribution_Local]
				  ,[Portfolio_Adjustments_Local]
				  ,[Portfolio_Unfunded_Commitment_Local]
				  ,[Portfolio_Commitment_CAD]
				  ,[Portfolio_Funded_CAD]
				  ,[Portfolio_Recallable_Distribution_CAD]
				  ,[Portfolio_Adjustments_CAD]
				  ,[Portfolio_Unfunded_Commitment_CAD]

					,'{"Currency": "' + src.Currency + '"}'
					  ,@srcLoadDTS
					  ,@today
					  ,@ETL_Load_Key

				From #temp_dynamo_commitment src
				Join #temp_eff_dates td on src.Effective_Date = td.As_Of_Date
				--Dim_Portfolio_Key
				Left Join EDW_Common.Dim_Portfolio p on src.Fund_Id = p.Portfolio_Id and p.Record_Is_Current_Flag = 1

				Left Join EDW_Common.Dim_Eagle_Portfolio_Detail pd on src.Fund_Id = pd.Portfolio_Id and pd.Record_Is_Current_Flag = 1

				--Dim_Security_Key
				Left Join EDW_Common.Dim_Security sec on 'Eagle_' + src.Security_Id = sec.Src_Security_Id and sec.Record_Is_Current_Flag = 1

				Left Join EDW_Common.Dim_Eagle_Security_Detail secd on src.Security_Id = secd.Security_Id and secd.Record_Is_Current_Flag = 1
				Left Join EDW_Common.Dim_Currency c on src.Currency = c.Currency and c.Record_Is_Current_Flag = 1


				Select @rowsInserted = Count(*) 
				From [EDW_BUS].Aggr_Private_Market_Commitment_Report
				Where Last_Update_DTS = @today

				Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_Commitment_Report', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

				/* cleanup temp tables */
				IF OBJECT_ID('tempdb..#temp_dynamo_position_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_position_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_nav') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_commitment
				END
		End

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_Commitment_Report', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END