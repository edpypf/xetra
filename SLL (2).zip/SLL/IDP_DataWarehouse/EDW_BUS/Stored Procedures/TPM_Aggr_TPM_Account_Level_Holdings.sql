﻿CREATE PROC [EDW_BUS].[TPM_Aggr_TPM_Account_Level_Holdings] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @Effective_Date date,
			@rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2

		IF Convert(date,@Batch_DTS) = '1900-01-01'
		BEGIN
			-- get effective date (previous business date) to check
			Set @Effective_Date = CASE DATEPART(weekday, @today) 
							WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
							WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
							ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
							END
		END 
		ELSE 
		BEGIN
			set @Effective_Date = @Batch_DTS
		END;

	DELETE from [EDW_BUS].[Aggr_TPM_Account_Level_Holdings]
	where effective_date = @Effective_date

BEGIN TRY
		IF OBJECT_ID('tempdb..#temp_acc_level_holdings') IS NOT NULL
		BEGIN
			DROP TABLE #temp_acc_level_holdings
		END

create table #temp_acc_level_holdings
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
with base_pool as (
select distinct 
	D.Date as Effective_Date,
	PD.Portfolio_Id as Composite_ID,
	s.Strategy_Id as IPS_Strategy,
	PE.Portfolio_Id as Portfolio_ID,
	Coalesce(NULLIF(SD.Security_Id, 'NA'), SM.Security_Alias) as Security_ID,
	Coalesce(NULLIF(SD.Security,'Not Available'), SM.Issue_Name) as Security_Name,
	P.Ending_Market_Value AS End_Market_Value
from 
[EDW_Common].[Bridge_Portfolio_Mapping] PM
join [EDW_Common].[V_Fact_Eagle_Total_Portfolio_Holding_Performance] P on P.[Dim_Portfolio_Key] = PM.Dim_Portfolio_Key and P.Dim_Date_Key = PM.Dim_Date_Key
join [EDW_Common].[Dim_Portfolio] PD on PD.[Dim_Portfolio_Key] = PM.Parent_Dim_Portfolio_Key
join [EDW_Common].[Dim_Portfolio] PE on PE.[Dim_Portfolio_Key] = PM.Dim_Portfolio_Key
left join [EDW_Common].[Dim_Security] SD on SD.dim_security_key = P.dim_security_key and ISNULL(SD.Source_System, 'NA') <> 'BarraOne'
left join [EDW_Common].[Dim_Eagle_Security_Detail] SM on P.dim_eagle_security_detail_key = SM.dim_eagle_security_detail_key
Join EDW_Common.Dim_Date d on P.Dim_Date_Key = D.Dim_Date_Key
Join [EDW_Common].[Dim_Strategy] S on S.[Dim_Strategy_Key] = PM.[Dim_Strategy_Key]

where 
PD.Portfolio_Id IN ('IMCC0001', 'IMCC0010', 'IMCC0015')
and PE.Portfolio_Type = 'PORT'
and SM.Security_Alias <> 0
and SM.Asset_Class_Type_Code <> '010' -- Fee Securities 
and Trim(P.Report_Freq_Code) = 'D'
and P.Ending_Market_Value <> 0 
and D.Date = @Effective_Date

),

pool_sum as
(
	select Effective_Date, Composite_ID, convert(float,ISNULL(sum(End_Market_Value),0)) as IMCO_Pool_Total_Market_Value
	from base_pool
	group by Effective_Date, Composite_ID
),

pool_mv_opb as 
(
	select distinct D.Date as Effective_Date, 'OPB' as Client_ID, PD.Portfolio_Id as Parent_Portfolio_ID, S.Strategy_Id, SM.Security_Id, P.Ending_Market_Value as OPB_Pool_Market_Value
	from
	[EDW_Common].[V_Fact_Eagle_Total_Portfolio_Holding_Performance] P 
	join [EDW_Common].[Dim_Portfolio] PD on PD.[Dim_Portfolio_Key] = P.Dim_Portfolio_Key
	join [EDW_Common].[Dim_Security] SM on P.[Dim_Security_Key] = SM.[Dim_Security_Key]
	join EDW_Common.Dim_Date D on P.Dim_Date_Key = D.Dim_Date_Key
	join [EDW_Common].[Bridge_Portfolio_Mapping] PM on PM.Parent_Dim_Portfolio_Key = P.Dim_Portfolio_Key and PM.Dim_Date_Key = P.Dim_Date_Key
	Join [EDW_Common].[Dim_Strategy] S on S.[Dim_Strategy_Key] = PM.[Dim_Strategy_Key]
	where P.Report_Freq_Code = 'D'
	and SM.Dim_Security_Key <> -1
	and PD.Portfolio_Id in ( 'IMAC200', 'IMAG190', 'IMAE170') 
	and SM.Security_Id in ('4709663','4734615','4736412')
	and D.Date = @Effective_Date
), 

pool_mv_wsib as  
(
select D.Date as Effective_Date, PM.Portfolio_Id as Parent_Portfolio_ID, SM.Security_Id, P.Ending_Market_Value as Pool_Market_Value,
case 
	when PM.Portfolio_Id in ('WS81', 'WS82', 'WS83') and SM.Security_Id = '967GWG006' then 'Canadian Public Equity'
	when PM.Portfolio_Id in ('WSOA', 'WSOD', 'WSOF') and SM.Security_Id in ('942JCM900', '942JCN007') then 'Global Public Equity'
	when PM.Portfolio_Id in ('WSOB', 'WSOE', 'WSOG') and SM.Security_Id in ('942KRF005', '942KRF906') then 'Emerging Markets Public Equity'
end as IPS_Strategy,
case 
	when PM.Portfolio_Id in ('WS81','WSOA','WSOB') then 'WSIBPEN'
	when PM.Portfolio_Id in ('WS82','WSOD','WSOE') then 'WSIBINS'
	when PM.Portfolio_Id in ('WS83','WSOF','WSOG') then 'WSIBLRI'
end as Client_ID
from [EDW_Common].[Fact_StateStreet_Performance_Position] P
join [EDW_Common].[Dim_Portfolio] PM on P.[Dim_Portfolio_Key] = PM.Dim_Portfolio_Key
join [EDW_Common].[Dim_Security] SM on P.[Dim_Security_Key] = SM.[Dim_Security_Key] 
join EDW_Common.Dim_Date D on P.Dim_Date_Key = D.Dim_Date_Key
where PM.Portfolio_Id in ('WS81','WSOA','WSOB','WS82','WSOD','WSOE', 'WS83','WSOF','WSOG')
and SM.Security_Id in ('967GWG006', '942JCM900', '942JCN007', '942KRF906', '942KRF005')
and D.Date = @Effective_Date
),



opb_acc as (
select t.*, p.IMCO_Pool_Total_Market_Value, mv.Client_ID, mv.Parent_Portfolio_ID, mv.OPB_Pool_Market_Value, (convert(float,t.End_Market_Value) / convert(float,p.IMCO_Pool_Total_Market_Value)) as Percent_Security_Represents, 
((convert(float,t.End_Market_Value) / convert(float,p.IMCO_Pool_Total_Market_Value)) *  convert(float,mv.OPB_Pool_Market_Value)) as OPB_Security_End_Market_Value 
	from base_pool t 
	inner join pool_sum p
	on p.Effective_Date = t.Effective_Date
	and p.Composite_ID = t.Composite_ID
	inner join pool_mv_opb mv
	on mv.Strategy_Id = t.IPS_Strategy
	and mv.Effective_Date = t.Effective_Date
),

wsib_acc as (
select t.*, p.IMCO_Pool_Total_Market_Value, a.Client_ID, a.Parent_Portfolio_ID, 
a.Pool_Market_Value,
(convert(float,t.End_Market_Value) / convert(float,p.IMCO_Pool_Total_Market_Value)) as Percent_Security_Represents, 
(convert(float,t.End_Market_Value) / convert(float,p.IMCO_Pool_Total_Market_Value))*(convert(float,a.Pool_Market_Value)) as Pool_Security_End_Market_Value
	from base_pool t 
	join pool_sum p on p.Effective_Date = t.Effective_Date and p.Composite_ID = t.Composite_ID
	join pool_mv_wsib a on a.Effective_Date = t.Effective_Date and a.IPS_Strategy = t.IPS_Strategy
),

pool_acc as (
--OPB Account Level 
select Effective_Date, Client_ID, Composite_ID, IPS_Strategy, Parent_Portfolio_ID, Portfolio_ID, Security_ID, Security_Name, OPB_Security_End_Market_Value as Security_Market_Value
from opb_acc

UNION ALL

--WSIB Account Level
select Effective_Date, Client_ID, Composite_ID, IPS_Strategy, Parent_Portfolio_ID, Portfolio_ID, Security_ID, Security_Name, Pool_Security_End_Market_Value as Security_Market_Value
from wsib_acc
),


non_pool_acc as (

--OPB Account Level (non-pool)

Select d.Date as Effective_Date, 
	cp.Client_Id, 
	s.Strategy_ID as IPS_Strategy, 
	p.Portfolio_Id, 
	sm.Security_Alias as Security_ID,
	sm.Issue_Name as Security_Name,
	ISNULL(hp.[Ending_Market_Value],0) as Security_Market_Value, 
	'NON-POOL' as Type
From  [EDW_Common].[V_Fact_Eagle_Total_Portfolio_Holding_Performance] hp 
Join EDW_Common.Dim_Portfolio p on hp.Dim_Portfolio_Key = p.Dim_Portfolio_Key
left join [EDW_Common].[Dim_Eagle_Security_Detail] sm on sm.dim_eagle_security_detail_key = hp.dim_eagle_security_detail_key 
and sm.Security_Id not in ('4709663','4734615','4736412') --Duplicate Calculation for these IPS Strategies (Accounted for in Pool Calculations)
Join (
	Select Dim_Strategy_Key, Dim_Date_Key, p.Portfolio_Id, c.Client_Id 
	From EDW_BUS.[V_Aggr_Client_Portfolio_Ownership] aggr
	Join EDW_Common.Dim_Portfolio p on aggr.Dim_Portfolio_Key = p.Dim_Portfolio_Key
	Join EDW_Common.Dim_Client c on aggr.Dim_Client_Key = c.Dim_Client_Key
) cp on hp.Dim_Date_Key = cp.Dim_Date_Key and p.Portfolio_Id = cp.Portfolio_Id
Join EDW_Common.Dim_Date d on hp.Dim_Date_Key = d.Dim_Date_Key
Join EDW_Common.Dim_Strategy s on s.Dim_Strategy_Key = cp.Dim_Strategy_Key 
--and s.Strategy_Id not in ('Canadian Public Equity', 'Emerging Markets Public Equity', 'Global Public Equity')  --Duplicate Calculation for these IPS Strategies (Accounted for in Pool Calculations)
where trim(hp.Report_Freq_Code) = 'D'
and sm.Security_Alias <> 0
and d.Date = @Effective_Date

UNION 

--WSIB Account Level (non-pool)
select distinct d.date as Effective_Date, cp.Client_Id, s.Strategy_Id as IPS_Strategy, p.Portfolio_Id, sc.Security_Id,  
sc.Security as Security_Name, ISNULL(convert(float,sp.Ending_Market_Value)*convert(float,cp.Percent_Portfolio_Owned),0) as Security_Market_Value, 'NON-POOL' as Type
from  [EDW_Common].[Fact_StateStreet_Performance_Position] sp
join EDW_Common.Dim_Portfolio p on sp.Dim_Portfolio_Key = p.Dim_Portfolio_Key
Join (
	Select Dim_Strategy_Key, Dim_Date_Key, aggr.Dim_Portfolio_Key, c.Client_Id, aggr.Percent_Portfolio_Owned
	From EDW_BUS.[V_Aggr_Client_Portfolio_Ownership] aggr
	Join EDW_Common.Dim_Portfolio p on aggr.Dim_Portfolio_Key = p.Dim_Portfolio_Key
	Join EDW_Common.Dim_Client c on aggr.Dim_Client_Key = c.Dim_Client_Key
) cp on sp.Dim_Date_Key = cp.Dim_Date_Key and sp.Dim_Portfolio_Key = cp.Dim_Portfolio_Key
Join EDW_Common.Dim_Date d on cp.Dim_Date_Key = d.Dim_Date_Key
Join EDW_Common.Dim_Strategy s on s.Dim_Strategy_Key = cp.Dim_Strategy_Key
join EDW_Common.Dim_Security sc on sc.Dim_Security_Key = sp.Dim_Security_Key and ISNULL(sc.Source_System,'NA') <> 'BarraOne'
and sc.Security_Id not in ('967GWG006', '942JCM900', '942JCN007', '942KRF906', '942KRF005') --Duplicate Calculation for these IPS Strategies (accounted for in Pool Calculations)
--and s.Strategy_Id not in ('Canadian Public Equity', 'Emerging Markets Public Equity', 'Global Public Equity') 
where cp.Client_Id in ('WSIBINS', 'WSIBLRI','WSIBPEN')
and Trim(sp.Report_Freq_Code) = 'D'
and sc.Dim_Security_Key <>0
and d.date = @Effective_Date

UNION 

--FX Account Level (non-pool)
select fx.effective_date as Effective_Date, m.client_id, m.IPS_Strategy as IPS_Strategy, fx.fund as Portfolio_id, 
fx.Trade_id as Security_Id, fx.Broker_Name as Security_Name, 
(ISNULL(convert(float,m.Percent_Portfolio_Owned)*convert(float,fx.Unrealized_gain_Loss),0)) as Security_Market_Value, 'NON-POOL FX' as Type
from  PSA.V_StateStreet_FX_Forward_Report fx 
join EDW_MART.TPM_Client_Portfolio_Ownership m on trim(fx.fund)=trim(m.Portfolio_ID) and fx.Effective_Date=m.Effective_Date
where fx.effective_date = @Effective_Date
), 

combined as (
select a.Effective_Date, a.Client_ID, a.IPS_Strategy, a.Parent_Portfolio_ID, a.Portfolio_ID, a.Security_ID, a.Security_Name, a.Security_Market_Value, 'POOL' as Type
from pool_acc a

UNION

select a.Effective_Date, a.Client_ID, a.IPS_Strategy, a.Portfolio_ID as Parent_Portfolio_ID, 'NA' as Portfolio_ID, a.Security_ID, a.Security_Name, a.Security_Market_Value, a.Type
from non_pool_acc a

), 

pool_mv_percent as (
select Effective_Date, sum(convert(float,Security_Market_Value)) as total_client_mv
from combined
where Type = 'POOL'
group by Effective_Date
)

select a.Effective_Date, a.Client_ID, a.IPS_Strategy, a.Parent_Portfolio_ID, a.Portfolio_ID, a.Security_ID, a.Security_Name, a.Security_Market_Value, a.Type, (convert(float,a.Security_Market_Value))/(convert(float,t.total_client_mv)) as Pool_Percent_Security_Market_Value
from combined a 
join pool_mv_percent t on a.Effective_Date = t.Effective_Date
where a.Effective_Date = @Effective_Date and a.Type = 'POOL'

UNION

select a.Effective_Date, a.Client_ID, a.IPS_Strategy, a.Parent_Portfolio_ID, a.Portfolio_ID, a.Security_ID, a.Security_Name, a.Security_Market_Value, a.Type, 0 as Pool_Percent_Security_Market_Value
from combined a 
where a.Type != 'POOL'

INSERT INTO [EDW_BUS].[Aggr_TPM_Account_Level_Holdings](

	Effective_Date, 
	Client_ID, 
	IPS_Strategy, 
	Parent_Portfolio_ID, 
	Portfolio_ID, 
	Security_ID,
	Security_Name, 
	Security_Market_Value, 
	Pool_Percent_Security_Market_Value, 
	Type,
	Load_DTS, 
	Other_Info,
	Last_Update_DTS, 
	Hash_Diff, 
	ETL_Load_Key, 
	Is_Src_Deleted)

select Effective_Date, 
		Client_ID, 
		IPS_Strategy, 
		TRIM(Parent_Portfolio_ID), 
		TRIM(Portfolio_ID), 
		TRIM(Security_ID),
		Security_Name, 
		Security_Market_Value, 
		Pool_Percent_Security_Market_Value, 
		Type, 
		@today, 
		null,
		@today,
		Hash_Diff, 
		@ETL_Load_Key, 
		0
from (
	Select 
		Effective_Date, 
		Client_ID, 
		IPS_Strategy, 
		Parent_Portfolio_ID, 
		Portfolio_ID, 
		Security_ID,
		Security_Name, 
		Security_Market_Value, 
		Pool_Percent_Security_Market_Value,
		Type,
		CONVERT(VARCHAR(64), hashbytes('SHA1', coalesce(concat(Security_Market_Value, '|', Pool_Percent_Security_Market_Value ), '')), 2) as Hash_Diff

from #temp_acc_level_holdings  
) src

--where not exists ( 
--		Select 1
--		From [EDW_BUS].[Aggr_TPM_Account_Level_Holdings] tgt
--		where tgt.Effective_Date = src.Effective_Date and tgt.Client_ID = src.Client_ID 
--		and tgt.IPS_Strategy = src.IPS_Strategy and tgt.Parent_Portfolio_ID = src.Parent_Portfolio_ID 
--		and tgt.Portfolio_ID = src.Portfolio_ID and tgt.Security_ID = src.Security_ID 
--		and tgt.Security_Name = src.Security_Name and tgt.Hash_Diff = src.Hash_Diff
--		) 

--		Select @rowsInserted = Count(*) 
--		From EDW_BUS.Aggr_TPM_Account_Level_Holdings
--		Where Last_Update_DTS = @today and Is_Src_Deleted = 0

--		Update  tgt
--		Set Is_Src_Deleted = 1, Last_Update_DTS = getdate(), ETL_Load_Key = @ETL_Load_Key
--		From [EDW_BUS].[Aggr_TPM_Account_Level_Holdings] tgt
--		where not exists (
--				Select 1 from #temp_acc_level_holdings src 
--				Where tgt.Effective_Date = src.Effective_Date and tgt.Client_ID = src.Client_ID 
--					and tgt.IPS_Strategy = src.IPS_Strategy and tgt.Parent_Portfolio_ID = src.Parent_Portfolio_ID 
--					and tgt.Portfolio_ID = src.Portfolio_ID and tgt.Security_ID = src.Security_ID 
--					and tgt.Security_Name = src.Security_Name 
--		) and coalesce(tgt.Is_Src_Deleted,0) = 0

--		Select @rowsExpired = Count(*)
--		From EDW_BUS.Aggr_TPM_Account_Level_Holdings
--		Where Last_Update_DTS = @today and Is_Src_Deleted = 1

--		Select @rowsUpdated = @rowsExpired

--		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_TPM_Account_Level_Holdings', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_TPM_Account_Level_Holdings', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END