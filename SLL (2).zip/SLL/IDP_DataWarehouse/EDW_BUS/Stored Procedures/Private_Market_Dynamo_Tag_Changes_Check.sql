﻿CREATE PROC [EDW_BUS].[Private_Market_Dynamo_Tag_Changes_Check] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

		Declare @today datetime2 = getdate()
		
		declare @rowsInserted int = 0,
				@rowsUpdated int = 0,
				@rowsExpired int = 0,
				@Effective_Date date,
				@Previous_Date date,
				@LoadType varchar(150)

				--,@Load_Type [varchar](255) = 'Delta|2023-06-02'
				--,@Batch_DTS date = '2023-06-09'
				--,@ETL_Load_Key int = 1

		IF Convert(date,@Batch_DTS) = '1900-01-01' and @Load_Type not like '%|%'
		BEGIN
			-- get effective date (previous business date) to check
			set @Effective_Date = CASE DATEPART(weekday, @today) 
							WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
							WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
							ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
							END
			set @Previous_Date = Dateadd(day, -7 , @Effective_Date)
			set @LoadType = @Load_Type
		END 
		ELSE 
		BEGIN
			set @Effective_Date = @Batch_DTS
			set @Previous_Date = right(@Load_Type, charindex('|', reverse(@Load_Type)) - 1)
			set @LoadType = left(@Load_Type, charindex('|', @Load_Type) - 1)
		END;

		--select  @Effective_Date, @Previous_Date, @LoadType
		
	BEGIN TRY

		with dynamo as 
		(
		SELECT   P.Effective_Date  
				,E.ENTITY_ID  Dynamo_FUND_ID  
				,E.ENTITY_NAME Dynamo_Fund_Name
				,E.USER_FIELD19  Dynamo_CUSIP_1  
				,E.USER_FIELD22  Dynamo_CUSIP_2  
				,E.USER_FIELD21  Dynamo_Mellon_ID  
				,SM.PRIMARY_ASSET_ID  
				,SM.PRIMARY_ASSET_ID_TYPE  
				,SMD.USER_GROUP_DESC15  ASSET_CLASS  
				,SM.ISSUE_NAME Asset_Name
				,P.POSITION_ID  
				,PD.LOCAL_CURRENCY  
				,PD.SECURITY_ALIAS  
				,PD.POSITION_DETAIL_ID
				,PD.MARKET_VALUE  
				,PD.LOCAL_MARKET_VALUE  
				,SM.INVESTMENT_TYPE  
				,SM.CURRENCY_CODE  CURRENCY
				,SMD.USER_GROUP_FLOAT5  Leverage  
				,SMD.USER_GROUP_CHAR10  Sector  
				,SMD.USER_GROUP_CHAR11  Region  
				,SMD.USER_GROUP_CHAR14  Revenue_Source  
				,SMD.USER_GROUP_DESC17  Asset_Type  
				,SMD.USER_GROUP_DESC18  Risk_Strategy  
				,E.ANALYSIS_CODE  Partner  
				,SMD.COUNTRY_OF_RISK  
		FROM	PSA.V_Eagle_ENTITY E   
				INNER JOIN PSA.V_Eagle_POSITION P ON P.ENTITY_ID = E.ENTITY_ID  
				INNER JOIN PSA.V_Eagle_POSITION_DETAIL PD  ON P.POSITION_ID = PD.POSITION_ID  
				INNER JOIN PSA.V_Eagle_SECURITY_MASTER SM ON PD.SECURITY_ALIAS = SM.SECURITY_ALIAS   
				LEFT JOIN PSA.V_Eagle_SECURITY_MASTER_DETAIL SMD  ON SM.SECURITY_ALIAS = SMD.SECURITY_ALIAS  
		WHERE	P.EFFECTIVE_DATE in (@Effective_Date, @Previous_Date)
				AND P.SRC_INTFC_INST = (SELECT INSTANCE FROM PSA.V_Eagle_INTERFACES WHERE SHORT_DESC ='DYNAMO') 
		)

		insert into [EDW_BUS].[Aggr_Private_Market_Dynamo_Tag_Changes]
		select	currentweek.effective_date, 
				currentweek.ASSET_CLASS,
				currentweek.Dynamo_fund_id,
				currentweek.Dynamo_Fund_Name,
				currentweek.primary_asset_id,
				currentweek.Leverage, 
				currentweek.Sector,  
				currentweek.Region,  
				currentweek.Revenue_Source,   
				currentweek.Risk_Strategy, 
				currentweek.Partner,
				previous.Effective_date as Previous_Effective_Date,
				previous.Leverage as Previous_Leverage,
				previous.Sector as Previous_Sector,
				previous.Revenue_Source as  Previous_Revenue_Source, 
				previous.Risk_Strategy as Previous_Risk_Strategy,
				previous.Partner as Previous_Partner,
				@today,
				Null,
				@ETL_Load_key,
				0
		from	dynamo as currentweek 
				join dynamo as previous on currentweek.PRIMARY_ASSET_ID = previous.PRIMARY_ASSET_ID and previous.Effective_Date = @Previous_Date
		where	currentweek.Effective_Date = @Effective_Date
				and (   currentweek.Leverage <> previous.Leverage 
						or currentweek.Sector <> previous.Sector
						or  currentweek.Revenue_Source <> previous.Revenue_Source 
						or currentweek.Risk_Strategy <> previous.Risk_Strategy
						or currentweek.Partner <> previous.Partner
					)




		Select @rowsInserted = Count(*) 
		From [EDW_BUS].[Aggr_Private_Market_Dynamo_Tag_Changes]
		Where Load_DTS = @today and Is_Src_Deleted = 0


		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Private_Market_Dynamo_Tag_Changes_Check', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Private_Market_Dynamo_Tag_Changes_Check', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END