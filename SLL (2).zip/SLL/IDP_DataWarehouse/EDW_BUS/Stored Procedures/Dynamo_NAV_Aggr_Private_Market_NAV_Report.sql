﻿CREATE PROC [EDW_BUS].[Dynamo_NAV_Aggr_Private_Market_NAV_Report] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS

BEGIN
	Declare @today datetime2 = getdate()
	
	
	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@Effective_Date date,
			@updateFlag int,
			@loadLoadedDTS datetime2,
			@updatedRecords int,
			@srcLoadDTS datetime2

	BEGIN TRY

			-- set initial update flag
			Select @updateFlag = 0

			-- get latest month-end date in fact table and compare current run date
			if @Load_Type in ('ADHOC', 'ONDEMAND') 
			Begin
					Select @Effective_Date = @Batch_DTS
					Select @updateFlag = 1
			End
			else
			Begin
			
				-- get latest month end date which has data in Eagle
				Select @Effective_Date = Max(d.Date) 
				From EDW_Common.Fact_Eagle_Position f
				Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
				where d.Date <= @Batch_DTS and d.Month_End_Flg = 1


				-- get last updated DTS in target table
				Select @loadLoadedDTS = max(aggr.Load_DTS)
				From EDW_Bus.Aggr_Private_Market_NAV_Report aggr
				Join EDW_Common.Dim_Date d on aggr.Dim_Date_Key = d.Dim_Date_Key
				Where d.Date = @Effective_Date


				/* check any update for last month end date from Eagle */
				Select @updatedRecords = count(*), @srcLoadDTS = max(Load_DTS)
				From (
					Select max(f.dim_date_key) dim_Date_Key, Max(Load_DTS) Load_DTS
					From EDW_Common.Fact_Eagle_Position f
					Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
					Where  d.Date = @Effective_Date and f.Load_DTS > @loadLoadedDTS

					union 

					Select max(f.dim_date_key) dim_Date_Key, max(Load_DTS) Load_DTS
					From EDW_Common.Fact_Eagle_Cash_Activity f
					Join EDW_Common.Dim_Date d on f.Dim_Date_Key = d.Dim_Date_Key
					Where  d.Date = @Effective_Date and f.Load_DTS > @loadLoadedDTS
				) f
				where Dim_Date_key is not null

				if @updatedRecords > 0 and @srcLoadDTS is not null 
				Begin
					Select @updateFlag = 1
				End

			End

			if @updateFlag > 0 
			Begin
				-- delete the current run effective date in the aggregate table

				Delete f  
				from EDW_Bus.Aggr_Private_Market_NAV_Report f
				join EDW_Common.Dim_Date d on f.Dim_date_key = d.Dim_Date_Key
				Where datediff(d, d.date,  @Effective_Date) = 0

				IF OBJECT_ID('tempdb..#temp_dynamo_position_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_position_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_summary') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_summary
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_nav') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_nav
				END

				create table #temp_dynamo_position_records
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 

				SELECT  
					pd.Portfolio_Id Fund_Id,
					sd.Security_Id,
					d.Date Effective_Date,
					Rtrim(pd.BANK_BRANCH_CODE) Asset_Class,
					Sum(ISNULL(p.MARKET_VALUE_income,0)) as Base_Market_Value  /*updated 04/30*/
				FROM EDW_Common.V_Fact_Eagle_Position p
				join EDW_Common.Dim_Eagle_Portfolio_Detail pd on p.Dim_Eagle_Portfolio_Detail_Key = pd.Dim_Eagle_Portfolio_Detail_Key
				Join EDW_Common.Dim_Eagle_Security_Detail sd on p.Dim_Eagle_Security_Detail_Key = sd.Dim_Eagle_Security_Detail_Key
				Join EDW_Common.Dim_Eagle_Interface i on p.Dim_Eagle_Interface_Key = i.Dim_Eagle_Interface_Key 
				Join EDW_Common.Dim_Date d on p.Dim_Date_Key = d.Dim_Date_Key
				WHERE  Rtrim(i.Interface_Name) = 'DYNAMO'
				and Rtrim(pd.BANK_BRANCH_CODE)  in ('GLOBAL CREDIT', 'GLOBAL CREDIT - PRIV', 'INFRASTRUCTURE', 'PRIVATE DEBT', 'PRIVATE EQUITY', 'REAL ESTATE')
				-- and datediff(d, d.Date, '2022-07-06') = 0
				and d.Date = @Effective_Date
				Group By pd.Portfolio_Id, sd.Security_Id, d.Date, Rtrim(pd.BANK_BRANCH_CODE)

				create table #temp_dynamo_cash_activity_records
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
  
				SELECT        
					   pd.Portfolio_Id Fund_Id,  
					   sd.Security_Id, 
					   d.Date Effective_Date,
					   Rtrim(pd.BANK_BRANCH_CODE) Asset_Class,
						sum(case when trans_type in  ('9','10','58','60','61','65','69','70','72','73') then  -1*ca.base_total_flow   
								 when trans_type in  ('1','4','5','6','7','8','11','34','35','40','41','44','45','46','47','49','50','51','52','57') then ca.base_total_flow else 0 end ) as Capital_Called_Base,  
						sum (case when trans_type in  ('28','29','30','64','64','76') then ISNULL(-1*ca.base_total_flow,0) else 0 end ) as Recallable_Base,  
						sum (case when trans_type in  ('15','31','53','54','66') then ISNULL(-1*ca.base_total_flow,0) else 0 end ) as Return_of_Capital_Base,  
						sum (case when trans_type in  ('2','13','16','17','18','19','20','21','22','23','24','26','27','32','36','37','38','39','43','56','62','63','67','74','75','79','25','68') then ISNULL(-1*ca.base_total_flow,0) else 0 end ) as Income_Realized_Base,

						sum (case when trans_type in  ('17','20','21','22','23','74','26','38','39','79') Then ISNULL(-1*ca.base_total_flow,0) else 0 end)  Income_Realized_Distribution,
						sum (case when trans_type in  ('64','28','29','30') Then isnull(-1*ca.base_total_flow,0) else 0 end) Recallable_Distribution,
						sum (case when trans_type in ('31') Then Isnull(-1*ca.base_total_flow,0) else 0 end) Return_of_Capital_Distribution,
						sum (case when trans_type in  ('6') Then ca.base_total_flow else 0 end) Invested_Capital,
						sum (case when trans_type in  ('7','34','44','45','46','47','49','50') Then ca.base_total_flow else 0 end) Fees,
						sum (case when trans_type in  ('6','7','64','28','29','30','35','36','44','46','49') Then ca.base_total_flow 
						          when trans_type in  ('48') Then -1*ca.base_total_flow else 0 end) Commitment_Drawn
				FROM EDW_Common.v_Fact_Eagle_Cash_Activity  ca   
				Join (
					Select Dim_Transaction_Type_key, replace(Transaction_Type_Code, 'Eagle_','') Trans_Type
					From EDW_Common.Dim_Transaction_Type
				) tt on ca.Dim_Transaction_Type_Key = tt.Dim_Transaction_Type_Key
				join EDW_Common.Dim_Eagle_Portfolio_Detail pd on ca.Dim_Eagle_Portfolio_Detail_Key = pd.Dim_Eagle_Portfolio_Detail_Key
				Join EDW_Common.Dim_Eagle_Security_Detail sd on ca.Dim_Eagle_Security_Detail_Key = sd.Dim_Eagle_Security_Detail_Key 
				join EDW_Common.Dim_Date d on ca.Dim_Date_Key = d.Dim_Date_Key
				Join EDW_Common.Dim_Eagle_Interface i on ca.Dim_Eagle_Interface_Key = i.Dim_Eagle_Interface_Key 
				WHERE Rtrim(i.Interface_Name) = 'DYNAMO'
				and Rtrim(pd.BANK_BRANCH_CODE)  in ('GLOBAL CREDIT', 'GLOBAL CREDIT - PRIV', 'INFRASTRUCTURE', 'PRIVATE DEBT', 'PRIVATE EQUITY', 'REAL ESTATE')
				AND d.Date <=  @Effective_Date 
				GROUP BY sd.Security_Id , pd.Portfolio_Id, d.Date, Rtrim(pd.BANK_BRANCH_CODE)


				create table #temp_dynamo_cash_activity_summary
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				With cur_q as (
				Select
						Fund_Id,  
						Security_Id, 

						Sum(Capital_Called_Base) Cur_Quarter_Capital_Called_Base,  
						sum(Recallable_Base) Cur_Quarter_Recallable_Base,  
						Sum(Return_of_Capital_Base) Cur_Quarter_Return_of_Capital_Base,  
						Sum(Income_Realized_Base) Cur_Quarter_Income_Realized_Base,
						Sum(Income_Realized_Distribution) Cur_Quarter_Income_Realized_Distribution,
						Sum(Recallable_Distribution) Cur_Quarter_Recallable_Distribution,
						Sum(Return_of_Capital_Distribution) Cur_Quarter_Return_of_Capital_Distribution,
						Sum(Invested_Capital) Cur_Quarter_Invested_Capital,
						Sum(Fees) Cur_Quarter_Fees
				From #temp_dynamo_cash_activity_records
				Group By Security_Id , Fund_Id, Asset_Class
				), 
				prev_q as (
				Select
						Fund_Id,  
						Security_Id, 

						Sum(Capital_Called_Base) Prev_Quarter_Capital_Called_Base,  
						sum(Recallable_Base) Prev_Quarter_Recallable_Base,  
						Sum(Return_of_Capital_Base) Prev_Quarter_Return_of_Capital_Base,  
						Sum(Income_Realized_Base) Prev_Quarter_Income_Realized_Base,
						Sum(Income_Realized_Distribution) Prev_Quarter_Income_Realized_Distribution,
						Sum(Recallable_Distribution) Prev_Quarter_Recallable_Distribution,
						Sum(Return_of_Capital_Distribution) Prev_Quarter_Return_of_Capital_Distribution,
						Sum(Invested_Capital) Prev_Quarter_Invested_Capital,
						Sum(Fees) Prev_Quarter_Fees
				From #temp_dynamo_cash_activity_records
				Where Effective_Date <= DATEADD( QUARTER, DATEDIFF( QUARTER, 0, @Effective_Date), 0) - 1
				Group By Security_Id , Fund_Id
				),
				ytd as (
				Select
						Fund_Id,  
						Security_Id, 

						Sum(Capital_Called_Base) YTD_Capital_Called_Base,  
						sum(Recallable_Base) YTD_Recallable_Base,  
						Sum(Return_of_Capital_Base) YTD_Return_of_Capital_Base,  
						Sum(Income_Realized_Base) YTD_Income_Realized_Base,
						Sum(Income_Realized_Distribution) YTD_Income_Realized_Distribution,
						Sum(Recallable_Distribution) YTD_Recallable_Distribution,
						Sum(Return_of_Capital_Distribution) YTD_Return_of_Capital_Distribution,
						Sum(Invested_Capital) YTD_Invested_Capital,
						Sum(Fees) YTD_Fees
				From #temp_dynamo_cash_activity_records
				Where Effective_Date >= DATEADD(yy, DATEDIFF(yy, 0, @Effective_Date), 0)
				Group By Security_Id , Fund_Id
				)
				Select
					  cur_q.Fund_Id  
					  ,cur_q.Security_Id
					  ,@Effective_Date Effective_Date
					  ,[Cur_Quarter_Capital_Called_Base]
					  ,[Cur_Quarter_Recallable_Base]
					  ,[Cur_Quarter_Return_of_Capital_Base]
					  ,[Cur_Quarter_Income_Realized_Base]
					  ,[Cur_Quarter_Income_Realized_Distribution]
					  ,[Cur_Quarter_Recallable_Distribution]
					  ,[Cur_Quarter_Return_of_Capital_Distribution]
					  ,[Cur_Quarter_Invested_Capital]
					  ,[Cur_Quarter_Fees]

					  ,[Prev_Quarter_Capital_Called_Base]
					  ,[Prev_Quarter_Recallable_Base]
					  ,[Prev_Quarter_Return_of_Capital_Base]
					  ,[Prev_Quarter_Income_Realized_Base]
					  ,[Prev_Quarter_Income_Realized_Distribution]
					  ,[Prev_Quarter_Recallable_Distribution]
					  ,[Prev_Quarter_Return_of_Capital_Distribution]
					  ,[Prev_Quarter_Invested_Capital]
					  ,[Prev_Quarter_Fees]

					  ,[YTD_Capital_Called_Base]
					  ,[YTD_Recallable_Base]
					  ,[YTD_Return_of_Capital_Base]
					  ,[YTD_Income_Realized_Base]
					  ,[YTD_Income_Realized_Distribution]
					  ,[YTD_Recallable_Distribution]
					  ,[YTD_Return_of_Capital_Distribution]
					  ,[YTD_Invested_Capital]
					  ,[YTD_Fees]

				From cur_q
				left join prev_q on cur_q.Security_Id = prev_q.Security_Id and cur_q.Fund_Id = prev_q.Fund_Id
				left join ytd on cur_q.Security_Id = ytd.Security_Id and cur_q.Fund_Id = ytd.Fund_Id

				create table #temp_dynamo_nav
				WITH
				(
						DISTRIBUTION = Round_Robin
				) as 
				Select
					  coalesce(p.Fund_Id, ca.Fund_Id) Fund_Id
					  ,coalesce(p.Security_Id,ca.Security_Id) Security_Id
					  ,@Effective_Date Effective_Date
					  ,p.Base_Market_Value
					  ,[Cur_Quarter_Capital_Called_Base]
					  ,[Cur_Quarter_Recallable_Base]
					  ,[Cur_Quarter_Return_of_Capital_Base]
					  ,[Cur_Quarter_Income_Realized_Base]
					  ,[Cur_Quarter_Income_Realized_Distribution]
					  ,[Cur_Quarter_Recallable_Distribution]
					  ,[Cur_Quarter_Return_of_Capital_Distribution]
					  ,[Cur_Quarter_Invested_Capital]
					  ,[Cur_Quarter_Fees]

					  ,[Prev_Quarter_Capital_Called_Base]
					  ,[Prev_Quarter_Recallable_Base]
					  ,[Prev_Quarter_Return_of_Capital_Base]
					  ,[Prev_Quarter_Income_Realized_Base]
					  ,[Prev_Quarter_Income_Realized_Distribution]
					  ,[Prev_Quarter_Recallable_Distribution]
					  ,[Prev_Quarter_Return_of_Capital_Distribution]
					  ,[Prev_Quarter_Invested_Capital]
					  ,[Prev_Quarter_Fees]

					  ,[YTD_Capital_Called_Base]
					  ,[YTD_Recallable_Base]
					  ,[YTD_Return_of_Capital_Base]
					  ,[YTD_Income_Realized_Base]
					  ,[YTD_Income_Realized_Distribution]
					  ,[YTD_Recallable_Distribution]
					  ,[YTD_Return_of_Capital_Distribution]
					  ,[YTD_Invested_Capital]
					  ,[YTD_Fees]

					  ,p.Base_Market_Value Cur_Quarter_Nav_Base
					  ,null Prev_Quarter_Nav_Base
					  ,null YTD_Nav_Base

					  ,Commitment_Drawn
				From #temp_dynamo_position_records p
				Left Join (
					Select Fund_Id, Security_Id, sum(Commitment_Drawn) Commitment_Drawn
					From #temp_dynamo_cash_activity_records
					Where datediff(d, Effective_Date, @Effective_Date) = 0 
					Group By Fund_Id, Security_Id
				) cd on p.Security_Id = cd.Security_Id and p.Fund_Id = cd.Fund_Id
				full join #temp_dynamo_cash_activity_summary ca on p.Security_Id = ca.Security_Id and p.Fund_Id = ca.Fund_Id
			

				INSERT INTO [EDW_BUS].[Aggr_Private_Market_NAV_Report]
				(
				  [Dim_Date_Key]
				  ,[Dim_Portfolio_Key]
				  ,[Dim_Eagle_Portfolio_Detail_Key]
				  ,[Dim_Security_Key]
				  ,[Dim_Eagle_Security_Detail_Key]
				  ,[Base_Market_Value]

				  ,[Cur_Quarter_Nav_Base]
				  ,[Cur_Quarter_Capital_Called_Base]
				  ,[Cur_Quarter_Recallable_Base]
				  ,[Cur_Quarter_Return_of_Capital_Base]
				  ,[Cur_Quarter_Income_Realized_Base]
				  ,[Cur_Quarter_Income_Realized_Distribution]
				  ,[Cur_Quarter_Recallable_Distribution]
				  ,[Cur_Quarter_Return_of_Capital_Distribution]
				  ,[Cur_Quarter_Invested_Capital]
				  ,[Cur_Quarter_Fees]
				  ,[Prev_Quarter_Nav_Base]
				  ,[Prev_Quarter_Capital_Called_Base]
				  ,[Prev_Quarter_Recallable_Base]
				  ,[Prev_Quarter_Return_of_Capital_Base]
				  ,[Prev_Quarter_Income_Realized_Base]
				  ,[Prev_Quarter_Income_Realized_Distribution]
				  ,[Prev_Quarter_Recallable_Distribution]
				  ,[Prev_Quarter_Return_of_Capital_Distribution]
				  ,[Prev_Quarter_Invested_Capital]
				  ,[Prev_Quarter_Fees]
				  ,[YTD_Nav_Base]
				  ,[YTD_Capital_Called_Base]
				  ,[YTD_Recallable_Base]
				  ,[YTD_Return_of_Capital_Base]
				  ,[YTD_Income_Realized_Base]
				  ,[YTD_Income_Realized_Distribution]
				  ,[YTD_Recallable_Distribution]
				  ,[YTD_Return_of_Capital_Distribution]
				  ,[YTD_Invested_Capital]
				  ,[YTD_Fees]
				  ,Commitment_Drawn
				  ,Load_DTS
				  ,[Last_Update_DTS]
				  ,[ETL_Load_Key]
				)
				Select
					  convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Date_Key]
					  ,coalesce(p.[Dim_Portfolio_Key],-1) [Dim_Portfolio_Key]
					  ,coalesce(pd.[Dim_Eagle_Portfolio_Detail_Key],-1) [Dim_Eagle_Portfolio_Detail_Key]
					  ,coalesce(sec.[Dim_Security_Key], -1) [Dim_Security_Key]
					  ,coalesce(secd.[Dim_Eagle_Security_Detail_Key], -1) [Dim_Eagle_Security_Detail_Key]

					  ,Base_Market_Value

					  ,Cur_Quarter_Nav_Base
					  ,[Cur_Quarter_Capital_Called_Base]
					  ,[Cur_Quarter_Recallable_Base]
					  ,[Cur_Quarter_Return_of_Capital_Base]
					  ,[Cur_Quarter_Income_Realized_Base]
					  ,[Cur_Quarter_Income_Realized_Distribution]
					  ,[Cur_Quarter_Recallable_Distribution]
					  ,[Cur_Quarter_Return_of_Capital_Distribution]
					  ,[Cur_Quarter_Invested_Capital]
					  ,[Cur_Quarter_Fees]

					  ,Prev_Quarter_Nav_Base
					  ,[Prev_Quarter_Capital_Called_Base]
					  ,[Prev_Quarter_Recallable_Base]
					  ,[Prev_Quarter_Return_of_Capital_Base]
					  ,[Prev_Quarter_Income_Realized_Base]
					  ,[Prev_Quarter_Income_Realized_Distribution]
					  ,[Prev_Quarter_Recallable_Distribution]
					  ,[Prev_Quarter_Return_of_Capital_Distribution]
					  ,[Prev_Quarter_Invested_Capital]
					  ,[Prev_Quarter_Fees]

					  ,YTD_Nav_Base
					  ,[YTD_Capital_Called_Base]
					  ,[YTD_Recallable_Base]
					  ,[YTD_Return_of_Capital_Base]
					  ,[YTD_Income_Realized_Base]
					  ,[YTD_Income_Realized_Distribution]
					  ,[YTD_Recallable_Distribution]
					  ,[YTD_Return_of_Capital_Distribution]
					  ,[YTD_Invested_Capital]
					  ,[YTD_Fees]
					  ,Commitment_Drawn
					  ,@srcLoadDTS
					  ,@today
					  ,@ETL_Load_Key

				From #temp_dynamo_nav src
				--Dim_Portfolio_Key
				Left Join EDW_Common.Dim_Portfolio p on src.Fund_Id = p.Portfolio_Id and p.Record_Is_Current_Flag = 1

				Left Join EDW_Common.Dim_Eagle_Portfolio_Detail pd on src.Fund_Id = pd.Portfolio_Id and pd.Record_Is_Current_Flag = 1

				--Dim_Security_Key
				Left Join EDW_Common.Dim_Security sec on 'Eagle_' + src.Security_Id = sec.Src_Security_Id and sec.Record_Is_Current_Flag = 1

				Left Join EDW_Common.Dim_Eagle_Security_Detail secd on src.Security_Id = secd.Security_Id and secd.Record_Is_Current_Flag = 1

				Select @rowsInserted = Count(*) 
				From [EDW_BUS].[Aggr_Private_Market_NAV_Report]
				Where Last_Update_DTS = @today

				Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_NAV_Report', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

				/* cleanup temp tables */
				IF OBJECT_ID('tempdb..#temp_dynamo_position_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_position_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_records') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_records
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_cash_activity_summary') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_cash_activity_summary
				END

				IF OBJECT_ID('tempdb..#temp_dynamo_nav') IS NOT NULL
				BEGIN
					DROP TABLE #temp_dynamo_nav
				END
		End

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Aggr_Private_Market_NAV_Report', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END