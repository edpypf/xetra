﻿CREATE PROC [EDW_BUS].[RM_Aggr_NISA_Trades_HLD] @ETL_LOAD_KEY [INT],@Load_Type [VARCHAR],@Batch_DTS [DATETIME2] AS


BEGIN 
	

BEGIN TRY
	
	DECLARE @effectiveDate DATE
	SET  @effectiveDate = @Batch_DTS

	DECLARE @rowsInserted INT = 0,
			@rowsCount INT = 0,
			@today datetime2 = getdate(),
			@rows int,
			@Business_Area varchar(255)= 'RISK',
			@Affected_Source_System varchar(255)= 'SQL_RISK_ETL'


		--Set effective date to T-1 or last business day
		IF @effectiveDate IS NOT NULL AND DATEDIFF(day, '1900-01-01', @effectiveDate) <> 0
		BEGIN
			SELECT @effectiveDate  = @effectiveDate 
		END
		ELSE
		BEGIN
			
			SELECT @effectiveDate = CASE DATEPART(WEEKDAY, GETDATE()) WHEN 2 THEN DATEADD(DAY, -3 , GETDATE()) ELSE DATEADD(DAY, -1 , GETDATE()) END

			SELECT @rows = count(Holiday_Date) FROM [EDW_ETL].[User_Holiday_Calendar]
			WHERE DATEDIFF(day, Holiday_Date, @effectiveDate) = 0
				AND Business_Area = @Business_Area and Affected_System = @Affected_Source_System

			WHILE @rows > 0
			BEGIN
				-- get previous business date
				SELECT @effectiveDate = CASE DATEPART(WEEKDAY, @effectiveDate) WHEN 2 THEN DATEADD(DAY, -3 , @effectiveDate) ELSE DATEADD(DAY, -1 , @effectiveDate) END

				SELECT @rows = count(Holiday_Date) FROM EDW_ETL.User_Holiday_Calendar
				WHERE DATEDIFF(day, Holiday_Date, @effectiveDate) = 0
					AND Business_Area = @Business_Area and Affected_System = @Affected_Source_System

			END
		END


	--Clean up consolidated view if holding date already exists 	
	SELECT @rowsCount = COUNT(1) FROM [EDW_BUS].[Agg_WSIB_NISA_Trades_HLD]
	WHERE HOLDING_DATE =@effectiveDate

	IF @rowsCount>1
	BEGIN
		DELETE FROM [EDW_BUS].[Agg_WSIB_NISA_Trades_HLD] WHERE HOLDING_DATE =@effectiveDate
	END

	


	;WITH REPOTRADE_EXCLUSION AS
	(
		SELECT DISTINCT REPO_CUSIP
		FROM EDW_Raw.V_WSIB_Nisa_Trades NT
		WHERE UPPER(TRIM(NT.REPO_TYPE)) IN ('REVERSE REPO','REPO')
		AND UPPER(TRIM(NT.TRANS_TYPE) )IN ( 'CANCEL' , 'RESIZE','MATURITY') 
		AND @EffectiveDate >= TRADE_DATE     -- parameter
		AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) IN (SELECT Portfolio_ID FROM [PSA].[V_Manual_Portfolio_Groups] where group_name = 'WSIB Accounting Position Split' and @EffectiveDate between start_date and end_Date) --parameter
    ),
	PennyLoadMaxDate as
	(SELECT 
			 @EffectiveDate      as HoldingDate,
			 MAX(Effective_Date) as MaxEffectiveDate
		FROM  [EDW_Raw].V_WSIB_Accounting_Position_Split
		WHERE EFFECTIVE_DATE < @EffectiveDate
	), Final AS 
    (
		SELECT  
		   CONVERT(varchar,@EffectiveDate, 112)		as HOLDINGDATE   
		   ,CONCAT(NT.BANK_ACCOUNT_NUMBER ,'_REPO') 	as  ACCOUNTID
		   ,NT.BANK_ACCOUNT_NUMBER 					as ACCOUNTDESCRIPTION
		   ,'CAD'									as ACCOUNTBASECURRENCY
		   ,'Repo'									as ASSETCLASS
		   ,'Repo'									as ASSETTYPE
		   ,CONCAT(CASE WHEN UPPER(TRIM(NT.REPO_TYPE)) = 'REVERSE REPO' THEN  'RREPO' ELSE 'REPO' END,'_',TRIM(NT.UNDERLYING_CUSIP),'_',NT.Par_Amount) as ASSETNAME
		   ,CONCAT(TRIM(NT.REPO_CUSIP),'-Repo-WSIB') as PRIMARYASSETID
		   ,NULL									as SECCDPRMY
		   ,'LOCALID'								as PRIMARYASSETIDTYPE
		   ,NULL		 							as SEDOL     
		   ,NT.Underlying_CUSIP						as CUSIP     
		   ,NULL 									as ISIN      
		   ,NULL 									as TICKER
		   ,CASE WHEN REPO_TYPE='REVERSE REPO' Then -1*NT.REAL_SETTLE_MONEY Else NT.REAL_SETTLE_MONEY END as NOTIONALAMOUNT
		   ,NULL									as WEIGHT
		   ,CASE WHEN REPO_TYPE='REVERSE REPO' Then -1*NT.REAL_SETTLE_MONEY Else NT.REAL_SETTLE_MONEY END as NUMBEROFSHARES
		   ,NULL 									as BASEACCRUEDINCOMEVALUE 
		   ,NULL 									as BASEMARKETVALUE  
		   ,NULL 									as BASENETASSETVALUE      
		   ,NULL 									as LOCALACCRUEDINCOMEVALUE 
		   ,NULL									as LOCALMARKETVALUE 
		   ,NULL 									as LOCALNETASSETVALUE     
		   ,'CAD'									as BASEMARKETVALUECURRENCY 
		   ,NT.CURRENCY								as LOCALMARKETVALUECURRENCY      
		   ,NULL 									as ASSETPRICEDATE   
		   ,NULL 									as ASSETPRICE       
		   ,NULL 									as ASSETPRICECURRENCY     
		   ,NULL 									as DP_ASSETTYPE     
		   ,NULL 									as RIC        
		   ,NULL 									as BBTICKER
		   ,NULL 									as REDCODE   
		   ,NULL 									as LOANXID   
		   ,NULL 									as BUCKETLIST
		FROM EDW_Raw.V_WSIB_Nisa_Trades NT  
		WHERE UPPER(TRIM(NT.REPO_TYPE)) IN ('REVERSE REPO','REPO')
		AND UPPER(TRIM(NT.TRANS_TYPE) )= 'INITIATION'  
		AND @EffectiveDate >= NT.TRADE_DATE     -- parameter
		AND @EffectiveDate < NT.TERMINATION_DATE -- parameter
		AND UPPER(TRIM(BANK_ACCOUNT_NUMBER)) IN (SELECT Portfolio_ID FROM [PSA].[V_Manual_Portfolio_Groups] where group_name = 'WSIB Accounting Position Split' and @EffectiveDate between start_date and end_Date) --parameter
		AND NT.REPO_CUSIP NOT IN (SELECT REPO_CUSIP FROM REPOTRADE_EXCLUSION)
		 
		UNION 
		
		SELECT  
			 CONVERT(varchar,V.Effective_Date, 112) 	 as HOLDINGDATE
			,V.Fund  									 as ACCOUNTID         
			,LEFT(V.Fund,CHARINDEX('_',V.Fund)-1)		as ACCOUNTDESCRIPTION     
			,V.Base_Currency_Code						 as ACCOUNTBASECURRENCY    
			,V.Asset_Class		 						 as ASSETCLASS       
			,V.Asset_Class          					 as ASSETTYPE 
			,V.Security_Name							 as ASSETNAME 
			,V.CUSIP_Number								 as PRIMARYASSETID   
			,NULL as SECCDPRMY 
			,'CUSIP' as PRIMARYASSETIDTYPE     
			,V.SEDOL_Number 							 as SEDOL     
			,V.CUSIP_Number 							 as CUSIP     
			,V.ISIN_Number 								 as ISIN      
			,NULL as TICKER    
			,CASE WHEN  V.Face_Amount <> 0 THEN V.Face_Amount
			 ELSE  V.Shares_Par_Value END 					as NOTIONALAMOUNT   
			,NULL as WEIGHT    
			,CASE WHEN  V.Face_Amount <> 0 THEN V.Face_Amount
			 ELSE  V.Shares_Par_Value END 	  				as NUMBEROFSHARES   
			,NULL as BASEACCRUEDINCOMEVALUE 
			,V.Base_Market_Value					as BASEMARKETVALUE  
			,NULL as BASENETASSETVALUE      
			,NULL as LOCALACCRUEDINCOMEVALUE 
			,V.Local_Market_Value					as LOCALMARKETVALUE 
			,NULL as LOCALNETASSETVALUE     
			,V.Base_Currency_Code					as BASEMARKETVALUECURRENCY 
			,V.Local_Currency_Code					as LOCALMARKETVALUECURRENCY      
			,NULL as ASSETPRICEDATE   
			,NULL as ASSETPRICE       
			,NULL as ASSETPRICECURRENCY     
			,NULL as DP_ASSETTYPE     
			,NULL as RIC        
			,NULL as BBTICKER
			,NULL as REDCODE   
			,NULL as LOANXID   
			,NULL as BUCKETLIST
		FROM EDW_Raw.V_WSIB_Accounting_Position_Split V
		WHERE V.Effective_Date = @EffectiveDate -- Parameter
		AND (UPPER(TRIM(V.Investment_Type_Code)) <>'ST'
			 OR UPPER(TRIM(V.Security_Name))  NOT LIKE '%REPO%' )
		AND V.Shares_Par_Value <> 0
		AND V.Asset_Class='FIXED INCOME'
		
		UNION
		
		SELECT  
			 CONVERT(varchar,V.Effective_Date, 112) 	as HOLDINGDATE
			,V.Fund  									as ACCOUNTID         
			,LEFT(V.Fund,CHARINDEX('_',V.Fund)-1)		as ACCOUNTDESCRIPTION     
			,'CAD'										as ACCOUNTBASECURRENCY    
			,V.Asset_Class		 						as ASSETCLASS       
			,V.Asset_Class			 					as ASSETTYPE 
			,V.Security_Name							as ASSETNAME 
			,V.CUSIP_Number								as PRIMARYASSETID   
			,NULL 										as SECCDPRMY 
			,'BARRAID' 									as PRIMARYASSETIDTYPE     
			,V.SEDOL_Number 							as SEDOL     
			,V.CUSIP_Number 							as CUSIP     
			,V.ISIN_Number 								as ISIN      
			,NULL 										as TICKER    
			,convert(float,V.Shares_Par_Value)			as NOTIONALAMOUNT   
			,NULL 										as WEIGHT    
			,V.Shares_Par_Value 						as NUMBEROFSHARES   
			,NULL 										as BASEACCRUEDINCOMEVALUE 
			,V.Base_Market_Value 						as BASEMARKETVALUE  
			,NULL 										as BASENETASSETVALUE      
			,NULL 										as LOCALACCRUEDINCOMEVALUE 
			,V.Shares_Par_Value						    as LOCALMARKETVALUE 
			,NULL 										as LOCALNETASSETVALUE     
			,V.Base_Currency_Code						as BASEMARKETVALUECURRENCY 
			,V.Local_Currency_Code						as LOCALMARKETVALUECURRENCY      
			,NULL 										as ASSETPRICEDATE   
			,NULL 										as ASSETPRICE       
			,NULL 										as ASSETPRICECURRENCY     
			,NULL 										as DP_ASSETTYPE     
			,NULL 										as RIC        
			,NULL 										as BBTICKER
			,NULL 										as REDCODE   
			,NULL 										as LOANXID   
			,NULL 										as BUCKETLIST
	FROM EDW_Raw.V_WSIB_Accounting_Position_Split V
	WHERE V.Effective_Date = @EffectiveDate -- Parameter
	AND (UPPER(TRIM(V.Investment_Type_Code)) <>'ST'
		 OR UPPER(TRIM(V.Security_Name))  NOT LIKE '%REPO%' )
	AND V.Shares_Par_Value <> 0 AND Asset_Class='CASH'
	
	UNION

	SELECT  
	     DISTINCT
		 CONVERT(varchar,P.HoldingDate, 112) 	 	 as HOLDINGDATE  
		,V.Fund  									 as ACCOUNTID         
		,LEFT(V.Fund,CHARINDEX('_',V.Fund)-1)    	 as ACCOUNTDESCRIPTION  
		,'CAD' as ACCOUNTBASECURRENCY    
		,'Cash' as ASSETCLASS       
		,'Cash' as ASSETTYPE 
		,'Penny Account' as ASSETNAME 
		,'CAD' as PRIMARYASSETID   
		,NULL as SECCDPRMY 
		,'BARRAID' as PRIMARYASSETIDTYPE     
		,NULL as SEDOL     
		,NULL as CUSIP    
		,NULL as ISIN      
		,NULL as TICKER    
		,0.01 as NOTIONALAMOUNT   
		,NULL as WEIGHT    
		,0.01 as NUMBEROFSHARES   
		,NULl as BASEACCRUEDINCOMEVALUE 
		,0.01 as BASEMARKETVALUE  
		,0.01 as BASENETASSETVALUE      
		,NULL as LOCALACCRUEDINCOMEVALUE 
		,NULL as LOCALMARKETVALUE 
		,NULL as LOCALNETASSETVALUE     
		,'CAD' as BASEMARKETVALUECURRENCY 
		,'CAD' as LOCALMARKETVALUECURRENCY      
		,NULL as ASSETPRICEDATE   
		,NULL as ASSETPRICE       
		,NULL as ASSETPRICECURRENCY     
		,NULL as DP_ASSETTYPE     
		,NULL as RIC       
		,NULL as BBTICKER
		,NULL as REDCODE   
		,NULL as LOANXID   
		,NULL as BUCKETLIST
	FROM [EDW_Raw].V_WSIB_Accounting_Position_Split V
	INNER JOIN PennyLoadMaxDate P on V.Effective_Date = P.MaxEffectiveDate  
	WHERE V.Shares_Par_Value <> 0
	 )
	 INSERT INTO [EDW_BUS].[Agg_WSIB_NISA_Trades_HLD]
	 (
		 [HOLDING_DATE]
		,[ACCOUNT_ID]
		,[ACCOUNT_DESCRIPTION]
		,[ACCOUNT_BASE_CURRENCY]
		,[ASSET_CLASS]
		,[ASSET_TYPE]
		,[ASSET_NAME]
		,[PRIMARY_ASSET_ID]
		,[SECCD_PRMY]
		,[PRIMARY_ASSET_ID_TYPE]
		,[SEDOL]
		,[CUSIP]
		,[ISIN]
		,[TICKER]
		,[NOTIONAL]
		,[WEIGHT]
		,[NUMBER_OF_SHARES]
		,[BASE_ACCRUED_INCOME_VALUE]
		,[BASE_MARKET_VALUE]
		,[BASE_NET_ASSET_VALUE]
		,[LOCAL_ACCRUED_INCOME_VALUE]
		,[LOCAL_MARKET_VALUE]
		,[LOCAL_NET_ASSET_VALUE]
		,[BASE_MARKET_VALUE_CURRENCY]
		,[LOCAL_MARKET_VALUE_CURRENCY]
		,[ASSET_PRICE_Date]
		,[ASSET_PRICE]
		,[ASSET_PRICE_CURRENCY]
		,[DP_ASSET_TYPE]
		,[RIC]
		,[BBTICKER]
		,[REDCODE]
		,[LOANXID]
		,[BUCKETLIST]
		,[Load_DTS]
		,[Hash_Diff]
		,[ETL_Load_Key]
		,[Source_Deleted_Flag]
	 )
	 SELECT 
		  HOLDINGDATE
		 ,ACCOUNTID         
		 ,ACCOUNTDESCRIPTION     
		 ,ACCOUNTBASECURRENCY    
		 ,ASSETCLASS       
		 ,ASSETTYPE 
		 ,ASSETNAME 
		 ,PRIMARYASSETID   
		 ,SECCDPRMY 
		 ,PRIMARYASSETIDTYPE     
		 ,SEDOL     
		 ,CUSIP     
		 ,ISIN      
		 ,TICKER    
		 ,NOTIONALAMOUNT   
		 ,WEIGHT    
		 ,NUMBEROFSHARES   
		 ,BASEACCRUEDINCOMEVALUE 
		 ,BASEMARKETVALUE  
		 ,BASENETASSETVALUE      
		 ,LOCALACCRUEDINCOMEVALUE 
		 ,LOCALMARKETVALUE 
		 ,LOCALNETASSETVALUE     
		 ,BASEMARKETVALUECURRENCY 
		 ,LOCALMARKETVALUECURRENCY 
		 ,ASSETPRICEDATE   
		 ,ASSETPRICE       
		 ,ASSETPRICECURRENCY     
		 ,DP_ASSETTYPE     
		 ,RIC        
		 ,BBTICKER
		 ,REDCODE   
		 ,LOANXID   
		 ,BUCKETLIST
		 ,@today
		 , CONVERT(VARCHAR(64), HASHBYTES('SHA1', UPPER(CONCAT(HOLDINGDATE, '|' ,ACCOUNTID         , '|' ,ACCOUNTDESCRIPTION     , '|' ,ACCOUNTBASECURRENCY    , '|' ,ASSETTYPE , '|' ,
		 							ASSETNAME , '|' ,PRIMARYASSETID   , '|' ,SECCDPRMY , '|' ,PRIMARYASSETIDTYPE     , '|' ,SEDOL     , '|' ,CUSIP     , '|' ,
		 							ISIN      , '|' ,TICKER    , '|' ,NOTIONALAMOUNT   , '|' ,WEIGHT    , '|' ,NUMBEROFSHARES   , '|' ,BASEACCRUEDINCOMEVALUE , '|' ,
		 							BASEMARKETVALUE  , '|' ,BASENETASSETVALUE      , '|' ,LOCALACCRUEDINCOMEVALUE , '|' ,LOCALMARKETVALUE , '|' ,LOCALNETASSETVALUE     , '|' ,
		 							BASEMARKETVALUECURRENCY , '|' ,LOCALMARKETVALUECURRENCY , '|' ,ASSETPRICEDATE   , '|' ,ASSETPRICE       , '|' ,
		 							ASSETPRICECURRENCY     , '|' ,DP_ASSETTYPE     , '|' ,RIC        , '|' ,BBTICKER, '|' ,REDCODE   , '|' ,LOANXID   , '|' ,BUCKETLIST, '|' ))), 2) AS Hash_Diff
		 ,@ETL_LOAD_KEY AS ETL_Load_Key
		 ,0 AS Source_Deleted_Flag
	 FROM FINAL


	 SELECT @rowsInserted = COUNT(*) 
		FROM [EDW_BUS].[Agg_WSIB_NISA_Trades_HLD]
		WHERE [Load_dts] = @today and [Source_Deleted_Flag] = 0

		EXEC [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.Agg_WSIB_NISA_Trades_HLD', @rowsInserted, 0, 0, 'Completed', null

	END TRY 

		BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_BUS.Agg_WSIB_NISA_Trades_HLD', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState
		
	END CATCH
END