﻿CREATE PROC [EDW_BUS].[BBG_Aggr_PX_PE_Weekday_Check] @ETL_Load_Key [bigint],@Load_Type [VARCHAR](200),@Batch_DTS [VARCHAR](100) AS

-- Description: For px-pe, the batch date is BD, this PROC will populate data for BD-1
-- if run day = monday, eff-date = last firday, use last friday and thursday data
-- if run day = tue - fri, use t-1 data
-- Debug: exec [EDW_BUS].[BBG_Aggr_PX_PE_Weekday_Check] 1,null,'1900-01-01'
-- DECLARE @Batch_DTS [VARCHAR](100); SET @Batch_DTS = '1900-01-01'
DECLARE --@DayOfWeek TINYINT,
		@T DATE,
		@T_1 DATE,
		@T_2 DATE;

SET @T =  CASE WHEN CONVERT(DATE,@Batch_DTS) = '1900-01-01'
                     THEN CONVERT(DATE,CONVERT(DATETIME,SWITCHOFFSET(GETDATE(),DATEPART(TZOFFSET,GETDATE() AT TIME ZONE 'Eastern Standard Time'))),23)   
			   ELSE CONVERT(DATE,@Batch_DTS)
          END

SET @T_1 = CASE DATEPART(WEEKDAY, CONVERT(DATE,@T,23)) 
				WHEN 1 THEN Dateadd(day, -2 , CONVERT(DATE,@T,23)) -- Sunday > Friday
				WHEN 2 THEN Dateadd(day, -3 , CONVERT(DATE,@T,23)) -- Monday > Friday
				ELSE Dateadd(day, -1 , CONVERT(DATE,@T,23)) -- Tuesday - Saturday > T-1
				END;
SET @T_2 = CASE DATEPART(WEEKDAY, CONVERT(DATE,@T,23)) 
				WHEN 1 THEN Dateadd(day, -3 , CONVERT(DATE,@T,23)) -- Sunday > Thursday
				WHEN 2 THEN Dateadd(day, -4 , CONVERT(DATE,@T,23)) -- Monday > Thursday
				WHEN 3 THEN Dateadd(day, -4 , CONVERT(DATE,@T,23)) -- Tuesday > Friday
				ELSE Dateadd(day, -2 , CONVERT(DATE,@T,23)) -- Wednesday - Saturday > T-1
				END;

-- SELECT @T, @T_1, @T_2;

DELETE FROM EDW_BUS.Aggr_BBG_PX_PE_Check
WHERE [Batch_Date] = @T_1;


IF (SELECT DATEPART(WEEKDAY, @T)) = 2 -- Monday
BEGIN
	INSERT INTO EDW_BUS.Aggr_BBG_PX_PE_Check
	SELECT 
		[Bloomberg_Identifier], 
		[Security_Name], 
		[ISIN], 
		[CUSIP],
		[SEDOL1], 
		[Currency],
		[Effective_Date], 
		[PRICE] = CASE 
				WHEN [MHIS_CLOSE_ON_PX] NOT IN ('','N.A.') THEN [MHIS_CLOSE_ON_PX]  
				ELSE CASE WHEN [PX_CLOSE_1D] NOT IN ('','N.A.') THEN [PX_CLOSE_1D]
					 ELSE [PX_LAST_EOD]
					 END
				END,
		[PRICE_DATE] = CASE
						WHEN [MHIS_CLOSE_ON_PX] NOT IN ('','N.A.') THEN convert(varchar(10),[MHIS_CLOSE_DT],101)
						ELSE CASE 
								WHEN px_dt_1d NOT IN ('N.A.','') AND [PX_CLOSE_1D] NOT IN ('','N.A.')
								THEN CASE WHEN CONVERT(DATE, [PX_DT_1D] ,101) <= @T_1 -- T-1 
										   THEN [PX_DT_1D] 
										  ELSE 'INVALID'
									  END 
								ELSE CASE WHEN [PX_CLOSE_DT] NOT IN ('N.A.','')
											THEN CASE WHEN CONVERT(DATE, [PX_CLOSE_DT],101) <= @T_1 -- T-1
													  THEN [PX_CLOSE_DT] 
													  ELSE 'INVALID'
												 END
											ELSE [PX_CLOSE_DT]
									  END
							END
					 END,
		[Batch_Date] = @T_1,
		[Pool_Name],
		[IsMonday] = 1
	FROM [EDW_Mart].[Bloomberg_PX_PE_Pool]  
	WHERE [Effective_Date] = @T_1 -- T-1
	AND [Currency]  NOT IN ('ILS','KWD','SAR','QAR','EGP')

	UNION ALL

	SELECT 
		[Bloomberg_Identifier], 
		[Security_Name], 
		[ISIN], 
		[CUSIP],
		[SEDOL1], 
		[Currency],
		[Effective_Date], 
	    [PRICE] = CASE 
					WHEN [MHIS_CLOSE_ON_PX] NOT IN ('','N.A.') THEN [MHIS_CLOSE_ON_PX]  
						ELSE CASE WHEN [PX_CLOSE_1D] NOT IN ('','N.A.') THEN [PX_CLOSE_1D]
							 ELSE [PX_LAST_EOD]
							 END
				   END,
		[PRICE_DATE] = CASE
						WHEN [MHIS_CLOSE_ON_PX] NOT IN ('','N.A.') THEN CONVERT(VARCHAR(10),[MHIS_CLOSE_DT],101)
						ELSE CASE 
								WHEN px_dt_1d NOT IN ('N.A.','') AND [PX_CLOSE_1D] NOT IN ('','N.A.')
								THEN CASE WHEN CONVERT(DATE, [PX_DT_1D] ,101) <= @T_2 -- T-2
										   THEN [PX_DT_1D] 
										  ELSE 'INVALID'
									  END 
								ELSE CASE WHEN [PX_CLOSE_DT] NOT IN ('N.A.','')
											THEN CASE WHEN CONVERT(DATE, [PX_CLOSE_DT],101) <= @T_2 -- T-2
													  THEN [PX_CLOSE_DT] 
													  ELSE 'INVALID'
												 END
											ELSE [PX_CLOSE_DT]
									  END 
							END
					END,
		[Batch_Date] = @T_1,
		[Pool_Name],
		[IsMonday] = 1
	FROM [EDW_Mart].[Bloomberg_PX_PE_Pool]  
	WHERE effective_date = @T_2 -- T-2
	AND [Currency] IN ('ILS','KWD','SAR','QAR','EGP')
END

ELSE -- Non Monday

BEGIN 

	INSERT INTO EDW_BUS.Aggr_BBG_PX_PE_Check
	SELECT 
		[Bloomberg_Identifier], 
		[Security_Name], 
		[ISIN], 
		[CUSIP],
		[SEDOL1], 
		[Currency],
		[Effective_Date], 
		[PRICE] = CASE 
				WHEN [MHIS_CLOSE_ON_PX] NOT IN ('','N.A.') THEN [MHIS_CLOSE_ON_PX]  
				ELSE CASE WHEN [PX_CLOSE_1D] NOT IN ('','N.A.') THEN [PX_CLOSE_1D]
					 ELSE [PX_LAST_EOD]
					 END
				END,
		[PRICE_DATE] = CASE
						WHEN [MHIS_CLOSE_ON_PX] NOT IN ('','N.A.') THEN convert(varchar(10),[MHIS_CLOSE_DT],101)
						ELSE CASE 
								WHEN px_dt_1d NOT IN ('N.A.','') AND [PX_CLOSE_1D] NOT IN ('','N.A.')
								THEN CASE WHEN CONVERT(DATE, [PX_DT_1D] ,101) <= @T_1 -- T-1 
										   THEN [PX_DT_1D] 
										  ELSE 'INVALID'
									  END 
								ELSE CASE WHEN [PX_CLOSE_DT] NOT IN ('N.A.','')
											THEN CASE WHEN CONVERT(DATE, [PX_CLOSE_DT],101) <= @T_1 -- T-1
													  THEN [PX_CLOSE_DT] 
													  ELSE 'INVALID'
												 END
											ELSE [PX_CLOSE_DT]
									  END
							END
					 END,
		[Batch_Date] = @T_1,
		[Pool_Name],
		[IsMonday] = 0
	FROM [EDW_Mart].[Bloomberg_PX_PE_Pool]  
	WHERE [Effective_Date] = @T_1 -- T-1
END

-- SELECT * FROM [EDW_Mart].[Bloomberg_PX_PE_Pool] WHERE [Effective_Date] = '2023-03-08'
-- SELECT * FROM EDW_BUS.Aggr_BBG_PX_PE_Check
-- SELECT * FROM [EDW_Mart].[Bloomberg_NAV_Price_Validation] WHERE [Effective_Date] = '2023-03-08'