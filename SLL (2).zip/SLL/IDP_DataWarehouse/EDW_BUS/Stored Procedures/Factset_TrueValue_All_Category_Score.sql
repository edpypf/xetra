﻿CREATE PROC [EDW_BUS].[Factset_TrueValue_All_Category_Score] @ETL_LOAD_KEY [INT],@Load_Type [VARCHAR],@Batch_Date [DATETIME2] AS 

BEGIN

   Truncate table [EDW_BUS].[Aggr_Factset_TruValue_All_Category_Score]

	INSERT [EDW_BUS].[Aggr_Factset_TruValue_All_Category_Score]
	SELECT
		distinct
		-- effective date --
		p.tv_date AS 'Effective Date',
		isin.isin AS ISIN, -- key identifier to link with MSCI ACWI Constituents --
		-- ESG scores --
		round(p.all_categories_pulse, 2) as 'Pulse Score',
		round(esg.all_categories_adj_insight, 2) as 'Adjusted Insight Score',
		round(m.all_categories_momentum, 2) as 'Momentum Score',
		v.all_categories_articlevol as 'Trailing 12 months (TTM) Article Volume'
	FROM
	-- standard joins between symbology tables and truvalue tables
	[PSA].[V_Factset_Sym_Isin] AS isin
	JOIN [PSA].[V_Factset_Sym_Coverage] AS cov ON isin.fsym_id = cov.fsym_id
	JOIN [PSA].[V_Factset_Tv_Sec_Entity_Hist] AS id ON id.fsym_id = cov.fsym_security_id
	JOIN [PSA].[V_Factset_Tv_Factset_Id_Map] AS idm ON idm.factset_id = id.factset_entity_id
	-- linking with pulse, insight, momentum and volume tables:
	JOIN [PSA].[V_Factset_Tv_Pulse] AS p ON p.tv_org_id = idm.provider_id
	JOIN [PSA].[V_Factset_Tv_Esg_Ranks] esg ON esg.tv_org_id = idm.provider_id AND esg.tv_date = p.tv_date
	JOIN [PSA].[V_Factset_Tv_Momentum] AS m ON m.tv_org_id = idm.provider_id AND m.tv_date = p.tv_date
	JOIN [PSA].[V_Factset_Tv_Volume] AS v on v.tv_org_id = idm.provider_id AND v.tv_date = p.tv_date
	WHERE
	(
		-- make sure get the latest/valid/live ISINs:
		(id.end_date is null and p.tv_date >= id.start_date)
		-- or include any expired/old ISIN for the period when the ISINs were still live:
		or (id.end_date is not null and p.tv_date <= id.end_date and p.tv_date >= id.start_date ) 
	)
	

END