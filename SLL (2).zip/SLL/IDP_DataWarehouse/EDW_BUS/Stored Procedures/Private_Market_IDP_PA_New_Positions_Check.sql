﻿CREATE PROC [EDW_BUS].[Private_Market_IDP_PA_New_Positions_Check] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

		Declare @today datetime2 = getdate()
		
		declare @rowsInserted int = 0,
				@rowsUpdated int = 0,
				@rowsExpired int = 0,
				@Effective_Date date,
				@Previous_Date date,
				@LoadType varchar(150)

				--,@Load_Type [varchar](255) = 'Delta|2023-06-02'
				--,@Batch_DTS date = '2023-06-09'
				--,@ETL_Load_Key int = 1

		IF Convert(date,@Batch_DTS) = '1900-01-01' and @Load_Type not like '%|%'
		BEGIN
			-- get effective date (previous business date) to check
			set @Effective_Date = CASE DATEPART(weekday, @today) 
							WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
							WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
							ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
							END
			set @Previous_Date = Dateadd(day, -7 , @Effective_Date)
			set @LoadType = @Load_Type
		END 
		ELSE 
		BEGIN
			set @Effective_Date = @Batch_DTS
			set @Previous_Date = right(@Load_Type, charindex('|', reverse(@Load_Type)) - 1)
			set @LoadType = left(@Load_Type, charindex('|', @Load_Type) - 1)
		END;

		--select  @Effective_Date, @Previous_Date, @LoadType
		
	BEGIN TRY

		with idp as 
		(
		select	effective_date,asset_class,primary_asset_id_type, portfolio_id, Accounting_Fund_ID, dynamo_fund_id,  dynamo_fund_name,count (*)as position_count 
		FROM	[EDW_Mart].[Private_Market_Position_Tag] 
		where	effective_date in (@Effective_Date, @Previous_Date)
				and asset_class in ('Private Equity', 'Real Estate','Private Infrastructure')
				and market_value <>0
		GROUP BY effective_date,asset_class,PRIMARY_ASSET_ID_TYPE, portfolio_id, Accounting_Fund_ID, dynamo_fund_id,  dynamo_fund_name 
		)

		insert into [EDW_BUS].[Aggr_Private_Market_IDP_PA_New_Positions]
		select   effective_date
				,asset_class
				,primary_asset_id_type
				,portfolio_id
				,Accounting_Fund_ID
				,dynamo_fund_id
				,dynamo_fund_name
				,position_count
				,@today
				,Null
				,@ETL_Load_key
				,0
		from	idp as currentweek 
		where	effective_date = @Effective_Date
				and dynamo_fund_id not in (select distinct dynamo_fund_id from idp where effective_date = @Previous_Date ) 



		Select @rowsInserted = Count(*) 
		From [EDW_BUS].[Aggr_Private_Market_IDP_PA_New_Positions]
		Where Load_DTS = @today and Is_Src_Deleted = 0


		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Private_Market_IDP_PA_New_Positions_Check', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.Private_Market_IDP_PA_New_Positions_Check', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END