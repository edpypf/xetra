﻿CREATE PROC [EDW_BUS].[FX_Aggr_Infra_Pool_Hedge_FX_Exposure] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2,
			@effective_date date,
			@lastQuarterEnd date,
			@lastQuarterEndBD date

	BEGIN TRY

		-- get business date
		IF Convert(date,@Batch_DTS) = '1900-01-01'
		BEGIN
			-- get effective date (previous business date) to check
			Set @effective_date = CASE DATEPART(weekday, @today) 
							WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
							WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
							ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
							END
		END 
		ELSE 
		BEGIN
			set @effective_date = @Batch_DTS
		END;

		BEGIN
			set @lastQuarterEnd = dateadd(qq, DateDiff(qq, 0, @effective_date), -1) 

			-- get last quarter end date
			Set @lastQuarterEndBD = CASE DATEPART(weekday, @lastQuarterEnd) 
							WHEN 7 THEN Dateadd(day, -1 , @lastQuarterEnd) -- Saturday > Friday
							WHEN 1 THEN Dateadd(day, -2 , @lastQuarterEnd) -- Sunday > Friday
							ELSE @lastQuarterEnd
							END
		END

		--FX---------------------
		IF OBJECT_ID('tempdb..#temp_InfraPool_FX_FXRate') IS NOT NULL
		BEGIN
			DROP TABLE #temp_InfraPool_FX_FXRate
		END

		CREATE TABLE #temp_InfraPool_FX_FXRate
			WITH
			(
					DISTRIBUTION = Round_Robin
			) AS 
		select d.date as Effective_Date,
		Currency,
		1/SPOT_RATE as FX_Rate
		from EDW_Common.V_Fact_Eagle_Currency_FX_Rate R
		Join EDW_Common.Dim_Currency C on R.Dim_From_currency_Key = C.Dim_Currency_Key and R.Is_Src_Deleted = 0 and C.Record_Is_current_Flag = 1
		join edw_common.dim_date d on d.dim_date_key = r.dim_date_key
		 where currency in (
		select distinct currency
		from PSA.V_Manual_Strategic_Hedge_Ratio
		where @effective_date between start_date and end_date) 
		and d.date = @lastQuarterEndBD

		--Risk Manager---------------
		IF OBJECT_ID('tempdb..#temp_InfraPool_RiskRate') IS NOT NULL
		BEGIN
			DROP TABLE #temp_InfraPool_RiskRate
		END

		CREATE TABLE #temp_InfraPool_RiskRate
			WITH
			(
					DISTRIBUTION = Round_Robin
			) AS 
		select AnalysisDate as Effective_Date,currency,sum(PV) as PV
		from [EDW_Mart].[Risk_Manager_FI_Analytics_Attribute_Valuation_Report]
		where PortfolioParameter='GVCC0001'
		and client ='IMCO'
		and level=2
		and IMCO_PortfolioID <>'*Unspecified'
		and analysisdate = @lastQuarterEndBD
		and Currency in ----Trade Currency listed in Strategic Hedge Ratio table
		(select distinct currency
		from PSA.V_Manual_Strategic_Hedge_Ratio
		where @effective_date between start_date and end_date)
		group by AnalysisDate,currency


		IF OBJECT_ID('tempdb..#temp_InfraPool_FX_NumOfUnits') IS NOT NULL
		BEGIN
			DROP TABLE #temp_InfraPool_FX_NumOfUnits
		END
		---positions----
		CREATE TABLE #temp_InfraPool_FX_NumOfUnits
			WITH
			(
					DISTRIBUTION = Round_Robin
			) AS 
		select Effective_Date,Client_Id,Strategy_Id,Portfolio_Id,Portfolio_Name,Client_No_of_Units from 
(
	select Effective_Date,Client_Id,Strategy_Id,Portfolio_Id,Portfolio_Name, interface_Instance, sum(client_no_of_units) as Client_No_of_Units,
	rank() over (order by interface_instance desc) as Rank -- show 285 (month end) data when possible
	from (
			Select distinct d.date as Effective_Date,Folio.Portfolio_Id,S.Strategy_Id, Folio.PortFolio_Name, 
			coalesce(cc.Client_Id, c.Client_Id) Client_Id, P.SHARE_PAR_VALUE as client_no_of_units, interface_Instance
			from EDW_Common.[V_Fact_Eagle_Position] P
			Join edw_common.Bridge_Portfolio_Mapping M 
				on P.Dim_Date_Key = M.Dim_Date_Key and P.Dim_Portfolio_Key = M.Dim_Portfolio_Key 
			Join EDW_Common.Dim_Client C on M.Dim_Client_Key = C.Dim_Client_Key
			Join EDW_Common.Dim_Portfolio Folio on Folio.Dim_Portfolio_Key = P.Dim_Portfolio_Key
			Join EDW_Common.Dim_Strategy S on M.Dim_Strategy_Key = S.Dim_Strategy_Key
			Join EDW_Common.Dim_Security Sec on p.Dim_Security_Key = Sec.Dim_Security_Key
			Join edw_common.dim_eagle_interface I on I.Dim_Eagle_Interface_Key = P.Dim_Eagle_Interface_Key and I.interface_Instance in ('283', '285')
			Left Join (
								Select Distinct Client_Id, Parent_Client_Id
								From EDW_Common.Dim_Client
								where Record_Is_Current_Flag = 1
								and Parent_Client_Id is not null 
						) cc on C.Client_Id = cc.Parent_Client_Id 
			join edw_common.dim_date d on d.dim_date_key = p.dim_date_key
			where d.date = @lastQuarterEndBD
			and s.strategy_id = 'Global Infrastructure'
			and sec.security_type = 'MF'
			and folio.portfolio_type = 'PORT'
			and m.relation_type = 'Manual_Mapping'
			and Portfolio_Id != 'IMAP920' --remove extra OPB portfolio for now
					) A
			Group By Effective_Date,Client_Id,Strategy_Id,Portfolio_Id,PortFolio_Name,interface_Instance
	) ranked_table
where rank = 1

		union

		select d.date as Effective_Date,
			coalesce(cc.Client_Id, c.Client_Id) Client_Id,
			s.Strategy_Id,
			P.Portfolio_Id,
			P.portfolio_name,
			sum(POS.shares_par_value) as Client_No_of_Units
		from EDW_Common.V_Fact_StateStreet_Account_Position POS
		Join EDW_Common.Bridge_Portfolio_Mapping bpm on POS.Dim_Date_Key = bpm.Dim_Date_Key and POS.Dim_Portfolio_Key = bpm.Dim_Portfolio_Key and bpm.Is_Src_Deleted = 0
		Join EDW_Common.Dim_Portfolio P on bpm.Dim_Portfolio_Key = P.Dim_Portfolio_Key
		Join EDW_Common.Dim_Client C on bpm.Dim_Client_Key = C.Dim_Client_Key
		Left Join (
							Select Distinct Client_Id, Parent_Client_Id
							From EDW_Common.Dim_Client
							where Record_Is_Current_Flag = 1
							and Parent_Client_Id is not null 
					) cc on c.Client_Id = cc.Parent_Client_Id
		Join EDW_Common.Dim_Strategy s on bpm.Dim_Strategy_Key = s.Dim_Strategy_Key
		Join EDW_Common.Dim_Security Sec on pos.Dim_Security_Key = Sec.Dim_Security_Key and Security Like '%IMCO INFRA LP CLASS%'
		join edw_common.dim_date d on d.dim_date_key = pos.dim_date_key
		where d.date = @lastQuarterEndBD
		and s.strategy_id = 'Global Infrastructure'
		Group By d.date,
			coalesce(cc.Client_Id, c.Client_Id),
			s.Strategy_Id,
			P.Portfolio_Id,
			P.portfolio_name 

		IF OBJECT_ID('tempdb..#temp_InfraPool_FX_TotalUnits') IS NOT NULL
		BEGIN
			DROP TABLE #temp_InfraPool_FX_TotalUnits
		END

		CREATE TABLE #temp_InfraPool_FX_TotalUnits
			WITH
			(
					DISTRIBUTION = Round_Robin
			) AS 
		select 
		Effective_Date, sum(Client_No_of_Units) as TotalUnits
		from #temp_InfraPool_FX_NumOfUnits
		group by Effective_Date

		IF OBJECT_ID('tempdb..#temp_InfraPool_FX_FXPosition') IS NOT NULL
		BEGIN
			DROP TABLE #temp_InfraPool_FX_FXPosition
		END

		CREATE TABLE #temp_InfraPool_FX_FXPosition
		WITH
		(
				DISTRIBUTION = Round_Robin
		) AS 
		select pos.Effective_Date, s.strategy_id as IPS_Strategy, c.client_id as Client_Id, p.portfolio_id as Portfolio_Id, pos.custody_code, pos.Traded_Currency, pos.Value_Date, sum(cast(pos.Local_Quantity as numeric(15,2)) ) as Local_Net_FX_Position
		from [EDW_Raw].[Mesirow_IMCO_Daily_Open_Position_Report_Positions] pos
			inner join [EDW_Common].[Dim_Date] dd on dd.Date = pos.Effective_Date 
			inner join [PSA].[V_Eagle_Entity_Xreference] r on r.XREF_ACCOUNT_ID=pos.custody_code
			inner join edw_common.dim_portfolio p on p.portfolio_id = r.entity_id
			inner join edw_common.bridge_portfolio_mapping m on m.dim_portfolio_key = p.dim_portfolio_key and m.dim_date_key = dd.Dim_Date_Key and m.is_src_deleted = 0
			inner join edw_common.dim_portfolio pp on pp.dim_portfolio_key = m.parent_dim_portfolio_key
			inner join edw_common.dim_strategy s on s.dim_strategy_key = m.dim_strategy_key
			inner join edw_common.dim_client c on c.dim_client_key = m.dim_client_key
		where pos.Effective_date=@effective_date	
			and pos.Group_Main='INFRA'
			and pos.entity_name like '%Pool%'
			and s.strategy_id = 'Global Infrastructure'
		group by pos.Effective_Date, s.strategy_id, c.client_id, p.portfolio_id, pos.custody_code, pos.Traded_Currency, pos.Value_Date

		--delete from EDW_Bus.Aggr_FX_Infra_Pool_FX_Exposure 
		--where effective_date = @effective_date

		insert into EDW_Bus.Aggr_FX_Infra_Pool_FX_Exposure 
		select *,
		case 
			when Exposure_and_Net_Position > 0 then
				'Under Hedged'
			when Exposure_and_Net_Position < 0 then
				'Over Hedged'
			when Exposure_and_Net_Position = 0 then
				'Fully Hedged'
			else
				null
		end as Hedge_Status,
		getdate() as Load_DTS,
		@ETL_Load_Key as ETL_Load_Key
		from 
		(
		select p.Effective_Date, n1.Effective_Date as Analysis_Date, p.Custody_Code, p.Traded_Currency as Trade_Currency, f.FX_Rate,
		p.Client_Id, p.IPS_Strategy, p.Portfolio_Id, n1.Portfolio_Name as Entity_Name, n1.Client_No_Of_Units, n2.TotalUnits as Total_No_Of_Units,
		Client_No_of_Units/TotalUnits as Client_Allocation, h.Strategic_Hedge_Ratio, p.Value_Date as FX_Forward_Value_Date,
		p.Local_Net_FX_Position, r.PV as Underlying_MV_By_Currency, r.PV / f.FX_Rate as Local_Exposure_By_Currency,
		 r.PV / f.FX_Rate * h.Strategic_Hedge_Ratio * Client_No_of_Units/TotalUnits as Underlying_Hedgeable_Exposure,
		 p.Local_Net_FX_Position + (r.PV / f.FX_Rate * h.Strategic_Hedge_Ratio * Client_No_of_Units/TotalUnits) as Exposure_and_Net_Position
		from #temp_InfraPool_FX_NumOfUnits n1
			inner join #temp_InfraPool_FX_TotalUnits n2 on n1.effective_date = n2.effective_date
			inner join #temp_InfraPool_FX_FXPosition p on 
				p.ips_strategy = n1.strategy_id and p.client_id = n1.client_id
			inner join #temp_InfraPool_FX_FXRate f on  
			p.traded_currency = f.currency
			inner join #temp_InfraPool_RiskRate r on r.currency = p.traded_currency
			inner join psa.v_manual_strategic_hedge_ratio h on h.currency = p.traded_currency
		) tmp

		Select @rowsInserted = Count(*) 
		From EDW_BUS.Aggr_TPM_Account_Level_Holdings
		Where Last_Update_DTS = @today and Is_Src_Deleted = 0

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.FX_Aggr_Infra_Pool_Hedge_FX_Exposure', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_BUS.FX_Aggr_Infra_Pool_Hedge_FX_Exposure', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END