﻿CREATE PROC [DataWarehouse_Staging].[Util_Set_Partition_Query] @PartitionColumn [varchar](255),@SourceQuery [varchar](8000) AS
BEGIN 
	
	Declare @fromPosition int
	Declare @sqlFromWhere varchar(4000)
	Declare @sql varchar(8000)

	-- get from index number
	Select @fromPosition = charindex('from', lower(@SourceQuery))

	-- remove 
	Select @sqlFromWhere = substring(@SourceQuery, @fromPosition, len(@SourceQuery) - @fromPosition + 1)
	
	Select @sql = 'Select min(' + @PartitionColumn + ') as MinNumber, max(' + @PartitionColumn + ') as MaxNumber ' + @sqlFromWhere

	Select @sql as Partition_Query

END

