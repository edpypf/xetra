﻿CREATE PROC [DataWarehouse_Staging].[Cleanup_DV_Temp_Tables] @Source_System [Varchar](40) AS
BEGIN

	BEGIN TRY

		Declare @query             AS NVARCHAR(MAX)
		Declare @table_name        As Varchar(128)
		Declare @i                 INT = 1
		Declare @nbr_statements    INT
		
		-- Synapse doesn't support cursors, so we need to create a tempoary table to add a sequence number so we can loop through the list using a while loop
		CREATE TABLE #tbl
		WITH
		( DISTRIBUTION = ROUND_ROBIN
		)
		AS
		SELECT ROW_NUMBER() OVER(ORDER BY (SELECT NULL))                 AS Sequence
             , Proc_Database + '_' + Proc_Schema + '.' + Affected_Table  AS Table_Name
			  FROM [DataWarehouse_Staging].[Ref_DVBUS_Prep_Procedures]
			 WHERE Source_System     = @Source_System
			   And Procedure_Purpose = 'Create Temp Table';

		-- Figure out how many tables we are dropping
        Set @nbr_statements = (SELECT COUNT(*) FROM #tbl)

		-- Loop through all tables, and drop them if they exist
		WHILE   @i <= @nbr_statements
		BEGIN
		    Set @table_name = (Select Table_Name From #tbl Where Sequence = @i);
			Set @query = 'IF OBJECT_ID(''' + @table_name + ''') IS NOT NULL BEGIN DROP TABLE ' + @table_name + ' END;' 
			EXEC(@query)

			Set @i += 1;
		END
		
		Drop Table #tbl
		
	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  NVARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT;  

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		THROW @ErrorSeverity,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH

end