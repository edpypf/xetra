﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_Limit_Sipp] (
    [Policy_Name]     VARCHAR (50) NOT NULL,
    [Limit_Name]      VARCHAR (50) NOT NULL,
    [Client]          VARCHAR (50) NOT NULL,
    [Policy_Strategy] VARCHAR (50) NOT NULL,
    [IMCO_Strategy]   VARCHAR (50) NOT NULL,
    [Limit_Type]      VARCHAR (50) NOT NULL,
    [Limit_Unit]      VARCHAR (50) NOT NULL,
    [Min_Value]       FLOAT (53)   NULL,
    [Target_Value]    FLOAT (53)   NULL,
    [Max_Value]       FLOAT (53)   NULL,
    [Begin_Date]      DATETIME     NULL,
    [End_Date]        DATETIME     NULL,
    [Updated_Date]    DATETIME     NULL,
    [Updated_By]      VARCHAR (50) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

