﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_Report_TPA_Mapping] (
    [Entity]             VARCHAR (255)   NOT NULL,
    [Decomposition_Name] VARCHAR (500)   NOT NULL,
    [Year]               INT             NOT NULL,
    [Month]              INT             NOT NULL,
    [Value]              NUMERIC (28, 8) NULL,
    [Active]             VARCHAR (2)     NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

