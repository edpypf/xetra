﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_Report_Footnote_Mapping] (
    [Report_Number]    INT           NOT NULL,
    [Report_Name]      VARCHAR (255) NOT NULL,
    [Client_Id]        VARCHAR (255) NOT NULL,
    [Start_Date]       DATE          NOT NULL,
    [End_Date]         DATE          NULL,
    [Mapping_Category] VARCHAR (255) NOT NULL,
    [Mapping_Item]     VARCHAR (255) NOT NULL,
    [Footnote_Number]  VARCHAR (255) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

