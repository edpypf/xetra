CREATE TABLE [DataWarehouse_Staging].[PA_USER_SIPP_Asset_Mix] (
	[StartDate]                DATE          NULL,
	[EndDate]                  DATE          NULL,
	[Client]                   VARCHAR (50)  NULL,
	[Asset_Class]              VARCHAR (150) NULL,
	[Target_Value]             FLOAT (53)    NULL,
	[Min_Value]                FLOAT (53)    NULL,
	[Max_Value]                FLOAT (53)    NULL,
	[Sort]                     INT           NULL,
	[Asset_Class_Group_Order]  INT           NULL,
	[Asset_Within_Group]       INT           NULL,
	[Asset_Within_Group_Order] INT           NULL,
    [HASH]                     VARCHAR(5000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
