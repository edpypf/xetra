﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Official_IPS_Strategies] (
    [IPS_Strategy]                    VARCHAR (100) NOT NULL,
    [IPS_Short_Name]                  VARCHAR (50)  NULL,
    [Strategy_Group]                  VARCHAR (100) NULL,
    [IPS_Strategy_Order]              INT           NULL,
    [Strategy_Group_Order]            INT           NULL,
    [IPS_Strategy_within_Group_Order] INT           NULL,
    [Start_Date]                      DATE          NULL,
    [End_Date]                        DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);









