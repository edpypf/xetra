﻿CREATE TABLE [DataWarehouse_Staging].[Manual_RM_Override_Tags] (
    [Override_Rule_Type] VARCHAR (255) NULL,
    [Portfolio_ID]       VARCHAR (255) NULL,
    [AssetID_Type]       VARCHAR (255) NULL,
    [AssetID_Value]      VARCHAR (255) NULL,
    [Tag_Name]           VARCHAR (255) NULL,
    [Tag_Value]          VARCHAR (255) NULL,
    [Custodian_Type]     VARCHAR (255) NULL,
    [Start_Date]         DATE          NULL,
    [End_Date]           DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

