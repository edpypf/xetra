﻿CREATE TABLE [DataWarehouse_Staging].[Manual_RM_Position_Remediation] (
    [PortfolioID]             VARCHAR (100) NULL,
    [CriteriaID_Type]         VARCHAR (100) NULL,
    [CriteriaID_Field]        VARCHAR (100) NULL,
    [CriteriaID_Field_Value]  VARCHAR (500) NULL,
    [TargetID_Type]           VARCHAR (100) NULL,
    [TargetID_Field]          VARCHAR (100) NULL,
    [TargetID_Field_Value]    VARCHAR (100) NULL,
    [Update_Type]             VARCHAR (100) NULL,
    [Custodian_Type]          VARCHAR (100) NULL,
    [Custodian_FileType]      VARCHAR (100) NULL,
    [Remediation_Frequency]   VARCHAR (100) NULL,
    [Start_Date]              DATE          NULL,
    [End_Date]                DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

