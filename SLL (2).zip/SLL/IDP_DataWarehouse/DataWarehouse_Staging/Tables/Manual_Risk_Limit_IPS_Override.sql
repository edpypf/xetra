﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_Limit_IPS_Override] (
    [Client]          VARCHAR (50)  NOT NULL,
    [Analysis_Date]   DATE          NOT NULL,
    [Strategy]        VARCHAR (150) NOT NULL,
    [Check_Desc]      VARCHAR (500) NOT NULL,
    [Check_Value]     VARCHAR (150) NULL,
    [Check_Status]    VARCHAR (3)   NULL,
    [Reported_Status] VARCHAR (3)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

