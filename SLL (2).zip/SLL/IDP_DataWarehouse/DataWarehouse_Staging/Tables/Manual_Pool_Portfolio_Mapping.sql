﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Pool_Portfolio_Mapping] (
    [Portfolio_ID]      VARCHAR (255) NOT NULL,
    [Primary_Asset_Id]  VARCHAR (255) NOT NULL,
    [Pool_Portfolio_Id] VARCHAR (255) NOT NULL,
    [Start_Date]        DATE          NOT NULL,
    [End_Date]          DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

