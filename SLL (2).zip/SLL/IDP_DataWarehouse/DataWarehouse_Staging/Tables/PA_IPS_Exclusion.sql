CREATE TABLE [DataWarehouse_Staging].[PA_IPS_Exclusion] (
	[StartDate]      DATE          NULL,
	[EndDate]        DATE          NULL,
	[Strategy]       VARCHAR (150) NULL,
	[Exclusion_Type] VARCHAR (250) NULL,
	[Asset_ID]       VARCHAR (250) NULL,
	[Asset]          VARCHAR (250) NULL,
	[Note]           VARCHAR (500) NULL,
    [HASH]               VARCHAR(5000)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
