﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_Limit_Sipp_Override] (
    [Client]        VARCHAR (50)  NOT NULL,
    [Analysis_Date] DATE          NOT NULL,
    [Asset_Class]   VARCHAR (150) NOT NULL,
    [Sort]          INT           NULL,
    [AM_Weight]     FLOAT (53)    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

