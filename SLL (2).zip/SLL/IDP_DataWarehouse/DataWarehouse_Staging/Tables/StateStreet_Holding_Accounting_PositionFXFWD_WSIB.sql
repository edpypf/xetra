﻿CREATE TABLE [DataWarehouse_Staging].[StateStreet_Holding_Accounting_PositionFXFWD_WSIB] (
    [SCR_LOAD_DTS]                DATETIME      NULL,
    [Effective_Date]              DATE          NOT NULL,
    [Fund]                        VARCHAR (500) NULL,
    [Fund_Name]                   VARCHAR (500) NULL,
    [Currency_Bought]             VARCHAR (500) NULL,
    [Currency_Sold]               VARCHAR (500) NULL,
    [Contractual_Settlement_Date] VARCHAR (500) NULL,
    [Unrealized_Gain_Loss]        VARCHAR (500) NULL,
    [Broker_Name]                 VARCHAR (500) NULL,
    [Trade_ID]                    VARCHAR (500) NULL,
    [Trade_Date]                  VARCHAR (500) NULL,
    [Buy_Trade_Exchange_Rate]     VARCHAR (500) NULL,
    [Amount_Bought]               VARCHAR (500) NULL,
    [Amount_Sold]                 VARCHAR (500) NULL,
    [FX_Buy_Sell_Ind]             VARCHAR (500) NULL,
    [Buy_Setup_Amount]            VARCHAR (500) NULL,
    [Sell_Setup_Amount]           VARCHAR (500) NULL,
    [Base_Current_Value]          VARCHAR (500) NULL,
    [Exchange_Rate]               VARCHAR (500) NULL,
    [Exchange_Rate_Source]        VARCHAR (500) NULL,
    [Sell_Trade_Exchange_Rate]    VARCHAR (500) NULL,
    [FX_Type]                     VARCHAR (500) NULL,
    [Forward_Date]                VARCHAR (500) NULL,
    [Transaction_Type]            VARCHAR (500) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

