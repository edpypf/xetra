CREATE TABLE [DataWarehouse_Staging].[PA_IMCO_RATING_MAPPING] (
	[Start_Date]        DATE          NULL,
	[End_Date]          DATE          NULL,
	[Rating]            NVARCHAR (15) NULL,
	[IMCO_Rating]       NVARCHAR (15) NULL,
	[IMCO_Rating_Group] NVARCHAR (15) NULL,
	[IMCO_Sort]         FLOAT (53)    NULL,
	[Rating_Term]       NVARCHAR (15) NULL,
    [HASH]               VARCHAR(5000)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
