﻿CREATE TABLE [DataWarehouse_Staging].[Eagle_Performance_Holding_Keys] (
    [Entity_ID]              CHAR (8)      NOT NULL,
    [DICTIONARY_ID]          NUMERIC (38)  NOT NULL,
    [BEGIN_EFFECTIVE_DATE]   DATETIME2 (7) NOT NULL,
    [END_EFFECTIVE_DATE]     DATETIME2 (7) NOT NULL,
    [Security_Alias]         NUMERIC (18)  NOT NULL,
    [PERF_ROLLUP_RETURNS_ID] NUMERIC (18)  NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);




