CREATE TABLE [DataWarehouse_Staging].[PA_CON_Counterparty] (
	[Analysis_Date] DATETIME       NULL,
	[Client]        NVARCHAR (255) NULL,
	[Counterparty]  NVARCHAR (255) NULL,
	[Exposure]      FLOAT (53)     NULL,
	[PFE]           FLOAT (53)     NULL,
    [Load_DTS_SQL]  DATETIME       NULL,
    [HASH]          VARCHAR (5000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
