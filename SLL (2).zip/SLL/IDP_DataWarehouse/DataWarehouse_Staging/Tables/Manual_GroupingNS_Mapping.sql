﻿CREATE TABLE [DataWarehouse_Staging].[Manual_GroupingNS_Mapping] (
    [Account_Number]      VARCHAR (50)  NULL,
    [Type]                VARCHAR (50)  NULL,
    [Valuation_Entity]    VARCHAR (150) NULL,
    [Counterparty_Entity] VARCHAR (150) NULL,
    [Grouping]            VARCHAR (150) NULL,
    [START_DT]            DATE          NULL,
    [END_DT]              DATE          NULL,
    [LOADED_ON]           DATETIME      NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

