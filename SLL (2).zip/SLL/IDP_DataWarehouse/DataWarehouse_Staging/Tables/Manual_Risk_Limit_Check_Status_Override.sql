﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_Limit_Check_Status_Override] (
    [Limit_Type]      VARCHAR (255)    NOT NULL,
    [Analysis_Date]   DATE             NOT NULL,
    [Client]          VARCHAR (255)    NOT NULL,
    [Strategy]        VARCHAR (255)    NOT NULL,
    [Check_Desc]      VARCHAR (255)    NOT NULL,
    [Check_Value]     VARCHAR (150)     NULL,
    [Check_Value_Txt] VARCHAR (255)    NULL,
    [Reported_Status] VARCHAR (3)      NULL,
	[Value_w_Com]     varchar (255) NULL,
	[Check_Status]    varchar (3) NULL,
    [Updated_Time]    DATETIME         NULL,
    [Updated_By]      VARCHAR (50)     NULL,
    [Date_Created]    DATETIME2 (7)    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

