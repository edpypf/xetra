CREATE TABLE [DataWarehouse_Staging].[PA_Asset_Mix] (
	[Date_]              DATE          NULL,
	[Client]             VARCHAR (15)  NULL,
	[Strategy]           VARCHAR (150) NULL,
	[MV]                 FLOAT (53)    NULL,
	[WT]                 FLOAT (53)    NULL,
	[SAA_Policy]         FLOAT (53)    NULL,
	[SAA_Policy_Adj]     FLOAT (53)    NULL,
	[Rel_Wt_Adj]         FLOAT (53)    NULL,
	[AAA_Overlay]        FLOAT (53)    NULL,
	[AM_w_AAA_MV]        FLOAT (53)    NULL,
	[AM_w_AAA_Pct]       FLOAT (53)    NULL,
	[TAA_Rel_Wt_adj_SAA] FLOAT (53)    NULL,
    [HASH]               VARCHAR(5000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
