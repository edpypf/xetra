﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Private_Investment_Target_Allocation] (
    [Client]            VARCHAR (255)   NOT NULL,
    [Start_Date]        DATE            NOT NULL,
    [End_Date]          DATE            NOT NULL,
    [Target_Allocation] NUMERIC (10, 4) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

