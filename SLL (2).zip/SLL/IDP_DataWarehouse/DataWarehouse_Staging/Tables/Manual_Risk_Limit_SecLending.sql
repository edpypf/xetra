﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_Limit_SecLending] (
    [Client]       VARCHAR (50)  NULL,
    [Portfolio]    VARCHAR (50)  NULL,
    [Counterparty] VARCHAR (50)  NULL,
    [Restriction]  VARCHAR (150) NULL,
    [Limit]        VARCHAR (50)  NULL,
    [Begin_Date]   DATETIME      NULL,
    [End_Date]     DATETIME      NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

