CREATE TABLE [DataWarehouse_Staging].[PA_USER_Manager_Unfunded_Commitment] (
	[StartDate]                  DATE           NULL,
	[EndDate]                    DATE           NULL,
	[Security_ID]                NVARCHAR (255) NULL,
	[Client]                     NVARCHAR (255) NULL,
	[Portfolio]                  VARCHAR (255)  NULL,
	[Fund ]                      NVARCHAR (255) NULL,
	[General_Partner]            NVARCHAR (255) NULL,
	[Currency]                   NVARCHAR (255) NULL,
	[Commited_Capital_Local]     FLOAT (53)     NULL,
	[Commited_Capital_Base]      FLOAT (53)     NULL,
	[Invested_Capital_Local]     FLOAT (53)     NULL,
	[Invested_Capital_Base]      FLOAT (53)     NULL,
	[Unfunded_Commitment_Local]  FLOAT (53)     NULL,
	[Unfunded_Commitment_Base]   FLOAT (53)     NULL,
	[Pct_Funded]                 FLOAT (53)     NULL,
	[Investment_Period_End_Date] DATE           NULL,
	[Fund_End_Date]              DATE           NULL,
	[Private_Mkt_Partner]        NVARCHAR (255) NULL,
	[Comment]                    NVARCHAR (255) NULL,
	[Client2]                    VARCHAR (255)  NULL,
    [HASH]               VARCHAR(5000)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
