CREATE TABLE [DataWarehouse_Staging].[PA_USER_Bank_and_GFI_Mapping] (
	[StartDate]                                 DATE           NULL,
	[EndDate]                                   DATE           NULL,
	[Category]                                  NVARCHAR (150) NULL,
	[Bank_Name]                                 NVARCHAR (150) NULL,
	[Risk_ID]                                   NVARCHAR (50)  NULL,
	[Ticker]                                    VARCHAR (50)   NULL,
	[DBRS_Rating]                               VARCHAR (50)   NULL,
	[Moody_Rating]                              VARCHAR (50)   NULL,
	[LT_Rating]                                 FLOAT (53)     NULL,
	[Moody_Long_Term_Rating]                    VARCHAR (50)   NULL,
	[DBRS_Long_Term_Issuer_Rating]              VARCHAR (50)   NULL,
	[SP_LT_Local_Currency_Issuer_Credit_Rating] VARCHAR (50)   NULL,
    [HASH]                                      VARCHAR(5000)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
