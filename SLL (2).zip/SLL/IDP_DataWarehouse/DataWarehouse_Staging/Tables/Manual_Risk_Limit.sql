﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_Limit] (
    [Limit_ID]     INT           NULL,
    [Policy_Name]  VARCHAR (50)  NULL,
    [Limit_Name]   VARCHAR (250) NULL,
    [Strategy]     VARCHAR (50)  NULL,
    [Limit_Type]   VARCHAR (50)  NULL,
    [Limit_Unit]   VARCHAR (50)  NULL,
    [Min_Value]    FLOAT (53)    NULL,
    [Target_Value] FLOAT (53)    NULL,
    [Max_Value]    FLOAT (53)    NULL,
    [Rating_Min]   VARCHAR (50)  NULL,
    [Begin_Date]   VARCHAR (50)  NULL,
    [End_Date]     VARCHAR (50)  NULL,
    [Updated_Time] DATETIME      NULL,
    [Updated_By]   VARCHAR (50)  NULL,
    [HASH]         VARCHAR(5000)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
GO
ALTER TABLE [DataWarehouse_Staging].[Manual_Risk_Limit] ADD  DEFAULT ('n/') FOR [Limit_Type]
GO
ALTER TABLE [DataWarehouse_Staging].[Manual_Risk_Limit] ADD  DEFAULT ('n/') FOR [Limit_Unit]
GO