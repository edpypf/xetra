﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Collateral_Haircut] (
    [Agreement_Type]  VARCHAR (4) NULL,
    [Counterparty]    VARCHAR (3) NULL,
    [Collateral_Type] VARCHAR (8) NOT NULL,
    [Term]            VARCHAR (5) NOT NULL,
    [Credit_Rating]   VARCHAR (4) NOT NULL,
    [Haircut]         NUMERIC (5) NOT NULL,
    [Updated_Date]    DATETIME    NULL,
    [StartDate]       DATETIME    NULL,
    [EndDate]         DATETIME    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

