﻿CREATE TABLE [DataWarehouse_Staging].[Eagle_ENTITY_DETAIL] (
    [ENTITY_DETAIL_ID]       CHAR (8)         NULL,
    [ENTITY_ID]              CHAR (8)         NULL,
    [ENTITY_TYPE]            CHAR (4)         NULL,
    [WEIGHT]                 NUMERIC (28, 12) NULL,
    [ENTITY_SUBTYPE]         CHAR (15)        NULL,
    [SRC_INTFC_INST]         NUMERIC (18)     NULL,
    [UPDATE_USER]            CHAR (30)        NULL,
    [UPDATE_DATE]            DATETIME2 (7)    NULL,
    [USER_IND1]              VARCHAR (25)     NULL,
    [USER_IND2]              VARCHAR (25)     NULL,
    [USER_IND3]              VARCHAR (25)     NULL,
    [LIST_ORDER]             NUMERIC (18)     NULL,
    [INDEX_FROM_DATE]        DATE             NULL,
    [INDEX_TO_DATE]          DATE             NULL,
    [PROCESS_ACROSS_CHANGES] VARCHAR (2)      NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);




