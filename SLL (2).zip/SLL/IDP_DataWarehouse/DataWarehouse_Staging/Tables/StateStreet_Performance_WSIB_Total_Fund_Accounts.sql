﻿CREATE TABLE [DataWarehouse_Staging].[StateStreet_Performance_WSIB_Total_Fund_Accounts] (
    [SCR_LOAD_DTS]        DATETIME      NULL,
    [Fund_ID]             VARCHAR (500) NULL,
    [Fund_Long_Name]      VARCHAR (500) NULL,
    [Ending_Market_Value] VARCHAR (500) NULL,
    [Effective_Date]      DATETIME      NOT NULL,
    [Account_Type]        VARCHAR (500) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

