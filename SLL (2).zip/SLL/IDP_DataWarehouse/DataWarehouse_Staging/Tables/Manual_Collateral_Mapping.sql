﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Collateral_Mapping] (
    [Type]        VARCHAR (50)  NULL,
    [Agreement]   VARCHAR (50)  NULL,
    [Netting_Set] VARCHAR (150) NULL,
    [START_DT]    DATE          NULL,
    [END_DT]      DATE          NULL,
    [LOADED_ON]   DATETIME      NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

