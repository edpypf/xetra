CREATE TABLE [DataWarehouse_Staging].[PA_IPS_Exception] (
	[Begin_Date]  DATE          NULL,
	[End_Date]    DATE          NULL,
	[Strategy]    VARCHAR (150) NULL,
	[Client]      VARCHAR (50)  NULL,
	[Report]      VARCHAR (50)  NULL,
	[Restriction] VARCHAR (150) NULL,
	[Exception]   VARCHAR (150) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
