﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Benchmark_Mapping] (
    [Client_ID]             VARCHAR (50)  NOT NULL,
    [Blend_Type]            VARCHAR (50)  NOT NULL,
    [IPS_Strategy]          VARCHAR (255) NOT NULL,
    [IMCO_Benchmark]        VARCHAR (255) NOT NULL,
    [Benchmark_Source_Name] VARCHAR (255) NOT NULL,
    [Benchmark_Source_ID]   VARCHAR (50)  NULL,
    [Start_Date]            DATE          NOT NULL,
    [End_Date]              DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

