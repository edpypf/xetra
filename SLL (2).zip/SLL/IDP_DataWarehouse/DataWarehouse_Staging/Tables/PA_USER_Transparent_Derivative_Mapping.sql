CREATE TABLE [DataWarehouse_Staging].[PA_USER_Transparent_Derivative_Mapping] (
	[StartDate]   DATE           NULL,
	[EndDate]     DATE           NULL,
	[Asset_Id]    NVARCHAR (255) NULL,
	[Asset_Name]  NVARCHAR (255) NULL,
	[Barraid]     NVARCHAR (255) NULL,
	[Inst_Type]   NVARCHAR (255) NULL,
	[Transparent] NVARCHAR (255) NULL,
    [HASH]        VARCHAR(5000)  NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
