﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_Config_Report_Measure_Mapping] (
    [Report_Number]       INT           NOT NULL,
    [Report_Name]         VARCHAR (255) NOT NULL,
    [Measure_Name]        VARCHAR (255) NOT NULL,
    [Report_Measure_Name] VARCHAR (255) NOT NULL,
    [Measure_Order]       INT           NOT NULL,
    [Value_Format]        VARCHAR (255) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

