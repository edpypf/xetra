﻿CREATE TABLE [DataWarehouse_Staging].[Manual_User_Permission] (
    [Report_Group] VARCHAR (500) NULL,
    [User_Role]    VARCHAR (500) NULL,
    [User_Email]   VARCHAR (500) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

