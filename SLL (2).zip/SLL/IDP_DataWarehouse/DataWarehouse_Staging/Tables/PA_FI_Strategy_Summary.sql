﻿CREATE TABLE [DataWarehouse_Staging].[PA_FI_Strategy_Summary] (
    [Date_]              DATE          NULL,
    [PortGroup]          VARCHAR (150) NULL,
    [Portcode]           VARCHAR (150) NULL,
    [PortName]           VARCHAR (150) NULL,
    [PortType]           CHAR (1)      NULL,
    [portsort]           INT           NULL,
    [client]             VARCHAR (50)  NULL,
    [Analysis_Date]      DATE          NULL,
    [Effective_Duration] FLOAT (53)    NULL,
    [DV01]               FLOAT (53)    NULL,
    [MV]                 FLOAT (53)    NULL,
    [TE]                 FLOAT (53)    NULL,
    [Port_Risk]          FLOAT (53)    NULL,
    [BM_Risk]            FLOAT (53)    NULL,
    [DV01_Adj]           FLOAT (53)    NULL,
    [Duration_BM]        FLOAT (53)    NULL,
    [DV01_BM]            FLOAT (53)    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

