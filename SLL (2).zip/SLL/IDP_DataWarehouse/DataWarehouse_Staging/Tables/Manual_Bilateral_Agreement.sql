﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Bilateral_Agreement] (
    [Bilateral_Agreement_Name]             VARCHAR (150) NULL,
    [Valuation_Entity]                     VARCHAR (150) NULL,
    [Counterparty_Entity]                  VARCHAR (150) NULL,
    [Netting_Set]                          VARCHAR (300) NULL,
    [Netting_Options]                      VARCHAR (50)  NULL,
    [Collateral_Arrangement]               VARCHAR (50)  NULL,
    [Valuation_Entity_Threshold_Amount]    FLOAT (53)    NULL,
    [Valuation_Entity_Currency]            VARCHAR (50)  NULL,
    [Counterparty_Entity_Threshold_Amount] FLOAT (53)    NULL,
    [Counterparty_Entity_Currency]         VARCHAR (50)  NULL,
    [Margin_Freq]                          VARCHAR (50)  NULL,
    [Settlement_Period]                    INT           NULL,
    [Valuation_Entity_Closeout_Period]     INT           NULL,
    [Counterparty_Entity_Closeout_Period]  INT           NULL,
    [START_DT]                             DATE          NULL,
    [END_DT]                               DATE          NULL,
    [LOADED_ON]                            DATETIME      NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

