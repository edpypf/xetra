﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Portfolio_Mapping] (
    [Portfolio_ID]                    VARCHAR (50)  NOT NULL,
    [Portfolio_Type]                  CHAR (10)     NULL,
    [Client_ID]                       CHAR (20)     NOT NULL,
    [IPS_Strategy]                    VARCHAR (100) NOT NULL,
    [Strategy_Inheritance_Ind]        CHAR (1)      NULL,
    [Parent_Portfolio_ID]             VARCHAR (50)  NULL,
    [Performance_Parent_Portfolio_ID] VARCHAR (50)  NULL,
    [Securitized_Parent_ID]           VARCHAR (50)  NULL,
    [Start_Date]                      DATE          NOT NULL,
    [End_Date]                        DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);








