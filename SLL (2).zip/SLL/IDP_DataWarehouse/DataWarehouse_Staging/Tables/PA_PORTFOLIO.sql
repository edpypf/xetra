CREATE TABLE [DataWarehouse_Staging].[PA_PORTFOLIO] (
	[Date_]                   DATE          NULL,
	[PortGroup]               VARCHAR (50)  NULL,
	[PortCode]                VARCHAR (50)  NULL,
	[PortName]                VARCHAR (50)  NULL,
	[PortType]                CHAR (1)      NULL,
	[PortSort]                NVARCHAR (10) NULL,
	[Client]                  VARCHAR (50)  NULL,
	[Internally_Managed_Fund] VARCHAR (150) NULL,
    [HASH]               VARCHAR(5000)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
