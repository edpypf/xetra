﻿CREATE TABLE [DataWarehouse_Staging].[Eagle_ENTITY_DETAIL_HISTORY]
(
	[ENTITY_DETAIL_ID] [char](8) NULL,
	[ENTITY_ID] [char](8) NULL,
	[ENTITY_TYPE] [char](4) NULL,
	[WEIGHT] [numeric](28, 12) NULL,
	[ENTITY_SUBTYPE] [char](15) NULL,
	[SRC_INTFC_INST] [numeric](18, 0) NULL,
	[EFFECTIVE_DATE] [varchar](50) NULL,
	[UPDATE_USER] [char](30) NULL,
	[UPDATE_DATE] [varchar](50) NULL,
	[USER_IND1] [varchar](25) NULL,
	[USER_IND2] [varchar](25) NULL,
	[USER_IND3] [varchar](25) NULL,
	[LIST_ORDER] [numeric](18, 0) NULL,
	[INDEX_FROM_DATE] [varchar](50) NULL,
	[INDEX_TO_DATE] [varchar](50) NULL,
	[PROCESS_ACROSS_CHANGES] [varchar](2) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO