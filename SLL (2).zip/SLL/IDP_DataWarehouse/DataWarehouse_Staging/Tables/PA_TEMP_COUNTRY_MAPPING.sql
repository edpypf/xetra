CREATE TABLE [DataWarehouse_Staging].[PA_TEMP_COUNTRY_MAPPING] (
	[StartDate]   DATE           NULL,
	[EndDate]     DATE           NULL,
	[Market]      NVARCHAR (255) NULL,
	[IMCO_Market] NVARCHAR (255) NULL,
	[Country2]    NVARCHAR (255) NULL,
	[Country3]    NVARCHAR (255) NULL,
	[CountryName] NVARCHAR (255) NULL,
	[F8]          NVARCHAR (255) NULL,
	[F9]          NVARCHAR (255) NULL,
    [HASH]        VARCHAR(5000)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
