﻿CREATE TABLE [DataWarehouse_Staging].[PA_Limit_IAP_Derivative_VaR] (
    [Analysis_Date]    DATE          NULL,
    [Client]           VARCHAR (50)  NULL,
    [Strategy]         VARCHAR (150) NULL,
    [Derivative_Group] VARCHAR (50)  NULL,
    [VaR]              FLOAT (53)    NULL,
    [Limit]            INT           NULL,
    [Status]           CHAR (1)      NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

