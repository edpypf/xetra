﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Strategic_Hedge_Ratio] (
    [IPS_Strategy]          VARCHAR (50)   NULL,
    [Currency]              VARCHAR (3)    NULL,
    [Strategic_Hedge_Ratio] NUMERIC (5, 2) NULL,
    [Start_Date]            DATE           NULL,
    [End_Date]              DATE           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

