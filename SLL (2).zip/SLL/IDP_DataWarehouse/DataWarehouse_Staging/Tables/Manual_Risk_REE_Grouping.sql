﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_REE_Grouping] (
    [IPS_Strategy_ID] VARCHAR (100) NULL,
    [Strategy_Group]  VARCHAR (40)  NULL,
    [REE_Quadrant]    VARCHAR (40)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

