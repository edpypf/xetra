CREATE TABLE [DataWarehouse_Staging].[PA_USER_Client] (
	[StartDate]     DATE          NULL,
	[EndDate]       DATE          NULL,
	[Client]        VARCHAR (50)  NULL,
	[Exposure_Port] VARCHAR (150) NULL,
	[Risk_Port]     VARCHAR (150) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
