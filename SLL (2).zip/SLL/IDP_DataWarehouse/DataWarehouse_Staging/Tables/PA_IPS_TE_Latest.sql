﻿CREATE TABLE [DataWarehouse_Staging].[PA_IPS_TE_Latest] (
	[Date]                        DATE          NULL,
	[Client]                      VARCHAR (200) NULL,
	[Strategy]                    VARCHAR (200) NULL,
	[Tracking_Error_decomp]       FLOAT (53)    NULL,
	[Date_Created]                VARCHAR (150) NULL,
    [HASH]                        VARCHAR(1500) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);