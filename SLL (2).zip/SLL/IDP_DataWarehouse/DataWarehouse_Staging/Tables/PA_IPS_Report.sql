CREATE TABLE [DataWarehouse_Staging].[PA_IPS_Report] (
	[Analysis_Date]   DATE          NULL,
	[Client]          VARCHAR (50)  NULL,
	[Strategy]        VARCHAR (150) NULL,
	[Port_Type]       VARCHAR (3)   NULL,
	[Check_Desc]      VARCHAR (150) NULL,
	[Check_Value]     FLOAT (53)    NULL,
	[Check_Value_Txt] VARCHAR (150) NULL,
	[BM_Value]        FLOAT (53)    NULL,
	[Check_Status]    VARCHAR (3)   NULL,
	[Reported_Status] VARCHAR (3)   NULL,
	[Report_Run]      DATETIME      NULL,
    [HASH]            VARCHAR(5000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
