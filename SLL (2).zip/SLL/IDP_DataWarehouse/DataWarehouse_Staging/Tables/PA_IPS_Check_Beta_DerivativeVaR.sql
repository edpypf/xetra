CREATE TABLE [DataWarehouse_Staging].[PA_IPS_Check_Beta_DerivativeVaR] (
	[Client]         NVARCHAR (255) NULL,
	[Portfolio]      NVARCHAR (255) NULL,
	[Port_Type]      NVARCHAR (255) NULL,
	[Model]          NVARCHAR (255) NULL,
	[Analysis_Date]  DATETIME       NULL,
	[Derivative_VaR] FLOAT (53)     NULL,
	[Relative_VaR]   FLOAT (53)     NULL,
	[Beta_SP500]     FLOAT (53)     NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
