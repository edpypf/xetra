﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Counterparty_Mapping] (
    [CLIENT]                   VARCHAR (50)  NULL,
    [INVESTMENT_TYPE]          VARCHAR (50)  NULL,
    [BROKER_CODE]              VARCHAR (50)  NULL,
    [COUNTERPARTY_NAME]        VARCHAR (150) NULL,
    [COUNTERPARTY_NAME_SOURCE] VARCHAR (150) NULL,
    [IMCO_COUNTERPARTY_NAME]   VARCHAR (150) NULL,
    [APPROVED_CPTY_FLAG]       VARCHAR (10)  NULL,
    [START_DT]                 DATE          NULL,
    [END_DT]                   DATE          NULL,
    [LOADED_ON]                DATETIME      NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

