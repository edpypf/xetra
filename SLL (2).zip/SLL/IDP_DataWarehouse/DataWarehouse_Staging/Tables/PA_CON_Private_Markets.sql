﻿CREATE TABLE [DataWarehouse_Staging].[PA_CON_Private_Markets] (
    [Analysis_Date]          DATE          NULL,
    [Client]                 VARCHAR (150) NULL,
    [Portfolio]              VARCHAR (150) NULL,
    [Level_1]                VARCHAR (150) NULL,
    [Level_2]                VARCHAR (150) NULL,
    [Manager]                VARCHAR (150) NULL,
    [Manager_Type]           VARCHAR (25)  NULL,
    [Private_Mkt_Asset_Type] VARCHAR (150) NULL,
    [Private_Mkt_Fund_Name]  VARCHAR (150) NULL,
    [Private_Mkt_Asset_Name] VARCHAR (150) NULL,
    [Native_Portfolio]       VARCHAR (150) NULL,
    [Asset_Name]             VARCHAR (500) NULL,
    [Inst_Type]              VARCHAR (150) NULL,
    [Asset_ID]               VARCHAR (100) NULL,
    [MV_M]                   FLOAT (53)    NULL,
    [Exp_M]                  FLOAT (53)    NULL,
    [Private_Mkt_Region]     VARCHAR (150) NULL,
    [Private_Mkt_Sector]     VARCHAR (150) NULL,
    [Currency]               VARCHAR (150) NULL,
    [Wt]                     FLOAT (53)    NULL,
    [Load_Date]              DATETIME      NULL,
    [Risk_Contribution]      FLOAT (53)    NULL,
    [FX_Hedge_Contribution]  FLOAT (53)    NULL,
    [Commitment]             FLOAT (53)    NULL,
    [Total_M]                FLOAT (53)    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

