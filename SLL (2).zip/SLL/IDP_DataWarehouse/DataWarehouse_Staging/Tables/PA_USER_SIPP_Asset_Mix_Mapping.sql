CREATE TABLE [DataWarehouse_Staging].[PA_USER_SIPP_Asset_Mix_Mapping] (
	[StartDate]   DATE          NULL,
	[EndDate]     DATE          NULL,
	[Client]      VARCHAR (50)  NULL,
	[Asset_Class] VARCHAR (150) NULL,
	[Strategy]    VARCHAR (150) NULL,
    [HASH]               VARCHAR(5000)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
