CREATE TABLE [DataWarehouse_Staging].[PA_TEMP_USER_BARRA_INSTRUMENT] (
	[StartDate]           DATE           NULL,
	[EndDate]             DATE           NULL,
	[INST_TYPE]           NVARCHAR (255) NULL,
	[Asset_Class]         NVARCHAR (255) NULL,
	[IPS_Instrument_Type] NVARCHAR (255) NULL,
	[Derivative]          NVARCHAR (255) NULL,
    [HASH]                VARCHAR(5000)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
