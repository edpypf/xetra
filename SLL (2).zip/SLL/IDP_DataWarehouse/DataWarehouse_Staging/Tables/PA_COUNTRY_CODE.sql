CREATE TABLE [DataWarehouse_Staging].[PA_COUNTRY_CODE] (
	[Date_]             DATE           NULL,
	[Country_of_Issuer] NVARCHAR (255) NULL,
	[COUNTRY_CODE]      NVARCHAR (255) NULL,
	[Currency_Code]     CHAR (3)       NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
