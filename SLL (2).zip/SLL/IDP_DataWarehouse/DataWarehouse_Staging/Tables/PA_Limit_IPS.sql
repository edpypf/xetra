﻿CREATE TABLE [DataWarehouse_Staging].[PA_Limit_IPS] (
    [Analysis_Date]        DATE           NULL,
    [Client]               VARCHAR (255)  NULL,
    [Strategy]             VARCHAR (255)  NULL,
    [Port_Type]            VARCHAR (3)    NULL,
    [Check_Desc]           VARCHAR (500)  NULL,
    [Check_Limit]          VARCHAR (150)  NULL,
    [Check_Value]          VARCHAR (150)   NULL,
    [Check_Value_Txt]      VARCHAR (150)  NULL,
    [BM_Value]             VARCHAR (50)   NULL,
    [Check_Status]         VARCHAR (3)    NULL,
    [Reported_Status]      VARCHAR (3)    NULL,
    [Exception_Desc]       VARCHAR (1000) NULL,
    [Exception_Start_Date] DATE           NULL,
    [Exception_End_Date]   DATE           NULL,
    [Limit_Unit]           VARCHAR (255)  NULL,
    [HASH]                 VARCHAR(5000)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

