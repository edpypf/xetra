﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_Monthly_Client_Fees] (
    [Client_ID]   CHAR (20)  NOT NULL,
    [Monthly_Fee] FLOAT (53) NULL,
    [Start_Date]  DATE       NOT NULL,
    [End_Date]    DATE       NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

