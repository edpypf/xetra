﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_Config_Report] (
    [Report_Number]  INT           NOT NULL,
    [Report_Name]    VARCHAR (255) NOT NULL,
    [Report_Group]   VARCHAR (255) NOT NULL,
    [TPA_Final_Flag] VARCHAR (2)   NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);



