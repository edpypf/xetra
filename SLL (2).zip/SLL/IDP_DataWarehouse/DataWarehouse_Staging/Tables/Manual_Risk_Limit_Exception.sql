﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_Limit_Exception] (
    [Client]       VARCHAR (50)   NULL,
    [Strategy]     VARCHAR (50)   NULL,
    [Limit_Name]   VARCHAR (4000) NULL,
    [Exception]    VARCHAR (4000) NULL,
    [PortGroup]    VARCHAR (50)   NULL,
    [Begin_Date]   DATETIME       NULL,
    [End_Date]     DATETIME       NULL,
    [Updated_Time] DATETIME       NULL,
    [Updated_By]   VARCHAR (50)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

