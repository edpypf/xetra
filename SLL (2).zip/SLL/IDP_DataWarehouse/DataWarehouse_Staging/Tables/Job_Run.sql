﻿CREATE TABLE [DataWarehouse_Staging].[Job_Run] (
    [Job_ID]       INT           IDENTITY (1, 1) NOT NULL,
    [Job_Run]      VARCHAR (50)  NULL,
    [JobStart_DTS] DATETIME2 (7) NULL,
    [JobEnd_DTS]   DATETIME2 (7) NULL,
    [Load_DTS]     DATETIME2 (7) NULL,
    [Batch_Date]   DATE          NULL,
    [Job_Status]   VARCHAR (50)  NULL,
    [Load_Type]    VARCHAR (255) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

