﻿CREATE TABLE [DataWarehouse_Staging].[PA_Risk_LCR_Client_Ratio] (
	[Client]             VARCHAR (150) NULL,
	[Effective_Date]     DATE          NULL,
	[Scenario_Name]      VARCHAR (150) NULL,
	[LCR_Ratio]          FLOAT (53)    NULL,
    [HASH]               VARCHAR(1500) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);