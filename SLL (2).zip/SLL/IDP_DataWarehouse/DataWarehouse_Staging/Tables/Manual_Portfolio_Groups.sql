﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Portfolio_Groups] (
    [Group_Name]       VARCHAR (100) NOT NULL,
    [Portfolio_ID]     VARCHAR (100) NOT NULL,
    [Start_Date]       DATE          NOT NULL,
    [End_Date]         DATE          NULL,
    [Responsible_Team] VARCHAR (40)  NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

