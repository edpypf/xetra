﻿CREATE TABLE [DataWarehouse_Staging].[Eagle_CUSTOM_INDEX_ATTRIBUTES] (
    [INSTANCE]             NUMERIC (18)     NOT NULL,
    [EFFECTIVE_DATE]       DATETIME2 (7)    NOT NULL,
    [ENTITY_ID]            CHAR (8)         NOT NULL,
    [ENTITY_DETAIL_ID]     CHAR (8)         NOT NULL,
    [TARGET_DICT_ID]       NUMERIC (18)     NOT NULL,
    [SOURCE_DICT_ID]       NUMERIC (18)     NOT NULL,
    [DICT_LEVEL]           NUMERIC (18)     NOT NULL,
    [DICT_LEVEL_VALUE]     CHAR (30)        NOT NULL,
    [WEIGHT]               NUMERIC (28, 12) NOT NULL,
    [CUST_INDX_TYPE]       CHAR (4)         NOT NULL,
    [SRC_INTFC_INST]       NUMERIC (18)     NOT NULL,
    [UPDATE_DATE]          DATETIME2 (7)    NOT NULL,
    [UPDATE_SOURCE]        CHAR (30)        NOT NULL,
    [TARGET_DICT_ITEM_ID]  NUMERIC (18)     NULL,
    [RESET_DATE_ID]        NUMERIC (18)     NULL,
    [RESET_FLAG]           CHAR (2)         NULL,
    [FX_SOURCE_RULE_ID]    NUMERIC (18)     NULL,
    [BUILD_SECURITY_LEVEL] CHAR (1)         NULL,
    [SRC_DICT_ITEM_ID]     NUMERIC (38)     NULL,
    [ROLLUP_LEVEL_ONLY]    NUMERIC (38)     NULL,
    [REF_ENTITY_ID]        CHAR (8)         NULL,
    [BLD_ASSGN_LEVEL_ONLY] NUMERIC (38)     NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);


