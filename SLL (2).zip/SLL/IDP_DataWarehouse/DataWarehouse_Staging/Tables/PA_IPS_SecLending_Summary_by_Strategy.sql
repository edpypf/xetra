CREATE TABLE [DataWarehouse_Staging].[PA_IPS_SecLending_Summary_by_Strategy] (
	[Analysis_Date]     DATE          NULL,
	[Client]            VARCHAR (50)  NULL,
	[Portfolio]         VARCHAR (100) NULL,
	[Counterparty]      VARCHAR (50)  NULL,
	[Restriction]       VARCHAR (500) NULL,
	[Limit]             VARCHAR (50)  NULL,
	[Status]            VARCHAR (5)   NULL,
	[StatuswExceptions] VARCHAR (5)   NULL,
	[Comment]           VARCHAR (500) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
