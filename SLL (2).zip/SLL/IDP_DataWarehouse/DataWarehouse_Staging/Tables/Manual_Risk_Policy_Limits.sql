﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Risk_Policy_Limits] (
    [IPS_Strategy]            VARCHAR (100) NOT NULL,
    [Monthly_Fee]             FLOAT (53)    NULL,
    [Target_Return]           FLOAT (53)    NULL,
    [Target_Excess_Return]    FLOAT (53)    NULL,
    [Target_Tracking_Error]   FLOAT (53)    NULL,
    [Max_Tracking_Error]      FLOAT (53)    NULL,
    [Target_Total_Risk]       FLOAT (53)    NULL,
    [Max_Total_Risk]          FLOAT (53)    NULL,
    [Target_Total_Risk_Ratio] FLOAT (53)    NULL,
    [Max_Total_Risk_Ratio]    FLOAT (53)    NULL,
    [Start_Date]              DATE          NOT NULL,
    [End_Date]                DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

