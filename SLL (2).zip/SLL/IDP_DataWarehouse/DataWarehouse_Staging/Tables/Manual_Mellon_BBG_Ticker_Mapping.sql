﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Mellon_BBG_Ticker_Mapping] (
    [Security_Description] VARCHAR (500) NULL,
    [ISIN]                 VARCHAR (50)  NULL,
    [SEDOL]                VARCHAR (50)  NULL,
    [Ticker_From_Mellon]   VARCHAR (50)  NULL,
    [Ticker_To_Bloomberg]  VARCHAR (50)  NULL,
    [Start_Date]           DATE          NULL,
    [End_Date]             DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

