﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_Config_Report_Measures] (
    [OLAP_Measure_Name] VARCHAR (255) NOT NULL,
    [View_Field_Name]   VARCHAR (255) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

