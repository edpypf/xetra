CREATE TABLE [DataWarehouse_Staging].[Manual_RM_IMCO_Product_Mapping] (
    [AssetClass]                     VARCHAR (250) NULL,
    [DP_AssetType]                   VARCHAR (250) NULL,
    [IMCO_Sector_1]                  VARCHAR (250) NULL,
    [Private_Mkt_Investment_Vehicle] VARCHAR (250) NULL,
    [IPS_Strategy]                   VARCHAR (250) NULL,
    [PositionType]                   VARCHAR (250) NULL,
    [isInflationIndexed]             VARCHAR (250) NULL,
    [Name]                           VARCHAR (250) NULL,
    [IMCO_Product]                   VARCHAR (250) NULL,
    [Derivative]                     CHAR (5)      NULL,
    [RuleId]                         INT           NULL,
    [isValid]                        INT           NULL,
    [RuleName]                       VARCHAR (150) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
GO

