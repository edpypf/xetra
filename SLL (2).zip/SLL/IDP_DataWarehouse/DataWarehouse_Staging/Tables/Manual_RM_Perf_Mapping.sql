﻿CREATE TABLE [DataWarehouse_Staging].[Manual_RM_Perf_Mapping] (
    [RM_PortfolioID]   VARCHAR (255) NOT NULL,
    [Perf_PortfolioID] VARCHAR (255) NOT NULL,
    [Start_Date]       DATE          NOT NULL,
    [End_Date]         DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

