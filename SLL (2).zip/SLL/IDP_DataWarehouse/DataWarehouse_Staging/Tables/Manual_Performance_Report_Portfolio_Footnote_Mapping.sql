﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_Report_Portfolio_Footnote_Mapping] (
    [Report_Group] VARCHAR (255) NOT NULL,
    [Client_Id]    VARCHAR (255) NOT NULL,
    [AUM_Type]     VARCHAR (255) NOT NULL,
    [Portfolio_ID] VARCHAR (255) NOT NULL,
    [Start_Date]   DATE          NOT NULL,
    [End_Date]     DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

