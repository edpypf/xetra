﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_Report_Portfolio_Mapping] (
    [OLAP_Extract_Name]    VARCHAR (255) NULL,
    [Report_Group]         VARCHAR (255) NOT NULL,
    [Client_Id]            VARCHAR (255) NOT NULL,
    [IPS_Strtegy]          VARCHAR (255) NULL,
    [Portfolio_ID]         VARCHAR (255) NOT NULL,
    [Portfolio_Name]       VARCHAR (500) NULL,
    [Group_Portfolio_Id]   VARCHAR (255) NULL,
    [Benchmark_Id]         VARCHAR (255) NULL,
    [Benchmark_Name]       VARCHAR (500) NULL,
    [Parent_Composite_Id]  VARCHAR (255) NULL,
    [Leverage_Adj_Flag_PF] VARCHAR (15)  NULL,
    [Sort_Order]           VARCHAR (255) NULL,
    [Start_Date]           DATE          NOT NULL,
    [End_Date]             DATE          NULL,
    [Mask_Flag]            VARCHAR (15)  NULL,
    [Leverage_Adj_Flag_BM] VARCHAR (15)  NULL,
    [Group_Portfolio_Flag] VARCHAR (15)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
GO



