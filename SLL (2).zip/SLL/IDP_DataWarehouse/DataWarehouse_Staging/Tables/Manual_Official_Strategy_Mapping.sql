﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Official_Strategy_Mapping] (
    [IPS_Strategy]    VARCHAR (100) NOT NULL,
    [Legacy_Strategy] VARCHAR (40)  NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);



