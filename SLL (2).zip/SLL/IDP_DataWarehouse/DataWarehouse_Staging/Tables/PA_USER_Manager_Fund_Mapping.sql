﻿CREATE TABLE [DataWarehouse_Staging].[PA_USER_Manager_Fund_Mapping] (
    [Begin_Date]   DATE          NOT NULL,
    [End_Date]     DATE          NULL,
    [Manager]      VARCHAR (150) NULL,
    [Manager_Type] VARCHAR (25)  NULL,
    [Fund_Name]    VARCHAR (150) NULL,
    [Fund_Type]    VARCHAR (25)  NULL,
    [Risk_ID]      VARCHAR (150) NOT NULL,
    [Source_ID]    VARCHAR (50)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

