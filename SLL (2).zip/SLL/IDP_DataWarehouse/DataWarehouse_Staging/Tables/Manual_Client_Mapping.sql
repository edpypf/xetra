﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Client_Mapping] (
    [Master_Client]    VARCHAR (100) NULL,
    [Alternate_Client] VARCHAR (100) NULL,
    [Update_Date]      DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

