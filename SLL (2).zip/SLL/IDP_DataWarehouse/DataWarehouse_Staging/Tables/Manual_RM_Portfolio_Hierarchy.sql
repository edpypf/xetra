﻿CREATE TABLE [DataWarehouse_Staging].[Manual_RM_Portfolio_Hierarchy] (
    [Portfolio_ID]        VARCHAR (50)   NOT NULL,
    [Client_ID]           VARCHAR (50)   NOT NULL,
    [Portfolio_Type]      VARCHAR (50)   NOT NULL,
    [IPS_Strategy]        VARCHAR (255)  NOT NULL,
    [Parent_Portfolio_ID] VARCHAR (50)   NOT NULL,
    [Has_Position]        INT            NULL,
    [Start_Date]          DATE           NOT NULL,
    [End_Date]            DATE           NULL,
    [Comment]             VARCHAR (3000) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);





