﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_Report_Measure_Override] (
    [Entity_Id]         VARCHAR (255)   NOT NULL,
    [OLAP_Measure_Name] VARCHAR (255)   NOT NULL,
    [Start_Date]        DATE            NOT NULL,
    [End_Date]          DATE            NULL,
    [Measure_Value]     NUMERIC (28, 8) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

