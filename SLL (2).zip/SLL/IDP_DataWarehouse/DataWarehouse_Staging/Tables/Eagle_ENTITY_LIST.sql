﻿CREATE TABLE [DataWarehouse_Staging].[Eagle_ENTITY_LIST] (
    [INSTANCE]           NUMERIC (18)  NULL,
    [ENTITY_ID]          CHAR (8)      NULL,
    [CODE]               CHAR (255)    NULL,
    [CONNECTOR]          CHAR (8)      NULL,
    [CODE_VALUE]         CHAR (255)    NULL,
    [UPD_DATETIME]       DATETIME2 (7) NULL,
    [CODE_INST]          NUMERIC (18)  NULL,
    [FIELD_ATTRIBUTE_ID] NUMERIC (18)  NULL,
    [OPERATOR]           CHAR (10)     NULL,
    [UPDATE_SOURCE]      VARCHAR (32)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);


