CREATE TABLE [DataWarehouse_Staging].[PA_IPS_DerivLeverageCheck] (
	[Date_]                   DATE          NULL,
	[Strategy]                VARCHAR (150) NULL,
	[Client]                  VARCHAR (50)  NULL,
	[Cash_Exposure]           VARCHAR (150) NULL,
	[Net_Derivative_Exposure] VARCHAR (150) NULL,
	[Leverage]                VARCHAR (10)  NULL,
    [HASH]                    VARCHAR(5000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
