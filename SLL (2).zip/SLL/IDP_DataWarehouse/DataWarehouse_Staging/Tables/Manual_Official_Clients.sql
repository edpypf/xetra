﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Official_Clients] (
    [Client_ID]        CHAR (20)     NOT NULL,
    [Client_Name]      VARCHAR (100) NULL,
    [Parent_Client_ID] VARCHAR (40)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

