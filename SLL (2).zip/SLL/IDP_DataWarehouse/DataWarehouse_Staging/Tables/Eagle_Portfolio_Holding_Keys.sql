﻿CREATE TABLE [DataWarehouse_Staging].[Eagle_Portfolio_Holding_Keys] (
    [Entity_ID]      CHAR (8)     NOT NULL,
    [Security_Alias] NUMERIC (18) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);


