﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Portfolio]
(
	[Portfolio_ID] [varchar](100) NOT NULL,
	[Portfolio_Classification] [varchar](100) NULL,
	[Manager] [varchar](100) NULL,
	[Manager_Classification_Risk] [varchar](100) NULL,
	[Reporting_Portfolio_Name] [varchar](100) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)