﻿CREATE TABLE [DataWarehouse_Staging].[PA_USER_Manager_Portfolio_Mapping] (
    [Begin_Date]      DATE          NOT NULL,
    [End_Date]        DATE          NULL,
    [Manager]         VARCHAR (150) NULL,
    [Manager_Type]    VARCHAR (25)  NULL,
    [Fund_Type]       VARCHAR (25)  NULL,
    [Accounting_Port] VARCHAR (50)  NOT NULL,
    [Risk_Port]       VARCHAR (150) NULL,
    [Fund_Currency]   VARCHAR (25)  NULL,
    [HASH]            VARCHAR(5000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

