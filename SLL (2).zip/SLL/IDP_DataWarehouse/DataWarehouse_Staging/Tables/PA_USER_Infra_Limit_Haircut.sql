CREATE TABLE [DataWarehouse_Staging].[PA_USER_Infra_Limit_Haircut] (
	[Begin_Date]             DATE          NULL,
	[End_Date]               DATE          NULL,
	[Client]                 VARCHAR (50)  NULL,
	[Portfolio]              VARCHAR (150) NULL,
	[Private_Mkt_Asset_Name] VARCHAR (150) NULL,
	[Manager]                VARCHAR (150) NULL,
	[Direct_Investment_Test] VARCHAR (50)  NULL,
	[Lead_Manager]           VARCHAR (50)  NULL,
	[Haircut_Applied]        VARCHAR (50)  NULL,
	[Haircut_pct]            FLOAT (53)    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
