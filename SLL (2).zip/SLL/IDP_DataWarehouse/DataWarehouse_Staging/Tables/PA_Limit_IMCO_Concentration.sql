﻿CREATE TABLE [DataWarehouse_Staging].[PA_Limit_IMCO_Concentration] (
    [Analysis_Date]          DATE           NULL,
    [Client]                 VARCHAR (50)   NULL,
    [Strategy]               VARCHAR (150)  NULL,
    [Port_Type]              CHAR (1)       NULL,
    [Check_Desc]             VARCHAR (500)  NULL,
    [Check_Limit]            VARCHAR (150)  NULL,
    [Check_Value]            FLOAT (53)     NULL,
    [Check_Value_Commitment] FLOAT (53)     NULL,
    [Check_Value_Txt]        VARCHAR (150)  NULL,
    [BM_Value]               FLOAT (53)     NULL,
    [Check_Status]           VARCHAR (3)    NULL,
    [Reported_Status]        VARCHAR (3)    NULL,
    [Exception_Desc]         VARCHAR (1000) NULL,
    [Exception_Start_Date]   DATE           NULL,
    [Exception_End_Date]     DATE           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

