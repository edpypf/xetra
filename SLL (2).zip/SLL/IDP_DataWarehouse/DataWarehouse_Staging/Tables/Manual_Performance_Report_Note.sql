﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_Report_Note] (
    [Report_Number] INT            NOT NULL,
    [Report_Name]   VARCHAR (255)  NOT NULL,
    [Client_Id]     VARCHAR (255)  NOT NULL,
    [Start_Date]    DATE           NOT NULL,
    [End_Date]      DATE           NULL,
    [Note_Text]     VARCHAR (4000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

