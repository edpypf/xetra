﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Portfolio_Tags] (
    [Portfolio_ID]                VARCHAR (100) NOT NULL,
    [Portfolio_Classification]    VARCHAR (100) NULL,
    [Custodian_Classification]    VARCHAR (50)  NULL,
    [Manager]                     VARCHAR (100) NULL,
    [Manager_Classification_Risk] VARCHAR (100) NULL,
    [Manager_Mandate_Type]        VARCHAR (50)  NULL,
    [Manager_Mandate_Curr]        VARCHAR (50)  NULL,
    [Reporting_Portfolio_Name]    VARCHAR (100) NULL,
    [CCE]                         VARCHAR (50)  NULL,
    [FX_Hedging]                  VARCHAR (100) NULL,
    [HP_Blend]                    VARCHAR (100) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);



