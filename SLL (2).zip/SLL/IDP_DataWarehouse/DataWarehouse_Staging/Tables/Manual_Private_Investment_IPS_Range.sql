﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Private_Investment_IPS_Range] (
    [Type]                   VARCHAR (255)   NOT NULL,
    [Category]               VARCHAR (255)   NOT NULL,
    [Start_Date]             DATE            NOT NULL,
    [End_Date]               DATE            NOT NULL,
    [IPS_Range_Lower_Limit]  NUMERIC (10, 4) NULL,
    [IPS_Range_Higher_limit] NUMERIC (10, 4) NULL,
    [Target]                 NUMERIC (10, 4) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

