﻿CREATE TABLE [DataWarehouse_Staging].[Manual_Performance_User_Net_Portfolio_Performance] (
    [Effective_Date]              DATETIME         NOT NULL,
    [Portfolio_Id]                VARCHAR (16)     NOT NULL,
    [Dataset_Frequency_Indicator] VARCHAR (2)      NOT NULL,
    [Net_Return_Percentage]       DECIMAL (28, 12) NOT NULL,
    [Updated_By]                  VARCHAR (50)     NOT NULL,
    [Updated_Time]                DATETIME         NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

