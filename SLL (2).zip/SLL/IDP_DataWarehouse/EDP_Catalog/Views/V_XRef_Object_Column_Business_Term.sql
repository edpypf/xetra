﻿CREATE VIEW [EDP_Catalog].[V_XRef_Object_Column_Business_Term]
AS SELECT [Business_Term]
      ,[Schema_Name]
      ,[Object_Name]
      ,[Column_Name]
      ,[Source_System_Code]
      ,[Last_Update_User]
      ,[Last_Update_Datetime]
  FROM [EDP_Catalog].[XRef_Object_Column_Business_Term];