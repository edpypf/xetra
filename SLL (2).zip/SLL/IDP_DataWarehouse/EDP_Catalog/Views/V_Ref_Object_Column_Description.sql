﻿CREATE VIEW [EDP_Catalog].[V_Ref_Object_Column_Description]
AS SELECT
	[Object_Schema_Name],
	[Object_Name],
    [Column_Name],
    [Column_Description],
    [Sample_Data],
    [Source_System_Code],
    [Last_Update_User],
    [Last_Update_Datetime]

FROM
   [EDP_Catalog].[Ref_Object_Column_Description];