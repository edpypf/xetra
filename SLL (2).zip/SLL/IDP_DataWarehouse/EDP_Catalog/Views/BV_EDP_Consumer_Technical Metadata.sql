﻿CREATE VIEW [EDP_Catalog].[BV_EDP_Consumer_Technical Metadata]
AS SELECT Info_Schema.TABLE_SCHEMA                              Object_Schema_Name
      ,Info_Schema.TABLE_NAME                                Object_Name
      ,Info_Schema.COLUMN_NAME                               Column_Name
      ,Ref_ColDes.Column_Description                         Column_Description
      ,Info_Schema.DATA_TYPE                                 Column_Data_Type
      ,CASE 
          WHEN Info_Schema.IS_NULLABLE = 'NO' THEN 'Y'			
          WHEN Info_Schema.IS_NULLABLE = 'YES' THEN 'N'
        END                                                  Required_Indicator		-- Renamed from "Mandatory/Nullable"
      ,Ref_ColDes.Sample_Data                                Sample_Data
      ,XRef_SubDomain.Data_Sub_Domain_Code                   Data_Sub_Domain_Code
      ,XRef_SubDomain.Data_Owner_Code                        Data_Owner_Code
      ,Ref_DataOwner.Data_Owner_Name                         Data_Owner_Name
      ,Info_Schema.ORDINAL_POSITION                          Column_Index
      ,CONCAT(Info_Schema.TABLE_SCHEMA
          , '_', Info_Schema.TABLE_NAME
          , '_', RIGHT('0000' + CONVERT(VARCHAR(4)
          , Info_Schema.ORDINAL_POSITION), 4))               Object_Column_Display_Order
      ,Ref_ColDes.Source_System_Code                         Source_System_Code
	  ,Ref_ColDes.Last_Update_Datetime                       Last_Update_Datetime

FROM INFORMATION_SCHEMA.COLUMNS Info_Schema
LEFT JOIN EDP_Catalog.Ref_Object_Column_Description Ref_ColDes
    ON Info_Schema.TABLE_SCHEMA = Ref_ColDes.Object_Schema_Name
    AND Info_Schema.TABLE_NAME = Ref_ColDes.Object_Name 
    AND Info_Schema.COLUMN_NAME = Ref_ColDes.Column_Name

LEFT JOIN EDP_Catalog.XRef_Data_Sub_Domain_Object XRef_SubDomain
    ON Info_Schema.TABLE_SCHEMA = XRef_SubDomain.Object_Schema_Name
    AND Info_Schema.TABLE_NAME = XRef_SubDomain.Object_Name

LEFT JOIN EDP_Catalog.Ref_Business_Data_Owner Ref_DataOwner
ON XRef_SubDomain.Data_Owner_Code = Ref_DataOwner.Data_Owner_Code

WHERE 
    Info_Schema.TABLE_SCHEMA = 'EDP_Consumer';