﻿CREATE VIEW [EDP_Catalog].[V_XRef_Data_Sub_Domain_Object]
AS SELECT
	[Data_Owner_Code],
    [Data_Sub_Domain_Code],
    [Object_Schema_Name],
    [Object_Name],
    [Source_System_Code],
    [Last_Update_User],
    [Last_Update_Datetime]

FROM
   [EDP_Catalog].[XRef_Data_Sub_Domain_Object];