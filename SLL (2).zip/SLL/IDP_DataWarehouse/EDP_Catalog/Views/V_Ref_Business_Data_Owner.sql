﻿CREATE VIEW [EDP_Catalog].[V_Ref_Business_Data_Owner]
AS SELECT
	[Data_Owner_Code],
    [Data_Owner_Name],
    [Data_Owner_Long_Name],
    [Source_System_Code],
    [Last_Update_User],
    [Last_Update_Datetime]

FROM
   [EDP_Catalog].[Ref_Business_Data_Owner];