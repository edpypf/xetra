﻿CREATE TABLE [EDP_Catalog].[XRef_Object_Column_Business_Term] (
    [Business_Term]        VARCHAR (255) NOT NULL,
    [Schema_Name]          VARCHAR (255) NOT NULL,
    [Object_Name]          VARCHAR (255) NOT NULL,
    [Column_Name]          VARCHAR (255) NOT NULL,
    [Source_System_Code]   VARCHAR (255) NOT NULL,
    [Last_Update_User]     VARCHAR (255) NOT NULL,
    [Last_Update_Datetime] DATETIME      NOT NULL,
    CONSTRAINT [PK_XRef_Object_Column_Business_Term] PRIMARY KEY NONCLUSTERED ([Business_Term] ASC, [Schema_Name] ASC, [Object_Name] ASC, [Column_Name] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Object_Name]));

