﻿CREATE TABLE [EDP_Catalog].[Ref_Object_Column_Description] (
    [Object_Schema_Name]   VARCHAR (64)  NOT NULL,
    [Object_Name]          VARCHAR (64)  NOT NULL,
    [Column_Name]          VARCHAR (64)  NOT NULL,
    [Column_Description]   VARCHAR (500) NULL,
    [Sample_Data]          VARCHAR (255) NULL,
    [Source_System_Code]   VARCHAR (255) NOT NULL,
    [Last_Update_User]     VARCHAR (255) NOT NULL,
    [Last_Update_Datetime] DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_Ref_Object_Column_Description] PRIMARY KEY NONCLUSTERED ([Object_Schema_Name] ASC, [Object_Name] ASC, [Column_Name] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Column_Name]));

