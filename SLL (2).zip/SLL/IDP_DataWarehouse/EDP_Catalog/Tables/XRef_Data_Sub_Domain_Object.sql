﻿CREATE TABLE [EDP_Catalog].[XRef_Data_Sub_Domain_Object] (
    [Data_Owner_Code]      VARCHAR (255) NOT NULL,
    [Data_Sub_Domain_Code] VARCHAR (255) NOT NULL,
    [Object_Schema_Name]   VARCHAR (255) NOT NULL,
    [Object_Name]          VARCHAR (255) NOT NULL,
    [Source_System_Code]   VARCHAR (255) NOT NULL,
    [Last_Update_User]     VARCHAR (255) NOT NULL,
    [Last_Update_Datetime] DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_XRef_Data_Sub_Domain_Object] PRIMARY KEY NONCLUSTERED ([Data_Owner_Code] ASC, [Data_Sub_Domain_Code] ASC, [Object_Schema_Name] ASC, [Object_Name] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Object_Name]));

