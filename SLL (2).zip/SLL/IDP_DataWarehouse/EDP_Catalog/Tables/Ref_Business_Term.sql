﻿CREATE TABLE [EDP_Catalog].[Ref_Business_Term] (
    [Business_Term]                     VARCHAR (255)  NOT NULL,
    [Term_Definition]                   VARCHAR (8000) NOT NULL,
    [Acronym_Comma_Separated_Name_List] VARCHAR (255)  NOT NULL,
    [Synonym_Comma_Separated_Name_List] VARCHAR (4000) NULL,
    [Slangs_Comma_Separated_Name_List]  VARCHAR (4000) NULL,
    [Idioms_Comma_Separated_Name_List]  VARCHAR (4000) NULL,
    [Plurals_Comma_Separated_Name_List] VARCHAR (4000) NULL,
    [Others_Comma_Separated_Name_List]  VARCHAR (4000) NULL,
    [Disabled_List]                     VARCHAR (4000) NULL,
    [Global_Comma_Separated_Name_List]  VARCHAR (4000) NULL,
    [Labels_Comma_Separated_Name_List]  VARCHAR (4000) NULL,
    [Link_Html]                         VARCHAR (4000) NULL,
    [Source_System_Code]                VARCHAR (255)  NOT NULL,
    [Last_Update_User]                  VARCHAR (255)  NOT NULL,
    [Last_Update_Datetime]              DATETIME2 (7)  NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Business_Term] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

