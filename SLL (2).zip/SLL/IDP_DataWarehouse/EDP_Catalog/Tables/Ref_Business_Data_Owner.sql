﻿CREATE TABLE [EDP_Catalog].[Ref_Business_Data_Owner] (
    [Data_Owner_Code]      VARCHAR (255) NOT NULL,
    [Data_Owner_Name]      VARCHAR (255) NULL,
    [Data_Owner_Long_Name] VARCHAR (255) NULL,
    [Source_System_Code]   VARCHAR (255) NOT NULL,
    [Last_Update_User]     VARCHAR (255) NOT NULL,
    [Last_Update_Datetime] DATETIME2 (7) NOT NULL,
    PRIMARY KEY NONCLUSTERED ([Data_Owner_Code] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

