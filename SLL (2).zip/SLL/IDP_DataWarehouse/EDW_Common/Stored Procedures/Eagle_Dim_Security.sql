﻿CREATE PROC [EDW_Common].[Eagle_Dim_Security] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@Batch_DTS datetime2
	
	Begin Try

		--Select @Batch_DTS = Batch_Date
		--From EDW_ETL.ETL_Load
		--Where ETL_Load_Key = @ETL_Load_Key

		IF OBJECT_ID('tempdb..#temp_src_security_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_security_records
		END

		-- load everything from source

		create table #temp_src_security_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select Src_Security_Id, Security_Id, Security, Security_Type, 'NA' Instrument_Type, 
			   null Security_Long_Name, null Security_Description,  null Security_Description_2,
			   BBG_CMS, BBG_PRA, BBGCID, BBGID, BBID, BNYM_ID, CHINA_INT, CINS, CMS_ID, 
				CSIID, CUSIP, DYNAMO, ID_BB, Internal, ISIN, JPM_ID, LOANX, MAS_ID, MELLON_INTERNAL, 
				MSCIID, MUCID, RUSSID, SEDOL, SHANGHAI,SHENZHEN, SICOVAM, SPDJBIID, SSC_ID, SWAPID, 
				TICKER, TSEID, TSID, UBBFOID, CASH,
			   convert(varchar(64), Hashbytes('SHA1', upper(concat(Rtrim(Security), '|', 
			   BBG_CMS, '|',  BBG_PRA, '|',  BBGCID,  '|', BBGID, '|',  BBID,  '|', BNYM_ID, '|',  CHINA_INT,  '|', CINS,  '|', CMS_ID, '|',  
				CSIID, '|',  CUSIP,  '|', DYNAMO,  '|', ID_BB,  '|', Internal,  '|', ISIN,  '|', JPM_ID,  '|', LOANX,  '|', MAS_ID,  '|', MELLON_INTERNAL,  '|', 
				MSCIID,  '|', MUCID,  '|', RUSSID,  '|', SEDOL,  '|', SHANGHAI, '|', SHENZHEN,  '|', SICOVAM,  '|', SPDJBIID,  '|', SSC_ID, SWAPID,  '|', 
				TICKER,  '|', TSEID,  '|', TSID,  '|', UBBFOID,  '|', CASH  ))) ,2) Hash_Diff
		From (
				Select Src_Security_Id, Security_Id, Security_Type, Security, 
						BBG_CMS, BBG_PRA, BBGCID, BBGID, BBID, BNYM_ID, CHINA_INT, CINS, CMS_ID, 
						CSIID, CUSIP, DYNAMO, ID_BB, Internal, ISIN, JPM_ID, LOANX, MAS_ID, MELLON_INTERNAL, 
						MSCIID, MUCID, RUSSID, SEDOL, SHANGHAI,SHENZHEN, SICOVAM, SPDJBIID, SSC_ID, SWAPID, 
						TICKER, TSEID, TSID, UBBFOID, CASH
				from (

					Select 'Eagle_' + convert(varchar(15), M.Security_Alias) as Src_Security_Id
					     , convert(varchar(15), M.Security_Alias) Security_Id
						 , coalesce(Rtrim(X.XREF_SECURITY_ID), 'NA')               as Security_XRef_ID
						 , coalesce(M.Issue_Description, 'Not Avaiable')               as Security
						 , coalesce(M.Security_Type, 'NA') Security_Type
						 , case Rtrim(X.XREF_TYPE)
						   when 'MELLON INTERNAL' then 'MELLON_INTERNAL'
						   when 'CSI ID' then 'CSIID'
						   when 'JPM ID' then 'JPMID'
						   Else Rtrim(X.XREF_TYPE)
						   end Security_XRef_Type
					From PSA.V_Eagle_Security_Master M
					Left Join PSA.V_Eagle_XREFERENCE  X on X.Security_Alias = M.Security_Alias		
					Where Rtrim(X.XREF_TYPE) in (
						'BBG_CMS', 'BBG_PRA', 'BBGCID', 'BBGID', 'BBID', 'BNYM_ID', 'CHINA_INT', 'CINS', 'CMS_ID', 'CSI ID', 
						'CSIID', 'CUSIP', 'DYNAMO', 'ID_BB', 'INTERNAL', 'Internal', 'ISIN', 'JPM ID', 'LOANX', 'MAS_ID', 'mellon internal', 
						'MELLON INTERNAL', 'MELLON_INTERNAL', 'Mellon_Internal', 'MSCIID', 'MUCID', 'RUSSID', 'SEDOL', 'SHANGHAI',
						'SHENZHEN', 'SICOVAM', 'SPDJBIID', 'SSC_ID', 'SWAPID', 'TICKER', 'TSEID', 'TSID', 'UBBFOID', 'CASH'
					) and M.Is_Src_Deleted = 0 
					
				) s
				Pivot (
				  max(Security_XRef_Id) for Security_XRef_Type in (
						BBG_CMS, BBG_PRA, BBGCID, BBGID, BBID, BNYM_ID, CHINA_INT, CINS, CMS_ID, 
						CSIID, CUSIP, DYNAMO, ID_BB, Internal, ISIN, JPM_ID, LOANX, MAS_ID, MELLON_INTERNAL, 
						MSCIID, MUCID, RUSSID, SEDOL, SHANGHAI,SHENZHEN, SICOVAM, SPDJBIID, SSC_ID, SWAPID, 
						TICKER, TSEID, TSID, UBBFOID, CASH
				  )
				) sp
		) src

		Insert Into [EDW_Common].[Dim_Security] (
				Src_Security_Id
		        ,Security_Id
				,Instrument_Type
				,Security
				,Security_Type
				,Security_Long_Name
				,Security_Description
				,Security_Description_2
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
				,Source_System
				,BBG_CMS, BBG_PRA, BBGCID, BBGID, BBID, BNYM_ID, CHINA_INT, CINS, CMS_ID, 
				CSIID, CUSIP, DYNAMO, ID_BB, Internal, ISIN, JPM_ID, LOANX, MAS_ID, MELLON_INTERNAL, 
				MSCIID, MUCID, RUSSID, SEDOL, SHANGHAI,SHENZHEN, SICOVAM, SPDJBIID, SSC_ID, SWAPID, 
				TICKER, TSEID, TSID, UBBFOID, CASH
		)
		Select Src_Security_Id, Security_id, Instrument_Type, Security, Security_Type, Security_Long_Name, Security_Description, Security_Description_2, 
		       @today, null, 1, @today, Hash_Diff, @ETL_Load_Key, 'Eagle',
			   BBG_CMS, BBG_PRA, BBGCID, BBGID, BBID, BNYM_ID, CHINA_INT, CINS, CMS_ID, 
				CSIID, CUSIP, DYNAMO, ID_BB, Internal, ISIN, JPM_ID, LOANX, MAS_ID, MELLON_INTERNAL, 
				MSCIID, MUCID, RUSSID, SEDOL, SHANGHAI,SHENZHEN, SICOVAM, SPDJBIID, SSC_ID, SWAPID, 
				TICKER, TSEID, TSID, UBBFOID, CASH
		From #temp_src_security_records src
		Where not exists (
			Select 1
			From [EDW_Common].[Dim_Security] tgt
			where Record_Is_Current_Flag = 1 and src.Src_Security_Id = tgt.Src_Security_Id and coalesce(src.Hash_Diff,'') = coalesce(tgt.Hash_Diff,'')
		)

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Dim_Security] tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_security_records src
			Where  src.Src_Security_Id = tgt.Src_Security_Id and coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')
		)

		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Security]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Security]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Security', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Security', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END