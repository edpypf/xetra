﻿CREATE PROC [EDW_Common].[IMCOManual_Dim_Client] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_client_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_client_records
		END

		-- load everything from source

		create table #temp_src_client_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select Src_Client_Id
			    ,[Client_ID]
				,[Client_Name]
				,[Parent_Client_ID]
				,[Is_Src_Deleted]
				,Hash_Diff
		From (
			Select Client_ID as Src_Client_Id
				    ,Rtrim([Client_ID]) Client_Id
					,[Client_Name]
					,[Parent_Client_ID]
					,[Is_Src_Deleted]
					,Hash_Diff
					,Row_Number() Over (Partition By Client_Id order by Load_DTS Desc) rn

			From [PSA].[Manual_Official_Clients]
		) src
		where rn = 1

		union

		Select Src_Client_Id
			    ,[Client_ID]
				,[Client_Name]
				,[Parent_Client_ID]
				,[Is_Src_Deleted]
				,Hash_Diff
		From (
			Select cm.Alternate_Client as Src_Client_Id
				    ,Rtrim(cm.Master_Client) as Client_Id
					,c.[Client_Name]
					,c.[Parent_Client_ID]
					,cm.[Is_Src_Deleted]
					,cm.Hash_Diff
					,Row_Number() Over (Partition By cm.Alternate_Client order by cm.Load_DTS Desc) rn

			From [PSA].[Manual_Client_Mapping] cm
			left join [PSA].[Manual_Official_Clients] c on cm.Master_Client = c.Client_Id
		) src
		where rn = 1


		Insert Into [EDW_Common].[Dim_Client] (
		        Src_Client_Id
				,[Client_ID]
				,[Client_Name]
				,[Parent_Client_ID]
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select Src_Client_Id, Client_Id, Client_Name, Parent_Client_Id, @today, null, 1, @today, Hash_Diff, @ETL_Load_Key
		From #temp_src_client_records src
		Where not exists (
			Select 1
			From [EDW_Common].[Dim_Client] tgt
			where Record_Is_Current_Flag = 1 and src.client_id = tgt.client_id and tgt.Src_Client_Id = src.Src_Client_Id and src.Hash_Diff = tgt.Hash_Diff
		)
		and src.Is_Src_Deleted = 0

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Dim_Client] tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_client_records src
			Where tgt.Client_Id = src.Client_Id and tgt.Src_Client_Id = src.Src_Client_Id and (coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1)
		)

		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Client]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Client]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Client', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Client', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END