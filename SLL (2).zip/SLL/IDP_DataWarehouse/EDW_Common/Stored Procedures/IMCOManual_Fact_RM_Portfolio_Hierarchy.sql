﻿CREATE PROC [EDW_Common].[IMCOManual_Fact_RM_Portfolio_Hierarchy] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2
			--,@ETL_Load_Key int = 1
	
	Begin Try

		--Select @lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		--From [EDW_Common].[Fact_Manual_RM_Portfolio_Hierarchy]

		IF OBJECT_ID('tempdb..#temp_src_manual_rm_portfolio_hierarchy') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_manual_rm_portfolio_hierarchy
		END

		create table #temp_src_manual_rm_portfolio_hierarchy
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select Dim_Date_Key
			,Date
			,Portfolio_ID
			,Client_ID
			,Portfolio_Type
			,Strategy_Id
			,Parent_Portfolio_ID
			,Has_Position
			,Start_Date
			,End_Date
			,Comment
			,min(Load_DTS) Load_DTS
			,min(case when Is_Src_Deleted = 1 then 1 else 0 end) Is_Src_Deleted
			,min(convert(varchar(64), Hashbytes('SHA1', upper(concat(coalesce(Rtrim(Portfolio_Type),''), '|', coalesce(Rtrim(Has_Position),'' )))),2)) Hash_Diff
		from
		(
			Select   D.Dim_Date_Key
			        ,D.Date
					,Portfolio_ID
					,Client_ID
					,Portfolio_Type
					,IPS_Strategy as Strategy_Id
					,Parent_Portfolio_ID
					,Has_Position
					,Start_Date
					,End_Date
					,Comment
					,Load_DTS
					,Is_Src_Deleted
					,row_number() over (partition by D.Date, Portfolio_ID, Client_ID, Parent_Portfolio_ID, IPS_Strategy, Start_Date order by Load_DTS DESC) rn
			From (
				 SELECT  Portfolio_ID
						,Client_ID
						,Portfolio_Type
						,IPS_Strategy
						,coalesce(Parent_Portfolio_ID, 'NA') as Parent_Portfolio_ID
						,Has_Position
						,Start_Date
						,End_Date
						,Comment
						,Is_Src_Deleted
						,Hash_Diff
						,Load_DTS
						,row_number() over (partition by Portfolio_ID, Client_ID, Parent_Portfolio_ID, IPS_Strategy, Start_Date order by Load_DTS DESC) rn
				  FROM [PSA].[Manual_RM_Portfolio_Hierarchy]
			) mpm
			Join EDW_Common.Dim_Date D on D.Date between mpm.Start_Date and case mpm.End_Date When '2099-12-31' Then getdate() Else mpm.End_Date End
			Where mpm.Portfolio_Id is not null and rn = 1 
		) m
		where rn = 1
		Group By Dim_Date_Key
			,Date
			,Portfolio_ID
			,Client_ID
			,Portfolio_Type
			,Strategy_Id
			,Parent_Portfolio_ID
			,Has_Position
			,Start_Date
			,End_Date
			,Comment


		--insert new records
		INSERT INTO [EDW_Common].[Fact_Manual_RM_Portfolio_Hierarchy]
        (   
			 Dim_Date_Key
			,[Dim_Portfolio_Key]
			,[Dim_Client_Key]
			,[Parent_Dim_Portfolio_Key]
			,Dim_Strategy_Key
			,Portfolio_ID
			,Client_ID
			,Portfolio_Type
			,IPS_Strategy
			,Parent_Portfolio_ID
			,Start_Date
			,End_Date
			,Comment
			,Load_DTS
			,Record_Created_DTS
			,[Last_Update_DTS]
			,Is_Src_Deleted
			,Other_Info
			,[Hash_Diff]
			,[ETL_Load_Key]
			,Has_Position
		)
			SELECT	 t.Dim_Date_Key
					,coalesce(p.[Dim_Portfolio_Key], -1) [Dim_Portfolio_Key]
					,coalesce(c.[Dim_Client_Key], -1) [Dim_Client_Key]
					,coalesce(c_pp.[Dim_Portfolio_Key], -1) [Parent_Dim_Portfolio_Key]
					,coalesce(c_s.Dim_Strategy_Key, coalesce(strg.Dim_Strategy_Key, -1)) Dim_Strategy_Key
					,t.Portfolio_ID
					,t.Client_ID
					,t.Portfolio_Type
					,t.Strategy_Id
					,t.Parent_Portfolio_ID
					,t.Start_Date
					,t.End_Date
					,t.Comment
					,t.Load_DTS
					,@today
					,@today
					,t.Is_Src_Deleted
					,'{"Strategy":"' + t.Strategy_Id + '",' +
					'"Portfolio":' + t.Portfolio_Id + '",' + 
					'"Parent_Portfolio":' + t.Parent_Portfolio_Id + '",' + 
					'}'
					,t.Hash_Diff
					,@ETL_Load_Key
					,t.Has_Position
		From #temp_src_manual_rm_portfolio_hierarchy t
		Left Join 
		(
			Select Portfolio_Id, Record_Start_DTS, max(coalesce([Record_End_DTS], '9999-12-31')) Record_End_DTS, max(Dim_Portfolio_Key) Dim_Portfolio_Key 
			From EDW_Common.Dim_Portfolio
			Group By Portfolio_Id, Record_Start_DTS
		) p on t.Portfolio_ID = p.Portfolio_Id and t.Date between p.Record_Start_DTS and p.[Record_End_DTS]
		Left Join EDW_Common.Dim_Client c on t.Client_Id = c.Src_Client_Id and c.Record_Is_Current_Flag = 1
		Left Join EDW_Common.Dim_Portfolio c_pp on t.Parent_Portfolio_ID = c_pp.Portfolio_Id and c_pp.Record_Is_Current_Flag = 1
		Left Join 
		(
				select Src_Strategy_Id, Record_Start_DTS,  max(dim_strategy_key) dim_strategy_key, max(Record_End_DTS) Record_End_DTS
				From EDW_Common.Dim_Strategy
				Where Is_Src_Deleted_Flag = 0
				group By Src_Strategy_Id, Record_Start_DTS
		) c_s on t.Strategy_Id = c_s.Src_Strategy_Id and t.Date Between c_s.Record_Start_DTS and c_s.Record_End_DTS -- c_s.Record_Is_Current_Flag = 1
		Left Join EDW_Common.Dim_Strategy strg on t.Strategy_Id = strg.Src_Strategy_Id and strg.Record_Is_Current_Flag = 1

		where not exists 
			(
				Select 1
				From [EDW_Common].[Fact_Manual_RM_Portfolio_Hierarchy] tgt
				where	tgt.Dim_Date_Key = t.Dim_Date_Key 
						and t.Portfolio_Id = tgt.Portfolio_Id 
						and t.Client_Id = tgt.Client_Id
						and t.Parent_Portfolio_ID = tgt.Parent_Portfolio_ID
						and t.Strategy_Id  = tgt.Ips_Strategy 
						and t.Start_Date = tgt.Start_Date
						and tgt.Is_Src_Deleted = 0
						and coalesce(t.Hash_Diff,'') = coalesce(tgt.Hash_Diff,'')
			) and t.Is_Src_Deleted = 0


		--expire the existing records
		Update tgt
		Set tgt.Last_Update_DTS = @today, 
			tgt.Is_Src_Deleted = 1, 
			tgt.ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Fact_Manual_RM_Portfolio_Hierarchy] tgt
		Where tgt.Is_Src_Deleted = 0 
		and exists
			(
				Select 1
				From #temp_src_manual_rm_portfolio_hierarchy src
				Where	--tgt.Dim_Date_Key = src.Dim_Date_Key 
						src.Portfolio_Id = tgt.Portfolio_Id
						and src.Client_Id = tgt.Client_Id
						and src.Strategy_Id  = tgt.Ips_Strategy 
						and src.Parent_Portfolio_ID = tgt.Parent_Portfolio_ID
						and src.Start_Date = tgt.Start_Date
						and ((coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')) or src.Is_Src_Deleted = 1)
			)

		/* expire the existing records which not exist in #temp_src_manual_rm_portfolio_hierarchy -- story 16305 & 16415 */
		Update tgt
		Set tgt.Last_Update_DTS = @today, 
			tgt.Is_Src_Deleted = 1, 
			tgt.ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Fact_Manual_RM_Portfolio_Hierarchy] tgt
		Where tgt.Is_Src_Deleted = 0 
		and not exists
			(
				Select 1
				From #temp_src_manual_rm_portfolio_hierarchy src
				Where	tgt.Dim_Date_Key = src.Dim_Date_Key 
						and src.Portfolio_Id = tgt.Portfolio_Id
						and src.Client_Id = tgt.Client_Id
						and src.Strategy_Id  = tgt.Ips_Strategy 
						and src.Parent_Portfolio_ID = tgt.Parent_Portfolio_ID
						and src.Start_Date = tgt.Start_Date
						and coalesce(tgt.Hash_Diff,'') = coalesce(src.Hash_Diff,'') 
						and src.Is_Src_Deleted = 0
			)

		/* update end_date -- story 16305 & 16415 */
		Update tgt
		Set tgt.Last_Update_DTS = @today, 
			tgt.End_Date = src.End_Date, 
			tgt.ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Fact_Manual_RM_Portfolio_Hierarchy] tgt
			Join #temp_src_manual_rm_portfolio_hierarchy src
				on tgt.Dim_Date_Key = src.Dim_Date_Key 
					and src.Portfolio_Id = tgt.Portfolio_Id
					and src.Client_Id = tgt.Client_Id
					and src.Strategy_Id  = tgt.Ips_Strategy 
					and src.Parent_Portfolio_ID = tgt.Parent_Portfolio_ID
					and src.Start_Date = tgt.Start_Date
					and src.End_Date <> tgt.End_Date
					and coalesce(tgt.Hash_Diff,'') = coalesce(src.Hash_Diff,'')
					and src.Is_Src_Deleted = 0
					and tgt.Is_Src_Deleted = 0 

		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Fact_Manual_RM_Portfolio_Hierarchy]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 0

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Fact_Manual_RM_Portfolio_Hierarchy]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 1

		Select @rowsUpdated = @rowsExpired


		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Manual_RM_Portfolio_Hierarchy', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Manual_RM_Portfolio_Hierarchy', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 500001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END