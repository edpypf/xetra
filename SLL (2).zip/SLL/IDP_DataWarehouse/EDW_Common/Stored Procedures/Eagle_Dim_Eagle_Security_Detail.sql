﻿CREATE PROC [EDW_Common].[Eagle_Dim_Eagle_Security_Detail] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@Batch_DTS datetime2
	
	Begin Try

		Select @Batch_DTS = Batch_Date
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		IF OBJECT_ID('tempdb..#temp_src_security_detail_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_security_detail_records
		END

		-- load everything from source

		create table #temp_src_security_detail_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select *,
			  convert(varchar(64), hashbytes('SHA1', Upper( Concat( SECURITY_ALIAS,'|',ISSUER_ID,'|',COUPON,'|',COUPON_FRACTIONAL_INDICATOR,'|',CURRENCY_CODE,'|',SETTLEMENT_CURRENCY,'|',EXPIRATION_DATE,'|',INVESTMENT_TYPE_CODE,'|',ISSUE_AMOUNT,'|',ISSUE_DESCRIPTION,'|',ISSUE_ID,'|',ISSUE_NAME,'|',MAT_DATE,'|',NRA_TAX_COUNTRY,'|',POOL_NUMBER,'|',PRIMARY_ASSET_ID,'|',PRIMARY_ASSET_ID_TYPE,'|',SECURITY_DESC2,'|',SECURITY_TYPE,'|',TICKER,'|',COUPON_FREQ_CODE,'|',COUPON_TYPE_CODE,'|',SECURITY_MINOR_TYPE,'|',LEGAL_STATUS_CODE,'|',COUPON_DAY_OF_MONTH,'|',CUSIP_CHANGE,'|',ANALYST_CODE,'|',EXCHANGE,'|',PRICE_MULTIPLIER,'|',DEF_PRICE_SOURCE,'|',ALT_ASSET_ID,'|',ALT_ASSET_ID_TYPE,'|',CREATE_DATE,'|',ALT_INVESTMENT_TYPE,'|',ALT_SECURITY_TYPE,'|',ENTITY_ID,'|',DEALERID,'|',LOOK_THRU_IND,'|',LOOK_THRU_VALUE,'|',SOURCE_NAME,'|',SOURCE_DATE,'|',CROSSOWN,'|',ISSUE_TAX_TYPE,'|',FWD_BROKER_CODE,'|',TRADING_FLAT,'|',GL_PRODUCT_CODE,'|',COUNTRY_OF_RISK,'|',COST_BASIS_RULE_TYPE,'|',RISK_CLASSIFICATION_TYPE,'|',INTERNATIONAL_SUKUK,'|',DOMESTIC_SUKUK,'|',INDUSTRY_GROUP,'|',INDUSTRY_SECTOR,'|',INDUSTRY_SUBGROUP,'|',INDUSTRY_SUBGROUP_NUMBER,'|',SECURITY_TYPE2,'|',ANNOUNCEMENT_DATE,'|',MARKET_SECTOR_DESCRIPTION,'|',SECURITY_DESCRIPTION,'|',SHORT_NAME,'|',ISSUER_INDUSTRY,'|',GICS_SECTOR,'|',GICS_NAME,'|',GICS_INDUSTRY_GROUP,'|',GICS_INDUSTRY_GROUP_NAME,'|',GICS_INDUSTRY,'|',GICS_INDUSTRY_NAME,'|',GICS_SUB_INDUSTRY,'|',GICS_SUB_INDUSTRY_NAME,'|',TRADING_STATUS,'|',COUNTRY_OF_ISSUE,'|',NAIC_CODE,'|',GICS_OVERRIDE_SUB_INDUSTRY,'|',GICS_OVERRIDE_INDUSTRY,'|',GICS_OVERRIDE_INDUSTRY_GROUP,'|',GICS_OVERRIDE_SECTOR,'|',ASSOCIATED_VARIABLE_CUSIP,'|',BLOOMBERG_SECTOR_CODE,'|',INDUSTRY_SECTOR_NUM,'|',MSCI_COUNTRY_CODE,'|',Asset_Class_Type_Code,'|',Industry_Sub_Sector,'|',PRI_GRESB_Classificatoin,'|',OECD_Non_OECD,'|',Asset_Class,'|',Investment_Structure,'|',Investment_Type,'|',Risk_Strategy,'|',Vintage,'|',Sector,'|',Region,'|',Revenue_source,'|',GICS_Sector_Long_Name,'|',GICS_Industry_Group_Long_Name ,'|',Instrument_Profile )) ) , 2) Hash_Diff
		from 
		(
			Select convert(varchar(255), sm.[SECURITY_ALIAS]) [SECURITY_ALIAS]
				  ,[ISSUER_ID]
				  ,[COUPON]
				  ,[COUPON_FRACTIONAL_INDICATOR]
				  ,[CURRENCY_CODE]
				  ,[SETTLEMENT_CURRENCY]
				  ,[EXPIRATION_DATE]
				  ,sm.[Investment_Type] [INVESTMENT_TYPE_CODE]
				  ,[ISSUE_AMOUNT]
				  ,[ISSUE_DESCRIPTION]
				  ,[ISSUE_ID]
				  ,[ISSUE_NAME]
				  ,[MAT_DATE]
				  ,[NRA_TAX_COUNTRY]
				  ,[POOL_NUMBER]
				  ,[PRIMARY_ASSET_ID]
				  ,[PRIMARY_ASSET_ID_TYPE]
				  ,[SECURITY_DESC2]
				  ,sm.[SECURITY_TYPE]
				  ,[TICKER]
				  ,[COUPON_FREQ_CODE]
				  ,[COUPON_TYPE_CODE]
				  ,[SECURITY_MINOR_TYPE]
				  ,[LEGAL_STATUS_CODE]
				  ,[COUPON_DAY_OF_MONTH]
				  ,[CUSIP_CHANGE]
				  ,[ANALYST_CODE]
				  ,[EXCHANGE]
				  ,[PRICE_MULTIPLIER]
				  ,[DEF_PRICE_SOURCE]
				  ,[ALT_ASSET_ID]
				  ,[ALT_ASSET_ID_TYPE]
				  ,[CREATE_DATE]
				  ,[ALT_INVESTMENT_TYPE]
				  ,[ALT_SECURITY_TYPE]
				  ,[ENTITY_ID]
				  ,[DEALERID]
				  ,[LOOK_THRU_IND]
				  ,[LOOK_THRU_VALUE]
				  ,sm.[SOURCE_NAME]
				  ,sm.[SOURCE_DATE]
				  ,[CROSSOWN]
				  ,[ISSUE_TAX_TYPE]
				  ,[FWD_BROKER_CODE]
				  ,[TRADING_FLAT]
				  ,[GL_PRODUCT_CODE]
				  ,[COUNTRY_OF_RISK]
				  ,[COST_BASIS_RULE_TYPE]
				  ,[RISK_CLASSIFICATION_TYPE]
				  ,[INTERNATIONAL_SUKUK]
				  ,[DOMESTIC_SUKUK]
				  ,[INDUSTRY_GROUP]
				  ,[INDUSTRY_SECTOR]
				  ,[INDUSTRY_SUBGROUP]
				  ,[INDUSTRY_SUBGROUP_NUMBER]
				  ,[SECURITY_TYPE2]
				  ,[ANNOUNCEMENT_DATE]
				  ,[MARKET_SECTOR_DESCRIPTION]
				  ,[SECURITY_DESCRIPTION]
				  ,[SHORT_NAME]
				  ,[ISSUER_INDUSTRY]
				  ,[GICS_SECTOR]
				  ,[GICS_NAME]
				  ,[GICS_INDUSTRY_GROUP]
				  ,[GICS_INDUSTRY_GROUP_NAME]
				  ,[GICS_INDUSTRY]
				  ,[GICS_INDUSTRY_NAME]
				  ,[GICS_SUB_INDUSTRY]
				  ,[GICS_SUB_INDUSTRY_NAME]
				  ,[TRADING_STATUS]
				  ,[COUNTRY_OF_ISSUE]
				  ,[NAIC_CODE]
				  ,[GICS_OVERRIDE_SUB_INDUSTRY]
				  ,[GICS_OVERRIDE_INDUSTRY]
				  ,[GICS_OVERRIDE_INDUSTRY_GROUP]
				  ,[GICS_OVERRIDE_SECTOR]
				  ,[ASSOCIATED_VARIABLE_CUSIP]
				  ,[BLOOMBERG_SECTOR_CODE]
				  ,[INDUSTRY_SECTOR_NUM]
				  ,[MSCI_COUNTRY_CODE]

				  ,sm.USER_GROUP_SECTOR14 Asset_Class_Type_Code
			  
				  ,smd.User_Group_Desc6 [Industry_Sub_Sector]
				  ,smd.User_Group_Desc7 [PRI_GRESB_Classificatoin]
				  ,smd.User_Group_Desc8 [OECD_Non_OECD]
				  ,smd.User_Group_Desc15 Asset_Class
				  ,smd.User_Group_Desc16 [Investment_Structure]
				  ,smd.User_Group_Desc17 [Investment_Type]
				  ,smd.User_Group_Desc18 Risk_Strategy
				  ,smd.User_Group_Char6 [Vintage]
				  ,smd.User_Group_Char10 Sector
				  ,smd.User_Group_Char11 [Region]
				  ,smd.User_Group_Char14 [Revenue_source]
				  ,GICSSEC.Long_Desc [GICS_Sector_Long_Name]
				  ,GICSIG.Long_Desc [GICS_Industry_Group_Long_Name]
				  ,smd.User_Group_Desc12 Instrument_Profile
			From [PSA].[v_Eagle_Security_Master] sm 
			left Join [PSA].[v_Eagle_Security_Master_Detail] smd on smd.[SECURITY_ALIAS] = convert(varchar(255), sm.[SECURITY_ALIAS])
			Left Join [PSA].[v_Eagle_SecMaster_Detail_Ext] smde on smd.[SECURITY_ALIAS] = smde.[SECURITY_ALIAS]
			Left Join (SELECT Rtrim(CV.short_DESC) short_DESC, cv.long_desc											
					   FROM PSA.V_Eagle_CODES C 
					   INNER JOIN PSA.V_Eagle_CODE_VALUES CV ON C.INSTANCE = CV.CODE_INST 
					   WHERE C.SHORT_DESC = 'GICSINDGROUP'
					  ) GICSIG	ON SMDE.GICS_INDUSTRY_GROUP = GICSIG.SHORT_DESC														
															
			Left Join (SELECT Rtrim(CV.short_DESC) short_DESC, cv.long_desc	 														
						FROM PSA.V_Eagle_CODES C 
					   INNER JOIN PSA.V_Eagle_CODE_VALUES CV ON C.INSTANCE = CV.CODE_INST 
					   WHERE C.SHORT_DESC ='GICSSECTOR'
					  ) GICSSEC	ON SMDE.GICS_SECTOR =GICSSEC.SHORT_DESC
			-- Where smd.Is_Src_Deleted = 0 and sm.Is_Src_Deleted = 0 and smde.Is_Src_Deleted = 0
		) src
		
		Insert Into [EDW_Common].[Dim_Eagle_Security_Detail] (
					  Security_Id
					  ,[SECURITY_ALIAS]

					  ,[ISSUER_ID]
					  ,[COUPON]
					  ,[COUPON_FRACTIONAL_INDICATOR]
					  ,[CURRENCY_CODE]
					  ,[SETTLEMENT_CURRENCY]
					  ,[EXPIRATION_DATE]
					  ,[INVESTMENT_TYPE_CODE]
					  ,[ISSUE_AMOUNT]
					  ,[ISSUE_DESCRIPTION]
					  ,[ISSUE_ID]
					  ,[ISSUE_NAME]
					  ,[MAT_DATE]
					  ,[NRA_TAX_COUNTRY]
					  ,[POOL_NUMBER]
					  ,[PRIMARY_ASSET_ID]
					  ,[PRIMARY_ASSET_ID_TYPE]
					  ,[SECURITY_DESC2]
					  ,[SECURITY_TYPE]
					  ,[TICKER]
					  ,[COUPON_FREQ_CODE]
					  ,[COUPON_TYPE_CODE]
					  ,[SECURITY_MINOR_TYPE]
					  ,[LEGAL_STATUS_CODE]
					  ,[COUPON_DAY_OF_MONTH]
					  ,[CUSIP_CHANGE]
					  ,[ANALYST_CODE]
					  ,[EXCHANGE]
					  ,[PRICE_MULTIPLIER]
					  ,[DEF_PRICE_SOURCE]
					  ,[ALT_ASSET_ID]
					  ,[ALT_ASSET_ID_TYPE]
					  ,[CREATE_DATE]
					  ,[ALT_INVESTMENT_TYPE]
					  ,[ALT_SECURITY_TYPE]
					  ,[ENTITY_ID]
					  ,[DEALERID]
					  ,[LOOK_THRU_IND]
					  ,[LOOK_THRU_VALUE]
					  ,[SOURCE_NAME]
					  ,[SOURCE_DATE]
					  ,[CROSSOWN]
					  ,[ISSUE_TAX_TYPE]
					  ,[FWD_BROKER_CODE]
					  ,[TRADING_FLAT]
					  ,[GL_PRODUCT_CODE]
					  ,[COUNTRY_OF_RISK]
					  ,[COST_BASIS_RULE_TYPE]
					  ,[RISK_CLASSIFICATION_TYPE]
					  ,[INTERNATIONAL_SUKUK]
					  ,[DOMESTIC_SUKUK]
					  ,[INDUSTRY_GROUP]
					  ,[INDUSTRY_SECTOR]
					  ,[INDUSTRY_SUBGROUP]
					  ,[INDUSTRY_SUBGROUP_NUMBER]
					  ,[SECURITY_TYPE2]
					  ,[ANNOUNCEMENT_DATE]
					  ,[MARKET_SECTOR_DESCRIPTION]
					  ,[SECURITY_DESCRIPTION]
					  ,[SHORT_NAME]
					  ,[ISSUER_INDUSTRY]
					  ,[GICS_SECTOR]
					  ,[GICS_NAME]
					  ,[GICS_INDUSTRY_GROUP]
					  ,[GICS_INDUSTRY_GROUP_NAME]
					  ,[GICS_INDUSTRY]
					  ,[GICS_INDUSTRY_NAME]
					  ,[GICS_SUB_INDUSTRY]
					  ,[GICS_SUB_INDUSTRY_NAME]
					  ,[TRADING_STATUS]
					  ,[COUNTRY_OF_ISSUE]
					  ,[NAIC_CODE]
					  ,[GICS_OVERRIDE_SUB_INDUSTRY]
					  ,[GICS_OVERRIDE_INDUSTRY]
					  ,[GICS_OVERRIDE_INDUSTRY_GROUP]
					  ,[GICS_OVERRIDE_SECTOR]
					  ,[ASSOCIATED_VARIABLE_CUSIP]
					  ,[BLOOMBERG_SECTOR_CODE]
					  ,[INDUSTRY_SECTOR_NUM]
					  ,[MSCI_COUNTRY_CODE]

					  ,Asset_Class_Type_Code
					  ,[Industry_Sub_Sector]
					  ,[PRI_GRESB_Classificatoin]
					  ,[OECD_Non_OECD]
					  ,Asset_Class
					  ,[Investment_Structure]
					  ,[Investment_Type]
					  ,Risk_Strategy
					  ,[Vintage]
					  ,Sector
					  ,[Region]
					  ,[Revenue_source]
					  ,[GICS_Sector_Long_Name]
					  ,[GICS_Industry_Group_Long_Name]
					  ,Instrument_Profile
					  ,[Hash_Diff]
					  ,[Record_Start_DTS]
					  ,[Record_End_DTS]
					  ,[Record_Is_Current_Flag]
					  ,[Last_Update_DTS]
					  ,[ETL_Load_Key]
		)
		Select		[SECURITY_ALIAS] Security_Id
					,[SECURITY_ALIAS]

					,[ISSUER_ID]
					,[COUPON]
					,[COUPON_FRACTIONAL_INDICATOR]
					,[CURRENCY_CODE]
					,[SETTLEMENT_CURRENCY]
					,[EXPIRATION_DATE]
					,[INVESTMENT_TYPE_CODE]
					,[ISSUE_AMOUNT]
					,[ISSUE_DESCRIPTION]
					,[ISSUE_ID]
					,[ISSUE_NAME]
					,[MAT_DATE]
					,[NRA_TAX_COUNTRY]
					,[POOL_NUMBER]
					,[PRIMARY_ASSET_ID]
					,[PRIMARY_ASSET_ID_TYPE]
					,[SECURITY_DESC2]
					,[SECURITY_TYPE]
					,[TICKER]
					,[COUPON_FREQ_CODE]
					,[COUPON_TYPE_CODE]
					,[SECURITY_MINOR_TYPE]
					,[LEGAL_STATUS_CODE]
					,[COUPON_DAY_OF_MONTH]
					,[CUSIP_CHANGE]
					,[ANALYST_CODE]
					,[EXCHANGE]
					,[PRICE_MULTIPLIER]
					,[DEF_PRICE_SOURCE]
					,[ALT_ASSET_ID]
					,[ALT_ASSET_ID_TYPE]
					,[CREATE_DATE]
					,[ALT_INVESTMENT_TYPE]
					,[ALT_SECURITY_TYPE]
					,[ENTITY_ID]
					,[DEALERID]
					,[LOOK_THRU_IND]
					,[LOOK_THRU_VALUE]
					,[SOURCE_NAME]
					,[SOURCE_DATE]
					,[CROSSOWN]
					,[ISSUE_TAX_TYPE]
					,[FWD_BROKER_CODE]
					,[TRADING_FLAT]
					,[GL_PRODUCT_CODE]
					,[COUNTRY_OF_RISK]
					,[COST_BASIS_RULE_TYPE]
					,[RISK_CLASSIFICATION_TYPE]
					,[INTERNATIONAL_SUKUK]
					,[DOMESTIC_SUKUK]
					,[INDUSTRY_GROUP]
					,[INDUSTRY_SECTOR]
					,[INDUSTRY_SUBGROUP]
					,[INDUSTRY_SUBGROUP_NUMBER]
					,[SECURITY_TYPE2]
					,[ANNOUNCEMENT_DATE]
					,[MARKET_SECTOR_DESCRIPTION]
					,[SECURITY_DESCRIPTION]
					,[SHORT_NAME]
					,[ISSUER_INDUSTRY]
					,[GICS_SECTOR]
					,[GICS_NAME]
					,[GICS_INDUSTRY_GROUP]
					,[GICS_INDUSTRY_GROUP_NAME]
					,[GICS_INDUSTRY]
					,[GICS_INDUSTRY_NAME]
					,[GICS_SUB_INDUSTRY]
					,[GICS_SUB_INDUSTRY_NAME]
					,[TRADING_STATUS]
					,[COUNTRY_OF_ISSUE]
					,[NAIC_CODE]
					,[GICS_OVERRIDE_SUB_INDUSTRY]
					,[GICS_OVERRIDE_INDUSTRY]
					,[GICS_OVERRIDE_INDUSTRY_GROUP]
					,[GICS_OVERRIDE_SECTOR]
					,[ASSOCIATED_VARIABLE_CUSIP]
					,[BLOOMBERG_SECTOR_CODE]
					,[INDUSTRY_SECTOR_NUM]
					,[MSCI_COUNTRY_CODE]

					  ,Asset_Class_Type_Code
					  ,[Industry_Sub_Sector]
					  ,[PRI_GRESB_Classificatoin]
					  ,[OECD_Non_OECD]
					  ,Asset_Class
					  ,[Investment_Structure]
					  ,[Investment_Type]
					  ,Risk_Strategy
					  ,[Vintage]
					  ,Sector
					  ,[Region]
					  ,[Revenue_source]
					  ,[GICS_Sector_Long_Name]
					  ,[GICS_Industry_Group_Long_Name]
					  ,Instrument_Profile

					,[Hash_Diff]
			  
				  , @today, null, 1, @today, @ETL_Load_Key
		From #temp_src_security_detail_records src
		Where not exists (
			Select 1
			From [EDW_Common].[Dim_Eagle_Security_detail] tgt
			where Record_Is_Current_Flag = 1 and src.[SECURITY_ALIAS] = tgt.[SECURITY_ALIAS] 
			and coalesce(src.[Hash_Diff],'') = coalesce(tgt.[Hash_Diff],'')

		)

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Dim_Eagle_Security_Detail] tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_security_detail_records src
			Where  src.[SECURITY_ALIAS] = tgt.[SECURITY_ALIAS] 
			       and coalesce(tgt.[Hash_Diff],'') <> coalesce(src.[Hash_Diff],'')
		)

		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Eagle_Security_Detail]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Eagle_Security_Detail]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Eagle_Security_Detail', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Eagle_Security_Detail', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END