﻿CREATE PROC [EDW_Common].[IMCOManual_Bridge_Pool_Portfolio_Mapping] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2
	
	Begin Try

		Select @lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From [EDW_Common].[Bridge_Pool_Portfolio_Mapping]

		IF OBJECT_ID('tempdb..#temp_src_manual_portfolio_mapping') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_manual_portfolio_mapping
		END

		create table #temp_src_manual_portfolio_mapping
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select D.Dim_Date_Key
			,D.Date
			,Portfolio_ID
			,Security_Id
			,[Pool_Portfolio_Id]
			,min(Primary_Asset_Id) Primary_Asset_Id
			,min(Load_DTS) Load_DTS
			,min(case when Is_Src_Deleted = 1 then 1 else 0 end) IS_Src_Deleted
			,min(convert(varchar(64), Hashbytes('SHA1', upper(coalesce(Rtrim([Pool_Portfolio_Id]),''))),2)) Hash_Diff
		from (
				SELECT [Portfolio_ID]
					  ,coalesce(convert(varchar(100), s.Security_Alias),'NA') Security_Id
					  ,m.Primary_Asset_Id
					  ,coalesce([Pool_Portfolio_Id],'NA') [Pool_Portfolio_Id]
					  ,[Start_Date]
					  ,[End_Date]
					  ,m.[Is_Src_Deleted]
					  ,m.Load_DTS
					  ,Row_Number() Over(Partition By [Portfolio_ID], m.Primary_Asset_Id, [Pool_Portfolio_Id], [Start_Date] Order by m.Load_DTS Desc) rn
				  FROM [PSA].Manual_Pool_Portfolio_Mapping m
				  Left Join PSA.V_Eagle_Security_Master s on m.Primary_Asset_Id = s.Primary_Asset_Id and s.Is_Src_Deleted = 0
				  where m.[Portfolio_ID] is not null
		) mpm
		Join EDW_Common.Dim_Date D on D.Date between mpm.Start_Date and case mpm.End_Date When '2099-12-31' Then getdate() Else mpm.End_Date End
		Where mpm.rn = 1 
		Group By D.Dim_Date_Key, D.Date, mpm.Portfolio_ID, Security_Id, [Pool_Portfolio_Id]


		INSERT INTO [EDW_Common].[Bridge_Pool_Portfolio_Mapping]
        (   
			Dim_Date_Key
		   ,[Dim_Portfolio_Key]
		   ,[Pool_Dim_Portfolio_Key] 
		   ,[Pool_Dim_Security_Key] 
		   ,[Relation_Type]
		   ,Is_Src_Deleted
		   ,Load_DTS
		   ,Record_Created_DTS
           ,[Last_Update_DTS]
		   ,Other_Info
           ,[Hash_Diff]
           ,[ETL_Load_Key]
		)
		SELECT		t.Dim_Date_Key
				   ,coalesce(p.[Dim_Portfolio_Key], -1) [Dim_Portfolio_Key]
				   ,coalesce(c_pp.[Dim_Portfolio_Key], -1) [Pool_Dim_Portfolio_Key]
				   ,coalesce(c_sec.Dim_Security_Key, -1) Pool_Dim_Security_Key
				   ,'Manual_Mapping'
				   ,t.IS_Src_Deleted
				   ,t.Load_DTS
				   ,@today
				   ,@today
				   ,'{"Portfolio":' + t.Portfolio_Id + '",' + 
					'"Pool_Portfolio":' + t.Pool_Portfolio_Id + '",' + 
					'"Security_Alias":' + t.Security_Id + '",' + 
					'"Primary_Asset_Id":' + t.Primary_Asset_Id + 
					'}'
				   ,t.Hash_Diff
					,@ETL_Load_Key
		From #temp_src_manual_portfolio_mapping t
		Left Join EDW_Common.Dim_Portfolio p on t.Portfolio_ID = p.Portfolio_Id and t.Date between p.Record_Start_DTS and coalesce(p.[Record_End_DTS],'2099-12-31')
		Left Join EDW_Common.Dim_Portfolio c_pp on t.[Pool_Portfolio_Id] = c_pp.Portfolio_Id and c_pp.Record_Is_Current_Flag = 1
		Left Join EDW_Common.Dim_Security c_sec on t.[Security_Id] = c_sec.Security_Id and c_sec.Instrument_Type = 'NA' and c_sec.Record_Is_Current_Flag = 1

		where not exists (
			Select 1
			From [EDW_Common].[Bridge_Pool_Portfolio_Mapping] tgt
			Join EDW_Common.Dim_Portfolio pt on tgt.Dim_Portfolio_Key = pt.Dim_Portfolio_Key
			Join EDW_Common.Dim_Portfolio ppt on tgt.Pool_Dim_Portfolio_Key = ppt.Dim_Portfolio_Key
			Join EDW_Common.Dim_Security sec on tgt.Pool_Dim_Security_Key = sec.Dim_Security_Key
			where tgt.Dim_Date_Key = t.Dim_Date_Key and pt.Portfolio_Id = t.Portfolio_ID and t.Pool_Portfolio_ID = ppt.Portfolio_Id 
			and sec.Security_Id = t.[Security_Id] and tgt.Is_Src_Deleted = 0
		) and t.Is_Src_Deleted = 0


		Update tgt
		Set Last_Update_DTS = @today, Is_Src_Deleted = 1, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Bridge_Pool_Portfolio_Mapping] tgt
		Join EDW_Common.Dim_Portfolio pt on tgt.Dim_Portfolio_Key = pt.Dim_Portfolio_Key
		Join EDW_Common.Dim_Portfolio ppt on tgt.Pool_Dim_Portfolio_Key = ppt.Dim_Portfolio_Key
		Join EDW_Common.Dim_Security sec on tgt.Pool_Dim_Security_Key = sec.Dim_Security_Key
		Where tgt.Is_Src_Deleted = 0 and 
		      (
				tgt.[Relation_Type] = 'Manual_Mapping' and
				not exists
				(
					Select 1
					From #temp_src_manual_portfolio_mapping src
					Where pt.Portfolio_Id = src.Portfolio_Id and tgt.Dim_Date_Key = src.Dim_Date_Key 
						    and src.Pool_Portfolio_ID = ppt.Portfolio_Id 
							and sec.Security_Id = src.Security_Id
							and src.Is_Src_Deleted = 0
				)

			  )


		Select @rowsInserted = Count(*) 
		From EDW_Common.[Bridge_Pool_Portfolio_Mapping]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 0

		Select @rowsExpired = Count(*)
		From EDW_Common.[Bridge_Pool_Portfolio_Mapping]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 1

		Select @rowsUpdated = @rowsExpired


		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Bridge_Pool_Portfolio_Mapping', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Bridge_Pool_Portfolio_Mapping', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 500001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END