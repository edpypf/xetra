﻿CREATE PROC [EDW_Common].[Eagle_Fact_Eagle_Total_Portfolio_Holding_Performance] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2
	
	Begin Try


		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From [EDW_Common].Fact_Eagle_Total_Portfolio_Holding_Performance


		INSERT INTO [EDW_Common].[Fact_Eagle_Total_Portfolio_Holding_Performance]
           ([Dim_Portfolio_Key]
		   ,Dim_Eagle_Portfolio_Detail_Key
		   ,[Dim_Security_Key]
		   ,[Dim_Eagle_Security_Detail_Key]
           ,[Dim_Date_Key]
		   ,Report_Freq_Code
           ,[Load_DTS]
           ,[ABAL]
           ,[Beginning_Market_Value]
           ,[DAILY_WTD_ADJ]
           ,[DVA]
           ,[Ending_Market_Value]
           ,[INC_ADJ_WTD]
           ,[MARKET_VALUE]
           ,[Report_Freq_Return]
           ,[MTD_IRR_RETURN]
           ,[MTD_IRR_RETURN_NET]
           ,[PRIN_RETURN]
           ,[QTD_AFTER_TAX_RETURN]
           ,[QTD_BEFORE_TAX_RETURN]
           ,[QTD_IRR_RETURN]
           ,[TOT_RETURN_NET]
           ,[UNIT_VALUE_PRIN]
           ,[UNIT_VALUE_TOT]
           ,[UPDATE_DATE]
           ,[UPDATE_SOURCE]
           ,[YTD_AFTER_TAX_RETURN]
           ,[YTD_BEFORE_TAX_RETURN]
           ,[YTD_IRR_RETURN]
           ,[YTD_MOD_DIETZ_RETURN]
           ,[YTD_PRIN_RETURN]
           ,[YTD_TOT_RETURN_NET]
           ,[Last_Update_DTS]
           ,[Hash_Diff]
           ,[ETL_Load_Key]
		   ,Is_Src_Deleted
		)
		SELECT      Coalesce(p.Dim_Portfolio_Key, -1) [Dim_Portfolio_Key]
					,Coalesce(pd.Dim_Eagle_Portfolio_Detail_Key,-1) Dim_Eagle_Portfolio_Detail_Key
					,Coalesce(s.Dim_Security_Key, -1) Dim_Security_Key
					,Coalesce(sd.Dim_Eagle_Security_Detail_Key,-1) Dim_Eagle_Security_Detail_Key
					,convert(int, convert(varchar(15), Effective_Date, 112)) [Dim_Date_Key]
					,src.PERF_FREQ_CODE
					,src.Load_DTS
					, [ABAL]
					, [Beginning_Market_Value]
					, [DAILY_WTD_ADJ]
					, [DVA]
					, [Ending_Market_Value]
					, [INC_ADJ_WTD]
					, [MARKET_VALUE]
					, [Report_Freq_Return]
					, [MTD_IRR_RETURN]
					, [MTD_IRR_RETURN_NET]
					, [PRIN_RETURN]
					, [QTD_AFTER_TAX_RETURN]
					, [QTD_BEFORE_TAX_RETURN]
					, [QTD_IRR_RETURN]
					, [TOT_RETURN_NET]
					, [UNIT_VALUE_PRIN]
					, [UNIT_VALUE_TOT]
					, [UPDATE_DATE]
					, [UPDATE_SOURCE]
					, [YTD_AFTER_TAX_RETURN]
					, [YTD_BEFORE_TAX_RETURN]
					, [YTD_IRR_RETURN]
					, [YTD_MOD_DIETZ_RETURN]
					, [YTD_PRIN_RETURN]
					, [YTD_TOT_RETURN_NET]
					,@today
					,src.Hash_Diff
					,@ETL_Load_Key
					,src.Is_Src_Deleted

		From (
				SELECT E.Entity_ID Portfolio_Id
				      ,PSR.SECURITY_ALIAS
				      ,PS.End_Effective_Date Effective_Date
					  ,PS.PERF_FREQ_CODE
					  ,PSR.Load_DTS
					  ,[ABAL]
					  ,PSR_USER_FLOAT1 [Beginning_Market_Value]
					  ,[DAILY_WTD_ADJ]
					  ,[DVA]
					  ,PSR_USER_FLOAT2 [Ending_Market_Value]
					  ,[INC_ADJ_WTD]
					  ,[MARKET_VALUE]
					  ,PSR_USER_FLOAT8 [Report_Freq_Return]
					  ,[MTD_IRR_RETURN]
					  ,[MTD_IRR_RETURN_NET]
					  ,[PRIN_RETURN]
					  ,[QTD_AFTER_TAX_RETURN]
					  ,[QTD_BEFORE_TAX_RETURN]
					  ,[QTD_IRR_RETURN]
					  ,[TOT_RETURN_NET]
					  ,[UNIT_VALUE_PRIN]
					  ,[UNIT_VALUE_TOT]
					  ,PSR.[UPDATE_DATE]
					  ,PSR.[UPDATE_SOURCE]
					  ,[YTD_AFTER_TAX_RETURN]
					  ,[YTD_BEFORE_TAX_RETURN]
					  ,[YTD_IRR_RETURN]
					  ,[YTD_MOD_DIETZ_RETURN]
					  ,[YTD_PRIN_RETURN]
					  ,[YTD_TOT_RETURN_NET]
					  ,PSR.Hash_Diff
					  ,PSR.Is_Src_Deleted
				  FROM   PSA.Eagle_Perf_Sec_Returns    PSR 
                    Inner Join PSA.V_Eagle_Perf_Summary  PS ON PS.PERF_SUM_INST  = PSR.PERF_SUM_INST 
                    Inner Join PSA.V_Eagle_Entity             E ON PS.ENTITY_ID      = E.ENTITY_ID 
                    Inner Join PSA.V_Eagle_Interfaces         I ON PS.SRC_INTFC_INST = I.INSTANCE
					Inner join PSA.V_Eagle_Security_Master S on S.SECURITY_ALIAS=PSR.SECURITY_ALIAS
                    WHERE PS.DICTIONARY_ID     = 0         
                    AND PS.PERF_FREQ_CODE    in ('D','M')
                    AND PS.PERF_SUMMARY_TYPE = 'S'        
					AND PS.SRC_INTFC_INST= 4
                    AND E.Entity_Type in ('SUB','PORT', 'COMP') -- Total Perfomance, Daily, Portfolio level, Portfolios and Composites
					and Isnull(S.user_group_sector14,0)<>'010' -- fee securities
					and PSR.Load_DTS > Coalesce(@lastLoadeDTS, '1900-01-01')
					-- and coalesce(PSR.Is_Src_Deleted, 0) = 0
			) src
			Left Join EDW_Common.Dim_Portfolio p on src.Portfolio_Id = p.Portfolio_Id and src.Effective_Date between p.Record_Start_DTS and coalesce(p.[Record_End_DTS], '9999-12-31') 
			Left Join EDW_Common.Dim_Eagle_Portfolio_Detail pd on src.Portfolio_Id = pd.Portfolio_Id and pd.Record_Is_Current_Flag = 1
			Left Join EDW_Common.Dim_Security s on 'Eagle_' + src.SECURITY_ALIAS = s.Src_Security_Id and s.Record_Is_Current_Flag = 1
			Left Join EDW_Common.Dim_Eagle_Security_Detail sd on src.SECURITY_ALIAS = sd.Security_Id and sd.Record_Is_Current_Flag = 1

		Select @rowsInserted = Count(*) 
		From EDW_Common.Fact_Eagle_Total_Portfolio_Holding_Performance
		Where Last_Update_DTS = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Total_Portfolio_Holding_Performance', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Total_Portfolio_Holding_Performance', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW @ErrorCode,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END