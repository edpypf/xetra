﻿CREATE PROC [EDW_Common].[Eagle_Dim_Eagle_Index_Detail] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_index_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_index_records
		END

		-- load everything from source

		create table #temp_src_index_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select *
		From (
			Select [Entity_ID] Index_Id
					,[ASSET_CLASS]
					,[BANK_ACCOUNT_NUMBER]
					,[BASE_CURRENCY]
					,[BUSINESS_SECTOR]
					,[COSTCASH_BULKING]
					,[COUNTRY_OF_TAX]
					,[CUSTODY_BANK]
					,[CUSTOMER_TYPE]
					,[DYNAGG_FLAG]
					,[ENTITY_BUILD_FLAG]
					,[ENTITY_SUB_TYPE]
					,[FLOATWEIGHT_FLAG]
					,[FX_DAYS_OFFSET]
					,[FX_SOURCE_RULE_ID]
					,[LEGAL_STATUS]
					,[MANAGER_NAME]
					,[MARKETING_GROUP]
					,[PARENT_COUNTRY_CODE]
					,[PORTFOLIO_TYPE_CODE]
					,[RELEASE_STATUS]
					,[REPORTING_NAME]
					,[RISK_COUNTRY_CODE]
					,[SRC_INTFC_INST]
					,[STAR_PARTITION]
					,[STATE_CODE]
					,[STYLE]
					,[TAX_STATUS]
					,[UNIT_OFFICER]
					,[UPD_USER]
					,[UPD_DATE]
					,[USER_DATE3]
					,[USER_DATE4]
					,[USER_DATE5]
					,[USER_FIELD4]
					,[USER_FIELD6]
					,CONVERT(VARCHAR(64), hashbytes('SHA1', UPPER(Concat([ASSET_CLASS], '|' ,[BANK_ACCOUNT_NUMBER], '|' ,[BASE_CURRENCY], '|' 
																		,[BUSINESS_SECTOR], '|' ,[COSTCASH_BULKING], '|' ,[COUNTRY_OF_TAX], '|' ,[CUSTODY_BANK], '|' 
																		,[CUSTOMER_TYPE], '|' ,[DYNAGG_FLAG], '|' ,[ENTITY_BUILD_FLAG], '|' ,[ENTITY_SUB_TYPE], '|' 
																		,[FLOATWEIGHT_FLAG], '|' ,[FX_DAYS_OFFSET], '|' ,[FX_SOURCE_RULE_ID], '|' ,[LEGAL_STATUS], '|' 
																		,[MANAGER_NAME], '|' ,[MARKETING_GROUP], '|' ,[PARENT_COUNTRY_CODE], '|' ,[PORTFOLIO_TYPE_CODE], '|' 
																		,[RELEASE_STATUS], '|' ,[REPORTING_NAME], '|' ,[RISK_COUNTRY_CODE], '|' ,[SRC_INTFC_INST], '|' 
																		,[STAR_PARTITION], '|' ,[STATE_CODE], '|' ,[STYLE], '|' ,[TAX_STATUS], '|' ,[UNIT_OFFICER], '|' 
																		,[UPD_USER], '|' ,[UPD_DATE], '|' ,[USER_DATE3], '|' ,[USER_DATE4], '|' ,[USER_DATE5], '|' 
																		,[USER_FIELD4], '|' ,[USER_FIELD6]))), 2) as Hash_Diff
					,Is_Src_Deleted
					,Row_Number() Over (Partition By Entity_Id order by Load_DTS Desc) rn
			From PSA.Eagle_Entity 
			Where Entity_Type in ('CIDX', 'INDX','AGG', 'SUB')
		) src
		where rn = 1 



		
		Insert Into EDW_Common.Dim_Eagle_Index_Detail(
				  Index_Id
				,[ASSET_CLASS]
				,[BANK_ACCOUNT_NUMBER]
				,[BASE_CURRENCY]
				,[BUSINESS_SECTOR]
				,[COSTCASH_BULKING]
				,[COUNTRY_OF_TAX]
				,[CUSTODY_BANK]
				,[CUSTOMER_TYPE]
				,[DYNAGG_FLAG]
				,[Index_BUILD_FLAG]
				,[Index_SUB_TYPE]
				,[FLOATWEIGHT_FLAG]
				,[FX_DAYS_OFFSET]
				,[FX_SOURCE_RULE_ID]
				,[LEGAL_STATUS]
				,[MANAGER_NAME]
				,[MARKETING_GROUP]
				,[PARENT_COUNTRY_CODE]
				,[PORTFOLIO_TYPE_CODE]
				,[RELEASE_STATUS]
				,[REPORTING_NAME]
				,[RISK_COUNTRY_CODE]
				,[SRC_INTFC_INST]
				,[STAR_PARTITION]
				,[STATE_CODE]
				,[STYLE]
				,[TAX_STATUS]
				,[UNIT_OFFICER]
				,[UPD_USER]
				,[UPD_DATE]
				,[USER_DATE3]
				,[USER_DATE4]
				,[USER_DATE5]
				,[USER_FIELD4]
				,[USER_FIELD6]
				,[Record_Start_DTS]
				,[Record_End_DTS]
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		) 
		Select Index_Id
			  ,[ASSET_CLASS]
				,[BANK_ACCOUNT_NUMBER]
				,[BASE_CURRENCY]
				,[BUSINESS_SECTOR]
				,[COSTCASH_BULKING]
				,[COUNTRY_OF_TAX]
				,[CUSTODY_BANK]
				,[CUSTOMER_TYPE]
				,[DYNAGG_FLAG]
				,[ENTITY_BUILD_FLAG]
				,[ENTITY_SUB_TYPE]
				,[FLOATWEIGHT_FLAG]
				,[FX_DAYS_OFFSET]
				,[FX_SOURCE_RULE_ID]
				,[LEGAL_STATUS]
				,[MANAGER_NAME]
				,[MARKETING_GROUP]
				,[PARENT_COUNTRY_CODE]
				,[PORTFOLIO_TYPE_CODE]
				,[RELEASE_STATUS]
				,[REPORTING_NAME]
				,[RISK_COUNTRY_CODE]
				,[SRC_INTFC_INST]
				,[STAR_PARTITION]
				,[STATE_CODE]
				,[STYLE]
				,[TAX_STATUS]
				,[UNIT_OFFICER]
				,[UPD_USER]
				,[UPD_DATE]
				,[USER_DATE3]
				,[USER_DATE4]
				,[USER_DATE5]
				,[USER_FIELD4]
				,[USER_FIELD6]
			  ,@today
			  ,null
			  ,1
			  ,@today
			  ,src.Hash_Diff
			  ,@ETL_Load_Key
		From #temp_src_index_records src
		Where not exists (
			Select 1
			From EDW_Common.Dim_Eagle_Index_Detail tgt
			where src.Index_Id = tgt.Index_Id and src.Hash_Diff = tgt.Hash_Diff
		)
		and src.Is_Src_Deleted = 0


		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].Dim_Eagle_Index_Detail tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_index_records src
			Where tgt.Index_Id = src.Index_Id and ((coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') and src.Is_Src_Deleted = 0) or src.Is_Src_Deleted = 1)
		)


		Select @rowsInserted = Count(*) 
		From EDW_Common.Dim_Eagle_Index_Detail
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].Dim_Eagle_Index_Detail
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired


		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Eagle_Index_Detail', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Eagle_Index_Detail', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END