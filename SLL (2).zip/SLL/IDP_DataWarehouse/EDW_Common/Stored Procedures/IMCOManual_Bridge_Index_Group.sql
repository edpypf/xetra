﻿CREATE PROC [EDW_Common].[IMCOManual_Bridge_Index_Group] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2
			
	
	Begin Try

		Select @lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From [EDW_Common].[Bridge_Index_Group]
		
		IF OBJECT_ID('tempdb..#temp_src_manual_index_group') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_manual_index_group
		END

		create table #temp_src_manual_index_group
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select 	D.Dim_Date_Key
			,D.Date
			,Index_Id
            ,Group_Name
			,min(Responsible_Team) Responsible_Team
			,min(Is_Src_Deleted) Is_Src_Deleted
			,min(Load_DTS) Load_DTS

			from (
		        SELECT Portfolio_ID Index_Id
                            ,Group_Name
							,Responsible_Team
                            ,Start_Date
                            ,End_Date
							,case when Is_Src_Deleted=1 then 1 else 0 end Is_Src_Deleted
							,Load_DTS
							,row_number() over (partition by Portfolio_ID, Group_Name, Start_Date order by Load_DTS DESC) rn
                FROM PSA.Manual_Portfolio_Groups

			) mpm
			Join EDW_Common.Dim_Date D on D.Date between mpm.Start_Date and case mpm.End_Date When '2099-12-31' Then getdate() Else mpm.End_Date End
			Where mpm.Index_Id is not null and Group_Name is not null and rn = 1 
			Group By D.Dim_Date_Key, D.Date, Index_Id, Group_Name

		INSERT INTO [EDW_Common].[Bridge_Index_Group]
        (   
			Dim_Date_Key
			,[Dim_Index_Key]
			,[Dim_Portfolio_Group_Key] 
           ,[Responsible_Team]
		   ,IS_Src_Deleted
		   ,Load_DTS
		   ,Record_Created_DTS
		   ,Other_Info
           ,[Last_Update_DTS]
           ,[Hash_Diff]
           ,[ETL_Load_Key]
		)
		SELECT		t.Dim_Date_Key
				   ,coalesce(p.[Dim_Index_Key], -1) [Dim_Index_Key]
				   ,coalesce(c_pg.[Dim_Portfolio_Group_Key], -1) [Dim_Portfolio_Group_Key]
				   ,Responsible_Team
				   ,t.Is_Src_Deleted
				   ,t.Load_DTS
				   ,@today
				   ,'{"Index":"' + t.Index_ID + '",' + 
				    '"Portfolio_Group":"' + t.Group_Name + '"}'
				   ,@today
					,null
					,@ETL_Load_Key

		From #temp_src_manual_index_group t
		Join EDW_Common.Dim_Index p on t.Index_ID = p.Index_Id and t.Date between p.Record_Start_DTS and coalesce(p.[Record_End_DTS], '9999-12-31')
		Join EDW_Common.Dim_Portfolio_Group c_pg on t.Group_Name = c_pg.Portfolio_Group_Name and c_pg.Record_Is_Current_Flag = 1

		where not exists (
			Select 1
			From [EDW_Common].[Bridge_Index_Group] tgt
			Join EDW_Common.Dim_Index pt on tgt.Dim_Index_Key= pt.Dim_Index_Key 
			Join EDW_Common.Dim_Portfolio_Group pgt on tgt.Dim_Portfolio_Group_Key= pgt.Dim_Portfolio_Group_Key 
			where t.Dim_Date_Key = tgt.Dim_Date_Key and t.Index_Id = pt.Index_Id and t.Group_Name = pgt.Portfolio_Group_Name 
			   and tgt.Is_Src_Deleted = 0
		) and t.Is_Src_Deleted = 0

		Select @rowsInserted = Count(*) 
		From EDW_Common.[Bridge_Index_Group]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 0

		Update tgt
		Set Last_Update_DTS = @today, Is_Src_Deleted = 1, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Bridge_Index_Group] tgt
		Join EDW_Common.Dim_Index p on tgt.Dim_Index_Key= p.Dim_Index_Key 
		Join EDW_Common.Dim_Portfolio_Group pgt on tgt.Dim_Portfolio_Group_Key= pgt.Dim_Portfolio_Group_Key 
		Where tgt.Is_Src_Deleted = 0 and exists
		(
			Select 1
			From #temp_src_manual_index_group src
			Where tgt.Dim_Date_Key = src.Dim_Date_Key and p.Index_Id = src.Index_Id and src.Group_Name = pgt.Portfolio_Group_Name 
			   and src.Is_Src_Deleted = 1
		)

		Select @rowsExpired = Count(*)
		From EDW_Common.[Bridge_Index_Group]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 1

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Bridge_Index_Group', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Bridge_Index_Group', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END