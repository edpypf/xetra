﻿CREATE PROC [EDW_Common].[Manual_Dim_SAA_Weight_Type] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0

			--,@ETL_Load_Key int = 3
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_saa_weight_type') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_saa_weight_type
		END

		-- load everything from source

		create table #temp_src_saa_weight_type
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 

		Select Distinct Weight_Type as Weight_Type_Id
				,Weight_Type
				,convert(varchar(64), hashbytes('SHA1', rtrim(Weight_Type)),2) Hash_Diff
		From PSA.Manual_Asset_Management_SAA
		Where Weight_Type is not null

		--union

		--select	'Benchmark Drifting SAA' as Weight_Type_Id,
		--		'Benchmark Drifting SAA' as Weight_Type,
		--		convert(varchar(64), hashbytes('SHA1', rtrim('Benchmark Drifting SAA')),2) Hash_Diff

		--union

		--select	trim(Benchmark_Source_Name) as Weight_Type_Id,
		--		'Sub Weight Drifting SAA' as Weight_Type,
		--		convert(varchar(64), hashbytes('SHA1', rtrim(Benchmark_Source_Name)),2) Hash_Diff
		--from PSA.V_Manual_Benchmark_Mapping
		--where EAGLE_PERF_BLEND_ID is not NULL

		union

		select	distinct 
				trim(Blend_Type) as Weight_Type_Id,
				trim(Blend_Type) as Weight_Type,
				convert(varchar(64), hashbytes('SHA1', rtrim(Blend_Type)),2) Hash_Diff
		from PSA.V_Manual_Benchmark_Mapping

		

		Insert Into [EDW_Common].Dim_SAA_Weight_Type (
		        SAA_Weight_Type_Id
				,SAA_Weight_Type
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select Weight_Type_Id, Weight_Type, @today, null, 1, @today, Hash_Diff, @ETL_Load_Key
		From #temp_src_saa_weight_type src
		Where not exists (
			Select 1
			From [EDW_Common].Dim_SAA_Weight_Type tgt
			where Record_Is_Current_Flag = 1 and src.Weight_Type_Id = tgt.SAA_Weight_Type_Id and src.Hash_Diff = tgt.Hash_Diff
		)

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].Dim_SAA_Weight_Type tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_saa_weight_type src
			Where tgt.SAA_Weight_Type_Id = src.Weight_Type_Id and coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')
		)

		Select @rowsInserted = Count(*) 
		From [EDW_Common].Dim_SAA_Weight_Type
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].Dim_SAA_Weight_Type
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_SAA_Weight_Type', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_SAA_Weight_Type', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END