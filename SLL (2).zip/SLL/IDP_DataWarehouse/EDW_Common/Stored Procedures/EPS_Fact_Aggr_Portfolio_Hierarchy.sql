﻿CREATE PROC [EDW_Common].[EPS_Fact_Aggr_Portfolio_Hierarchy] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @Effective_Date date,
		@rowsInserted int = 0,
		@rowsUpdated int = 0,
		@rowsExpired int = 0

	Declare @today datetime2 = getdate()

	IF Convert(date,@Batch_DTS) = '1900-01-01'
		BEGIN
			-- get effective date (previous business date) to check
			Set @Effective_Date = CASE DATEPART(weekday, @today) 
							WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
							WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
							ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
							END
		END 
		ELSE 
		BEGIN
			set @Effective_Date = @Batch_DTS
		END;

	Begin Try


		IF OBJECT_ID('tempdb..#eps_portfolio_hierarchy') IS NOT NULL
		BEGIN
			DROP TABLE #eps_portfolio_hierarchy
		END

		create table #eps_portfolio_hierarchy
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as
		With share_par_value as
		(
			select b.dim_date_key 
				,b.dim_portfolio_key
				,b.Dim_Client_Key
				,p.Portfolio_Id 	
				,f.share_par_value 
				,f.market_value
			From [EDW_Common].[V_Fact_Aggr_EPS_Portfolio_Hierarchy_Base] b
			join edw_common.dim_portfolio p on b.dim_portfolio_key = p.dim_portfolio_key
			join edw_common.dim_security s on b.dim_security_key = s.dim_security_key
			join edw_common.dim_client c on b.dim_client_key = c.dim_client_Key
			left join (
				Select fs.Dim_Date_Key, fs.Security_Id, m.Client_Id, fs.share_par_value, fs.market_value
				From (
					Select  ap.Dim_Date_Key, 
							p.Portfolio_Id,
							s.Security_Id,
							ap.shares_par_value as share_par_value,
							ap.base_market_value as market_value
					From [EDW_Common].[V_Fact_StateStreet_Account_Position] ap
					join edw_common.dim_portfolio p on ap.dim_portfolio_key = p.dim_portfolio_key
					join edw_common.dim_security s on ap.dim_security_key = s.dim_security_key
			
				) fs 
				left join (
					Select Distinct m.dim_date_key, p.portfolio_id, c.client_id
					From edw_common.bridge_portfolio_mapping m 
					join edw_common.dim_portfolio p on m.dim_portfolio_key = p.dim_portfolio_key
					join edw_common.dim_client c on m.dim_client_key = c.dim_client_Key
				) m on fs.dim_date_key = m.dim_date_Key and fs.portfolio_id = m.portfolio_Id 
			) f on b.Dim_Date_Key = f.Dim_Date_Key and s.Security_Id = f.Security_Id and c.Client_Id = f.Client_Id
			join edw_common.dim_date d on b.dim_date_key = d.dim_date_key
			where b.Relationship ='Unit-Holder' and d.date = @Effective_Date
		),	
		total_share_par_value as
		(
			select	 b.Dim_Date_Key		  
					, b.Dim_portfolio_Key
					, b.Dim_Client_Key
					, b.Portfolio_Id
					, b.share_par_value
					, t.Total_share_par_value
			from share_par_value b
			left join (
							select Dim_Date_Key, Portfolio_Id, Sum(share_par_value) as Total_share_par_value 
							From share_par_value
							Group by Dim_Date_Key, Portfolio_Id
						) t on t.Dim_Date_Key=b.Dim_Date_Key and t.Portfolio_Id=b.Portfolio_Id
		),
		 fact_statestreet_performance as
		(
			select s.dim_date_key, coalesce(rmp.Dim_portfolio_Key,s.Dim_portfolio_Key) as portfolio_Key, coalesce(pm.RM_portfolioId,p.Portfolio_Id) as Portfolio_Id, s.ending_market_value
			from [EDW_Common].[V_Fact_StateStreet_Total_Portfolio_Performance] s
			inner join edw_common.dim_portfolio p on p.dim_portfolio_key = s.dim_portfolio_key 
			join edw_common.dim_date d on s.dim_date_key = d.dim_date_key
			left join psa.v_manual_rm_perf_mapping pm on pm.perf_portfolioId = p.Portfolio_Id and d.date between pm.start_date and pm.end_date
			left join edw_common.dim_portfolio rmp on rmp.Portfolio_Id = pm.RM_portfolioId and rmp.Record_Is_Current_Flag = 1
			where s.report_freq_code = 'D' and d.date = @Effective_Date
		),
		fact_eagle_performance_daily as
		(
			select e.dim_date_key, e.Dim_portfolio_Key as portfolio_Key, p.Portfolio_Id,  e.ending_market_value
			from [EDW_Common].[V_Fact_Eagle_Total_Portfolio_Performance] e
			inner join edw_common.dim_portfolio p on p.dim_portfolio_key = e.dim_portfolio_key
			join edw_common.dim_date d on e.dim_date_key = d.dim_date_key
			where report_freq_code = 'D' and d.date = @Effective_Date
		),
		fact_eagle_performance_monthly as
		(
			select e.dim_date_key, e.Dim_portfolio_Key as portfolio_Key, p.Portfolio_Id,  e.ending_market_value
			from [EDW_Common].[V_Fact_Eagle_Total_Portfolio_Performance] e
			inner join edw_common.dim_portfolio p on p.dim_portfolio_key = e.dim_portfolio_key
			join edw_common.dim_date d on e.dim_date_key = d.dim_date_key
			where report_freq_code = 'M' and d.date = @Effective_Date
		),
		fact_eagle_performance as
		(
			--use eagle monthly data when available
			select d.dim_date_key, d.portfolio_key, d.portfolio_id, coalesce(m.ending_market_value, d.ending_market_value) as ending_market_value
			from fact_eagle_performance_daily d
				left outer join fact_eagle_performance_monthly m 
				on m.dim_date_key = d.dim_date_key
					and m.portfolio_key = d.portfolio_key
					and m.portfolio_id = d.portfolio_id
		),
		fact_performance as
		(
			select dim_date_key, portfolio_Key, Portfolio_Id, ending_market_value
			from fact_statestreet_performance

			union

			select dim_date_key, portfolio_Key, Portfolio_Id, ending_market_value
			from fact_eagle_performance e
			where not exists
				(select 1 from fact_statestreet_performance s where s.Portfolio_Id = e.Portfolio_Id and s.dim_date_key = e.dim_date_key)

		),
		fact_Position as (
			Select fp.dim_date_key, p.Portfolio_id, s.Security_id, fp.Market_Value
			From [EDW_Common].[V_Fact_Eagle_Position] fp
			inner join edw_common.dim_portfolio p on fp.dim_portfolio_key = p.dim_portfolio_key
			inner join edw_common.Dim_Eagle_Security_Detail s on fp.Dim_Eagle_Security_Detail_Key = s.Dim_Eagle_Security_Detail_key
			Inner join edw_common.dim_eagle_interface i on fp.dim_eagle_interface_key = i.dim_eagle_interface_key
			join edw_common.dim_date d on fp.dim_date_key = d.dim_date_key
			Where s.investment_type_Code<> 'CASH' and i.Interface_Name = 'BNYM' and d.date = @Effective_Date
		),
		direct_aggregate as
		(
			select b.Dim_Date_Key, pp.Portfolio_Id Parent_Portfolio_ID, sum(p1.Ending_Market_Value) as Ending_Market_Value
		    From [EDW_Common].[V_Fact_Aggr_EPS_Portfolio_Hierarchy_Base] b
			join EDW_Common.Dim_Portfolio p on b.dim_portfolio_key = p.dim_portfolio_key
			join EDW_Common.Dim_Portfolio pp on b.parent_dim_portfolio_key = pp.dim_portfolio_key
			Left Join Fact_Performance  P1 on P1.Portfolio_ID = p.Portfolio_ID
													and P1.dim_date_key = b.dim_date_key
			join edw_common.dim_date d on b.dim_date_key = d.dim_date_key
			Where d.date = @Effective_Date and  b.Relationship ='Direct Relationship' and p.Portfolio_ID <> pp.Portfolio_ID -- Exclude top level records
			Group by b.Dim_Date_Key, pp.Portfolio_ID
		),
		direct as 
		(
			--direct
			select
			   fi.[Dim_Date_Key]
			  ,fi.[Top_Level_Dim_Portfolio_Key]
			  ,fi.[Dim_Portfolio_Key]
			  ,fi.[Parent_Dim_Portfolio_Key]
			  ,fi.[Dim_Client_Key]
			  ,fi.[Dim_Strategy_Key]
			  ,fi.[Dim_Security_Key]
			  ,fi.[Hierarchy_String]
			  ,fi.[Relationship]
			  ,fi.[Relationship_Type]
			  ,fi.Hash_Diff
			  ,f1.ending_market_value
			  ,'Performance.Ending_Market_Value' as mv_Source
			  ,1 as ownership_multiplier
			  ,p.Portfolio_Id
			  ,pp.Portfolio_Id Parent_Portfolio_Id
			from [EDW_Common].[V_Fact_Aggr_EPS_Portfolio_Hierarchy_Base] fi
			join EDW_Common.Dim_Portfolio p on fi.dim_portfolio_key = p.dim_portfolio_key
			join EDW_Common.Dim_Portfolio pp on fi.Parent_dim_portfolio_key = pp.dim_portfolio_key
			left outer join fact_performance f1 on f1.portfolio_id = p.portfolio_id
					and f1.Dim_Date_Key = fi.dim_date_key
			join edw_common.dim_date d on fi.dim_date_key = d.dim_date_key
			Where d.date = @Effective_Date and fi.Relationship ='Direct Relationship'
		),
		unit_holder as
		(
			--unit holder
			select
			   h.[Dim_Date_Key]
			  ,h.[Top_Level_Dim_Portfolio_Key]
			  ,h.[Dim_Portfolio_Key]
			  ,h.[Parent_Dim_Portfolio_Key]
			  ,h.[Dim_Client_Key]
			  ,h.[Dim_Strategy_Key]
			  ,h.[Dim_Security_Key]
			  ,h.[Hierarchy_String]
			  ,h.[Relationship]
			  ,h.[Relationship_Type]			
			  ,h.Hash_Diff
			  ,coalesce(f.ending_market_value, a.ending_market_value) as ending_market_value
			  ,case
					when f.ending_market_value is null then 'Sum Performance.Ending_Market_Value for children'
					else
						'Performance.Ending_Market_Value' 
				end as mv_Source
			  ,convert(float,t.share_par_value) / convert(float,t.total_share_par_value) as ownership_multiplier
			  ,p.Portfolio_Id
			  ,pp.Portfolio_Id Parent_Portfolio_Id
			from [EDW_Common].[V_Fact_Aggr_EPS_Portfolio_Hierarchy_Base] h
			join EDW_Common.Dim_Portfolio p on h.dim_portfolio_key = p.dim_portfolio_key
			join EDW_Common.Dim_Portfolio pp on h.Parent_dim_portfolio_key = pp.dim_portfolio_key
			left outer join fact_performance f on f.portfolio_id = p.portfolio_id and f.Dim_Date_Key = h.Dim_Date_Key
			left outer join total_share_par_value t on t.Dim_Client_Key = h.Dim_Client_Key and t.portfolio_id = p.portfolio_id and t.Dim_Date_Key = h.Dim_Date_Key
			left outer join direct_aggregate a on a.parent_portfolio_id = p.portfolio_id and a.Dim_Date_Key = h.Dim_Date_Key
			join edw_common.dim_date d on h.dim_date_key = d.dim_date_key
			Where d.date = @Effective_Date and h.Relationship ='Unit-Holder '
		),
		overlay as
		(
			--overlay
			select  
				   o.[Dim_Date_Key]
				  ,o.[Top_Level_Dim_Portfolio_Key]
				  ,o.[Dim_Portfolio_Key]
				  ,o.[Parent_Dim_Portfolio_Key]
				  ,o.[Dim_Client_Key]
				  ,o.[Dim_Strategy_Key]
				  ,o.[Dim_Security_Key]
				  ,o.[Hierarchy_String]
				  ,o.[Relationship]
				  ,o.[Relationship_Type]	
				  ,o.Hash_Diff
				  ,f1.ending_market_value,
				'Performance.Ending_Market_Value' as mv_Source,
				convert(float,coalesce(f2.market_value, f3.ending_market_value)) / convert(float,f1.ending_market_value) as ownership_multiplier
			     ,p.Portfolio_Id
			     ,pp.Portfolio_Id Parent_Portfolio_Id
			from [EDW_Common].[V_Fact_Aggr_EPS_Portfolio_Hierarchy_Base] o
			join EDW_Common.Dim_Portfolio p on o.dim_portfolio_key = p.dim_portfolio_key
			join EDW_Common.Dim_Portfolio pp on o.Parent_dim_portfolio_key = pp.dim_portfolio_key
			left Join (
				Select  oh.Dim_Date_Key, p.portfolio_id, pp.portfolio_id parent_portfolio_id, 
						sum(pos.Market_Value) Market_Value
				From [EDW_Common].[V_Fact_Aggr_EPS_Portfolio_Hierarchy_Base] oh
				join EDW_Common.Dim_Security sec on oh.Dim_Security_Key = sec.Dim_Security_Key
				join EDW_Common.Dim_Portfolio p on oh.dim_portfolio_key = p.dim_portfolio_key
				join EDW_Common.Dim_Portfolio pp on oh.Parent_dim_portfolio_key = pp.dim_portfolio_key
				join EDW_Common.Dim_Date dh on oh.Dim_Date_Key = dh.Dim_Date_Key
				left outer join fact_position pos on pos.portfolio_id = pp.portfolio_id and pos.security_id = sec.security_id and pos.Dim_Date_Key = oh.Dim_Date_Key
				where dh.Date = @Effective_Date and sec.Security_id <> 'NA' and oh.Relationship = 'Overlay'
				Group By oh.Dim_Date_Key, p.portfolio_id, pp.portfolio_id
			) f2 on f2.portfolio_id = p.portfolio_id and f2.parent_portfolio_id = pp.portfolio_id and f2.Dim_Date_Key = o.Dim_Date_Key
			left outer join fact_performance f1 on f1.portfolio_id = p.portfolio_id and f1.Dim_Date_Key = o.Dim_Date_Key
			left outer join fact_performance f3 on f3.portfolio_id = pp.portfolio_id and f3.Dim_Date_Key = o.Dim_Date_Key
			join EDW_Common.Dim_Date d on o.Dim_Date_Key = d.Dim_Date_Key
			where Relationship='Overlay' and d.Date = @Effective_Date
		)
		select * from overlay
		union
		select * from unit_holder
		union
		select * from direct d


		Insert Into [EDW_Common].[Fact_Aggr_EPS_Portfolio_Hierarchy]
		(
			  [Dim_Date_Key]
			  ,[Top_Level_Dim_Portfolio_Key]
			  ,[Dim_Portfolio_Key]
			  ,[Parent_Dim_Portfolio_Key]
			  ,[Dim_Client_Key]
			  ,[Dim_Strategy_Key]
			  ,[Hierarchy_String]
			  ,[Relationship_Type]
			  ,[Ending_Market_Value]
			  ,[MV_Source]
			  ,[Ownership_Multiplier]
			  ,[Other_Info]
			  ,[Load_DTS]
			  ,[Last_Update_DTS]
			  ,[Hash_Diff]
			  ,[ETL_Load_Key]
		)
		Select Distinct
			  P0.[Dim_Date_Key]
			  ,P0.[Top_Level_Dim_Portfolio_Key]
			  ,P0.[Dim_Portfolio_Key]
			  ,P0.[Parent_Dim_Portfolio_Key]
			  ,P0.[Dim_Client_Key]
			  ,P0.[Dim_Strategy_Key]
			  ,P0.[Hierarchy_String]
			  ,P0.[Relationship_Type]
			  ,P0.[Ending_Market_Value]
			  ,P0.[MV_Source]
			  , Coalesce(convert(float, P8.Ownership_Multiplier),1) * -- Calculate cumulative ownership multiplier
				Coalesce(convert(float, P7.Ownership_Multiplier),1) *
				Coalesce(convert(float, P6.Ownership_Multiplier),1) *
				Coalesce(convert(float, P5.Ownership_Multiplier),1) * 
				coalesce(convert(float, P4.Ownership_Multiplier),1) *
				coalesce(convert(float, P3.Ownership_Multiplier),1) *
				coalesce(convert(float, P2.Ownership_Multiplier),1) *
				coalesce(convert(float, P1.Ownership_Multiplier),1) *
				coalesce(convert(float, P0.Ownership_Multiplier),1) As Ownership_Multiplier 
			  ,null
			  ,@today
			  ,@today
			  ,P0.Hash_Diff
			  ,@ETL_Load_Key
		From #eps_portfolio_hierarchy P0
		Left Join				 
		#eps_portfolio_hierarchy  P1 on P0.Parent_Portfolio_ID = P1.Portfolio_ID
									and P0.Portfolio_ID <> P0.Parent_Portfolio_ID
									and P0.Dim_Client_Key = P1.Dim_Client_Key
									and p0.[Dim_Date_Key] = p1.[Dim_Date_Key]
		left join				 
		#eps_portfolio_hierarchy  P2 on P1.Parent_Portfolio_ID = P2.Portfolio_ID
									and P1.Portfolio_ID <> P1.Parent_Portfolio_ID
									and P1.Dim_Client_Key = P2.Dim_Client_Key
									and p1.[Dim_Date_Key] = p2.[Dim_Date_Key]
		left join
		#eps_portfolio_hierarchy  P3 on P2.Parent_Portfolio_ID = P3.Portfolio_ID
									and P2.Portfolio_ID <> P2.Parent_Portfolio_ID
									and P2.Dim_Client_Key = P3.Dim_Client_Key
									and p2.[Dim_Date_Key] = p3.[Dim_Date_Key]
		left join
		#eps_portfolio_hierarchy  P4 on P3.Parent_Portfolio_ID = P4.Portfolio_ID
									and P3.Portfolio_ID <> P3.Parent_Portfolio_ID
									and P3.Dim_Client_Key = P4.Dim_Client_Key
									and p3.[Dim_Date_Key] = p4.[Dim_Date_Key]
		left join
		#eps_portfolio_hierarchy  P5 on P4.Parent_Portfolio_ID = P5.Portfolio_ID
									and P4.Portfolio_ID <> P4.Parent_Portfolio_ID
									and P4.Dim_Client_Key = P5.Dim_Client_Key
									and p4.[Dim_Date_Key] = p5.[Dim_Date_Key]
		left join
		#eps_portfolio_hierarchy  P6 on P5.Parent_Portfolio_ID = P6.Portfolio_ID
									and P5.Portfolio_ID <> P5.Parent_Portfolio_ID
									and P5.Dim_Client_Key = P6.Dim_Client_Key
									and p5.[Dim_Date_Key] = p6.[Dim_Date_Key]
		left join
		#eps_portfolio_hierarchy  P7 on P6.Parent_Portfolio_ID = P7.Portfolio_ID
									and P6.Portfolio_ID <> P7.Parent_Portfolio_ID
									and P6.Dim_Client_Key = P7.Dim_Client_Key
									and p6.[Dim_Date_Key] = p7.[Dim_Date_Key]
		left join
		#eps_portfolio_hierarchy  P8 on P7.Parent_Portfolio_ID = P8.Portfolio_ID
									and P7.Portfolio_ID <> P8.Parent_Portfolio_ID
									and P7.Dim_Client_Key = P8.Dim_Client_Key
									and p7.[Dim_Date_Key] = p8.[Dim_Date_Key]

		
		--ETL Logging
		Select @rowsInserted = Count(*) 
		From [EDW_Common].Fact_Aggr_EPS_Portfolio_Hierarchy
		Where [Last_Update_DTS] = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].Fact_Aggr_EPS_Portfolio_Hierarchy
		Where [Last_Update_DTS] = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Fact_Aggr_EPS_Portfolio_Hierarchy', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
		
	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
		DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Fact_Aggr_EPS_Portfolio_Hierarchy', 0, 0, 0, 'Failed', @ErrorMessage

		SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
				@ErrorMessage,  
				@ErrorState;

	END CATCH
	

end
;