﻿CREATE PROC [EDW_Common].[EPS_Fact_Aggr_Portfolio_Hierarchy_Base] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN


		Declare @Effective_Date date,
			@rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0

		Declare @today datetime2 = getdate()

		IF Convert(date,@Batch_DTS) = '1900-01-01'
		BEGIN
			-- get effective date (previous business date) to check
			Set @Effective_Date = CASE DATEPART(weekday, @today) 
							WHEN 1 THEN Dateadd(day, -2 , @today) -- Sunday > Friday
							WHEN 2 THEN Dateadd(day, -3 , @today) -- Monday > Friday
							ELSE Dateadd(day, -1 , @today) -- Tuesday - Saturday 
							END
		END 
		ELSE 
		BEGIN
			set @Effective_Date = @Batch_DTS
		END;

		Begin Try



			IF OBJECT_ID('tempdb..#flattened_hierarchy') IS NOT NULL
			BEGIN
				DROP TABLE #flattened_hierarchy
			END

			IF OBJECT_ID('tempdb..#direct_hierarchy') IS NOT NULL
			BEGIN
				DROP TABLE #direct_hierarchy
			END

			IF OBJECT_ID('tempdb..#unit_holder_hierarchy') IS NOT NULL
			BEGIN
				DROP TABLE #unit_holder_hierarchy
			END

			IF OBJECT_ID('tempdb..#overlay_hierarchy') IS NOT NULL
			BEGIN
				DROP TABLE #overlay_hierarchy
			END

			IF OBJECT_ID('tempdb..#full_hierarchy') IS NOT NULL
			BEGIN
				DROP TABLE #full_hierarchy
			END


			/********************************Direct Relationship********************************************************/
			create table #direct_hierarchy
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as
			With stage_excluded_relationships as
			(
				select Distinct pc.Portfolio_id child, p.Portfolio_id parent, bpm.dim_date_key
				From [EDW_Common].[Bridge_Portfolio_Mapping] bpm
				INNER JOIN edw_common.dim_portfolio p on bpm.Parent_Dim_portfolio_key = p.dim_portfolio_key
				INNER JOIN edw_common.dim_portfolio pc on bpm.Dim_portfolio_key = pc.dim_portfolio_key
				where bpm.is_src_deleted = 0
					--and bpm.perf_parent_dim_portfolio_key != -1
					and p.Portfolio_ID NOT LIKE ('IMTC%')              -- Eliminate Eagle IMCO "super-composites" that include top level client portfolios
					and p.Portfolio_ID NOT LIKE ('WSIC_%')              -- as these result in the portfolios being tagged as IMCO owned.
					and p.Portfolio_ID NOT LIKE ('SPKC%')
					and pc.Portfolio_id != p.Portfolio_id
					--and bpm.overlay_dim_portfolio_key = -1
			),
			excluded_relationships as
			(
			select p.child as portfolio_Id, pp.child as parent_portfolio_Id, pp.parent grandparent_portfolio_Id,p.dim_date_key
			From stage_excluded_relationships p
				inner Join stage_excluded_relationships pp on p.parent = pp.child and p.dim_date_key = pp.dim_date_key
			)
			,
			bridge_portfolio_mapping as 
			(
			Select distinct bpp.Dim_Portfolio_Key,bpp.parent_Dim_Portfolio_Key, bpp.perf_parent_dim_portfolio_key, [Dim_Client_Key], [Dim_Strategy_Key], Relation_Type, bpp.dim_date_key
			From [EDW_Common].[Bridge_Portfolio_Mapping] bpp 
			LEFT JOIN edw_common.Dim_Portfolio dp ON bpp.Dim_Portfolio_Key = dp.Dim_Portfolio_Key
			LEFt JOIN edw_common.Dim_Portfolio dp1 ON bpp.parent_Dim_Portfolio_Key = dp1.Dim_Portfolio_Key
			WHERE NOT EXISTS (select 1 from excluded_relationships x where x.portfolio_Id = dp.portfolio_Id and x.grandparent_portfolio_Id = dp1.portfolio_Id and bpp.dim_date_key = x.dim_date_key)
			and bpp.is_src_deleted = 0
			--and bpp.overlay_dim_portfolio_key = -1
			),
			Direct_Portfolio_Hierarchy As
			(
				Select distinct DP.Portfolio_ID
				 , DP.Portfolio_Name
				 , Coalesce(dp2.portfolio_Id,dp1.portfolio_Id,DP.Portfolio_ID)     as Parent_Portfolio_ID   -- If portfolio has no parent, make it its own parent
				 , Coalesce(dp2.Portfolio_Name,dp1.Portfolio_Name,DP.Portfolio_Name) as Parent_Portfolio_Name
				 , CASE WHEN DP.Portfolio_ID IN (select distinct portfolio_id from psa.v_manual_portfolio_groups where group_name = 'Enterprise Portfolio Service' and @Effective_Date between start_date and end_date) THEN 'TOP'
						WHEN Relation_Type = 'Eagle_Mapping' THEN 'Eagle - ' + coalesce(dp1.portfolio_type, 'NA') + ' - ' + coalesce(DP.portfolio_type, 'NA')
						WHEN Relation_Type = 'Manual_Mapping' THEN 'Manual - ' + coalesce(dp1.portfolio_type, 'NA') + ' - ' + coalesce(DP.portfolio_type, 'NA')
						WHEN bpp.parent_dim_portfolio_key = -1 THEN 'TOP'
						ELSE 'NA'
					END AS Relationship_Type
				 , 'EPS' AS Business_Owner
				 ,	dc.Client_ID
				 , DP.Portfolio_Classification
				 , DP.Manager
				 , DP.Manager_Classification_Risk
				 , DP.Reporting_Portfolio_Name
				 -- Remove unofficial strategies from output to ensure that correct tagging is picked up
				 , Case ds.Strategy_Id When 'Total Plan' then NULL 
						Else ds.Strategy_Id End AS IPS_Strategy
				, d.date as Effective_Date
			  From bridge_portfolio_mapping bpp
				   LEFT JOIN [EDW_Common].Dim_Portfolio DP ON BPP.Dim_Portfolio_Key   = DP.Dim_Portfolio_Key                                          
				   LEFT JOIN [EDW_Common].dim_portfolio dp1 ON BPP.parent_Dim_Portfolio_Key = dp1.Dim_Portfolio_Key 
				   LEFT JOIN [EDW_Common].dim_portfolio dp2 ON BPP.perf_parent_Dim_Portfolio_Key = dp2.Dim_Portfolio_Key and dp2.portfolio_id != 'NA'
				   LEFT JOIN [EDW_Common].[Dim_Client] dc ON dc.dim_client_key = BPP.dim_client_key
				   LEFT JOIN [EDW_Common].[Dim_Strategy] ds ON ds.[Dim_Strategy_Key] = BPP.[Dim_Strategy_Key]
				   inner join edw_common.dim_date d on d.dim_date_key =  bpp.dim_date_key
			  where Coalesce(dp1.portfolio_Id,DP.Portfolio_ID) NOT LIKE ('IMTC%')              -- Eliminate Eagle IMCO "super-composites" that include top level client portfolios
			   and Coalesce(dp1.portfolio_Id,DP.Portfolio_ID) NOT LIKE ('WSIC_%')              -- as these result in the portfolios being tagged as IMCO owned.
			   and Coalesce(dp1.portfolio_Id,DP.Portfolio_ID) NOT LIKE ('SPKC%')
			),
			--SELECT Portfolio_ID,Portfolio_Name,Parent_Portfolio_ID,Parent_Portfolio_Name,Relationship_Type,Business_Owner
			--,Client_ID,Portfolio_Classification,Manager,Manager_Classification_Risk,Reporting_Portfolio_Name,IPS_Strategy,Effective_Date
			--from Direct_Portfolio_Hierarchy E;
			counter as
			(
				select effective_date, portfolio_id, parent_portfolio_id, count(*) as count
				from Direct_Portfolio_Hierarchy
				group by effective_date, portfolio_id, parent_portfolio_id
				having count(*) > 1
			),
			combine as
			(
				--take the manual version if there is a duplicate
				select *
				from Direct_Portfolio_Hierarchy d
				where exists
					(select 1 
						from counter c
						where c.portfolio_id = d.portfolio_id
						and c.parent_portfolio_id = d.parent_portfolio_id
						and c.effective_date = d.effective_date
						and c.count > 1)
					and d.relationship_type like 'Manual%'

				union

				--the remainder
				select *
				from Direct_Portfolio_Hierarchy d
				where not exists
					(select 1 
						from counter c
						where c.portfolio_id = d.portfolio_id
						and c.parent_portfolio_id = d.parent_portfolio_id
						and c.effective_date = d.effective_date
						and c.count > 1)
			)
			select 	'Direct Relationship' as Relationship,
					d.effective_date,
					d.portfolio_id,
					d.parent_portfolio_id,
					d.relationship_type,
					d.portfolio_name,
					d.client_id,
					d.portfolio_classification,
					d.manager,
					d.manager_classification_risk,
					d.reporting_portfolio_name,
					d.ips_strategy,
					-1 as dim_security_key
			from combine d
			where effective_date=@Effective_Date


			/********************************Unit Holder Relationship********************************************************/
			create table #unit_holder_hierarchy
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as
			with ips_strategy as
			(
				select distinct p.dim_portfolio_key, p.portfolio_id, p.portfolio_name, s.strategy_id, c.client_id--, m.dim_date_key
				from edw_common.bridge_portfolio_mapping m
					inner join edw_common.dim_portfolio p
						on p.dim_portfolio_key = m.dim_portfolio_key
					inner join edw_common.dim_strategy s
						on s.dim_strategy_key = m.dim_strategy_key and s.strategy_id != 'NA'
					inner join edw_common.dim_client c
						on c.dim_client_key = m.dim_client_key and c.client_id != 'NA'
				where p.portfolio_classification = 'IPS Strategy'
					and m.is_src_deleted = 0
				--and m.dim_date_key = '20211130'
			),
			bridge_unit_holder as
			(
				select distinct 
						p.portfolio_id, p.portfolio_name, s.security_id, m.dim_security_key,
						c.client_id, p.portfolio_classification,
						p.manager,
						p.manager_classification_risk,
						p.reporting_portfolio_name,
						p1.portfolio_id as parent_portfolio_id,
						p1.portfolio_name as parent_portfolio_name,
						st.strategy_id as ips_strategy,
						c1.client_id as parent_client_id,
						i.portfolio_id as new_parent_portfolio_id,
						p2.portfolio_name as new_parent_portfolio_name,
						case when perf_p.portfolio_id = 'NA' then null else perf_p.portfolio_id end as perf_portfolio_id,
						case when perf_p.portfolio_name = 'Not Avaliable' then null else perf_p.portfolio_name end as perf_portfolio_name,
						d.date as effective_date
				from edw_common.bridge_portfolio_mapping m
					inner join edw_common.dim_portfolio p
						on p.dim_portfolio_key = m.parent_dim_portfolio_key
					left outer join edw_common.dim_portfolio perf_p
						on perf_p.dim_portfolio_key = m.perf_parent_dim_portfolio_key
					inner join edw_common.dim_security s
						on s.dim_security_key = m.dim_security_key
					inner join edw_common.dim_client c
						on c.dim_client_key = m.dim_client_key
					left outer join [EDW_Common].[V_Fact_StateStreet_Account_Position] fs
						on fs.dim_security_key = m.dim_security_key
						and fs.dim_date_key = m.dim_date_key
					inner join edw_common.dim_portfolio p1
						on p1.dim_portfolio_key = fs.dim_portfolio_key
					inner join edw_common.dim_strategy st
						on st.dim_strategy_key = m.dim_strategy_key
					left join edw_common.bridge_portfolio_mapping m1
						on m1.dim_portfolio_key = p1.dim_portfolio_key
						and m1.dim_date_key = m.dim_date_key
					left join edw_common.dim_client c1
						on c1.dim_client_key = m1.dim_client_key
					left join ips_strategy i 
						on i.strategy_id = st.strategy_id
						and i.client_id = c1.client_id
						--and i.dim_date_key = m.dim_date_key
					left join edw_common.dim_portfolio p2 
						on p2.dim_portfolio_key = i.dim_portfolio_key
						and p2.record_is_current_flag = 1
					inner join edw_common.dim_date d 
						on d.dim_date_key = m.dim_date_key
				where m.parent_dim_portfolio_key != -1
					and m.dim_security_key != -1
					and m.is_src_deleted = 0
					and p2.dim_portfolio_key is not null
					--and perf_p.portfolio_id = 'NA'
			)
			select distinct 'Unit-Holder' as Relationship,
				effective_date,
				coalesce(b.perf_portfolio_id, b.portfolio_id) as portfolio_id,
				coalesce(b.new_parent_portfolio_id, b.parent_portfolio_id) as parent_portfolio_id,
				'Unit-Holder' +
				   Case 
				     when b.perf_portfolio_id != 'NA' then ' - Manual performance parent override'
					 When b.new_parent_portfolio_id is not null then ' - Performance redirect from ' + b.parent_portfolio_id 
					 Else ''
				   End as relationship_type,
				b.portfolio_name,
				b.client_id,
				b.portfolio_classification,	
				b.manager,
				b.manager_classification_risk,
				b.reporting_portfolio_name,
				b.ips_strategy,
				b.dim_security_key
			from bridge_unit_holder b
			where b.effective_date = @Effective_Date
				and coalesce(b.perf_portfolio_id, b.portfolio_id) != coalesce(b.new_parent_portfolio_id, b.parent_portfolio_id)

			/********************************Overlay Relationship********************************************************/
			create table #overlay_hierarchy
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as
			select distinct 'Overlay' as Relationship,
							d.date as effective_date ,
							p.portfolio_id, 
							p1.portfolio_id as parent_portfolio_id,
							'Overlay_Proxy' as relationship_type,			
							p.portfolio_name,
							c.client_id,
							p.portfolio_classification,
							p.manager,
							p.manager_classification_risk,
							p.reporting_portfolio_name,
							s.strategy_id as ips_strategy,
							m.pool_Dim_Security_Key Dim_Security_Key
				from edw_common.bridge_pool_portfolio_mapping m  
				left outer join edw_common.dim_portfolio p
					on p.dim_portfolio_key = m.pool_dim_portfolio_key
				left outer join edw_common.dim_portfolio p1
					on p1.dim_portfolio_key = m.dim_portfolio_key
				left outer join
				(
					select p.Portfolio_Id, bpm.Dim_date_key, bpm.Dim_Client_Key, bpm.Dim_Strategy_Key
					From edw_common.bridge_portfolio_mapping bpm
					join  edw_common.dim_portfolio p
					on p.dim_portfolio_key = bpm.dim_portfolio_key
				) m_pool
					on m_pool.Portfolio_Id = p.Portfolio_Id
					and m_pool.dim_date_key = m.dim_date_key
				left outer join edw_common.dim_client c
					on c.dim_client_key = m_pool.dim_client_key
				left outer join edw_common.dim_strategy s
					on s.dim_strategy_key = m_pool.dim_strategy_key
				left outer join edw_common.dim_date d
					on d.dim_date_key = m.dim_date_key
			  where m.pool_dim_portfolio_key != -1
				and m.is_src_deleted = 0
				and d.date=@Effective_Date

			create table #full_hierarchy
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as
			select *
			from #overlay_hierarchy

			union

			select *
			from #unit_holder_hierarchy

			union

			select *
			from #direct_hierarchy d
			where not exists
				(
					select effective_date, portfolio_id
					from #unit_holder_hierarchy h
					where h.effective_date = d.effective_date
					and h.portfolio_id = d.portfolio_id
				)


			-- load everything from source
			create table #flattened_hierarchy
			WITH
			(
					DISTRIBUTION = Round_Robin
			) as
			with flattened as
					(
					Select distinct
							P0.Effective_Date
							,
							--removed because all portfolios have a parent now due to the top level IMCO 
							--case coalesce(P7.Parent_Portfolio_ID,'Y') When 'Y' then '' When 'NA' then '' When P7.Portfolio_ID then '' Else P7.Parent_Portfolio_ID + ' -> ' End +
					
							case coalesce(P8.Portfolio_ID,'Y') When 'Y' then '' Else P8.Portfolio_ID + ' -> ' End +
							case coalesce(P7.Portfolio_ID,'Y') When 'Y' then '' Else P7.Portfolio_ID + ' -> ' End +
							case coalesce(P6.Portfolio_ID,'Y') When 'Y' then '' Else P6.Portfolio_ID + ' -> ' End +
							case coalesce(P5.Portfolio_ID,'Y') When 'Y' then '' Else P5.Portfolio_ID + ' -> ' End + 
							case coalesce(P4.Portfolio_ID,'Y') When 'Y' then '' Else P4.Portfolio_ID + ' -> ' End + 
							case coalesce(P3.Portfolio_ID,'Y') When 'Y' then '' Else P3.Portfolio_ID + ' -> ' End + 
							case coalesce(P2.Portfolio_ID,'Y') When 'Y' then '' Else P2.Portfolio_ID + ' -> ' End + 
							case coalesce(P1.Portfolio_ID,'Y') When 'Y' then '' Else P1.Portfolio_ID + ' -> ' End + 
							P0.Portfolio_ID         as Hierarchy_String
							, P0.Portfolio_ID
							, P0.Parent_Portfolio_ID
							, P0.Relationship
							, P0.Relationship_Type               -- Tags from Lowest level, except for Client, and Strategy, which come from the highest level available
							, P0.Portfolio_Classification
							, P0.Manager
							, P0.Manager_Classification_Risk
							, P0.Reporting_Portfolio_Name
							, P0.Portfolio_Name
							, Coalesce(P8.Client_ID,P7.Client_ID,P6.Client_ID,P5.Client_ID,P4.Client_ID,P3.Client_ID,P2.Client_ID,P1.Client_ID,P0.Client_ID)                as Top_Client_ID       -- Get client of top level portfolio
							, P8.Client_ID as Client_ID_8
							, P7.Client_ID as Client_ID_7
							, P6.Client_ID as Client_ID_6 
							, P5.Client_ID as Client_ID_5 
							, P4.Client_ID as Client_ID_4 
							, P3.Client_ID as Client_ID_3 
							, P2.Client_ID as Client_ID_2 
							, P1.Client_ID as Client_ID_1 
							, P0.Client_ID as Client_ID_0 
							, Coalesce(P8.IPS_Strategy,P7.IPS_Strategy,P6.IPS_Strategy,P5.IPS_Strategy,P4.IPS_Strategy,P3.IPS_Strategy,P2.IPS_Strategy,P1.IPS_Strategy,P0.IPS_Strategy) as IPS_Strategy -- Get strategy from top level that has one
							,P0.Dim_Security_Key
						from #full_hierarchy  P0
							Left Join				 
							#full_hierarchy  P1 on P0.Parent_Portfolio_ID = P1.Portfolio_ID
														and P0.Portfolio_ID <> P0.Parent_Portfolio_ID
														and p0.effective_date = p1.effective_date
							left join				 
							#full_hierarchy  P2 on P1.Parent_Portfolio_ID = P2.Portfolio_ID
														and P1.Portfolio_ID <> P1.Parent_Portfolio_ID
														and p1.effective_date = p2.effective_date
							left join
							#full_hierarchy  P3 on P2.Parent_Portfolio_ID = P3.Portfolio_ID
														and P2.Portfolio_ID <> P2.Parent_Portfolio_ID
														and p2.effective_date = p3.effective_date
							left join
							#full_hierarchy  P4 on P3.Parent_Portfolio_ID = P4.Portfolio_ID
														and P3.Portfolio_ID <> P3.Parent_Portfolio_ID
														and p3.effective_date = p4.effective_date
							left join
							#full_hierarchy  P5 on P4.Parent_Portfolio_ID = P5.Portfolio_ID
														and P4.Portfolio_ID <> P4.Parent_Portfolio_ID
														and p4.effective_date = p5.effective_date
							left join
							#full_hierarchy  P6 on P5.Parent_Portfolio_ID = P6.Portfolio_ID
														and P5.Portfolio_ID <> P5.Parent_Portfolio_ID
														and p5.effective_date = p6.effective_date
							left join
							#full_hierarchy  P7 on P6.Parent_Portfolio_ID = P7.Portfolio_ID
														and P6.Portfolio_ID <> P7.Parent_Portfolio_ID
														and p6.effective_date = p7.effective_date
							left join
							#full_hierarchy  P8 on P7.Parent_Portfolio_ID = P8.Portfolio_ID
														and P7.Portfolio_ID <> P8.Parent_Portfolio_ID
														and p7.effective_date = p8.effective_date
					),
					flattened_calculated as
					(
						select distinct
							effective_date,
							hierarchy_string,
							portfolio_id,
							parent_portfolio_id,
							Relationship,
							relationship_type,
							portfolio_classification,
							manager,
							manager_classification_risk,
							reporting_portfolio_name,
							portfolio_name,
							top_client_id,
							ips_strategy,
						--Client ID logic: If the top level is the IMCO Top level portfolio, we do not want to show the client ID as IMCO.
						--				   Instead, we want to show the level right below it, the top level by Client
						--				   However, there is a case of IMCO pools, so only do this client calc when the top level is IMCO
						--                 and the top level is also IMCO
						case
							when Top_Client_ID = 'IMCO' and dbo.SUBSTRING_INDEX(Hierarchy_String,' -> ',1) = 'IMCO' then
								case
									when Client_ID_8 = 'IMCO' then
										case 
											when Client_ID_7 != 'NA' then
												Client_ID_7
											else
												Client_ID_8
										end
									when Client_ID_7 = 'IMCO' then
										case 
											when Client_ID_6 != 'NA' then
												Client_ID_6
											else
												Client_ID_7
										end
									when Client_ID_6 = 'IMCO' then
										case 
											when Client_ID_5 != 'NA' then
												Client_ID_5
											else
												Client_ID_6
										end
									when Client_ID_5 = 'IMCO' then
										case 
											when Client_ID_4 != 'NA' then
												Client_ID_4
											else
												Client_ID_5
										end
									when Client_ID_4 = 'IMCO' then
										case 
											when Client_ID_3 != 'NA' then
												Client_ID_3
											else
												Client_ID_4
										end
									when Client_ID_3 = 'IMCO' then
										case 
											when Client_ID_2 != 'NA' then
												Client_ID_2
											else
												Client_ID_3
										end
									when Client_ID_2 = 'IMCO' then
										case 
											when Client_ID_1 != 'NA' then
												Client_ID_1
											else
												Client_ID_2
										end
									when Client_ID_1 = 'IMCO' then
										case 
											when Client_ID_0 != 'NA' then
												Client_ID_0
											else
												Client_ID_1
										end
									else
										Client_ID_0
								end
							else
								Top_Client_ID
						end as Client_ID,
						Dim_Security_key
						from flattened
					)
					select
						d.dim_date_key
						,c_c.dim_client_key
						,c_c.client_id
						,tp.dim_portfolio_key as top_level_dim_portfolio_key
						,tp.portfolio_id as top_level_portfolio_id
						, p.dim_portfolio_key
						, p.portfolio_id
						, p1.dim_portfolio_key as parent_dim_portfolio_key
						, p1.portfolio_id as parent_portfolio_id
						, c_s.dim_strategy_key
						, c_s.strategy_id
						, Hierarchy_String
						, Relationship
						, Relationship_Type
						,Dim_Security_key
					from flattened_calculated f	
						inner join psa.v_manual_portfolio_groups g
							on g.portfolio_id =  dbo.SUBSTRING_INDEX(Hierarchy_String,' -> ',1)
						inner join edw_common.dim_date d 
							on d.date = f.effective_date
						left outer Join (
											select Client_Id, max(dim_client_key) dim_client_key
											From EDW_Common.Dim_Client
											Where record_is_current_flag = 1
											group By client_id
								) c_c 
							on f.Client_Id = c_c.Client_Id
						left outer join edw_common.dim_portfolio tp
							on dbo.SUBSTRING_INDEX(f.Hierarchy_String,' -> ',1) = tp.Portfolio_Id and tp.record_is_current_flag = 1
						left outer join edw_common.dim_portfolio p
							on f.portfolio_id = p.Portfolio_Id and p.record_is_current_flag = 1
						left outer join edw_common.dim_portfolio p1
							on f.parent_portfolio_id = p1.Portfolio_Id and p1.record_is_current_flag = 1
						Left Join (
											select Strategy_Id, max(dim_strategy_key) dim_strategy_key
											From EDW_Common.Dim_Strategy
											Where Is_Src_Deleted_Flag = 0
												and record_is_current_flag = 1
											group By Strategy_Id
								) c_s on 
								case 
									when f.IPS_Strategy is null then
										'Not Available'
									else
										IPS_Strategy
								end = c_s.Strategy_Id
					where g.group_name = 'Enterprise Portfolio Service'

			/*
			delete from [EDW_Common].[Fact_Aggr_EPS_Portfolio_Hierarchy_Base]
					where dim_date_key = CONVERT(CHAR(8), @Effective_Date, 112);
			*/

			;with src as
			(	
				Select Dim_Date_Key
					,coalesce(Top_Level_Dim_Portfolio_key, -1) as Top_Level_Dim_Portfolio_Key
					,Top_Level_Portfolio_Id
					,coalesce(Dim_Portfolio_Key, -1) as Dim_Portfolio_Key
					,Portfolio_Id
					,coalesce(Parent_Dim_Portfolio_Key, -1) as Parent_Dim_Portfolio_Key
					,Parent_Portfolio_Id
					,coalesce(Dim_Client_Key, -1) as Dim_Client_Key
					,Client_Id
					,coalesce(Dim_Strategy_Key, -1) as Dim_Strategy_Key
					,coalesce(Dim_Security_Key,-1) as Dim_Security_Key
					,Hierarchy_String
					,Relationship
					,Relationship_Type
					,CONVERT(VARCHAR(64), hashbytes('SHA1', coalesce(concat(Hierarchy_String, '|', Relationship_Type ), '')), 2) as Hash_Diff
				From #flattened_hierarchy t
			)
			INSERT INTO [EDW_Common].[Fact_Aggr_EPS_Portfolio_Hierarchy_Base]
				([Dim_Date_Key]
				,[Top_Level_Dim_Portfolio_Key]
				,[Dim_Portfolio_Key]
				,[Parent_Dim_Portfolio_Key]
				,[Dim_Client_Key]
				,[Dim_Strategy_Key]
				,[Dim_Security_Key]
				,[Hierarchy_String]
				,[Relationship]
				,[Relationship_Type]				
				,[Other_Info]
				,[Load_DTS]
				,[Last_Update_DTS]
				,[Hash_Diff]
				,[ETL_Load_Key])
			Select 
				t.Dim_Date_Key
				,coalesce(t.Top_Level_Dim_Portfolio_Key, -1)
				,coalesce(t.Dim_Portfolio_Key, -1)
				,coalesce(t.Parent_Dim_Portfolio_Key, -1)
				,coalesce(t.Dim_Client_Key, -1)
				,coalesce(t.Dim_Strategy_Key, -1)
				,coalesce(t.Dim_Security_Key, -1)
				,t.Hierarchy_String
				,t.Relationship
				,t.Relationship_Type		
				,null
				,@today
				,@today
				,t.Hash_Diff
				,@ETL_Load_Key
			From src t
		
			--ETL Logging
			Select @rowsInserted = Count(*) 
			From [EDW_Common].[Fact_Aggr_EPS_Portfolio_Hierarchy_Base]
			Where [Last_Update_DTS] = @today

			Select @rowsExpired = Count(*)
			From [EDW_Common].[Fact_Aggr_EPS_Portfolio_Hierarchy_Base]
			Where [Last_Update_DTS] = @today

			Select @rowsUpdated = @rowsExpired

			Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Fact_Aggr_Portfolio_Hierarchy_Base', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
		
		END TRY

		BEGIN CATCH
			DECLARE @ErrorMessage  VARCHAR(4000);  
			DECLARE @ErrorSeverity INT;  
			DECLARE @ErrorState    INT; 
			DECLARE @ErrorCode     INT;		

			SELECT   
				@ErrorMessage  = ERROR_MESSAGE(),  
				@ErrorSeverity = ERROR_SEVERITY(),  
				@ErrorState    = ERROR_STATE();

			Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Fact_Aggr_Portfolio_Hierarchy_Base', 0, 0, 0, 'Failed', @ErrorMessage

			SET @ErrorCode = 50000 + @ErrorSeverity;
		
			THROW 50001,
				  @ErrorMessage,  
				  @ErrorState;

		END CATCH
	

end