﻿CREATE PROC [EDW_Common].[IMCOManual_Dim_Portfolio] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_portfolio_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_portfolio_records
		END

		
		-- load everything from source
		create table #temp_src_portfolio_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select	PM.Portfolio_Id,
				Portfolio_Classification,
				Reporting_Portfolio_Name,
				PM.Is_Src_Deleted,
				convert(varchar(64), Hashbytes('SHA1', UPPER(concat(coalesce(Rtrim(PM.Portfolio_Id),''), '|', coalesce(rtrim(Portfolio_Classification),''),	'|', coalesce(rtrim(Reporting_Portfolio_Name),'')))),2) Hash_Diff

		From ( 	Select  Rtrim(Portfolio_Id) Portfolio_Id
						,[Is_Src_Deleted]
						,Row_Number() Over (Partition By Portfolio_Id order by Load_DTS Desc) rn
				From [PSA].[Manual_Portfolio_Mapping]

				Union

				Select Parent_Portfolio_Id Portfolio
						,[Is_Src_Deleted]
						,Row_Number() Over (Partition By Parent_Portfolio_Id order by Load_DTS Desc) rn
				From [PSA].[Manual_Portfolio_Mapping]

				union 
				Select Overlay_Proxy_For_Portfolio Portfolio_Id
						,[Is_Src_Deleted]
						,Row_Number() Over (Partition By Overlay_Proxy_For_Portfolio order by Load_DTS Desc) rn
				From [PSA].[Manual_Portfolio_Mapping]
			) PM
			left join PSA.V_Manual_Portfolio P on PM.Portfolio_Id = P.Portfolio_ID
		
		
		where	PM.rn = 1 
				and PM.Portfolio_Id is not null


		--UPDATE ATTRIBUTES OF EXISTING RECORD - SCD TYPE 1
		Update	tgt
		Set		tgt.Portfolio_Classification = src.Portfolio_Classification, 
				tgt.Reporting_Portfolio_Name = src.Reporting_Portfolio_Name,
				tgt.Last_Update_DTS = getdate()

		from ( select	Portfolio_ID,
						Portfolio_Classification,
						Reporting_Portfolio_Name

				from	#temp_src_portfolio_records

				except

				select	Portfolio_ID,
						Portfolio_Classification,
						Reporting_Portfolio_Name

				From	EDW_Common.Dim_Portfolio
			 ) src 
			 inner join EDW_Common.Dim_Portfolio tgt on tgt.Portfolio_Id = src.Portfolio_Id

		where tgt.Record_Is_Current_Flag = 1


		--/** Only insert the portfolio where it is not covered by other source system **/
		Insert Into EDW_Common.Dim_Portfolio 
		(
			 Portfolio_ID
			,Portfolio_Name
			,Portfolio_Classification
			,Reporting_Portfolio_Name
			,Record_Start_DTS
			,Record_End_DTS
			,Record_Is_Current_Flag
			,Last_Update_DTS
			,Hash_Diff
			,ETL_Load_Key
		)
		Select	 src.Portfolio_Id
				,src.Portfolio_Id
				,src.Portfolio_Classification
				,src.Reporting_Portfolio_Name
				,'2000-01-01'
				,null
				,1
				,@today
				,src.Hash_Diff
				,@ETL_Load_Key

		From	#temp_src_portfolio_records src
		Where	not exists 
				(
					Select 1
					From EDW_Common.Dim_Portfolio tgt
					where Record_Is_Current_Flag = 1 
					and src.Portfolio_Id = tgt.Portfolio_Id 
				)
				and src.Is_Src_Deleted = 0


		--ETL Logging	
		Select @rowsInserted = Count(*) 
		From EDW_Common.Dim_Portfolio
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From EDW_Common.Dim_Portfolio
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Portfolio', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY


	--Error Handling
	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Portfolio', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END