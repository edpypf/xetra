﻿CREATE PROC [EDW_Common].[IMCOManual_Dim_Security] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_security_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_security_records
		END

		-- load everything from source

		create table #temp_src_security_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select Src_Security_Id
		        ,Security_Id
				,[Is_Src_Deleted]
				,convert(varchar(64), Hashbytes('SHA1', upper(coalesce(Rtrim(Security_Id),''))),2) Hash_Diff
		From (
			Select  'StateStreet_' + Rtrim(Securitized_Parent_Id) Src_Security_Id 
			        ,Rtrim(Securitized_Parent_Id) Security_Id
					,[Is_Src_Deleted]
					,Row_Number() Over (Partition By Securitized_Parent_Id order by Load_DTS Desc) rn
			From [PSA].[Manual_Portfolio_Mapping]
			where Securitized_Parent_Id is not null
			and not exists 
			(
				Select 1 from PSA.StateStreet_Accounting_Positions
				Where Rtrim(CUSIP_Number) = Rtrim(Securitized_Parent_Id)
			)
		) src
		where rn = 1 


		/** Only insert the portfolio where it is not covered by other source system **/
		Insert Into EDW_Common.Dim_Security (
			    Src_Security_Id
		        ,Security_Id
				,Instrument_Type
				,Security
				,Security_Long_Name
				,Security_Description
				,Security_Description_2
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select Src_Security_Id
		      ,Security_Id
		      ,'NA'
			  ,Security_Id
			  ,Security_Id
			  ,null
			  ,null
			  ,'2000-01-01', null, 1, @today
			  ,Hash_Diff
			  ,@ETL_Load_Key
		From #temp_src_security_records src
		Where not exists (
			Select 1
			From EDW_Common.Dim_Security tgt
			where Record_Is_Current_Flag = 1 and src.Src_Security_Id = tgt.Src_Security_Id 
		)
		and src.Is_Src_Deleted = 0


		/*
		Insert Into EDW_Common.Dim_Portfolio (
				  [Portfolio_ID]
				  ,[Portfolio_Name]
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select [Entity_ID]
			  ,[Entity_Name]
			  ,@today, null, 1, @today
			  ,Hash_Diff
			  ,@ETL_Load_Key
		From #temp_src_portfolio_records src
		Where not exists (
			Select 1
			From EDW_Common.Dim_Portfolio tgt
			where Record_Is_Current_Flag = 1 and src.Entity_Id = tgt.Portfolio_Id and src.Hash_Diff = tgt.Hash_Diff
		)
		and src.Is_Src_Deleted = 0

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From EDW_Common.Dim_Portfolio tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_portfolio_records src
			Where tgt.Portfolio_Id = src.Entity_Id and (coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1)
		)
		*/


		Select @rowsInserted = Count(*) 
		From EDW_Common.Dim_Security
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From EDW_Common.Dim_Security
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Security', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Security', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END