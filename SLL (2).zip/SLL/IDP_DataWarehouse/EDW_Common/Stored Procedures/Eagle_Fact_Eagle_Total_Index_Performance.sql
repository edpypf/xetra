﻿CREATE PROC [EDW_Common].[Eagle_Fact_Eagle_Total_Index_Performance] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2


	
	Begin Try


		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From [EDW_Common].[Fact_Eagle_Total_Index_Performance]


		--INSERT INTO FACT TABLE
		INSERT INTO [EDW_Common].[Fact_Eagle_Total_Index_Performance]
        (
			Dim_Index_Key,
			Dim_Eagle_Index_Detail_Key,
			Dim_Date_Key,
			Dim_Index_Type_Key,
			Report_Freq,
			Load_DTS,
			ABAL,
			PSR_USER_FLOAT1,
			PSR_USER_FLOAT2,
			PSR_USER_FLOAT32,
			PSR_USER_FLOAT50,
			PSR_USER_FLOAT7,
			Report_Freq_Return,
			SRC_INTFC_INST,
			PERF_ROLLUP_RETURNS_ID,
			UPDATE_DATE,
			UPDATE_SOURCE,
			Last_Update_DTS,
			Hash_Diff,
			ETL_Load_Key,
			Is_Src_Deleted,
			Other_Info
		)

		SELECT  coalesce(i.Dim_Index_Key, -1) Dim_Index_Key,
				coalesce(id.Dim_Eagle_Index_Detail_Key,-1) Dim_Eagle_Index_Detail_Key,
				convert(int, convert(varchar(15), Effective_Date, 112)) Dim_Date_Key,
				coalesce(bt.Dim_Blend_Type_Key, -1) Dim_Blend_Type_Key,
				Report_Freq,
				src.Load_DTS,
				ABAL,
				PSR_USER_FLOAT1,
				PSR_USER_FLOAT2,
				PSR_USER_FLOAT32,
				PSR_USER_FLOAT50,
				PSR_USER_FLOAT7,
				Report_Freq_Return, 
				src.SRC_INTFC_INST,
				src.PERF_ROLLUP_RETURNS_ID,
				UPDATE_DATE,
				UPDATE_SOURCE,
				@today,
				src.Hash_Diff,
				@ETL_Load_Key,
				Is_Src_Deleted,
				Case when i.Dim_Index_Key is null or id.Dim_Eagle_Index_Detail_Key is null then
					'{"Entity_Id": "' + src.Index_Id + '", ' + 
					  '"Blend_Type": "' + src.Blend_Type + '"' + 
					'}'
				Else null End


		FROM  ( SELECT	distinct
						E.Entity_ID as Index_Id,
						E.Entity_Name,
						PS.End_Effective_Date as Effective_Date,
						Coalesce(DD.DICT_L2_CODE_VALUE,'DEFAULT') Blend_Type,
						PS.SRC_INTFC_INST,
						PSR.PERF_ROLLUP_RETURNS_ID,
						ABAL,
						PSR_USER_FLOAT1,
						PSR_USER_FLOAT2,
						PSR_USER_FLOAT32,
						PSR_USER_FLOAT50,
						PSR_USER_FLOAT7,
						PSR_USER_FLOAT8 Report_Freq_Return,
						I.LONG_DESC Source_Interface,
						PSR.UPDATE_DATE,
						PSR.UPDATE_SOURCE,
						PS.PERF_FREQ_CODE Report_Freq,
						PSR.Hash_Diff,
						PSR.Load_DTS,
						PSR.Is_Src_Deleted

				From	PSA.Eagle_Perf_Sec_Returns PSR  
						Inner Join PSA.V_Eagle_Perf_Summary PS ON PS.PERF_SUM_INST  = PSR.PERF_SUM_INST  
						Inner Join PSA.V_Eagle_Entity E ON PS.ENTITY_ID = E.ENTITY_ID  
						Inner Join PSA.V_Eagle_Interfaces I ON PS.SRC_INTFC_INST = I.INSTANCE 
						Inner join PSA.V_Eagle_Dictionary_Detail DD on DD.DICTIONARY_ITEM_ID = PSR.PERF_ROLLUP_RETURNS_ID 
							and DD.DICTIONARY_ID = PS.DICTIONARY_ID  

				WHERE	PS.DICTIONARY_ID = 23
						AND PS.PERF_FREQ_CODE in ('D','M')
						AND PS.PERF_SUMMARY_TYPE = 'P'
						AND E.Entity_Type in ('CIDX', 'INDX','AGG', 'SUB')  -- Total Perfomance, Index
						and PSR.Load_DTS > Coalesce(@lastLoadeDTS, '1900-01-01')
						-- and coalesce(PSR.Is_Src_Deleted,0) = 0
			) src

			Left Join EDW_Common.Dim_Index i on src.Index_Id = i.Index_Id 
				and src.Effective_Date between i.Record_Start_DTS and coalesce(i.Record_End_DTS, '9999-12-31')
	
			Left Join EDW_Common.Dim_Eagle_Index_Detail id on src.Index_Id = id.Index_Id 
				and id.Record_Is_Current_Flag = 1

			Left Join EDW_Common.Dim_Blend_Type bt on src.Blend_Type = bt.Blend_Type 
				and bt.Record_Is_Current_Flag = 1


		--LOGGING ETL RESULT
		Select @rowsInserted = Count(*) 
		From EDW_Common.[Fact_Eagle_Total_Index_Performance]
		Where Last_Update_DTS = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Total_Index_Performance', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Total_Index_Performance', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW @ErrorCode,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END