﻿CREATE PROC [EDW_Common].[Eagle_Fact_Eagle_Currency_FX_Rate] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN


	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2

			--@Load_Type varchar(255) = 'DELTA',
			--@Batch_DTS datetime2 = getdate(),
			--@ETL_Load_Key int = 0


	
	Begin Try


		-- get last loaded dts in current fact table
		Select	@lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From	EDW_Common.Fact_Eagle_Currency_FX_Rate



		INSERT INTO EDW_Common.Fact_Eagle_Currency_FX_Rate
		(
			  [Dim_Date_Key]
			  ,[Dim_From_Currency_Key]
			  ,[Dim_Currency_Key]
			  ,[Dim_Eagle_Interface_Key]
			  ,[SPOT_RATE]
			  ,[FOR_1MNTH_RATE]
			  ,[FOR_2MNTH_RATE]
			  ,[FOR_3MNTH_RATE]
			  ,[FOR_6MNTH_RATE]
			  ,[FOR_12MNTH_RATE]
			  ,[BIDRATE]
			  ,[OFFERRATE]
			  ,[FOR_7DAY_RATE]
			  ,[FOR_9MNTH_RATE]
			  ,[FOR_24MNTH_RATE]
			  ,[FOR_4MNTH_RATE]
			  ,[FOR_5MNTH_RATE]
			  ,[FOR_7MNTH_RATE]
			  ,[FOR_8MNTH_RATE]
			  ,[FOR_10MNTH_RATE]
			  ,[FOR_11MNTH_RATE]
			  ,[FOR_13MNTH_RATE]
			  ,[FOR_14MNTH_RATE]
			  ,[FOR_15MNTH_RATE]
			  ,[FOR_16MNTH_RATE]
			  ,[FOR_17MNTH_RATE]
			  ,[FOR_18MNTH_RATE]
			  ,[FOR_19MNTH_RATE]
			  ,[FOR_20MNTH_RATE]
			  ,[FOR_21MNTH_RATE]
			  ,[FOR_22MNTH_RATE]
			  ,[FOR_23MNTH_RATE]
			  ,[ON_DEPOSIT_RATE]
			  ,[TN_DEPOSIT_RATE]
				
			  ,[SRC_UPDATE_SOURCE]
			  ,[SRC_UPDATE_DATE]
			  ,Load_DTS
			  ,[Other_Info]
			  ,[Last_Update_DTS]
			  ,[Hash_Diff]
			  ,[ETL_Load_Key]
			  ,[Is_Src_Deleted]
		)


			SELECT	convert(int, convert(varchar(15), Effective_Date, 112)) as Dim_Date_Key,
					coalesce(fcur.Dim_Currency_Key, -1)						as Dim_From_Currency_Key,
					coalesce(cur.Dim_Currency_Key, -1)						as Dim_Currency_Key,
					coalesce(intf.Dim_Eagle_Interface_Key, -1)					as Dim_Interface_Key
					
				  ,[SPOT_RATE]
				  ,[FOR_1MNTH_RATE]
				  ,[FOR_2MNTH_RATE]
				  ,[FOR_3MNTH_RATE]
				  ,[FOR_6MNTH_RATE]
				  ,[FOR_12MNTH_RATE]
				  ,[BIDRATE]
				  ,[OFFERRATE]
				  ,[FOR_7DAY_RATE]
				  ,[FOR_9MNTH_RATE]
				  ,[FOR_24MNTH_RATE]
				  ,[FOR_4MNTH_RATE]
				  ,[FOR_5MNTH_RATE]
				  ,[FOR_7MNTH_RATE]
				  ,[FOR_8MNTH_RATE]
				  ,[FOR_10MNTH_RATE]
				  ,[FOR_11MNTH_RATE]
				  ,[FOR_13MNTH_RATE]
				  ,[FOR_14MNTH_RATE]
				  ,[FOR_15MNTH_RATE]
				  ,[FOR_16MNTH_RATE]
				  ,[FOR_17MNTH_RATE]
				  ,[FOR_18MNTH_RATE]
				  ,[FOR_19MNTH_RATE]
				  ,[FOR_20MNTH_RATE]
				  ,[FOR_21MNTH_RATE]
				  ,[FOR_22MNTH_RATE]
				  ,[FOR_23MNTH_RATE]
				  ,[ON_DEPOSIT_RATE]
				  ,[TN_DEPOSIT_RATE]

				  ,fx.[UPDATE_SOURCE]
				  ,fx.[UPDATE_DATE]
				  ,fx.Load_DTS
				  ,null
				  ,@today
				  ,fx.Hash_Diff
				  ,@ETL_Load_Key
			      ,fx.Is_Src_Deleted


			FROM PSA.V_Eagle_FX_Rates fx
			Join PsA.V_Eagle_Security_Master SM on fx.FROM_SECALIAS = SM.SECURITY_ALIAS
			Join PSA.V_Eagle_Security_Master SM2 on fx.SECURITY_ALIAS = SM2.SECURITY_ALIAS

			--Dim_Currency_Key
			Left Join EDW_Common.Dim_Currency cur on SM2.CURRENCY_CODE = cur.CURRENCY 
					and cur.Record_Is_Current_Flag = 1

			--Dim_From_Currency_Key
			Left Join EDW_Common.Dim_Currency fcur on SM.CURRENCY_CODE = fcur.CURRENCY 
					and fcur.Record_Is_Current_Flag = 1

			--Dim_Interfaces_Key
			Left Join EDW_Common.Dim_Eagle_Interface intf on convert(varchar(15), fx.SRC_INTFC_INST) = intf.Interface_Instance 
	 				and intf.Record_Is_Current_Flag = 1

			Where fx.Load_DTS > Coalesce(@lastLoadeDTS, '1900-01-01')

		--LOGGING ETL RESULT
		Select @rowsInserted = Count(*) 
		From EDW_Common.Fact_Eagle_Currency_FX_Rate
		Where Last_Update_DTS = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Currency_FX_Rate', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Currency_FX_Rate', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW @ErrorCode,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END