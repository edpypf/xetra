﻿CREATE PROC [EDW_Common].[BarraOne_Dim_Sector_Barra] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@Batch_DTS datetime2
	
	Begin Try

		Select @Batch_DTS = Batch_Date
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		IF OBJECT_ID('tempdb..#temp_src_sector_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_sector_records
		END

		-- load everything from source

		create table #temp_src_sector_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select Sector
				,convert(varchar(64), hashbytes('SHA1', Upper(Rtrim(Sector))), 2) Hash_Diff
		From (
			Select distinct IMCO_Sector_Mapped as Sector
				From PSA.[V_Barra_Characteristics_Sector] b
				Where b.analysis_date in (
								Select Distinct [As Of]
								From PSA.Barra_Header h
								where datediff(day, h.Begin_Batch, @Batch_DTS) = 0 
							)
		) src
		Where Sector is not null


		
		Insert Into [EDW_Common].[Dim_Sector_Barra] (
				Sector
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select Sector, @today, null, 1, @today, Hash_Diff, @ETL_Load_Key
		From #temp_src_sector_records src
		Where not exists (
			Select 1
			From [EDW_Common].[Dim_Sector_Barra] tgt
			where Record_Is_Current_Flag = 1 and src.Sector = tgt.Sector and src.Hash_Diff = tgt.Hash_Diff
		)

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Dim_Sector_Barra] tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_sector_records src
			Where tgt.Sector = src.Sector and coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')
		)

		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Sector_Barra]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Sector_Barra]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Sector_Barra', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Sector_Barra', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END