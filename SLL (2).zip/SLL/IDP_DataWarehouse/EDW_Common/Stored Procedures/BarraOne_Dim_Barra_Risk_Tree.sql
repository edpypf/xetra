﻿CREATE PROC [EDW_Common].[BarraOne_Dim_Barra_Risk_Tree] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@Batch_DTS datetime2
	
	Begin Try

		Select @Batch_DTS = Batch_Date
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		IF OBJECT_ID('tempdb..#temp_src_risk_tree_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_risk_tree_records
		END

			-- load everything from source

		create table #temp_src_risk_tree_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select distinct
				coalesce(Level_1, 'ALL') + '->' +  coalesce(Level_2, 'ALL') + '->' + coalesce(Level_3, 'ALL') + '->' + coalesce(Level_4, 'ALL') + '->' + coalesce(Level_5, 'ALL') Risk_Tree_Level
				, Native_Portfolio
				, Portfolio
				, Port_Type
				, Model
				, Level_1
				, Level_2
				, Level_3
				, Level_4
				, Level_5
				, Native_Portfolio_Description
				, Portfolio_Mapped
				, convert(varchar(64), hashbytes('SHA1', Upper(Concat(Native_Portfolio_Description, '|', Portfolio_Mapped))), 2) Hash_Diff
		From (
			Select   
				a.Port_Type
				, a.Portfolio
				, a.[Risk Model Name] AS Model
				, b.Level_1
				, b.Level_2
				, b.Level_3
				, b.Level_4
				, b.Level_5
				, coalesce(b.Native_Portfolio,'**') Native_Portfolio
				, coalesce(b.Native_Portfolio_Description, 'Not Applicable') Native_Portfolio_Description
				, case when Right(Rtrim(a.Portfolio),3) = '_DF'  then
						case when Rtrim(a.Portfolio) = 'OPB Tree_DF'
							then 'Client_OPB Prod Portfolio Tree by IMCO strategy'
							when Rtrim(a.Portfolio) = 'WSIB Tree_DF'
								then 'Client_WSIB Prod Portfolio Tree by IMCO strategy'
							when Rtrim(a.Portfolio) = 'WSIB Tree BM_ActualSAA_DF'
								then 'Client_WSIB BM Portfolio Tree by IMCO strategy_ActualSAA'
							when Rtrim(a.Portfolio) = 'Apollo_Accord_Fund_III_B_Proxy_DF'
								then 'Apollo_Accord_Fund_III_B_Proxy'
							when Rtrim(a.Portfolio) = 'OPB Tree BM_ActualSAA_DF'
								then 'Client_OPB BM Portfolio Tree by IMCO strategy_ActualSAA'
							else
								substring(rtrim(a.Portfolio), 1, len(rtrim(a.Portfolio))-3)
							end
					else 
						a.Portfolio
					end as Portfolio_Mapped
			From PSA.[Barra_Header] a 
			INNER JOIN PSA.[Barra_Characteristics] b ON a.BatchID = b.BatchID 
			where a.islatest=1 and b.Level_1 is not null 
			and a.[As Of] in (
								Select Distinct [As Of]
								From PSA.Barra_Header h
								where datediff(day, h.Begin_Batch, @Batch_DTS) = 0 
							)
			-- where datediff(day, a.Begin_Batch, @Batch_DTS) = 0 
				

			Union

			Select  distinct
					a.Port_Type
				, a.Portfolio
				, a.[Risk Model Name] AS Model
				, 'ALL' Level_1
				, 'ALL' Level_2
				, 'ALL' Level_3
				, 'ALL' Level_4
				, 'ALL' Level_5
				, '**' Native_Portfolio
				, 'Not Applicable' Native_Portfolio_Description
				, case when Right(Rtrim(a.Portfolio),3) = '_DF'  then
						case when Rtrim(a.Portfolio) = 'OPB Tree_DF'
							then 'Client_OPB Prod Portfolio Tree by IMCO strategy'
							when Rtrim(a.Portfolio) = 'WSIB Tree_DF'
								then 'Client_WSIB Prod Portfolio Tree by IMCO strategy'
							when Rtrim(a.Portfolio) = 'WSIB Tree BM_ActualSAA_DF'
								then 'Client_WSIB BM Portfolio Tree by IMCO strategy_ActualSAA'
							when Rtrim(a.Portfolio) = 'Apollo_Accord_Fund_III_B_Proxy_DF'
								then 'Apollo_Accord_Fund_III_B_Proxy'
							when Rtrim(a.Portfolio) = 'OPB Tree BM_ActualSAA_DF'
								then 'Client_OPB BM Portfolio Tree by IMCO strategy_ActualSAA'
							else
								substring(rtrim(a.Portfolio), 1, len(rtrim(a.Portfolio))-3)
							end
					else 
						a.Portfolio
					end as Portfolio_Mapped
			From PSA.[Barra_Header] a 
			INNER JOIN PSA.[Barra_Characteristics] AS b ON a.BatchID = b.BatchID 
			where a.islatest=1 and b.Level_1 is null 
			and a.[As Of] in (
					Select Distinct [As Of]
					From PSA.Barra_Header h
					where datediff(day, h.Begin_Batch, @Batch_DTS) = 0 
				)
			-- where datediff(day, a.Begin_Batch, @Batch_DTS) = 0 
				
		) src

		
		INSERT INTO [EDW_Common].[Dim_Barra_Risk_Tree]
           ([Risk_Tree_Level]
           ,[Native_Portfolio]
           ,[Model]
           ,[Port_Type]
           ,[Portfolio]
		   ,Portfolio_Mapped
           ,[Native_Portfolio_Description]
           ,[Level_1]
           ,[Level_2]
           ,[Level_3]
           ,[Level_4]
           ,[Level_5]
           ,[Record_Start_DTS]
           ,[Record_End_DTS]
           ,[Record_Is_Current_Flag]
           ,[Last_Update_DTS]
           ,[Hash_Diff]
           ,[ETL_Load_Key]
		)
     
		Select  Risk_Tree_Level
				, Native_Portfolio
				, Model
				, Port_Type
				, Portfolio
				, Portfolio_Mapped
				, Native_Portfolio_Description
				, Level_1
				, Level_2
				, Level_3
				, Level_4
				, Level_5
				, @today, null, 1, @today, Hash_Diff, @ETL_Load_Key
		From #temp_src_risk_tree_records src
		Where not exists (
			Select 1
			From [EDW_Common].[Dim_Barra_Risk_Tree] tgt
			where Record_Is_Current_Flag = 1 and src.Model = tgt.Model and src.Portfolio = tgt.Portfolio and src.Port_Type = tgt.Port_Type and src.Native_Portfolio = tgt.Native_Portfolio 
			     and src.Risk_Tree_Level = tgt.Risk_Tree_Level and coalesce(src.Hash_Diff,'') = coalesce(tgt.Hash_Diff,'')
		)

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Dim_Barra_Risk_Tree] tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_risk_tree_records src
			Where src.Model = tgt.Model and src.Portfolio = tgt.Portfolio and src.Port_Type = tgt.Port_Type and src.Native_Portfolio = tgt.Native_Portfolio  and src.Risk_Tree_Level = tgt.Risk_Tree_Level  and coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')
		)

		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Barra_Risk_Tree]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Barra_Risk_Tree]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Barra_Risk_Tree', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Barra_Risk_Tree', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END