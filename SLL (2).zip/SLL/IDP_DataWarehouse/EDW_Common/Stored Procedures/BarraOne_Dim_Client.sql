﻿CREATE PROC [EDW_Common].[BarraOne_Dim_Client] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@Batch_DTS datetime2
	
	Begin Try

		Select @Batch_DTS = Batch_Date
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		IF OBJECT_ID('tempdb..#temp_src_client_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_client_records
		END

			-- load everything from source

		create table #temp_src_client_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 

			Select Distinct b.client as Src_Client_Id
				    ,coalesce(cm.Master_Client, b.client) as Client_Id
					,coalesce(coalesce(c.[Client_Name], cp.Client_Name), b.client) Client_Name
					,coalesce(c.[Parent_Client_ID], cp.Parent_client_id) Parent_client_id
					,0 [Is_Src_Deleted]
					,convert(varchar(64), hashbytes('SHA1', upper(concat(rtrim(coalesce(coalesce(c.[Client_Name], cp.Client_Name), b.client)), '|', coalesce(coalesce(c.[Parent_Client_ID], cp.Parent_client_id),'')))), 2) Hash_Diff

			From (Select distinct Client From   PSA.Barra_Header) b
			left join [PSA].[Manual_Client_Mapping] cm on b.Client = cm.Alternate_Client
			left join [PSA].[Manual_Official_Clients] c on cm.Master_Client = c.Client_Id
			left join [PSA].[Manual_Official_Clients] cp on b.client = cp.Client_Id
			where b.Client is not null


		
		Insert Into [EDW_Common].[Dim_Client] (
		        Src_Client_Id
				,[Client_ID]
				,[Client_Name]
				,[Parent_Client_ID]
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select Src_Client_Id, Client_Id, Client_Name, Parent_Client_Id, @today, null, 1, @today, Hash_Diff, @ETL_Load_Key
		From #temp_src_client_records src
		Where not exists (
			Select 1
			From [EDW_Common].[Dim_Client] tgt
			where Record_Is_Current_Flag = 1 and src.client_id = tgt.client_id and tgt.Src_Client_Id = src.Src_Client_Id and src.Hash_Diff = tgt.Hash_Diff
		)
		and src.Is_Src_Deleted = 0

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Dim_Client] tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_client_records src
			Where tgt.Client_Id = src.Client_Id and tgt.Src_Client_Id = src.Src_Client_Id and (coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1)
		)

		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Client]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Client]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Client', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Client', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END