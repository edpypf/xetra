﻿CREATE PROC [EDW_Common].[Common_Dim_Portfolio] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

Declare @today datetime2 = getdate()

Declare @rowsInserted int = 0,
		@rowsUpdated int = 0,
		@rowsExpired int = 0

		--,@Load_Type varchar(255) = 'DELTA'
		--,@Load_DTS datetime2 = getdate()
		--,@ETL_Load_Key int = -1 ;
		
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_dim_portfolio_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_dim_portfolio_records
		END

		-- load everything from source into temp table
		create table #temp_src_dim_portfolio_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 


		with eagle as 
		(	Select	Portfolio_id,
					Portfolio_Name,
					Portfolio_Type,
					Is_Src_Deleted
					
			From ( 	Select	rtrim([Entity_ID]) Portfolio_id
							,Rtrim([Entity_Name]) Portfolio_Name
							,Rtrim(Entity_Type) Portfolio_Type
							,Is_Src_Deleted
							,Row_Number() Over (Partition By rtrim([Entity_ID]) order by Load_DTS Desc) rn
					From PSA.Eagle_Entity
					where Entity_Type in ('SUB','PORT','COMP')
				 ) src
			where rn = 1
		),
		imco as 
		(	Select	distinct
					PM.Portfolio_Id,
					Rtrim(coalesce(M.Portfolio_Type,RM.Portfolio_Type)) Portfolio_Type,
					Portfolio_Classification,
					Reporting_Portfolio_Name,
					Manager,
					Manager_Classification_Risk,
					CCE,
					FX_Hedging,
					PM.Is_Src_Deleted,
					Custodian_Classification,
					Manager_Mandate_Type,
					Manager_Mandate_Curr,
					HP_Blend

			From ( 	Select   Portfolio_Id
							,Is_Src_Deleted
							,Row_Number() Over (Partition By Portfolio_Id order by Load_DTS Desc) rn
					From [PSA].[Manual_Portfolio_Mapping]

					Union

					Select	 Portfolio_Id
							,Is_Src_Deleted
							,Row_Number() Over (Partition By Portfolio_Id Order by Load_DTS Desc) rn
					From [PSA].[Manual_Portfolio_Tags]

					Union

					Select	 Parent_Portfolio_Id Portfolio
							,min(case when coalesce(Is_Src_Deleted, 0)=1 then 1 else 0 end) [Is_Src_Deleted]
							,1 rn
					From [PSA].[Manual_Portfolio_Mapping]
					where Parent_Portfolio_Id is not null
					Group By Parent_Portfolio_Id

					union 

					--Select  Overlay_Proxy_For_Portfolio Portfolio_Id
					--		,min(case when coalesce(Is_Src_Deleted, 0)=1 then 1 else 0 end) [Is_Src_Deleted]
					--		,1 rn
					--From [PSA].[Manual_Portfolio_Mapping]
					--where Overlay_Proxy_For_Portfolio is not null
					--Group By Overlay_Proxy_For_Portfolio

					--union

					Select Performance_Parent_Portfolio_Id Portfolio
							,min(case when coalesce(Is_Src_Deleted, 0)=1 then 1 else 0 end) [Is_Src_Deleted]
							,1 rn
					From [PSA].[Manual_Portfolio_Mapping]
					where Performance_Parent_Portfolio_Id is not null
					Group By Performance_Parent_Portfolio_Id

					union

					Select  Portfolio_Id,
							Is_Src_Deleted,
							Row_Number() Over (Partition By Portfolio_Id Order by Load_DTS Desc) rn
					From [PSA].[Manual_RM_Portfolio_Hierarchy]

					union

					Select	Parent_Portfolio_Id Portfolio_Id,
							min(case when coalesce(Is_Src_Deleted, 0)=1 then 1 else 0 end) [Is_Src_Deleted],
							1 rn
					From [PSA].[Manual_RM_Portfolio_Hierarchy]
					where Parent_Portfolio_Id is not null
					Group By Parent_Portfolio_Id
				) PM
				left join PSA.V_Manual_Portfolio_Tags P on PM.Portfolio_Id = P.Portfolio_ID
				left join ( select	Portfolio_ID,
									Portfolio_Type,
									row_number() over (partition by Portfolio_Id order by Start_Date desc) rn
							from	PSA.V_Manual_Portfolio_Mapping
						  ) M on PM.Portfolio_Id = M.Portfolio_ID and M.rn = 1
				left join [PSA].[V_Manual_RM_Portfolio_Hierarchy] RM on PM.Portfolio_Id = RM.Portfolio_ID
		
			where	PM.rn = 1 
					and PM.Portfolio_Id is not null
		),
		ss as 
		(	Select  Distinct 
					Rtrim(Portfolio_Id) Portfolio_Id
					,Rtrim(Portfolio_Name) Portfolio_Name
					,Inception_Date
			From (  select	 Account_ID Portfolio_Id
							,Name Portfolio_Name
							,Inception_Date
					from ( SELECT  Account_ID
									,Name
									,Inception_Date
									,row_number() over (partition by Account_ID order by Load_DTS desc) rn
								FROM PSA.StateStreet_Fund_Performance
							) p
					where p.rn = 1
					Union
					 -- Pull in any funds that are in the accounting extract, but not the performance extract
					SELECT	 distinct
								a.Fund Portfolio_Id
							,a.Fund_Name Portfolio_Name
							,NULL as Inception_Date
					from	PSA.StateStreet_Accounting_Positions a
					Where	not exists ( select 1
											from PSA.StateStreet_Fund_Performance p
											where p.Account_ID = a.Fund )
				) s
		),

		--get unique Portfolio_Ids
		p as
		(	select	distinct
					Portfolio_ID
			from	eagle
			union
			select	distinct
					Portfolio_ID
			from	imco
			union
			select	distinct
					Portfolio_ID
			from	ss
		)


			select *
			from (  select	T.*,
							convert(varchar(64), Hashbytes('SHA1', UPPER(concat(coalesce(rtrim(Portfolio_Name),''), '|', coalesce(rtrim(Inception_Date),''), '|', coalesce(rtrim(Portfolio_Classification),''), '|', coalesce(rtrim(Reporting_Portfolio_Name),''), '|', coalesce(rtrim(Manager),''), '|', coalesce(rtrim(Manager_Classification_Risk),''), '|', coalesce(rtrim(Portfolio_Type),''), '|', coalesce(rtrim(CCE),''), '|', coalesce(rtrim(FX_Hedging),''), '|', coalesce(rtrim(Custodian_Classification),''), '|', coalesce(rtrim(Manager_Mandate_Type),''), '|', coalesce(rtrim(Manager_Mandate_Curr),''), '|', coalesce(rtrim(HP_Blend),'') ))),2) Hash_Diff

					from ( select	
									p.Portfolio_ID,
									max(coalesce(ss.Portfolio_Name, eagle.Portfolio_Name, imco.Portfolio_ID))	Portfolio_Name,
									max(coalesce(imco.Portfolio_Type, eagle.Portfolio_Type))	Portfolio_Type,
									max(ss.Inception_Date) Inception_Date,
									max(imco.Portfolio_Classification) Portfolio_Classification ,
									max(imco.Reporting_Portfolio_Name) Reporting_Portfolio_Name,
									max(imco.Manager) Manager,
									max(imco.Manager_Classification_Risk) Manager_Classification_Risk,
									max(imco.CCE) CCE,
									max(imco.FX_Hedging) FX_Hedging,
									max(Custodian_Classification) Custodian_Classification,
									max(Manager_Mandate_Type) Manager_Mandate_Type,
									max(Manager_Mandate_Curr) Manager_Mandate_Curr,
									max(HP_Blend) HP_Blend,
									min(case when ss.Portfolio_Name is not null then 0
										when coalesce(eagle.Is_Src_Deleted, imco.Is_Src_Deleted)=1 and ss.Portfolio_Name is null then 1
										else 0 end ) Is_Src_Deleted

		
							from	p
									left join ss on p.Portfolio_ID = ss.Portfolio_ID
									left join eagle on p.Portfolio_ID = eagle.Portfolio_ID
									left join imco on p.Portfolio_ID = imco.Portfolio_ID
							Group By p.Portfolio_ID
							) T
				) src
		

		--INSERT NEW RECORDS INTO DIM TABLE
		insert into EDW_Common.Dim_Portfolio
		(
			Portfolio_ID,
			Portfolio_Name,
			Portfolio_Type,
			Inception_Date,
			Portfolio_Classification,
			Reporting_Portfolio_Name,
			Manager,
			Manager_Classification_Risk,
			CCE,
			FX_Hedging,
			Record_Start_DTS,
			Record_End_DTS,
		    Custodian_Classification,
		    Manager_Mandate_Type,
		    Manager_Mandate_Curr,
			HP_Blend,
			Record_Is_Current_Flag,
			Last_Update_DTS,
			Hash_Diff,
			ETL_Load_Key
		)
			select	src.Portfolio_ID,
					src.Portfolio_Name,
					src.Portfolio_Type,
					src.Inception_Date,
					src.Portfolio_Classification,
					src.Reporting_Portfolio_Name,
					src.Manager,
					src.Manager_Classification_Risk,
					src.CCE,
					src.FX_Hedging,
					case when tgt.Portfolio_Id is null then '2000-01-01' else @today end,
					null,
					src.Custodian_Classification,
					src.Manager_Mandate_Type,
					src.Manager_Mandate_Curr,
					src.HP_Blend,
					1,
					@today,
					src.Hash_Diff,
					@ETL_Load_Key

			from	#temp_src_dim_portfolio_records src
					Left Join EDW_Common.Dim_Portfolio tgt on src.Portfolio_Id = tgt.Portfolio_Id and tgt.Record_Is_Current_Flag = 1

			where	(
						tgt.Portfolio_Id is null 
						or (tgt.Portfolio_Id is not null and src.Hash_Diff <> tgt.Hash_Diff)
					)
					and src.Is_Src_Deleted = 0

		
		--UPDATE/EXPIRE EXISTING RECORDS
		Update tgt
		Set Last_Update_DTS = @today, 
			Record_End_DTS = @today, 
			Record_Is_Current_Flag = 0, 
			ETL_Load_Key = @ETL_Load_Key
		From EDW_Common.Dim_Portfolio tgt
		Where tgt.Record_Is_Current_Flag = 1 
			and exists
			(	Select	1
				From	#temp_src_dim_portfolio_records src
				Where	tgt.Portfolio_Id = src.Portfolio_Id 
						and ( coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1 )
			)



		--ETL Logging
		Select @rowsInserted = Count(*) 
		From EDW_Common.Dim_Portfolio
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From EDW_Common.Dim_Portfolio
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Portfolio', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	--Error Handling
	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Portfolio', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END