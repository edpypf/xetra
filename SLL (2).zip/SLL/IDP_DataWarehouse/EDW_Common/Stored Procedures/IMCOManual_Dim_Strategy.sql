﻿CREATE PROC [EDW_Common].[IMCOManual_Dim_Strategy] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_strategy_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_strategy_records
		END

		-- load everything from source

		create table #temp_src_strategy_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		With mpm as (
			Select  [IPS_Strategy]
				   ,[Legacy_Strategy]
				   ,[Is_Src_Deleted]
			  From (
				SELECT [IPS_Strategy]
					  ,[Legacy_Strategy]
					  ,[Is_Src_Deleted]
					  ,Row_Number() Over(Partition By [Legacy_Strategy], [IPS_Strategy]  Order by Load_DTS Desc) rn
				FROM [PSA].[Manual_Official_Strategy_Mapping]
			  ) sm
			  Where rn = 1
		)
		Select [IPS_Strategy] Src_Strategy_Id
			    ,[IPS_Strategy] Strategy_Id
				,[Strategy_Group]
				,[IPS_Short_Name]
				,[IPS_Strategy_Order]
				,[Strategy_Group_Order]
			    ,[IPS_Strategy_within_Group_Order]
				,[Is_Src_Deleted]
				,Start_Date
				,End_Date
				,Hash_Diff
		From (
			Select [IPS_Strategy]
				   ,[Strategy_Group]
				   ,[IPS_Short_Name]
				   ,[IPS_Strategy_Order]
				   ,[Strategy_Group_Order]
				   ,[IPS_Strategy_within_Group_Order]
				   ,Start_Date
				   ,End_Date
					,[Is_Src_Deleted]
					,Hash_Diff
					,Row_Number() Over (Partition By [IPS_Strategy], Start_Date order by Load_DTS Desc) rn

			From [PSA].[Manual_Official_IPS_Strategies]
		) src
		where rn = 1

		union 

		Select Src_Strategy_Id,
				Strategy_Id,
				[Strategy_Group],
				[IPS_Short_Name],
				[IPS_Strategy_Order],
				[Strategy_Group_Order],
				[IPS_Strategy_within_Group_Order],
				[Is_Src_Deleted],
				Start_Date,
				End_Date,
				Hash_Diff
		From (
			Select 
					mpm.Legacy_Strategy Src_Strategy_Id
				   ,s.[IPS_Strategy] Strategy_Id
				   ,s.[Strategy_Group]
				   ,s.[IPS_Short_Name]
				   ,s.[IPS_Strategy_Order]
				   ,s.[Strategy_Group_Order]
				   ,s.[IPS_Strategy_within_Group_Order]
				   ,mpm.[Is_Src_Deleted]
				   ,s.Start_Date
				   ,s.End_Date
				   ,s.Hash_Diff
			From [PSA].[V_Manual_Official_IPS_Strategies] s
			Join mpm on s.[IPS_Strategy] = mpm.[IPS_Strategy]
			Where mpm.Legacy_Strategy <> mpm.[IPS_Strategy]
		) src

		union

		/* find official strategy mapping to another */
		Select Src_Strategy_Id,
				Strategy_Id,
				[Strategy_Group],
				[IPS_Short_Name],
				[IPS_Strategy_Order],
				[Strategy_Group_Order],
				[IPS_Strategy_within_Group_Order],
				[Is_Src_Deleted],
				Start_Date,
				End_Date,
				Hash_Diff
		From (
			Select 
					sm_inter.Legacy_Strategy Src_Strategy_Id
				   ,s.[IPS_Strategy] Strategy_Id
				   ,s.[Strategy_Group]
				   ,s.[IPS_Short_Name]
				   ,s.[IPS_Strategy_Order]
				   ,s.[Strategy_Group_Order]
				   ,s.[IPS_Strategy_within_Group_Order]
				   ,case when sm.[Is_Src_Deleted]=1 or sm_inter.[Is_Src_Deleted] = 1 then 1 else 0 end [Is_Src_Deleted]
				   ,s.Start_Date
				   ,s.End_Date
				   ,s.Hash_Diff
			From mpm sm_inter  
			Join mpm sm on sm_inter.[IPS_Strategy] = sm.[Legacy_Strategy] 
			Join [PSA].[V_Manual_Official_IPS_Strategies] s on sm.[IPS_Strategy] = s.[IPS_Strategy]
			where sm_inter.Legacy_Strategy <> sm_inter.IPS_Strategy and sm_inter.Legacy_Strategy <> sm_inter.IPS_Strategy
		) src

		
		Insert Into [EDW_Common].[Dim_Strategy] (
				Src_Strategy_Id
				,Strategy_Id
				,Strategy_Group
				,[Strategy_Short_Name]
				,[Strategy_Order]
				,[Strategy_Group_Order]
				,[Strategy_In_Group_Order]
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
				,Is_Src_Deleted_flag
				,Is_Official_Flag
		)
		Select  Src_Strategy_Id,
				Strategy_Id,
				[Strategy_Group],
				[IPS_Short_Name],
				[IPS_Strategy_Order],
				[Strategy_Group_Order],
				[IPS_Strategy_within_Group_Order],
				Start_Date, End_Date, 
				case when End_Date > @today then 1 else 0 end, @today, Hash_Diff, @ETL_Load_Key
				,Is_Src_Deleted
				,1
		From #temp_src_strategy_records src 
		Where not exists (
			Select 1
			From [EDW_Common].[Dim_Strategy] tgt
			where Is_Src_Deleted_flag = 0 and src.Start_Date = tgt.Record_Start_DTS and src.End_Date = tgt.Record_end_DTS and src.Src_Strategy_Id = tgt.Src_Strategy_Id and src.Hash_Diff = tgt.Hash_Diff
		)
		and src.Is_Src_Deleted = 0

		Update tgt
		Set Last_Update_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key, Is_Src_Deleted_flag = 0
		From [EDW_Common].[Dim_Strategy] tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_strategy_records src
			Where src.Src_Strategy_Id = tgt.Src_Strategy_Id and src.Start_Date = tgt.Record_Start_DTS and coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') 
		)


		/* set deleted flag for any record not in src */
		Update tgt
		Set Last_Update_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key, Is_Src_Deleted_flag = 1
		From [EDW_Common].[Dim_Strategy] tgt
		Where tgt.Is_Official_Flag = 1 and Is_Src_Deleted_flag = 0 and not exists
		(
			Select 1
			From #temp_src_strategy_records src
			Where src.Src_Strategy_Id = tgt.Src_Strategy_Id and src.Start_Date = tgt.Record_Start_DTS and src.End_Date = tgt.Record_End_DTS 
		)

		/* set deleted flag for any record deleted in src */
		Update tgt
		Set Last_Update_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key, Is_Src_Deleted_flag = 1
		From [EDW_Common].[Dim_Strategy] tgt
		Where tgt.Is_Official_Flag = 1 and Is_Src_Deleted_flag = 0 and  exists
		(
			Select 1
			From #temp_src_strategy_records src
			Where src.Src_Strategy_Id = tgt.Src_Strategy_Id and src.Start_Date = tgt.Record_Start_DTS and src.Is_Src_Deleted = 1 
		)
		

		/* fix possible end_date records with current flag = 1 if any */
		Update tgt
		Set Last_Update_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Dim_Strategy] tgt
		Where tgt.Record_Is_Current_Flag = 1 and tgt.Is_Official_Flag = 1 and (Record_End_DTS <= @today or Is_Src_Deleted_flag = 1)


		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Strategy]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Strategy]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Strategy', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Strategy', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END