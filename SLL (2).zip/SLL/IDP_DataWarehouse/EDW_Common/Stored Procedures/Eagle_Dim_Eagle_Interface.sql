﻿CREATE PROC [EDW_Common].[Eagle_Dim_Eagle_Interface] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@Batch_DTS datetime2
	
	Begin Try

		Select @Batch_DTS = Batch_Date
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		IF OBJECT_ID('tempdb..#temp_src_interfaces') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_interfaces
		END

		-- load everything from source
		create table #temp_src_interfaces
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select	RTRIM(INSTANCE) INSTANCE,
				RTRIM(Source_Interface_Short) Source_Interface_Short,
				RTRIM(Source_Interface_Long) Source_Interface_Long,
				COMMENTS,
				Is_Src_Deleted,
		       convert(varchar(64), Hashbytes('SHA1', upper(concat(coalesce(Rtrim(INSTANCE),''), '|', coalesce(Rtrim(Source_Interface_Short),''), '|', coalesce(Rtrim(Source_Interface_Long),''), '|', coalesce(Rtrim(Is_Src_Deleted),'') ))),2) Hash_Diff
		From ( Select	INSTANCE,
						SHORT_DESC as Source_Interface_Short,
						LONG_DESC as Source_Interface_Long,
						COMMENTS,
						Is_Src_Deleted
				From PSA.V_Eagle_Interfaces
			 ) src

			 
		--INSERT NEW RECORDS INTO DIM TABLE
		Insert Into [EDW_Common].[Dim_Eagle_Interface] 
		(
		    Interface_INSTANCE,
			Interface_Name,
			Interface_Full_Name,
			COMMENTS,
			Record_Start_DTS,
			Record_End_DTS,
			Record_Is_Current_Flag,
			Last_Update_DTS,
			Hash_Diff,
			ETL_Load_Key
		)
		Select	INSTANCE,
				Source_Interface_Short,
				Source_Interface_Long,
				COMMENTS,
				@today, 
				null, 
				1, 
				@today, 
				Hash_Diff,
				@ETL_Load_Key

		From #temp_src_interfaces src
		Where not exists 
			(
				Select 1
				From [EDW_Common].[Dim_Eagle_Interface] tgt
				where Record_Is_Current_Flag = 1 and src.INSTANCE = tgt.Interface_INSTANCE 
					  and coalesce(src.Hash_Diff,'') = coalesce(tgt.Hash_Diff,'')
			)
			and src.Is_Src_Deleted = 0


		--UPDATE/EXPIRE EXISTING RECORDS
		Update tgt
		Set Last_Update_DTS = @today,
			Record_End_DTS = @today, 
			Record_Is_Current_Flag = 0, 
			ETL_Load_Key = @ETL_Load_Key

		From EDW_Common.Dim_Eagle_Interface tgt
		Where tgt.Record_Is_Current_Flag = 1 
			and exists
			(
				Select	1
				From	#temp_src_interfaces src
				Where	src.INSTANCE = tgt.Interface_INSTANCE 
						and ( (coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') and src.Is_Src_Deleted = 0 ) or src.Is_Src_Deleted = 1 )
			)


		--ETL Logging
		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Eagle_Interface]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Eagle_Interface]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Eagle_Interface', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	--Error Handling
	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Eagle_Interface', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END