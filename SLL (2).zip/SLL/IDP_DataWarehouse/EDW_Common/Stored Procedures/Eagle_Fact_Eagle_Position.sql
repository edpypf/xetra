﻿CREATE PROC [EDW_Common].[Eagle_Fact_Eagle_Position] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN


	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2

			--@Load_Type varchar(255) = 'DELTA',
			--@Batch_DTS datetime2 = getdate(),
			--@ETL_Load_Key int = 0


	
	Begin Try


		-- get last loaded dts in current fact table
		Select	@lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From	EDW_Common.Fact_Eagle_Position



		INSERT INTO EDW_Common.Fact_Eagle_Position
		(
			Dim_Portfolio_Key,
			Dim_Security_Key,
			Dim_Eagle_Portfolio_Detail_Key,
			Dim_Eagle_Security_Detail_Key,
			Dim_Base_Currency_Key,
			Dim_Local_Currency_Key,
			Dim_Date_Key,
			Dim_Eagle_Interface_Key,
			LONG_SHORT_IND,
			ACCRUED_INCOME,
			ACCRUED_INCOME_LOCAL,
			BASE_UNREALIZED_GL,
			CASH_ACCT_ALIAS,
			COUPON_RECEIVABLE,
			COUPON_RECEIVABLE_LOCAL,
			CURR_FX_RATE,
			CURRENCY_RETURN,
			DIVIDEND_RECEIVABLE,
			DIVIDEND_RECEIVABLE_LOCAL,
			EXCHANGE_RATE_DATE,
			HEDGE_CUSIP,
			INCOME_RETURN,
			INDX_WEIGHT,
			INTEREST_EARNED,
			LOCAL_MARKET_VALUE,
			LOCAL_UNREALIZED_GL,
			MARKET_VALUE,
			MARKET_VALUE_INCOME,
			MARKET_VALUE_INCOME_LOCAL,
			MISC_INC_RECEIVABLE,
			MISC_INC_RECEIVABLE_LOCAL,
			MKT_EXCHANGE_RATE,
			NOTIONAL_COST,
			NOTIONAL_COST_LOCAL,
			NOTIONAL_MARKET_VALUE,
			NOTIONAL_MARKET_VALUE_LOCAL,
			ORIG_FACE,
			ORIGINAL_COST_AMOUNT,
			PRICE,
			PRICE_DATE,
			PRICE_RETURN,
			PRINCIPAL_RETURN,
			RECLAIM_RECEIVABLE,
			RECLAIM_RECEIVABLE_LOCAL,
			SECURITY_INCOME,
			SETTLE_QUANTITY,
			SHARE_PAR_VALUE,
			SRC_SYS_C,
			STAR_MARKET_VALUE,
			STAR_MARKET_VALUE_LOCAL,
			TOTAL_RETURN,
			UNREALIZED_CURR_GL,
			UNREALIZED_SEC_GL,

			URGL_VAR_MGN,
			URGL_VAR_MGN_LOCAL,
			BASE_VARIATION_MARGIN,
			LOCAL_VARIATION_MARGIN,
			BOOK_VALUE,
			BOOK_VALUE_LOCAL ,
			POS_FLAG,
			SETTLEMENT_DATE_POSITION ,
			Src_UPDATE_DATE,
			Src_UPDATE_SOURCE,
			Other_Info,
			Load_DTS,
			Last_Update_DTS,
			Hash_Diff,
			ETL_Load_Key,
			Position_Id,
			Position_Detail_Id,
			Is_Src_Deleted
		)


			SELECT	coalesce(p.Dim_Portfolio_Key, -1)						as Dim_Portfolio_Key,
					coalesce(sec.Dim_Security_Key, -1)						as Dim_Security_Key,
					coalesce(pd.Dim_Eagle_Portfolio_Detail_Key, -1)						as Dim_Eagle_Portfolio_Detail_Key,
					coalesce(secd.Dim_Eagle_Security_Detail_Key, -1)						as Dim_Eagle_Security_Detail_Key,
					coalesce(cur.Dim_Currency_Key, -1)						as Dim_Base_Currency_Key,
					coalesce(lc.Dim_Currency_Key, -1)						as Dim_Local_Currency_Key,
					convert(int, convert(varchar(15), Effective_Date, 112)) as Dim_Date_Key,
					coalesce(intf.Dim_Eagle_Interface_Key, -1)					as Dim_Eagle_Interface_Key,
					LONG_SHORT_IND,
					ACCRUED_INCOME,
					ACCRUED_INCOME_LOCAL,
					BASE_UNREALIZED_GL,
					CASH_ACCT_ALIAS,
					COUPON_RECEIVABLE,
					COUPON_RECEIVABLE_LOCAL,
					CURR_FX_RATE,
					CURRENCY_RETURN,
					DIVIDEND_RECEIVABLE,
					DIVIDEND_RECEIVABLE_LOCAL,
					EXCHANGE_RATE_DATE,
					HEDGE_CUSIP,
					INCOME_RETURN,
					INDX_WEIGHT,
					INTEREST_EARNED,
					LOCAL_MARKET_VALUE,
					LOCAL_UNREALIZED_GL,
					MARKET_VALUE,
					MARKET_VALUE_INCOME,
					MARKET_VALUE_INCOME_LOCAL,
					MISC_INC_RECEIVABLE,
					MISC_INC_RECEIVABLE_LOCAL,
					MKT_EXCHANGE_RATE,
					NOTIONAL_COST,
					NOTIONAL_COST_LOCAL,
					NOTIONAL_MARKET_VALUE,
					NOTIONAL_MARKET_VALUE_LOCAL,
					ORIG_FACE,
					ORIGINAL_COST_AMOUNT,
					PRICE,
					PRICE_DATE,
					PRICE_RETURN,
					PRINCIPAL_RETURN,
					RECLAIM_RECEIVABLE,
					RECLAIM_RECEIVABLE_LOCAL,
					SECURITY_INCOME,
					SETTLE_QUANTITY,
					SHARE_PAR_VALUE,
					SRC_SYS_C,
					STAR_MARKET_VALUE,
					STAR_MARKET_VALUE_LOCAL,
					TOTAL_RETURN,
					UNREALIZED_CURR_GL,
					UNREALIZED_SEC_GL,
					URGL_VAR_MGN,
					URGL_VAR_MGN_LOCAL,
					BASE_VARIATION_MARGIN,
					LOCAL_VARIATION_MARGIN,
					BOOK_VALUE,
					BOOK_VALUE_LOCAL ,
					POS_FLAG,
					SETTLEMENT_DATE_POSITION ,

					UPDATE_DATE,
					UPDATE_SOURCE,
				    case when p.Dim_Portfolio_key is null or pd.Dim_Eagle_Portfolio_Detail_Key is null 
				        or sec.Dim_Security_Key is null or secd.Dim_Eagle_Security_Detail_Key is null
						or cur.Dim_Currency_Key is null or lc.Dim_Currency_key is null
						or intf.Dim_Eagle_Interface_Key is null then
						'{' + 
						'"Portfolio_Id": "' + convert(varchar(50), src.Portfolio_ID) + '",' + 
						'"Security_Alias":"' + convert(varchar(50), src.Security_Id) + '",' + 
						'"SRC_INTFC_INST":"' + convert(varchar(50), src.SRC_INTFC_INST) + '",' + 
						'"Base_Currency":"' + src.BASE_CURRENCY + '",' + 
						'"Local_Currency":"' + src.Local_CURRENCY + '"' + 
						'}'
					else 
						null
					End,
					Load_DTS,
					@today,
					src.Hash_Diff,
					@ETL_Load_Key,
					Position_Id,
					Position_Detail_Id,
					case when Is_Position_Deleted = 1 then 1 else Is_Src_Deleted End Is_Src_Deleted


			FROM  ( SELECT	
							Portfolio_ID,
							Security_ID,
							EFF_DT AS EFFECTIVE_DATE,
							LONG_SHORT_IND,
							cast(SRC_INTFC_INST as varchar) SRC_INTFC_INST,
							ACCRUED_INCOME,
							ACCRUED_INCOME_LOCAL,
							BASE_CURRENCY,
							BASE_UNREALIZED_GL,
							CASH_ACCT_ALIAS,
							COUPON_RECEIVABLE,
							COUPON_RECEIVABLE_LOCAL,
							CURR_FX_RATE,
							CURRENCY_RETURN,
							DIVIDEND_RECEIVABLE,
							DIVIDEND_RECEIVABLE_LOCAL,
							EXCHANGE_RATE_DATE,
							HEDGE_CUSIP,
							INCOME_RETURN,
							INDX_WEIGHT,
							INTEREST_EARNED,
							LOCAL_CURRENCY,
							LOCAL_MARKET_VALUE,
							LOCAL_UNREALIZED_GL,
							MARKET_VALUE,
							MARKET_VALUE_INCOME,
							MARKET_VALUE_INCOME_LOCAL,
							MISC_INC_RECEIVABLE,
							MISC_INC_RECEIVABLE_LOCAL,
							MKT_EXCHANGE_RATE,
							NOTIONAL_COST,
							NOTIONAL_COST_LOCAL,
							NOTIONAL_MARKET_VALUE,
							NOTIONAL_MARKET_VALUE_LOCAL,
							ORIG_FACE,
							ORIGINAL_COST_AMOUNT,
							PRICE,
							PRICE_DATE,
							PRICE_RETURN,
							PRINCIPAL_RETURN,
							RECLAIM_RECEIVABLE,
							RECLAIM_RECEIVABLE_LOCAL,
							SECURITY_INCOME,
							SETTLE_QUANTITY,
							SHARE_PAR_VALUE,
							SRC_SYS_C,
							STAR_MARKET_VALUE,
							STAR_MARKET_VALUE_LOCAL,
							TOTAL_RETURN,
							UNREALIZED_CURR_GL,
							UNREALIZED_SEC_GL,
							UPDATE_DATE,
							UPDATE_SOURCE,
							URGL_VAR_MGN,
							URGL_VAR_MGN_LOCAL,

							VAR_MGN   as BASE_VARIATION_MARGIN,
							VAR_MGN_LOCAL   as LOCAL_VARIATION_MARGIN,
							BOOK_VALUE,
							BOOK_VALUE_LOCAL ,
							POS_FLAG,
							SETTLEMENT_DATE_POSITION ,
							Load_DTS,
							Hash_Diff,
							Position_Detail_Id,
							Position_Id,
							Is_Src_Deleted,
							Is_Position_Deleted

					FROM (	SELECT	
									P.ENTITY_ID as Portfolio_ID
									, coalesce(P.Effective_Date, PD.Effective_Date) as EFF_DT
									, cast(PD.Security_Alias as varchar) as Security_ID
									, PD.*
									, P.SRC_INTFC_INST
									, P.POS_FLAG
									, P.Is_Src_Deleted Is_Position_Deleted
							FROM	PSA.V_Eagle_Position as P
									INNER JOIN PSA.Eagle_Position_Detail as PD ON P.POSITION_ID = PD.POSITION_ID
									-- LEFT JOIN PSA.V_Eagle_XREFERENCE X  on X.Security_Alias = PD.Security_Alias 
							WHERE	 PD.Load_DTS > Coalesce(@lastLoadeDTS, '1900-01-01')
									 and P.SRC_INTFC_INST in (158, 283,284,285,286,330)			--DYNAMO, BNYM, BNYM_LOT, BNYM_ME, BNYM_ME_LOT, GENEVA
						 ) T
				 ) src

				 --Dim_Portfolio_Key
				 Left Join EDW_Common.Dim_Portfolio p on src.Portfolio_Id = p.Portfolio_Id 
							and src.EFFECTIVE_DATE between p.Record_Start_DTS and coalesce(p.[Record_End_DTS], '9999-12-31') 
				 --Dim_Security_Key
				 Left Join EDW_Common.Dim_Security sec on 'Eagle_' + src.Security_Id = sec.Src_Security_Id and sec.Record_Is_Current_Flag = 1

				 Left Join EDW_Common.Dim_Eagle_Portfolio_Detail pd on src.Portfolio_Id = pd.Portfolio_Id and pd.Record_Is_Current_Flag = 1

				 Left Join EDW_Common.Dim_Eagle_Security_Detail secd on src.Security_Id = secd.Security_Id and secd.Record_Is_Current_Flag = 1

				 --Dim_Base_Currency_Key
				 Left Join EDW_Common.Dim_Currency cur on src.BASE_CURRENCY = cur.CURRENCY 
							and cur.Record_Is_Current_Flag = 1
				 --Dim_Local_Currency_Key
				 Left Join EDW_Common.Dim_Currency lc on src.Local_CURRENCY = lc.CURRENCY 
							and lc.Record_Is_Current_Flag = 1
				 --Dim_Interfaces_Key
				 Left Join EDW_Common.Dim_Eagle_Interface intf on src.SRC_INTFC_INST = intf.Interface_Instance 
	 						and intf.Record_Is_Current_Flag = 1



		--LOGGING ETL RESULT
		Select @rowsInserted = Count(*) 
		From EDW_Common.[Fact_Eagle_Position]
		Where Last_Update_DTS = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Position', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Position', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW @ErrorCode,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END