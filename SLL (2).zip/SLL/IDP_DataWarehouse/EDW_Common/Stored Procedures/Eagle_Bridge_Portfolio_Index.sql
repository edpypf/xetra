﻿CREATE PROC [EDW_Common].[Eagle_Bridge_Portfolio_Index] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN


	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0


	Begin Try

		if @Load_DTS is null
		Begin
			Select @Load_DTS = Batch_Date
			From EDW_ETL.ETL_Load
			Where ETL_Load_Key = @ETL_Load_Key
		End

		IF OBJECT_ID('tempdb..#temp_src_bridge_portfolio_index_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_bridge_portfolio_index_records
		END


		--CREATE SOURCE TEMP TABLE 
		create table #temp_src_bridge_portfolio_index_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 

		Select	Portfolio_ID,
				Index_ID,
				Benchmark_Order,
				Benchmark_Purpose,
				Is_Src_Deleted,
				CONVERT(VARCHAR(64), hashbytes('SHA1', UPPER(concat(RTRIM(Portfolio_ID), '|', RTRIM(Index_ID), '|', RTRIM(Benchmark_Order), '|', RTRIM(Benchmark_Purpose), '|', RTRIM(Is_Src_Deleted) ))), 2) Hash_Diff
		From ( 	SELECT	DISTINCT
						P.ENTITY_ID		as Portfolio_ID,
						B.ENTITY_ID		as Index_ID,
						ED.LIST_ORDER   as Benchmark_Order,
						CV.LONG_DESC	as Benchmark_Purpose,
						P.Is_Src_Deleted

				FROM PSA.V_Eagle_ENTITY_DETAIL ED
					INNER JOIN PSA.V_Eagle_ENTITY P ON P.ENTITY_ID = ED.ENTITY_ID
					INNER JOIN PSA.V_Eagle_ENTITY B ON B.ENTITY_ID = RTRIM(ED.ENTITY_DETAIL_ID)
					LEFT JOIN
			              ( -- Get translation for List_Order (Benchmark purpose)
			       
			              PSA.Eagle_CODE_VALUES   CV 
			              INNER JOIN PSA.Eagle_CODES C ON CV.CODE_INST = C.INSTANCE AND C.Short_Desc = 'IBMARKDEF'
			              ) ON CV.SHORT_DESC = ED.LIST_ORDER

				WHERE ED.ENTITY_TYPE = 'INDX'
				AND P.ENTITY_TYPE in ('SUB', 'PORT', 'COMP') 
			) src



		--INSERT NEW RECORDS FROM SOURCE TEMP TABLE
		Insert Into EDW_Common.Bridge_Portfolio_Index 
		(
			Portfolio_ID,
			Index_ID,
			Benchmark_Order,
			Benchmark_Purpose,
			Record_Start_DTS,
			Record_End_DTS,
			Record_Is_Current_Flag,
			Last_Update_DTS,
			Is_Src_Deleted,
			Hash_Diff,
			ETL_Load_Key
		)

		Select	Portfolio_ID,
				Index_ID,
				Benchmark_Order,
				Benchmark_Purpose,
				@today, 
				null, 
				1, 
				@today, 
				Is_Src_Deleted,
				Hash_Diff,
				@ETL_Load_Key

		From #temp_src_bridge_portfolio_index_records src
		Where not exists 
			(
				Select	1
				From	[EDW_Common].[Bridge_Portfolio_Index] tgt
				where	Record_Is_Current_Flag = 1 
						and tgt.Portfolio_ID = src.Portfolio_ID 
						and tgt.Index_ID = src.Index_ID 
						and tgt.Benchmark_Order = src.Benchmark_Order 
						and src.Hash_Diff = tgt.Hash_Diff
			)
			and src.Is_Src_Deleted = 0



		--UPDATE/EXPIRE EXISTING RECORDS
		Update tgt
		Set Last_Update_DTS = @today, 
			Record_End_DTS = @today, 
			Record_Is_Current_Flag = 0, 
			ETL_Load_Key = @ETL_Load_Key

		From EDW_Common.Bridge_Portfolio_Index tgt
		Where	tgt.Record_Is_Current_Flag = 1 
				and tgt.Is_Src_Deleted = 0
				and exists
				(
					Select	1
					From	#temp_src_bridge_portfolio_index_records src
					Where	tgt.Portfolio_ID = src.Portfolio_ID 
							and tgt.Index_ID = src.Index_ID 
							and tgt.Benchmark_Order = src.Benchmark_Order 
							and ( coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1 )
				)



		--ETL Logging
		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Bridge_Portfolio_Index]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Bridge_Portfolio_Index]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Bridge_Portfolio_Index', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Bridge_Portfolio_Index', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END
GO


