﻿CREATE PROC [EDW_Common].[Eagle_Bridge_Portfolio_Mapping] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS


BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2
	
	Begin Try

		Select @lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From [EDW_Common].[Bridge_Portfolio_Mapping]

		IF OBJECT_ID('tempdb..#temp_src_manual_portfolio_mapping') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_manual_portfolio_mapping
		END

		IF OBJECT_ID('tempdb..#temp_src_eagle_portfolio_mapping') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_eagle_portfolio_mapping
		END


		create table #temp_src_manual_portfolio_mapping
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select 
					Date
				    ,Portfolio_ID
					,Parent_Portfolio_ID
					,Performance_Parent_Portfolio_ID
					,Client_Id
					,Strategy_Id
					,[Strategy_Inheritance_Ind] 
					,[Securitized_Parent_Id]
					,Start_Date
					,End_Date
					,Load_DTS
					,Is_Src_Deleted
		From
		(
			Select  D.Date
				    ,Portfolio_ID
					,Parent_Portfolio_ID
					,Performance_Parent_Portfolio_ID
					,Client_Id
					,Strategy_Id
					,[Strategy_Inheritance_Ind] 
					,[Securitized_Parent_Id]
					,Start_Date
					,End_Date
					,Load_DTS
					,Is_Src_Deleted
					,row_number() over (partition by D.Date, Portfolio_ID, Client_Id, Strategy_Id order by Load_DTS DESC) rn
			From (
				 SELECT Portfolio_ID
							,coalesce(Parent_Portfolio_ID,'NA') Parent_Portfolio_ID
							,coalesce(Performance_Parent_Portfolio_ID,'NA') Performance_Parent_Portfolio_ID
							,Rtrim(Client_Id) Client_Id
							,IPS_Strategy Strategy_Id
							,[Strategy_Inheritance_Ind] 
							,coalesce([Securitized_Parent_Id],'NA') [Securitized_Parent_Id]
							,Start_Date
							,End_Date
							,Load_DTS
							,Is_Src_Deleted
							,row_number() over (partition by Portfolio_ID, Rtrim(Client_Id), IPS_Strategy, Start_Date order by Load_DTS DESC) rn
				  FROM PSA.Manual_Portfolio_Mapping 
				  Where Coalesce(Portfolio_Type,'NA') not in ('CIDX', 'INDX')
			) mpm
			Join EDW_Common.Dim_Date D on D.Date between mpm.Start_Date and case mpm.End_Date When '2099-12-31' Then getdate() Else mpm.End_Date End
			Where mpm.Portfolio_Id is not null and rn = 1  and Is_Src_Deleted = 0
		) m
		where rn = 1

		create table #temp_src_eagle_portfolio_mapping
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select D.Dim_Date_Key
			,D.Date
			,src.Entity_ID Portfolio_ID
			,coalesce(src.Parent_Entity_ID, 'NA') Parent_Portfolio_ID
			,coalesce(coalesce(mpm_p.Client_Id,mpm.Client_Id), 'NA') Client_Id
			,coalesce(coalesce(mpm_p.Strategy_Id,mpm.Strategy_Id), 'NA') Strategy_Id
			,min(coalesce(coalesce(mpm_p.Securitized_Parent_Id, mpm.Securitized_Parent_Id), 'NA')) Securitized_Parent_Id
			,min(coalesce('StateStreet_' + coalesce(mpm_p.[Securitized_Parent_Id], mpm.[Securitized_Parent_Id]), 'NA')) [Src_Securitized_Parent_Id]
			,coalesce(coalesce(mpm_p.Performance_Parent_Portfolio_ID, mpm.Performance_Parent_Portfolio_ID),'NA') Performance_Parent_Portfolio_ID
			,min(coalesce(mpm_p.[Strategy_Inheritance_Ind], mpm.[Strategy_Inheritance_Ind])) [Strategy_Inheritance_Ind]
			,min(src.Is_Src_Deleted) Is_Src_Deleted
			,max(src.Load_DTS) Load_DTS
			,null Hash_Diff
		from (
				Select e.Entity_ID, ed.Entity_ID Parent_Entity_ID , ed.Eff_Start_Date Start_Date, ed.Eff_End_Date End_Date, e.Load_DTS Load_DTS, 
				Case when e.Is_Src_Deleted = 1 then 1 else 0 end Is_Src_Deleted
                From PSA.v_Eagle_Entity e
				Join [PSA].[V_Eagle_Entity_Relationship] ed ON e.entity_id = ed.ENTITY_DETAIL_ID 
                Where e.Entity_Type in ('SUB', 'PORT', 'COMP') and ed.Entity_Type in ('SUB', 'PORT', 'COMP')
		) src
		Join EDW_Common.Dim_Date D on D.Date between src.Start_Date and case src.End_Date When '2099-12-31' Then getdate() Else src.End_Date End
		Left Join #temp_src_manual_portfolio_mapping mpm on src.Parent_Entity_ID = mpm.Portfolio_Id and d.Date = mpm.Date -- src.Start_Date between mpm.Start_Date and mpm.End_Date and mpm.rn = 1 and mpm.is_src_deleted = 0
		Left Join #temp_src_manual_portfolio_mapping mpm_p on src.Entity_ID = mpm_p.Portfolio_Id and mpm_p.Parent_Portfolio_Id is null and d.Date = mpm_p.Date -- src.Start_Date between mpm_p.Start_Date and mpm_p.End_Date and mpm_p.rn = 1 and mpm_p.is_src_deleted = 0
		where not exists (
			Select 1
			From #temp_src_manual_portfolio_mapping mpm
			where mpm.Portfolio_Id = src.Entity_ID and mpm.Parent_Portfolio_Id=src.Parent_Entity_ID -- and mpm.rn = 1 and mpm.Is_Src_Deleted = 0
		)
		Group By D.Dim_Date_Key
			,D.Date
			,src.Entity_ID 
			,src.Parent_Entity_ID 
			,coalesce(mpm_p.Client_Id, mpm.Client_Id)
			,coalesce(mpm_p.Strategy_Id,mpm.Strategy_Id)
			,coalesce(mpm_p.Securitized_Parent_Id, mpm.Securitized_Parent_Id)
			,coalesce(mpm_p.Performance_Parent_Portfolio_ID,mpm.Performance_Parent_Portfolio_ID)

		INSERT INTO [EDW_Common].[Bridge_Portfolio_Mapping]
        (   
			Dim_Date_Key
		   ,[Dim_Portfolio_Key]
           ,[Parent_Dim_Portfolio_Key]
		   ,Perf_Parent_Dim_Portfolio_Key
		   ,Dim_Client_Key
		   ,Dim_Strategy_Key
		   ,Dim_Security_Key
		   ,Strategy_Inheritance_Ind
		   ,[Relation_Type]
		   ,Is_Src_Deleted
		   ,Load_DTS
		   ,Record_Created_DTS
           ,[Last_Update_DTS]
		   ,Other_Info
           ,[Hash_Diff]
           ,[ETL_Load_Key]
		)
		SELECT		t.Dim_Date_Key
				   ,coalesce(p.[Dim_Portfolio_Key], -1) [Dim_Portfolio_Key]
				   ,coalesce(c_pp.[Dim_Portfolio_Key], -1) [Parent_Dim_Portfolio_Key]
				   ,coalesce(c_ppp.[Dim_Portfolio_Key], -1) Perf_Parent_Dim_Portfolio_Key
				   ,coalesce(c_c.Dim_Client_Key, -1) Dim_Client_Key
				   ,coalesce(c_s.Dim_Strategy_Key, -1) Dim_Strategy_Key
				   ,coalesce(c_sec.Dim_Security_Key, -1) Dim_Security_Key
				   ,t.Strategy_Inheritance_Ind
				   ,'Eagle_Mapping'
				   ,t.IS_Src_Deleted
				   ,t.Load_DTS
				   ,@today
				   ,@today
				   ,'{"Client":"' + t.Client_Id + '",' +
				    '"Strategy":"' + t.Strategy_Id + '",' + 
				    '"Portfolio":"' + t.Portfolio_Id + '",' + 
					'"Parent_Portfolio":"' + t.Parent_Portfolio_Id + '",' + 
					'"Securitized_Parent":"' + t.Securitized_Parent_Id + '",' + 
					'"Performance_Portfolio":"' + + t.Performance_Parent_Portfolio_ID + 
					'}'
				   ,t.Hash_Diff
					,@ETL_Load_Key
		From #temp_src_eagle_portfolio_mapping t
		Left Join EDW_Common.Dim_Portfolio p on t.Portfolio_ID = p.Portfolio_Id and t.Date between p.Record_Start_DTS and coalesce(p.[Record_End_DTS], '9999-12-31')
		Left Join EDW_Common.Dim_Portfolio c_pp on t.Parent_Portfolio_ID = c_pp.Portfolio_Id and c_pp.Record_Is_Current_Flag = 1
		Left Join EDW_Common.Dim_Portfolio c_ppp on t.Performance_Parent_Portfolio_ID = c_ppp.Portfolio_Id and c_ppp.Record_Is_Current_Flag = 1
		Left Join EDW_Common.Dim_Client c_c on t.Client_Id = c_c.Src_Client_Id and c_c.Record_Is_Current_Flag = 1
		Left Join (
				select Src_Strategy_Id, Record_Start_DTS,  max(dim_strategy_key) dim_strategy_key, max(Record_End_DTS) Record_End_DTS
				From EDW_Common.Dim_Strategy
				Where Is_Src_Deleted_Flag = 0
				group By Src_Strategy_Id, Record_Start_DTS
		) c_s on t.Strategy_Id = c_s.Src_Strategy_Id and t.Date Between c_s.Record_Start_DTS and c_s.Record_End_DTS --  c_s.Record_Is_Current_Flag = 1
		Left Join EDW_Common.Dim_Security c_sec on t.[Src_Securitized_Parent_Id] = c_sec.Src_Security_Id and c_sec.Record_Is_Current_Flag = 1

		where not exists (
			Select 1
			From [EDW_Common].[Bridge_Portfolio_Mapping] tgt
			Join EDW_Common.Dim_Portfolio pt on tgt.Dim_Portfolio_Key = pt.Dim_Portfolio_Key
			Join EDW_Common.Dim_Portfolio ppt on tgt.Parent_Dim_Portfolio_Key = ppt.Dim_Portfolio_Key
			Join EDW_Common.Dim_Portfolio ppp on tgt.Perf_Parent_Dim_Portfolio_Key = ppp.Dim_Portfolio_Key
			Join EDW_Common.Dim_Client c on tgt.Dim_Client_Key = c.Dim_Client_Key
			Join EDW_Common.Dim_Strategy s on tgt.Dim_Strategy_Key = s.Dim_Strategy_Key
			Join EDW_Common.Dim_Security sec on tgt.Dim_Security_Key = sec.Dim_Security_Key
			where tgt.Dim_Date_Key = t.Dim_Date_Key and pt.Portfolio_Id = t.Portfolio_ID and t.Parent_Portfolio_ID = ppt.Portfolio_Id 
			      and c.Src_Client_Id = t.Client_Id and s.Src_Strategy_Id = t.Strategy_Id and sec.Security_Id = t.Securitized_Parent_Id 
				  and ppp.Portfolio_Id = t.Performance_Parent_Portfolio_ID and tgt.Is_Src_Deleted = 0
		) and t.Is_Src_Deleted = 0


		Update tgt
		Set Last_Update_DTS = @today, Is_Src_Deleted = 1, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Bridge_Portfolio_Mapping] tgt
		Join EDW_Common.Dim_Portfolio pt on tgt.Dim_Portfolio_Key = pt.Dim_Portfolio_Key
		Join EDW_Common.Dim_Portfolio ppt on tgt.Parent_Dim_Portfolio_Key = ppt.Dim_Portfolio_Key
		Join EDW_Common.Dim_Portfolio ppp on tgt.Perf_Parent_Dim_Portfolio_Key = ppp.Dim_Portfolio_Key
		Join EDW_Common.Dim_Client c on tgt.Dim_Client_Key = c.Dim_Client_Key
		Join EDW_Common.Dim_Strategy s on tgt.Dim_Strategy_Key = s.Dim_Strategy_Key
		Join EDW_Common.Dim_Security sec on tgt.Dim_Security_Key = sec.Dim_Security_Key
		Where tgt.Is_Src_Deleted = 0 and exists
		(
			Select 1
			From #temp_src_eagle_portfolio_mapping src
			Where tgt.Dim_Date_Key = src.Dim_Date_Key and pt.Portfolio_Id = src.Portfolio_ID and src.Parent_Portfolio_ID = ppt.Portfolio_Id 
			and (
				c.Src_Client_Id <> src.Client_Id 
				or s.Src_Strategy_Id <> src.Strategy_Id 
				or sec.Security_Id <> src.Securitized_Parent_Id  
				or ppp.Portfolio_Id <> src.Performance_Parent_Portfolio_ID 
				or src.Is_Src_Deleted = 1
			)
		)

		/* expire the deleted relationship */
		Update tgt
		Set Last_Update_DTS = @today, Is_Src_Deleted = 1, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Bridge_Portfolio_Mapping] tgt
		Join EDW_Common.Dim_Portfolio pt on tgt.Dim_Portfolio_Key = pt.Dim_Portfolio_Key
		Join EDW_Common.Dim_Portfolio ppt on tgt.Parent_Dim_Portfolio_Key = ppt.Dim_Portfolio_Key
		Where tgt.Is_Src_Deleted = 0 and tgt.Relation_Type = 'Eagle_Mapping' and not exists
		(
			Select 1
			From #temp_src_eagle_portfolio_mapping src
			Where tgt.Dim_Date_Key = src.Dim_Date_Key and pt.Portfolio_Id = src.Portfolio_ID and src.Parent_Portfolio_ID = ppt.Portfolio_Id 
		)


		Select @rowsInserted = Count(*) 
		From EDW_Common.[Bridge_Portfolio_Mapping]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 0

		Select @rowsExpired = Count(*)
		From EDW_Common.[Bridge_Portfolio_Mapping]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 1

		Select @rowsUpdated = @rowsExpired


		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Bridge_Portfolio_Mapping', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Bridge_Portfolio_Mapping', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 500001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END