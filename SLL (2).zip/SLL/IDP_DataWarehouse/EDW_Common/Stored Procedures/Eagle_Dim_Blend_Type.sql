﻿CREATE PROC [EDW_Common].[Eagle_Dim_Blend_Type] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN


	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@Batch_DTS datetime2


	Begin Try

		Select @Batch_DTS = Batch_Date
		From EDW_ETL.ETL_Load
		Where ETL_Load_Key = @ETL_Load_Key

		IF OBJECT_ID('tempdb..#temp_src_blend_type_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_blend_type_records
		END


		--CREATE SOURCE TEMP TABLE 
		create table #temp_src_blend_type_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select	Blend_Type,
				convert(varchar(64), hashbytes('SHA1', Upper(Rtrim(Blend_Type))), 2) Hash_Diff
		From ( 	select	distinct 
						DD.DICT_L2_CODE_VALUE as Blend_Type
				from	PSA.V_Eagle_Dictionary_Detail DD 
				where	DD.DICT_L2_CODE_VALUE is not null
			) src



		--INSERT NEW RECORDS FROM SOURCE TEMP TABLE
		Insert Into EDW_Common.Dim_Blend_Type 
		(
			Blend_Type,
			Record_Start_DTS,
			Record_End_DTS,
			Record_Is_Current_Flag,
			Last_Update_DTS,
			Hash_Diff,
			ETL_Load_Key
		)

		Select	Blend_Type, 
				@today, 
				null, 
				1, 
				@today, 
				Hash_Diff, 
				@ETL_Load_Key

		From #temp_src_blend_type_records src
		Where not exists 
			(
				Select 1
				From [EDW_Common].[Dim_Blend_Type] tgt
				where Record_Is_Current_Flag = 1 and src.Blend_Type = tgt.Blend_Type and src.Hash_Diff = tgt.Hash_Diff
			)

		--UPDATE/EXPIRE EXISTING RECORDS
		Update tgt
		Set Last_Update_DTS = @today, 
			Record_End_DTS = @today, 
			Record_Is_Current_Flag = 0, 
			ETL_Load_Key = @ETL_Load_Key

		From EDW_Common.Dim_Blend_Type tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_blend_type_records src
			Where tgt.Blend_Type = src.Blend_Type and coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')
		)

		--ETL Logging
		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Blend_Type]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Blend_Type]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Blend_Type', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Blend_Type', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END