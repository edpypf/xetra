﻿CREATE PROC [EDW_Common].[IMCOManual_Dim_Portfolio_Group] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_portfolio_group_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_portfolio_group_records
		END

		-- load everything from source

		create table #temp_src_portfolio_group_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select Group_Name
				,[Is_Src_Deleted]
				,convert(varchar(64), hashbytes('SHA1', coalesce(UPPER(RTRIM(Group_Name)),'')), 2) Hash_Diff
		From (
			Select   [Group_Name]
					,min(case when [Is_Src_Deleted] = 1 then 1 else 0 end) [Is_Src_Deleted]
			From [PSA].[Manual_Portfolio_Groups]
			Group By [Group_Name]

		) src

		Union 

		Select 'WSIB Asset Mix Reporting' as Group_Name, 0 [Is_Src_Deleted], 
		convert(varchar(64), hashbytes('SHA1', upper('WSIB Asset Mix Reporting')), 2)  Hash_Diff

		union

		SELECT 'WSIB Total Fund Account List' as Group_Name, 0 [Is_Src_Deleted], 
				convert(varchar(64), hashbytes('SHA1', upper('WSIB Total Fund Account List')), 2)  Hash_Diff

	
		Insert Into [EDW_Common].[Dim_Portfolio_Group] (
				Portfolio_Group_Id
		        ,Portfolio_Group_Name
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select Group_Name, Group_Name, @today, null, 1, @today, Hash_Diff, @ETL_Load_Key
		From #temp_src_portfolio_group_records src
		Where not exists (
			Select 1
			From [EDW_Common].[Dim_Portfolio_Group] tgt
			where Record_Is_Current_Flag = 1 and src.Group_Name = tgt.Portfolio_Group_Name and src.Hash_Diff = tgt.Hash_Diff 
		)
		and src.Is_Src_Deleted = 0 and Group_Name is not null

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Dim_Portfolio_Group] tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_portfolio_group_records src
			Where src.Group_Name = tgt.Portfolio_Group_Name and (coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1)
		)

		Select @rowsInserted = Count(*) 
		From [EDW_Common].[Dim_Portfolio_Group]
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].[Dim_Portfolio_Group]
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Portfolio_Group', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null
    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec [EDW_ETL].[Update_ETL_Load_Control] @ETL_Load_Key, 'EDW_Common.Dim_Portfolio_Group', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END