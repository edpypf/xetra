﻿CREATE PROC [EDW_Common].[Eagle_Dim_Portfolio] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_portfolio_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_portfolio_records
		END

		-- load everything from source

		create table #temp_src_portfolio_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select *
		From (
			Select Distinct rtrim([Entity_ID]) [Entity_ID]
					,Rtrim([Entity_Name]) [Entity_Name]
					,CONVERT(VARCHAR(64), hashbytes('SHA1', UPPER(coalesce([Entity_Name],''))), 2) as Hash_Diff
					,Is_Src_Deleted
					,Row_Number() Over (Partition By Entity_Id order by Load_DTS Desc) rn
			From PSA.Eagle_Entity
			where Entity_Type in ('SUB', 'PORT','COMP')
			and not exists (
				Select 1 
				From (
			         select Account_ID Portfolio_Id
                     from PSA.StateStreet_Fund_Performance
                      
					 Union
                     -- Pull in any funds that are in the accounting extract, but not the performance extract
                    SELECT 
                         Fund Portfolio_Id
                    from PSA.StateStreet_Accounting_Positions
				) p 
				where Portfolio_id = rtrim([Entity_ID])
			)
		) src
		where rn = 1 


		/** Eagle Portfolio Name will not overwrite StateStreet if portfolio id is same **/
		/*
		Insert Into EDW_Common.Dim_Portfolio (
				  [Portfolio_ID]
				  ,[Portfolio_Name]
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select src.[Entity_ID]
			  ,src.[Entity_Name]
			  ,case when tgt.Portfolio_Id is null then '2000-01-01' else @today end
			  , null
			  , 1
			  , @today
			  ,src.Hash_Diff
			  ,@ETL_Load_Key
		From #temp_src_portfolio_records src
		Left Join EDW_Common.Dim_Portfolio tgt on src.[Entity_ID] = tgt.Portfolio_Id and tgt.Record_Is_Current_Flag = 1
		where src.Is_Src_Deleted = 0 and tgt.Portfolio_Id is null


		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From EDW_Common.Dim_Portfolio tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_portfolio_records src
			Where tgt.Portfolio_Id = src.Entity_Id and src.Is_Src_Deleted = 1
		)
		*/

	
		Insert Into EDW_Common.Dim_Portfolio (
				  [Portfolio_ID]
				  ,[Portfolio_Name]
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select [Entity_ID]
			  ,[Entity_Name]
			  ,@today, null, 1, @today
			  ,Hash_Diff
			  ,@ETL_Load_Key
		From #temp_src_portfolio_records src
		Where not exists (
			Select 1
			From EDW_Common.Dim_Portfolio tgt
			where Record_Is_Current_Flag = 1 and src.Entity_Id = tgt.Portfolio_Id and src.Hash_Diff = tgt.Hash_Diff
		)
		and src.Is_Src_Deleted = 0

		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From EDW_Common.Dim_Portfolio tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_portfolio_records src
			Where tgt.Portfolio_Id = src.Entity_Id and (coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') or src.Is_Src_Deleted = 1)
		)
		


		Select @rowsInserted = Count(*) 
		From EDW_Common.Dim_Portfolio
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From EDW_Common.Dim_Portfolio
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Portfolio', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Portfolio', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END
