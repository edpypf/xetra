﻿CREATE PROC [EDW_Common].[Eagle_Fact_Ealge_Client_Strategy_SAA_Weight] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
/*
-- =============================================
-- Author: Azamat
-- Create date:
-- Description: load fact [EDW_Common].Fact_Ealge_Client_Strategy_SAA_Weight
--				note that @Load_Type and @Batch_DTS are not actually used 
-- exec [EDW_Common].[test2_Eagle_Fact_Ealge_Client_Strategy_SAA_Weight]  'DELTA','2022-06-30',1
-- exec [EDW_Common].[Eagle_Fact_Ealge_Client_Strategy_SAA_Weight]  'DELTA','2022-08-01',1
-- =============================================
--Change History
--Date			Changed by			Description
--2023-09-19	Michael Wang		refactor and encapsulate logic
--2023-09-21	Luis Diaz-Medina	Use only 1 CTE instead of 2 CTEs. Also, query only the required columns
--2023-11-16	Vincent Yu			Modified PJPP logic to accept new investment type
--2023-12-16	Vincent Yu			Modified  logic to remove hardcode and adapt to accept new client automatically
*/
	
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2			
			--,@ETL_Load_Key int = 7
	
	Begin Try


		-- get last loaded dts in current fact table
		Select @lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From [EDW_Common].Fact_Ealge_Client_Strategy_SAA_Weight

		SET @lastLoadeDTS = dateadd(dd,-1,@lastLoadeDTS) --test
		PRINT @lastLoadeDTS;


		IF OBJECT_ID('tempdb..#temp_src_saa_weight') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_saa_weight
		END

		-- load everything from source
		create table #temp_src_saa_weight
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 

		with IPS as
		(	SELECT	distinct
					Client_id,
					Portfolio_ID,
					rm.IPS_Strategy
			FROM	[EDW_Mart].[EPS_Portfolio_Hierarchy] rm
			where	Parent_Portfolio_ID in ( select distinct Portfolio_ID from [EDW_Mart].[EPS_Portfolio_Hierarchy] where top_level = 'IMCO' and Parent_Portfolio_ID = 'IMCO'  )
					and IPS_Strategy not in ('Not Available', 'Other')
					and Effective_Date >= '2022-04-01'
		),
		TMP_Eagle_Perf_Sec_Returns as (
			Select *
			From (
				SELECT
				A.[PERF_SUM_INST], 
				A.[SECURITY_ALIAS],
				A.[PERF_ROLLUP_RETURNS_ID],
				A.ABAL,
				A.PSR_USER_FLOAT8,
				A.PSR_USER_FLOAT1,
				A.PSR_USER_FLOAT2,
				A.PSR_USER_FLOAT7,
				A.PSR_USER_FLOAT32 ,
				A.Load_DTS, 
				A.Update_Date,
				A.Update_Source,
				B.[ENTITY_ID], 
				B.[SRC_INTFC_INST], 
				--B.[PERF_SUM_INST], 
				B.[DICTIONARY_ID],
				B.[END_EFFECTIVE_DATE],
				B.[PERF_FREQ_CODE],
				Row_Number() Over(Partition By A.[PERF_SUM_INST], A.[SECURITY_ALIAS],A.[PERF_ROLLUP_RETURNS_ID] 			
				Order by  A.Load_DTS desc) rn
				FROM [PSA].[Eagle_Perf_Sec_Returns] A
				inner join [PSA].[V_Eagle_Perf_Summary] B on A.PERF_SUM_INST = B.PERF_SUM_INST -- Pending to TEST
				WHERE A.Load_DTS > @lastLoadeDTS -- 2023-09-20
				AND B.PERF_FREQ_CODE = 'D'
				AND B.[DICTIONARY_ID] IN (106,14)
			) d
			where rn = 1
		)

		-- BENCHMARK DRIFTING SAA for OPB, PJPP etc, Automated with table IMCOManual User_Portfolio_Mapping 
		SELECT Distinct 
				MBM.Client_ID Client_ID,
				MBM.Blend_Type as Weight_Type,
                OSM.IPS_Strategy as Strategy_ID    ,    
			    convert(int, convert(varchar(15), PSR.END_EFFECTIVE_DATE, 112)) Dim_Date_Key,				
                convert(int, convert(varchar(15), PSR.END_EFFECTIVE_DATE, 112)) SAA_Dim_Date_Key,      
                PSR.ABAL  [Begin_Drifting_Weight]            ,       
                PSR.PSR_USER_FLOAT8  [Gross_Return]  ,
                PSR.PSR_USER_FLOAT1   ,
                PSR.PSR_USER_FLOAT2   , 
                PSR.PSR_USER_FLOAT7   , 
                PSR.PSR_USER_FLOAT32  ,
				TRIM(DD.DICT_L2_CODE_VALUE) as DICT_L2_CODE_VALUE,
				--NULL as SAA_Weight_Type_Id,
				PSR.Load_DTS, 
				PSR.Update_Date,
				PSR.Update_Source,
				convert(varchar(64), hashbytes('SHA1', coalesce(concat(PSR.ABAL, '|', PSR.PSR_USER_FLOAT8, '|', PSR.PSR_USER_FLOAT1, '|', PSR.PSR_USER_FLOAT2, '|', PSR.PSR_USER_FLOAT7, '|', PSR.PSR_USER_FLOAT32),'')), 2) Hash_Diff
		FROM	TMP_Eagle_Perf_Sec_Returns PSR 			
				INNER JOIN PSA.V_Eagle_DICTIONARY_DETAIL DD ON DD.DICTIONARY_ID      = PSR.DICTIONARY_ID
												AND DD.DICTIONARY_ITEM_ID = PSR.PERF_ROLLUP_RETURNS_ID
				Left Join PSA.V_Manual_Official_Strategy_Mapping OSM ON OSM.Legacy_Strategy = TRIM(DD.DICT_L2_CODE_VALUE)
				INNER JOIN [EDW_Mart].[PSA_Manual_Benchmark_Mapping] MBM
				ON PSR.END_EFFECTIVE_DATE BETWEEN [Start_Date] and [End_Date] 
				AND PSR.ENTITY_ID = MBM.Entity
				AND OSM.IPS_Strategy=MBM.IPS_Strategy

				--INNER JOIN (select Entity, Client_ID, Blend_Type, IPS_Strategy from [EDW_Mart].[PSA_Manual_Benchmark_Mapping]
				--			where @today BETWEEN [Start_Date] and [End_Date]) AS PC
				--	   ON PSR.ENTITY_ID = PC.Entity
				--	   AND OSM.IPS_Strategy=PC.IPS_Strategy
        WHERE	PSR.PERF_FREQ_CODE          IN ('D')         
				AND PSR.PERF_ROLLUP_RETURNS_ID <> 1             
				AND PSR.DICTIONARY_ID            = 106
				and 0 < (select count(*) from PSA.Manual_Official_Strategy_Mapping)          
				and PSR.Load_DTS > @lastLoadeDTS
				and OSM.IPS_Strategy is not null

		UNION

		--OPB PORTFOLIO DRIFTING SAA
		SELECT  Distinct 
				'OPB' Client_ID      ,
				'Portfolio Drifting SAA' as Weight_Type,
				PM.IPS_Strategy as Strategy_ID    ,    
				convert(int, convert(varchar(15), PSR.END_EFFECTIVE_DATE, 112)) Dim_Date_Key,				
				convert(int, convert(varchar(15), PSR.END_EFFECTIVE_DATE, 112)) SAA_Dim_Date_Key,      
				NULL  [Begin_Drifting_Weight] ,       
				cast(PSR.PSR_USER_FLOAT8 as float)  [Gross_Return]  ,
				PSR.PSR_USER_FLOAT1   ,
				PSR.PSR_USER_FLOAT2   , 
				PSR.PSR_USER_FLOAT7   , 
				PSR.PSR_USER_FLOAT32  ,
				NULL as DICT_L2_CODE_VALUE,
				--NULL as SAA_Weight_Type_Id,
				PSR.Load_DTS, 
				PSR.Update_Date,
				PSR.Update_Source,
				convert(varchar(64), hashbytes('SHA1', coalesce(concat(PSR.PSR_USER_FLOAT8, '|', PSR.PSR_USER_FLOAT1, '|', PSR.PSR_USER_FLOAT2, '|', PSR.PSR_USER_FLOAT7, '|', PSR.PSR_USER_FLOAT32),'')), 2) Hash_Diff
		FROM	TMP_Eagle_Perf_Sec_Returns PSR -- PSA.V_Eagle_PERF_SEC_RETURNS PSR								
				LEFT JOIN PSA.V_Manual_Portfolio_Mapping PM ON PSR.ENTITY_ID = PM.Portfolio_ID and PM.End_date >= getdate()
				--Left Join IPS on ps.ENTITY_ID = ips.Portfolio_ID
		WHERE	PSR.dictionary_id = 14
				AND PSR.PERF_FREQ_CODE = 'D'
				AND PSR.SRC_INTFC_INST = 4
				--AND PS.END_EFFECTIVE_DATE = '2022-06-30'
				AND ( PSR.entity_id in ( SELECT distinct Portfolio_ID FROM IPS where client_id = 'OPB') 
					  or PSR.entity_id in ('IMAC110','IMAC120') )  --hardcoding IMAC110 (Dynamic FX) and IMAC120 (AAA) per William's request since these 2 are not available in the EPS view
				and PSR.Load_DTS > @lastLoadeDTS
				and PM.IPS_Strategy is not null

		
		UNION

		--PJPP PORTFOLIO DRIFTING SAA
		SELECT  Distinct 
		'PJPP' Client_ID      ,
		'Portfolio Drifting SAA' as Weight_Type,
		PM.IPS_Strategy as Strategy_ID    ,    
		convert(int, convert(varchar(15), PSR.END_EFFECTIVE_DATE, 112)) Dim_Date_Key,				
		convert(int, convert(varchar(15), PSR.END_EFFECTIVE_DATE, 112)) SAA_Dim_Date_Key,      
		NULL  [Begin_Drifting_Weight] ,       
		cast(PSR.PSR_USER_FLOAT8 as float)  [Gross_Return]  ,
		PSR.PSR_USER_FLOAT1   ,
		PSR.PSR_USER_FLOAT2   , 
		PSR.PSR_USER_FLOAT7   , 
		PSR.PSR_USER_FLOAT32  ,
		NULL as DICT_L2_CODE_VALUE,
		--NULL as SAA_Weight_Type_Id,
		PSR.Load_DTS, 
		PSR.Update_Date,
		PSR.Update_Source,
		convert(varchar(64), hashbytes('SHA1', coalesce(concat(PSR.PSR_USER_FLOAT8, '|', PSR.PSR_USER_FLOAT1, '|', PSR.PSR_USER_FLOAT2, '|', PSR.PSR_USER_FLOAT7, '|', PSR.PSR_USER_FLOAT32),'')), 2) Hash_Diff
		FROM	TMP_Eagle_Perf_Sec_Returns PSR -- PSA.V_Eagle_PERF_SEC_RETURNS PSR								
				LEFT JOIN PSA.V_Manual_Portfolio_Mapping PM ON PSR.ENTITY_ID = PM.Portfolio_ID and PM.End_date >= getdate()
				--Left Join IPS on ps.ENTITY_ID = ips.Portfolio_ID
		WHERE	PSR.dictionary_id = 14
				AND PSR.PERF_FREQ_CODE = 'D'
				AND PSR.SRC_INTFC_INST = 4
				--AND PS.END_EFFECTIVE_DATE = '2022-06-30'
				AND PSR.entity_id in ( SELECT distinct Portfolio_ID FROM IPS where client_id = 'PJPP' and Portfolio_ID !='IMC0010') 
				and PSR.Load_DTS > @lastLoadeDTS
				and PM.IPS_Strategy is not null

		--insert into target table 
		INSERT INTO [EDW_Common].Fact_Ealge_Client_Strategy_SAA_Weight
		(Dim_Client_Key
		,[Dim_Strategy_Key]
		,[Dim_Date_Key]
		,SAA_Dim_Date_Key
		,[Load_DTS]
		,[Begin_Drifting_Weight]
		,[Gross_Return] 
		,[PSR_USER_FLOAT1]
		,[PSR_USER_FLOAT2] 
		,[PSR_USER_FLOAT7]
		,[PSR_USER_FLOAT32] 
		,Src_Update_DTS
		,Src_Update_Source
		,[Last_Update_DTS]
		,Other_Info
		,[Hash_Diff]
		,[ETL_Load_Key]
		,Dim_SAA_Weight_Type_Key
		)

			SELECT coalesce(c.Dim_Client_Key,-1) Dim_Client_Key
					,coalesce(s.Dim_Strategy_Key, -1) Dim_Strategy_Key
					,src.Dim_Date_Key
					,src.SAA_Dim_Date_Key
					,src.Load_DTS
					,src.[Begin_Drifting_Weight]
				    ,src.[Gross_Return] 
				    ,src.[PSR_USER_FLOAT1]
				    ,src.[PSR_USER_FLOAT2] 
				    ,src.[PSR_USER_FLOAT7]
				    ,src.[PSR_USER_FLOAT32] 
					,src.Update_Date
					,src.Update_Source
					,@today
					,'{"Client":"' + coalesce(src.Client_Id, '') + '",' +
					 '"SAA_Weight_Type":"' + coalesce(src.Weight_Type, '') + '",' +
					 '"Strategy":"' + src.Strategy_Id + '"}' Other_Info
					,src.Hash_Diff
					,@ETL_Load_Key
					,coalesce(w.Dim_SAA_Weight_Type_Key, -1) Dim_SAA_Weight_Type_Key

			FROM  #temp_src_saa_weight src
			Left Join EDW_Common.Dim_Client c on src.Client_Id = c.Src_Client_Id and c.Record_Is_Current_Flag = 1
			Left Join EDW_Common.Dim_Strategy s on src.Strategy_Id = s.Src_Strategy_Id and s.Record_Is_Current_Flag = 1
			Left Join EDW_Common.Dim_SAA_Weight_Type w on src.Weight_Type = w.SAA_Weight_Type_Id and w.Record_Is_Current_Flag = 1


		Select @rowsInserted = Count(*) 
		From EDW_Common.Fact_Ealge_Client_Strategy_SAA_Weight
		Where Last_Update_DTS = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Ealge_Client_Strategy_SAA_Weight', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Ealge_Client_Strategy_SAA_Weight', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW @ErrorCode,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END