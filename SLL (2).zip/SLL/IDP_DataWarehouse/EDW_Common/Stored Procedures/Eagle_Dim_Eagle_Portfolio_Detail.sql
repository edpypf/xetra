﻿CREATE PROC [EDW_Common].[Eagle_Dim_Eagle_Portfolio_Detail] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_portfolio_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_portfolio_records
		END

		-- load everything from source

		create table #temp_src_portfolio_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select *
		From (
			Select E.[Entity_ID] Portfolio_Id
					,[ACC_SYS_OPENING_DATE]
					,[ACCOUNTING_BASIS]
					,[ACCT_DT_RULE_PRIORITY]
					,[ACTIVE_STATUS]
					,[ASSET_CLASS]
					,[AUTO_SETTLE_INDICATOR]
					,[BANK_ACCOUNT_NUMBER]
					,[BANK_BRANCH_CODE]
					,[BASE_CURRENCY]
					,[BUSINESS_SECTOR]
					,[COA_NAME]
					,[CON_CASH_TYPE]
					,[COST_METHOD]
					,[COSTCASH_BULKING]
					,[COUNTRY_OF_TAX]
					,[CUSTOMER_TYPE]
					,[DYNAGG_FLAG]
					,[EARN_PROCESS_FREQ]
					,[ENTITY_FUND_TYPE]
					,[ENTITY_LONG_NAME]
					,[FISCAL_END_DATE]
					,[FLOATWEIGHT_FLAG]
					,[FX_DAYS_OFFSET]
					,[FX_SOURCE]
					,[FX_SOURCE_RULE_ID]
					,[INCEPTION_DATE]
					,[LEGAL_NAME]
					,[LOT_SELECTION_METHOD]
					,[PORTFOLIO_TYPE_CODE]
					,[PRICE_METHOD]
					,[PRICE_SOURCE]
					,[RELEASE_STATUS]
					,[SRC_INTFC_INST]
					,[STAR_PARTITION]
					,[TAX_STATUS]
					,[TECHNICAL_SHORT_INDICATOR]
					,[TERMINATION_DATE]
					,[TRADE_STATUS]
					,E.[UPD_DATE]
					,E.[UPD_USER]
					,[VAR_RATE_SOURCE]
					,[WASH_SALE_INHIBIT_INDICATOR]
					,Analysis_Code
					,E.User_Field19 SS_CUSIP_1
					,E.User_Field21 OPB_Mellon_ID 
					,E.User_Field22 SS_CUSIP_2
 					,EE.User_Char11 Management_Company
					,EE.User_Char12 Parent_Investor
					,EE.User_Char13 Reporting_Currency
					,CONVERT(VARCHAR(64), hashbytes('SHA1', UPPER(Concat(ACC_SYS_OPENING_DATE, '|' ,ACCOUNTING_BASIS, '|' ,ACCT_DT_RULE_PRIORITY, '|' ,ACTIVE_STATUS, '|' ,ASSET_CLASS, '|' ,AUTO_SETTLE_INDICATOR, '|' ,BANK_ACCOUNT_NUMBER, '|' ,BANK_BRANCH_CODE, '|' ,BASE_CURRENCY, '|' ,BUSINESS_SECTOR, '|' ,COA_NAME, '|' ,CON_CASH_TYPE, '|' ,COST_METHOD, '|' ,COSTCASH_BULKING, '|' ,COUNTRY_OF_TAX, '|' ,CUSTOMER_TYPE, '|' ,DYNAGG_FLAG, '|' ,EARN_PROCESS_FREQ, '|' ,ENTITY_FUND_TYPE, '|' ,ENTITY_LONG_NAME, '|' ,ENTITY_NAME, '|' ,FISCAL_END_DATE, '|' ,FLOATWEIGHT_FLAG, '|' ,FX_DAYS_OFFSET, '|' ,FX_SOURCE, '|' ,FX_SOURCE_RULE_ID, '|' ,INCEPTION_DATE, '|' ,LEGAL_NAME, '|' ,LOT_SELECTION_METHOD, '|' ,PORTFOLIO_TYPE_CODE, '|' ,PRICE_METHOD, '|' ,PRICE_SOURCE, '|' ,RELEASE_STATUS, '|' ,SRC_INTFC_INST, '|' ,STAR_PARTITION, '|' ,TAX_STATUS, '|' ,TECHNICAL_SHORT_INDICATOR, '|' ,TERMINATION_DATE, '|' ,TRADE_STATUS, '|' ,E.UPD_DATE, '|' ,E.UPD_USER, '|' ,VAR_RATE_SOURCE, '|' ,WASH_SALE_INHIBIT_INDICATOR, '|', Analysis_Code ,'|', E.User_Field19 ,'|', E.User_Field21 ,'|', E.User_Field22, '|', EE.User_Char11, '|', EE.User_Char12 ,'|', EE.User_Char13))), 2) as Hash_Diff
					,E.Is_Src_Deleted
					,Row_Number() Over (Partition By E.Entity_Id order by E.Load_DTS Desc) rn
			From PSA.V_Eagle_Entity E
			Left Join PSA.V_Eagle_Entity_Extension EE on E.Entity_Id = EE.Entity_Id and EE.Is_Src_Deleted = 0 
			where Entity_Type in ('SUB', 'PORT','COMP')
		) src
		where rn = 1 

		Insert Into EDW_Common.Dim_Eagle_Portfolio_Detail(
				  Portfolio_Id
				  ,[ACC_SYS_OPENING_DATE]
				  ,[ACCOUNTING_BASIS]
				  ,[ACCT_DT_RULE_PRIORITY]
				  ,[ACTIVE_STATUS]
				  ,[ASSET_CLASS]
				  ,[AUTO_SETTLE_INDICATOR]
				  ,[BANK_ACCOUNT_NUMBER]
				  ,[BANK_BRANCH_CODE]
				  ,[BASE_CURRENCY]
				  ,[BUSINESS_SECTOR]
				  ,[COA_NAME]
				  ,[CON_CASH_TYPE]
				  ,[COST_METHOD]
				  ,[COSTCASH_BULKING]
				  ,[COUNTRY_OF_TAX]
				  ,[CUSTOMER_TYPE]
				  ,[DYNAGG_FLAG]
				  ,[EARN_PROCESS_FREQ]
				  ,[ENTITY_FUND_TYPE]
				  ,[ENTITY_LONG_NAME]
				  ,[FISCAL_END_DATE]
				  ,[FLOATWEIGHT_FLAG]
				  ,[FX_DAYS_OFFSET]
				  ,[FX_SOURCE]
				  ,[FX_SOURCE_RULE_ID]
				  ,[INCEPTION_DATE]
				  ,[LEGAL_NAME]
				  ,[LOT_SELECTION_METHOD]
				  ,[PORTFOLIO_TYPE_CODE]
				  ,[PRICE_METHOD]
				  ,[PRICE_SOURCE]
				  ,[RELEASE_STATUS]
				  ,[SRC_INTFC_INST]
				  ,[STAR_PARTITION]
				  ,[TAX_STATUS]
				  ,[TECHNICAL_SHORT_INDICATOR]
				  ,[TERMINATION_DATE]
				  ,[TRADE_STATUS]
				  ,[UPD_DATE]
				  ,[UPD_USER]
				  ,[VAR_RATE_SOURCE]
				  ,[WASH_SALE_INHIBIT_INDICATOR]
				  ,Analysis_Code
				  ,SS_CUSIP_1
				  ,OPB_Mellon_ID 
				  ,SS_CUSIP_2
				  ,Management_Company
				  ,Parent_Investor
				  ,Reporting_Currency
				  ,[Record_Start_DTS]
				  ,[Record_End_DTS]
				  ,Record_Is_Current_Flag
				  ,Last_Update_DTS
				  ,Hash_Diff
				  ,ETL_Load_Key
		) 
		Select Portfolio_Id
			  ,[ACC_SYS_OPENING_DATE]
			  ,[ACCOUNTING_BASIS]
			  ,[ACCT_DT_RULE_PRIORITY]
			  ,[ACTIVE_STATUS]
			  ,[ASSET_CLASS]
			  ,[AUTO_SETTLE_INDICATOR]
			  ,[BANK_ACCOUNT_NUMBER]
			  ,Rtrim([BANK_BRANCH_CODE]) [BANK_BRANCH_CODE]
			  ,[BASE_CURRENCY]
			  ,[BUSINESS_SECTOR]
			  ,[COA_NAME]
			  ,[CON_CASH_TYPE]
			  ,[COST_METHOD]
			  ,[COSTCASH_BULKING]
			  ,[COUNTRY_OF_TAX]
			  ,[CUSTOMER_TYPE]
			  ,[DYNAGG_FLAG]
			  ,[EARN_PROCESS_FREQ]
			  ,[ENTITY_FUND_TYPE]
			  ,[ENTITY_LONG_NAME]
			  ,[FISCAL_END_DATE]
			  ,[FLOATWEIGHT_FLAG]
			  ,[FX_DAYS_OFFSET]
			  ,[FX_SOURCE]
			  ,[FX_SOURCE_RULE_ID]
			  ,[INCEPTION_DATE]
			  ,[LEGAL_NAME]
			  ,[LOT_SELECTION_METHOD]
			  ,[PORTFOLIO_TYPE_CODE]
			  ,[PRICE_METHOD]
			  ,[PRICE_SOURCE]
			  ,[RELEASE_STATUS]
			  ,[SRC_INTFC_INST]
			  ,[STAR_PARTITION]
			  ,[TAX_STATUS]
			  ,[TECHNICAL_SHORT_INDICATOR]
			  ,[TERMINATION_DATE]
			  ,[TRADE_STATUS]
			  ,[UPD_DATE]
			  ,[UPD_USER]
			  ,[VAR_RATE_SOURCE]
			  ,[WASH_SALE_INHIBIT_INDICATOR]
			  ,Analysis_Code
			,SS_CUSIP_1
			,OPB_Mellon_ID 
			,SS_CUSIP_2
			,Management_Company
			,Parent_Investor
			,Reporting_Currency
			  ,@today
			  ,null
			  ,1
			  ,@today
			  ,src.Hash_Diff
			  ,@ETL_Load_Key
		From #temp_src_portfolio_records src
		Where not exists (
			Select 1
			From EDW_Common.Dim_Eagle_Portfolio_Detail tgt
			where tgt.Record_Is_Current_Flag = 1 and src.Portfolio_Id = tgt.Portfolio_Id and src.Hash_Diff = tgt.Hash_Diff
		)
		and src.Is_Src_Deleted = 0


		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].Dim_Eagle_Portfolio_Detail tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_portfolio_records src
			Where tgt.Portfolio_Id = src.Portfolio_Id and ((coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'') and src.Is_Src_Deleted = 0) or src.Is_Src_Deleted = 1)
		)


		Select @rowsInserted = Count(*) 
		From EDW_Common.Dim_Eagle_Portfolio_Detail
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From [EDW_Common].Dim_Eagle_Portfolio_Detail
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired


		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Eagle_Portfolio_Detail', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Eagle_Portfolio_Detail', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END