﻿CREATE PROC [EDW_Common].[IMCOManual_Fact_Benchmark_Mapping] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Begin Try

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2
			--,@ETL_Load_Key int = -1

		
		IF OBJECT_ID('tempdb..#temp_src_manual_benchmark_mapping') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_manual_benchmark_mapping
		END

		create table #temp_src_manual_benchmark_mapping
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select 	 D.Dim_Date_Key
				,D.Date
				,Client_ID
				,Blend_Type
				,IPS_Strategy
				,IMCO_Benchmark
				,Benchmark_Source_Name
				,Benchmark_Source_ID
				,Start_Date
				,End_Date
				,min(Is_Src_Deleted) Is_Src_Deleted
				,min(Load_DTS) Load_DTS
				,convert(varchar(64), Hashbytes('SHA1', upper(concat(coalesce(Rtrim(Benchmark_Source_ID),''), '|', coalesce(Rtrim(End_Date),'')))),2) Hash_Diff
		from (	SELECT	 Client_ID
						,Blend_Type
						,IPS_Strategy
						,IMCO_Benchmark
						,Benchmark_Source_Name
						,Benchmark_Source_ID
						,Start_Date
						,End_Date
						,case when Is_Src_Deleted=1 then 1 else 0 end Is_Src_Deleted
						,Load_DTS
						,Row_Number() Over (Partition By  Client_ID,Blend_Type,IPS_Strategy,IMCO_Benchmark,Benchmark_Source_Name,Start_Date  Order by Load_DTS Desc) rn
				FROM PSA.[Manual_Benchmark_Mapping]
			 ) mpm
			Inner Join EDW_Common.Dim_Date D on D.Date between mpm.Start_Date and case mpm.End_Date When '2099-12-31' Then getdate() Else mpm.End_Date End	
		Where	rn = 1 
		Group By D.Dim_Date_Key
				,D.Date
				,Client_ID
				,Blend_Type
				,IPS_Strategy
				,IMCO_Benchmark
				,Benchmark_Source_Name
				,Benchmark_Source_ID
				,Start_Date
				,End_Date

		
		--expire the existing records
		Update tgt
		Set Last_Update_DTS = @today, 
			Is_Src_Deleted = 1, 
			ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Fact_Manual_Benchmark_Mapping] tgt
		Where tgt.Is_Src_Deleted = 0 
			and exists
		(
			Select 1
			From #temp_src_manual_benchmark_mapping src
			Where	--tgt.Dim_Date_Key = src.Dim_Date_Key 
					tgt.Client_id = src.Client_Id
					and tgt.IPS_Strategy = src.IPS_Strategy 
					and tgt.Blend_Type = src.Blend_Type 
					and tgt.IMCO_Benchmark = src.IMCO_Benchmark
					and tgt.Benchmark_Source_Name = src.Benchmark_Source_Name 
					and tgt.Start_Date = src.Start_Date
					and ((coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')) or src.Is_Src_Deleted = 1)
		)

		--insert new records
		INSERT INTO [EDW_Common].[Fact_Manual_Benchmark_Mapping]
        (   
			 Dim_Date_Key
			,Dim_Client_Key
			,Dim_Strategy_Key
			,Client_ID
			,Blend_Type
			,IPS_Strategy
			,IMCO_Benchmark
			,Benchmark_Source_Name
			,Benchmark_Source_ID
			,Start_Date
			,End_Date
			,Is_Src_Deleted
			,Load_DTS
			,Record_Created_DTS
			,Last_Update_DTS
			,Hash_Diff
			,ETL_Load_Key
		)

		SELECT	 t.Dim_Date_Key
				,coalesce(c.Dim_Client_Key, -1) Dim_Client_Key
				,coalesce(c_s.Dim_Strategy_Key, coalesce(strg.Dim_Strategy_Key, -1)) Dim_Strategy_Key
				,t.Client_ID
				,Blend_Type
				,IPS_Strategy
				,IMCO_Benchmark
				,Benchmark_Source_Name
				,Benchmark_Source_ID
				,Start_Date
				,End_Date
				,t.Is_Src_Deleted
				,t.Load_DTS
				,@today
				,@today
				,t.Hash_Diff
				,@ETL_Load_Key

		From	#temp_src_manual_benchmark_mapping t
				Left Join EDW_Common.Dim_Client c on t.Client_Id = c.Src_Client_Id and c.Record_Is_Current_Flag = 1
				Left Join 
				(
						select Src_Strategy_Id, Record_Start_DTS,  max(dim_strategy_key) dim_strategy_key, max(Record_End_DTS) Record_End_DTS
						From EDW_Common.Dim_Strategy
						Where Is_Src_Deleted_Flag = 0
						group By Src_Strategy_Id, Record_Start_DTS
				) c_s on t.IPS_Strategy = c_s.Src_Strategy_Id and t.Date Between c_s.Record_Start_DTS and c_s.Record_End_DTS -- c_s.Record_Is_Current_Flag = 1
				Left Join EDW_Common.Dim_Strategy strg on t.IPS_Strategy = strg.Src_Strategy_Id and strg.Record_Is_Current_Flag = 1

		where not exists 
		(
			Select 1
			From [EDW_Common].[Fact_Manual_Benchmark_Mapping] tgt
			where	t.Dim_Date_Key = tgt.Dim_Date_Key 
					and tgt.Client_ID = t.Client_ID
					and tgt.IPS_Strategy = t.IPS_Strategy 
					and tgt.Blend_Type = t.Blend_Type 
					and tgt.IMCO_Benchmark = t.IMCO_Benchmark
					and tgt.Benchmark_Source_Name = t.Benchmark_Source_Name 
					and tgt.Start_Date = t.Start_Date
					and tgt.Is_Src_Deleted = 0
					and coalesce(t.Hash_Diff,'') = coalesce(tgt.Hash_Diff,'')
		) and t.Is_Src_Deleted = 0


		--ETL Logging
		Select @rowsInserted = Count(*) 
		From EDW_Common.[Fact_Manual_Benchmark_Mapping]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 0


		Select @rowsExpired = Count(*)
		From EDW_Common.[Fact_Manual_Benchmark_Mapping]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 1

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Manual_Benchmark_Mapping', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Manual_Benchmark_Mapping', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END