﻿CREATE PROC [EDW_Common].[BarraOne_Fact_Barra_Risk_Attribution_Matrix] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@analysisDates varchar(255),
			@dateKeyStr varchar(255)

	
	Begin Try
		-- get current batch load for current fact table
		if @Batch_DTS is null 
			Select @Batch_DTS = Batch_Date
			From EDW_ETL.ETL_Load
			Where ETL_Load_Key = @ETL_Load_Key


		IF OBJECT_ID('tempdb..#temp_src_batch_analysis_dates') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_batch_analysis_dates
		END

			-- load everything from source

		create table #temp_src_batch_analysis_dates
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select Distinct convert(int, replace(convert(varchar(15), [As Of], 102),'.','')) Analysis_Date_Key,  convert(varchar(15), [As Of], 102) Analysis_Date
		From PSA.Barra_Header h
		where datediff(day, h.Begin_Batch, @Batch_DTS) = 0 

		if @Load_Type='ASOF' 
			Select @analysisDates = convert(varchar(15), @Batch_DTS, 102) , @dateKeyStr = replace(convert(varchar(15), @Batch_DTS, 102),'.','')
		else
			Select @analysisDates = string_agg(Analysis_Date, ','), @dateKeyStr = string_agg(Analysis_Date_Key, ',')
			From #temp_src_batch_analysis_dates 


		-- delete the same analysis date in the batch load
		Delete from [EDW_Common].[Fact_Barra_Risk_Attribution_Matrix]
		Where charindex(convert(varchar(15), Dim_Date_Key), @dateKeyStr) > 0
		
		--Delete from [EDW_Common].[Fact_Barra_Risk_Attribution_Matrix]
		--where datediff(day, [Load_DTS],  @Batch_DTS) = 0


		INSERT INTO [EDW_Common].[Fact_Barra_Risk_Attribution_Matrix]
           ([Dim_Date_Key]
           ,[Dim_Client_Key]
		   ,[Dim_Strategy_Key]
           ,[Dim_Barra_Risk_Tree_Key]
           ,[Dim_Country_Key]
		   ,[Dim_Currency_Key]
           ,[Dim_Security_Key]
		   ,[Dim_Security_Look_Through_Key]
           ,[Dim_Issuer_Key]
           ,[Dim_Manager_Key]
           ,[Dim_Sector_Barra_Key]
		   ,Holding_Date
           ,[MV]
           ,[Delta_Adjusted_Exposure]
           ,[Notional]
           ,[DV01]
           ,[CV01]
           ,[Port_Risk_Contr]
           ,[Port_Risk_Contr_Pct]
		   ,Total_Risk
		   ,Active_Total_Risk
		   ,Active_Risk_Contribution
		   ,Covariance_Date		   
		   ,Other_Info
           ,[Load_DTS]
           ,[Last_Update_DTS]
           ,[ETL_Load_Key]
		)

		SELECT  convert(int, convert(varchar(15), Analysis_Date, 112)) [Dim_Date_Key] 
				, coalesce(c.Dim_Client_Key, -1) Dim_Client_Key
				, coalesce(strg.Dim_Strategy_key, -1) Dim_Strategy_key
				, coalesce(rt.Dim_Barra_Risk_Tree_Key, -1) Dim_Barra_Risk_Tree_Key
				, coalesce(ctn.Dim_Country_key, -1)  Dim_Country_key
				, coalesce(cy.Dim_Currency_Key, -1) Dim_Currency_Key
				, coalesce(s.Dim_Security_Key, -1)   Dim_Security_Key
				,coalesce(slt.[Dim_Security_Look_Through_Key], -1)  [Dim_Security_Look_Through_Key]
				, coalesce(i.Dim_Issuer_Key, -1)   Dim_Issuer_Key
				, coalesce(mgr.Dim_Manager_Key, -1) Dim_Manager_Key
				, coalesce(sect.Dim_Sector_Barra_Key, -1) Dim_Sector_Barra_Key
				, t.Holdings_Date
				, [MV]
				, [Delta_Adjusted_Exposure]
				, [Notional]
				, [DV01]
				, [CV01]
				, [Port_Risk_Contr]
				, [Port_Risk_Contr_Pct]
				, Total_Risk
				, Active_Total_Risk
				, Active_Risk_Contribution
				, Covariance_Date
				, case when c.Dim_Client_Key is null or
				            strg.Dim_Strategy_key is null or
							rt.Dim_Barra_Risk_Tree_Key is null or
							ctn.Dim_Country_key is null or
							cy.Dim_Currency_Key is null or
							s.Dim_Security_Key is null or
							slt.[Dim_Security_Look_Through_Key] is null or
							i.Dim_Issuer_Key is null or
							mgr.Dim_Manager_Key is null or
							sect.Dim_Sector_Barra_Key is null
						then 
						  '{"ClientId":"' + t.Client_Id + '", ' + 
						  ' "Country":"' + t.IMCO_Country_Mapped + '", ' + 
						  ' "Currency":"' + t.Currency + '", ' +
						  ' "Issuer":"' + t.IMCO_Issuer_Mapped + '",'  +
						  ' "Sector":"' + t.IMCO_Sector_Mapped + '",' + 
						  ' "Manager":"' + t.IMCO_Manager_Mapped + '",' + 
						  ' "AssetId":"' + t.Asset_Id + '", ' + 
						  ' "Portfolio":"' + t.Portfolio + '" ' +
						  ' "Level_1":"' + coalesce(t.Level_1,'') + '" ' + 
						  '}' 
					else 
						null
					End Other_Info
				,@Batch_DTS
				,@today
				,@ETL_Load_Key

		From (
				  Select      c.Client Client_Id, 
								 c.Analysis_Date,
								 c.Model,
								 c.Port_Type,
								 c.Portfolio Portfolio, 
								 case when c.client='IMCO' then c.Portfolio else c.Level_1 end Strategy,
								 c.Level_1,
								 coalesce(c.Level_1, 'ALL') + '->' +  coalesce(c.Level_2, 'ALL') + '->' + coalesce(c.Level_3, 'ALL') + '->' + coalesce(c.Level_4, 'ALL') + '->' + coalesce(c.Level_5, 'ALL') Risk_Tree_Level,
								 c.native_portfolio,
								 c.Currency,
								 c.IMCO_Country_Mapped,
								 c.IMCO_Issuer_Mapped,
								 'Barra_' + c.Asset_Id Src_Security_Id,
								 c.Asset_Id,
								 coalesce(c.Look_Through_Source_Id,'') Look_Through_Source_Id,
								 coalesce(c.Inst_Type,'') as Instrument_Type,
								 cs.IMCO_Sector_Mapped,
								 c.IMCO_Manager_Mapped,
								 ap.Holdings_Date,
								 ap.MV MV,
								 ap.Delta_Adjusted_Exposure, 
								 ap.Notional,
								 fi.DV01,                                          -- Dollar value of an 01
								 convert(numeric(28, 12), fi.Spread_Dollar_Duration)/100  as CV01,            -- Credit Value of an 01
								 rt.Port_Risk_Contr, 
								 rt.Port_Risk_Contr_Pct,
								 rt.Total_Risk,
								 rt.Active_Total_Risk,
								 rt.Active_Risk_Contribution,
								 rt.Covariance_Date

/*
								 max(ap.Holdings_Date) Holding_Date,
								 sum(convert(numeric(28, 12),ap.MV)) MV,
								 sum(convert(numeric(28, 12), ap.Delta_Adjusted_Exposure)) Delta_Adjusted_Exposure, 
								 sum(convert(numeric(28, 12),ap.Notional)) Notional,
								 sum(convert(numeric(28, 12),fi.DV01)) DV01,                                          -- Dollar value of an 01
								 sum(convert(numeric(28, 12), fi.Spread_Dollar_Duration)/100)  as CV01,            -- Credit Value of an 01
								 sum(convert(numeric(28, 12),rt.Port_Risk_Contr)) Port_Risk_Contr, 
								 sum(convert(numeric(28, 12),rt.Port_Risk_Contr_Pct)) Port_Risk_Contr_Pct,
								 sum(convert(numeric(28, 12),rt.Total_Risk)) Total_Risk,
								 sum(convert(numeric(28, 12),rt.Active_Total_Risk)) Active_Total_Risk,
								 sum(convert(numeric(28, 12),rt.Active_Risk_Contribution)) Active_Risk_Contribution,
								 max(rt.Covariance_Date) Covariance_Date
*/								
				    From [PSA].[V_Barra_Characteristics] c
					left join (
							Select h.Begin_Batch
								, h.Portfolio
								, h.Port_Type
								, h.[Risk Model Name] AS Model
								, h.Reported
								, h.[client] AS Client
								, s.native_portfolio
								, s.look_through_source_ID
								, s.inst_type
								, s.asset_id
								, s.analysis_date
								, s.IMCO_Sector_Mapped
							From PSA.Barra_Header h
							join [PSA].[V_Barra_Characteristics_Sector] s on h.BatchId = s.BatchId
							where h.islatest= 1 and  charindex(convert(varchar(15), s.Analysis_Date, 102), @analysisDates) > 0 
					) cs on c.client = cs.client 
					    and c.Model = cs.Model
						and c.portfolio = cs.portfolio 
						and c.port_type = cs.port_type 
						and c.analysis_date = cs.analysis_date
						and c.native_portfolio = cs.native_portfolio
						and c.look_through_source_ID = cs.look_through_source_ID
						and c.inst_type = cs.inst_type
						and c.asset_id = cs.asset_id
					join 
					(
						Select  h.Begin_Batch
								, h.Portfolio
								, h.Port_Type
								, h.[Risk Model Name] AS Model
								, h.Reported
								, h.[client] AS Client
								, p.native_portfolio
								, p.look_through_source_ID
								, p.inst_type
								, p.asset_id
								, p.analysis_date
								, p.holdings_date
								, p.mv
								, p.Delta_Adjusted_Exposure
								, p.Notional

						From PSA.Barra_Header h
						join PSA.Barra_Analytics_Position p on h.BatchId = p.BatchId
						where h.islatest= 1 and charindex(convert(varchar(15), p.analysis_date, 102), @analysisDates) > 0
						-- where datediff(day, h.Begin_Batch, @Batch_DTS) = 0
					)
					ap on c.client = ap.client 
						and c.portfolio = ap.portfolio 
						and c.Model = ap.Model
						and c.port_type = ap.port_type 
						and c.analysis_date = ap.analysis_date
						and c.native_portfolio = ap.native_portfolio
						and c.look_through_source_ID = ap.look_through_source_ID
						and c.inst_type = ap.inst_type
						and c.asset_id = ap.asset_id
					left Join 
					(
						Select  h.Begin_Batch
								, h.Portfolio
								, h.Port_Type
								, h.[Risk Model Name] AS Model
								, h.Reported
								, h.[client] AS Client
								, v.native_portfolio
								, v.look_through_source_ID
								, v.inst_type
								, v.asset_id
								, v.analysis_date
								, v.Port_Risk_Contr
								, v.Port_Risk_Contr_Pct
								, v.Total_Risk
								, v.Active_Total_Risk
								, v.Active_Risk_Contribution
								, v.Covariance_Date
						From PSA.Barra_Header h
						join [PSA].[Barra_Risk_View_Total] v on h.BatchId = v.BatchId
						where h.islatest= 1 and charindex(convert(varchar(15), v.Analysis_Date, 102), @analysisDates) > 0  
					) rt on c.client = rt.client 
						and c.portfolio = rt.portfolio 
						and c.Model = rt.Model
						and c.port_type = rt.port_type 
						and c.analysis_date = rt.analysis_date
						and c.native_portfolio = rt.native_portfolio
						and c.look_through_source_ID = rt.look_through_source_ID
						and c.inst_type = rt.inst_type
						and c.asset_id = rt.asset_id
					left join 
					( Select  h.Begin_Batch
								, h.Portfolio
								, h.Port_Type
								, h.[Risk Model Name] AS Model
								, h.Reported
								, h.[client] AS Client
								, af.native_portfolio
								, af.look_through_source_ID
								, af.inst_type
								, af.asset_id
								, af.analysis_date
								, af.DV01
								, af.Spread_Dollar_Duration
						From PSA.Barra_Header h
						join PSA.Barra_Analytics_FI af on h.BatchID = af.BatchID 
						where h.islatest= 1 and  charindex(convert(varchar(15), af.Analysis_Date, 102), @analysisDates) > 0  
					) fi ON c.client = fi.client 
						and c.portfolio = fi.portfolio 
						and c.Model = fi.Model
						and c.port_type = fi.port_type 
						and c.analysis_date = fi.analysis_date
						and c.native_portfolio = fi.native_portfolio
						and c.look_through_source_ID = fi.look_through_source_ID
						and c.inst_type = fi.inst_type
						and c.asset_id = fi.asset_id
					where c.Model in ('BIM301XL','MAC.XL') 
					-- and datediff(day,c.Begin_Batch, @Batch_DTS) = 0
					and charindex(convert(varchar(15), c.Analysis_Date, 102), @analysisDates) > 0  
					/*
					Group by     c.Client, 
								 c.Port_Type,
								 c.Portfolio,
								 case when c.client='IMCO' then c.Portfolio else c.Level_1 end, 
					             coalesce(c.Level_1, 'ALL') + '->' +  coalesce(c.Level_2, 'ALL') + '->' + coalesce(c.Level_3, 'ALL') + '->' + coalesce(c.Level_4, 'ALL') + '->' + coalesce(c.Level_5, 'ALL'),
								 c.native_portfolio,
								 c.Analysis_Date,
								 c.Currency,
								 c.IMCO_Country_Mapped,
								 c.IMCO_Issuer_Mapped,
								 c.Asset_Id,
								 coalesce(c.Look_Through_Source_Id,''),
								 coalesce(c.Inst_Type,''),
								 cs.IMCO_Sector_Mapped,
								 case when c.Private_Mkt_Partner is not null                                                      then 
									case
										when c.private_mkt_partner in ('Realized', 'Internal', 'Directs', 'No GP - Direct') then 'IMCO'
										when c.private_mkt_partner = 'Clocktower'                                           then 'Clocktower Group'
										else c.private_mkt_partner 
									end
								when m.Manager is not null                                                                  then m.Manager
								when f.Fund_Type = 'Manager Composite'                                                      then f.Manager
								--when b.Native_Portfolio is not null                                                         then b.Native_Portfolio
								else 'IMCO'
								end
					*/

		) t
		Inner Join EDW_Common.Dim_Client c on t.Client_Id = c.Src_Client_Id and c.Record_Is_Current_Flag = 1 
		Left Join edw_common.dim_Strategy strg on t.Strategy = strg.Src_Strategy_Id and strg.Record_Is_Current_Flag = 1 
		Left Join EDW_Common.Dim_Barra_Risk_Tree rt on t.Model = rt.Model and t.Risk_Tree_Level = rt.Risk_Tree_Level and t.Port_Type = rt.Port_Type and t.Portfolio = rt.Portfolio
		                                      and t.native_portfolio = rt.native_portfolio and rt.Record_Is_Current_Flag = 1 
		Left Join EDW_Common.Dim_Country ctn on t.IMCO_Country_Mapped = ctn.Country and ctn.Record_Is_Current_Flag = 1 
		Left Join EDW_Common.Dim_Currency cy on t.Currency = cy.Currency and cy.Record_Is_Current_Flag = 1 
		Left Join EDW_Common.Dim_Issuer i on t.IMCO_Issuer_Mapped = i.Issuer and i.Record_Is_Current_Flag = 1 
		Left Join EDW_Common.Dim_Security s on  t.Instrument_Type = s.Instrument_Type and t.Src_Security_Id = s.Src_Security_Id and s.Record_Is_Current_Flag = 1 
		Left Join EDW_Common.Dim_Sector_Barra sect on t.IMCO_Sector_Mapped = sect.Sector and sect.Record_Is_Current_Flag = 1 
		Left Join EDW_Common.Dim_Security_Look_Through slt on t.Look_Through_Source_Id = slt.Look_Through_Source_Id and slt.Record_Is_Current_Flag = 1 

		Left Join EDW_Common.Dim_Manager mgr on t.IMCO_Manager_Mapped = mgr.Manager and mgr.Record_Is_Current_Flag = 1 


		Select @rowsInserted = Count(*) 
		From EDW_Common.Fact_Barra_Risk_Attribution_Matrix
		Where Last_Update_DTS = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Barra_Risk_Attribution_Matrix', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

		IF OBJECT_ID('tempdb..#temp_src_batch_analysis_dates') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_batch_analysis_dates
		END

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Barra_Risk_Attribution_Matrix', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END
GO