﻿CREATE PROC [EDW_Common].[Eagle_Bridge_Portfolio_Group] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2
			
	
	Begin Try

		Select @lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From [EDW_Common].[Bridge_Portfolio_Group]
		
		IF OBJECT_ID('tempdb..#temp_src_eagle_portfolio_group') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_eagle_portfolio_group
		END

		create table #temp_src_eagle_portfolio_group
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select 	D.Dim_Date_Key
			,D.Date
			,Portfolio_ID
            ,Portfolio_Group_Id
			,min(Responsible_Team) Responsible_Team
			,min(Is_Src_Deleted) Is_Src_Deleted
			,min(Load_DTS) Load_DTS

			from (
					select Code_Value Portfolio_Id, Entity_Id Portfolio_Group_Id, 
					'2020-01-01' Start_Date,
					case when Is_Src_Deleted = 1 then dateadd(dd, -1, getdate()) else '2099-12-31' end End_Date,
					case when Is_Src_Deleted = 1 then 1 else 0 end Is_Src_Deleted,
					'Eagle_Source' Responsible_Team,
					Load_DTS

					From PSA.V_Eagle_ENTITY_LIST 

					Union
					
					SELECT cv.long_desc Portfolio_Id,  
						c.short_desc Portfolio_Group_Id,
						'2020-01-01' Start_Date,
						case when cv.Is_Src_Deleted = 1 then dateadd(dd, -1, getdate()) else '2099-12-31' end End_Date,
						case when cv.Is_Src_Deleted = 1 then 1 else 0 end Is_Src_Deleted,
						'Eagle_Source' Responsible_Team,
						cv.Load_DTS
                    FROM Psa.V_Eagle_codes c   
                    INNER JOIN psa.V_Eagle_code_values cv  ON c.instance = cv.code_inst 
					Where c.short_desc Like '%COMPS'


			) mpm
			Join EDW_Common.Dim_Date D on D.Date between mpm.Start_Date and case mpm.End_Date When '2099-12-31' Then getdate() Else mpm.End_Date End
			Where mpm.Portfolio_ID is not null and Portfolio_Group_Id is not null 
			Group By D.Dim_Date_Key, D.Date, Portfolio_ID, Portfolio_Group_Id

		INSERT INTO [EDW_Common].[Bridge_Portfolio_Group]
        (   
			Dim_Date_Key
			,[Dim_Portfolio_Key]
			,[Dim_Portfolio_Group_Key] 
           ,[Responsible_Team]
		   ,IS_Src_Deleted
		   ,Load_DTS
		   ,Record_Created_DTS
		   ,Other_Info
           ,[Last_Update_DTS]
           ,[Hash_Diff]
           ,[ETL_Load_Key]
		)
		SELECT		t.Dim_Date_Key
				   ,coalesce(p.[Dim_Portfolio_Key], -1) [Dim_Portfolio_Key]
				   ,coalesce(c_pg.[Dim_Portfolio_Group_Key], -1) [Dim_Portfolio_Group_Key]
				   ,Responsible_Team
				   ,t.Is_Src_Deleted
				   ,t.Load_DTS
				   ,@today
				   ,'{"Portfolio":"' + t.Portfolio_ID + '",' + 
				    '"Portfolio_Group":"' + t.Portfolio_Group_Id + '"}'
				   ,@today
					,null
					,@ETL_Load_Key

		From #temp_src_eagle_portfolio_group t
		Inner Join EDW_Common.Dim_Portfolio p on t.Portfolio_ID = p.Portfolio_Id and t.Date between p.Record_Start_DTS and coalesce(p.[Record_End_DTS], '9999-12-31')
		left Join EDW_Common.Dim_Portfolio_Group c_pg on t.Portfolio_Group_Id = c_pg.Portfolio_Group_Id and c_pg.Record_Is_Current_Flag = 1

		where not exists (
			Select 1
			From [EDW_Common].[Bridge_Portfolio_Group] tgt
			Join EDW_Common.Dim_Portfolio pt on tgt.Dim_Portfolio_Key= pt.Dim_Portfolio_Key 
			Join EDW_Common.Dim_Portfolio_Group pgt on tgt.Dim_Portfolio_Group_Key= pgt.Dim_Portfolio_Group_Key 
			where t.Dim_Date_Key = tgt.Dim_Date_Key and t.Portfolio_Id = pt.Portfolio_Id and t.Portfolio_Group_Id = pgt.Portfolio_Group_Id 
			   and tgt.Is_Src_Deleted = 0
		) and t.Is_Src_Deleted = 0 

		Select @rowsInserted = Count(*) 
		From EDW_Common.[Bridge_Portfolio_Group]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 0

		Update tgt
		Set Last_Update_DTS = @today, Is_Src_Deleted = 1, ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Bridge_Portfolio_Group] tgt
		Join EDW_Common.Dim_Portfolio p on tgt.Dim_Portfolio_Key= p.Dim_Portfolio_Key 
		Join EDW_Common.Dim_Portfolio_Group pgt on tgt.Dim_Portfolio_Group_Key= pgt.Dim_Portfolio_Group_Key 
		Where tgt.Is_Src_Deleted = 0 and exists
		(
			Select 1
			From #temp_src_eagle_portfolio_group src
			Where tgt.Dim_Date_Key = src.Dim_Date_Key and p.Portfolio_Id = src.Portfolio_Id and src.Portfolio_Group_Id = pgt.Portfolio_Group_Id 
			   and src.Is_Src_Deleted = 1
		)

		Select @rowsExpired = Count(*)
		From EDW_Common.[Bridge_Portfolio_Group]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 1

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Bridge_Portfolio_Group', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Bridge_Portfolio_Group', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END