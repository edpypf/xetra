﻿CREATE PROC [EDW_Common].[IMCOManual_Fact_Private_Position_Tag] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN

	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2
			--,@ETL_Load_Key int = -1;

				
	Begin Try

		Select @lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From [EDW_Common].[Fact_Manual_Private_Position_Tag]
		
		IF OBJECT_ID('tempdb..#temp_src_manual_private_positions_tag') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_manual_private_positions_tag
		END

		create table #temp_src_manual_private_positions_tag
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select 	 D.Dim_Date_Key
				,D.Date
				,Client
				,Portfolio_ID
				,Accounting_Fund_ID
				,Dynamo_Fund_ID
				,PRIMARY_ASSET_ID
				,PRIMARY_ASSET_ID_TYPE
				,Private_Mkt_Asset_ID
				,Private_Mkt_Fund
				,Private_Mkt_Fund_Name
				,Private_Mkt_Asset_Class
				,Private_Mkt_Asset_Name
				,Private_Mkt_Investment_Vehicle
				,Private_Mkt_Region
				,Private_Mkt_Asset_Type
				,Private_Mkt_Sector
				,Private_Mkt_Revenue_Source
				,Private_Mkt_Risk_Strategy
				,Private_Mkt_Partner
				,Private_Mkt_Leverage 
				,Issuer_Name
				,Country_Risk
				,Currency_Risk
				,Currency_Fund
				,GICS_INDUSTRY_GROUP
				,Market_Value
				,Market_Value_Local
				,Market_Value_Currency_Risk
				,Sector_2
				,IMCO_Instrument
				,Private_Mkt_Country
				,Private_Mkt_Currency
				,Exposure_Scalar 
				,Income_Risk_Exposure_Scalar 
				,Metro_Area
				,Number_of_Assets
				,Property_Subtype
				,Property_Type_and_Region
				,Specific_Risk_Scalar 
				,Instrument_Type
				,PE_Common_Factor_Risk_Scalar
				,PE_Investment_Type
				,PE_Public_Proxy
				,Proxy_Identifier
				,Proxy_Identifier_Type
				,Price_Proxy
				,Proxy_Notional
				,Start_Date
				,End_Date
				,min(Is_Src_Deleted) Is_Src_Deleted
				,min(Load_DTS) Load_DTS
				,convert(varchar(64), Hashbytes('SHA1', upper(concat(coalesce(Rtrim(PRIMARY_ASSET_ID_TYPE),''), '|', coalesce(Rtrim(Private_Mkt_Fund),''), '|', coalesce(Rtrim(Private_Mkt_Fund_Name),''), '|', coalesce(Rtrim(Private_Mkt_Asset_Class),''), '|', coalesce(Rtrim(Private_Mkt_Investment_Vehicle),''), '|', coalesce(Rtrim(Private_Mkt_Region),''), '|', coalesce(Rtrim(Private_Mkt_Asset_Type),''), '|', coalesce(Rtrim(Private_Mkt_Sector),''), '|', coalesce(Rtrim(Private_Mkt_Revenue_Source),''), '|', coalesce(Rtrim(Private_Mkt_Risk_Strategy),''), '|', coalesce(Rtrim(Private_Mkt_Partner),''), '|', coalesce(Rtrim(Private_Mkt_Leverage ),''), '|', coalesce(Rtrim(Issuer_Name),''), '|', coalesce(Rtrim(Country_Risk),''), '|', coalesce(Rtrim(Currency_Risk),''), '|', coalesce(Rtrim(Currency_Fund),''), '|', coalesce(Rtrim(GICS_INDUSTRY_GROUP),''), '|', coalesce(Rtrim(Market_Value),''), '|', coalesce(Rtrim(Market_Value_Local),''), '|', coalesce(Rtrim(Market_Value_Currency_Risk),''), '|', coalesce(Rtrim(Sector_2),''), '|', coalesce(Rtrim(IMCO_Instrument),''), '|', coalesce(Rtrim(Private_Mkt_Country),''), '|',	coalesce(Rtrim(Private_Mkt_Currency),''), '|', coalesce(Rtrim(Exposure_Scalar),''), '|', coalesce(Rtrim(Income_Risk_Exposure_Scalar),''),'|', coalesce(Rtrim(Metro_Area),''), '|', coalesce(Rtrim(Number_of_Assets),''), '|', coalesce(Rtrim(Property_Subtype),''), '|', coalesce(Rtrim(Property_Type_and_Region),''), '|', coalesce(Rtrim(Specific_Risk_Scalar),''), '|', coalesce(Rtrim(Instrument_Type),''), '|', coalesce(Rtrim(PE_Common_Factor_Risk_Scalar),''), '|', coalesce(Rtrim(PE_Investment_Type),''), '|', coalesce(Rtrim(PE_Public_Proxy),''), '|', coalesce(Rtrim(Proxy_Identifier),''), '|', coalesce(Rtrim(Proxy_Identifier_Type),''), '|', coalesce(Rtrim(Price_Proxy),''), '|', coalesce(Rtrim(Proxy_Notional),''), '|', coalesce(Rtrim(Start_Date),''), '|', coalesce(Rtrim(End_Date),''), '|', coalesce(Rtrim(Private_Mkt_Asset_ID),'') ))),2) Hash_Diff

		from (	SELECT	 Client
						,Portfolio_ID
						,Accounting_Fund_ID
						,Dynamo_Fund_ID
						,PRIMARY_ASSET_ID
						,PRIMARY_ASSET_ID_TYPE
						,Private_Mkt_Asset_ID
						,Private_Mkt_Fund
						,Private_Mkt_Fund_Name
						,Private_Mkt_Asset_Class
						,Private_Mkt_Asset_Name
						,Private_Mkt_Investment_Vehicle
						,Private_Mkt_Region
						,Private_Mkt_Asset_Type
						,Private_Mkt_Sector
						,Private_Mkt_Revenue_Source
						,Private_Mkt_Risk_Strategy
						,Private_Mkt_Partner
						,Private_Mkt_Leverage 
						,Issuer_Name
						,Country_Risk
						,Currency_Risk
						,Currency_Fund
						,GICS_INDUSTRY_GROUP
						,Market_Value
						,Market_Value_Local
						,Market_Value_Currency_Risk
						,Sector_2
						,IMCO_Instrument
						,Private_Mkt_Country
						,Private_Mkt_Currency
						,Exposure_Scalar 
						,Income_Risk_Exposure_Scalar 
						,Metro_Area
						,Number_of_Assets
						,Property_Subtype
						,Property_Type_and_Region
						,Specific_Risk_Scalar 
						,Instrument_Type
						,PE_Common_Factor_Risk_Scalar
						,PE_Investment_Type
						,PE_Public_Proxy
						,Proxy_Identifier
						,Proxy_Identifier_Type
						,Price_Proxy
						,Proxy_Notional
						,Start_Date
						,End_Date
						,case when Is_Src_Deleted=1 then 1 else 0 end Is_Src_Deleted
						,Load_DTS
						,Row_Number() Over (Partition By [Client],[Portfolio_ID],[Dynamo_Fund_ID],[Accounting_Fund_ID],[PRIMARY_ASSET_ID],Private_Mkt_Asset_Name, Start_Date   Order by Load_DTS Desc) rn
				FROM PSA.[Manual_Private_Position_Tag]
			 ) mpm
			Inner Join EDW_Common.Dim_Date D on D.Date between mpm.Start_Date and case mpm.End_Date When '2099-12-31' Then getdate() Else mpm.End_Date End
	
		Where	rn = 1 
		Group By D.Dim_Date_Key
				,D.Date
				,Client
				,Portfolio_ID
				,Accounting_Fund_ID
				,Dynamo_Fund_ID
				,PRIMARY_ASSET_ID
				,PRIMARY_ASSET_ID_TYPE
				,Private_Mkt_Asset_ID
				,Private_Mkt_Fund
				,Private_Mkt_Fund_Name
				,Private_Mkt_Asset_Class
				,Private_Mkt_Asset_Name
				,Private_Mkt_Investment_Vehicle
				,Private_Mkt_Region
				,Private_Mkt_Asset_Type
				,Private_Mkt_Sector
				,Private_Mkt_Revenue_Source
				,Private_Mkt_Risk_Strategy
				,Private_Mkt_Partner
				,Private_Mkt_Leverage 
				,Issuer_Name
				,Country_Risk
				,Currency_Risk
				,Currency_Fund
				,GICS_INDUSTRY_GROUP
				,Market_Value
				,Market_Value_Local
				,Market_Value_Currency_Risk
				,Sector_2
				,IMCO_Instrument
				,Private_Mkt_Country
				,Private_Mkt_Currency
				,Exposure_Scalar 
				,Income_Risk_Exposure_Scalar 
				,Metro_Area
				,Number_of_Assets
				,Property_Subtype
				,Property_Type_and_Region
				,Specific_Risk_Scalar 
				,Instrument_Type
				,PE_Common_Factor_Risk_Scalar
				,PE_Investment_Type
				,PE_Public_Proxy
				,Proxy_Identifier
				,Proxy_Identifier_Type
				,Price_Proxy
				,Proxy_Notional
				,Start_Date
				,End_Date


		
		--expire the existing records
		Update tgt
		Set Last_Update_DTS = @today, 
			Is_Src_Deleted = 1, 
			ETL_Load_Key = @ETL_Load_Key
		From [EDW_Common].[Fact_Manual_Private_Position_Tag] tgt
		Where tgt.Is_Src_Deleted = 0 
			and exists
		(
			Select 1
			From #temp_src_manual_private_positions_tag src
			Where	--tgt.Dim_Date_Key = src.Dim_Date_Key 
					tgt.Portfolio_Id = src.Portfolio_Id 
					and tgt.Client = src.Client
					and tgt.Dynamo_Fund_ID = src.Dynamo_Fund_ID 
					and tgt.Accounting_Fund_ID = src.Accounting_Fund_ID
					and tgt.PRIMARY_ASSET_ID = src.PRIMARY_ASSET_ID 
					and tgt.Private_Mkt_Asset_Name = src.Private_Mkt_Asset_Name
					and tgt.Start_Date = src.Start_Date
					--and src.Is_Src_Deleted = 1
					and ((coalesce(tgt.Hash_Diff,'') <> coalesce(src.Hash_Diff,'')) or src.Is_Src_Deleted = 1)
		)

		--insert new records
		INSERT INTO [EDW_Common].[Fact_Manual_Private_Position_Tag]
        (   
			 Dim_Date_Key
			,Dim_Client_Key
			,Dim_Portfolio_Key
			,Client
			,Portfolio_ID
			,Accounting_Fund_ID
			,Dynamo_Fund_ID
			,PRIMARY_ASSET_ID
			,PRIMARY_ASSET_ID_TYPE
			,Private_Mkt_Asset_ID
			,Private_Mkt_Fund
			,Private_Mkt_Fund_Name
			,Private_Mkt_Asset_Class
			,Private_Mkt_Asset_Name
			,Private_Mkt_Investment_Vehicle
			,Private_Mkt_Region
			,Private_Mkt_Asset_Type
			,Private_Mkt_Sector
			,Private_Mkt_Revenue_Source
			,Private_Mkt_Risk_Strategy
			,Private_Mkt_Partner
			,Private_Mkt_Leverage 
			,Issuer_Name
			,Country_Risk
			,Currency_Risk
			,Currency_Fund
			,GICS_INDUSTRY_GROUP
			,Market_Value
			,Market_Value_Local
			,Market_Value_Currency_Risk
			,Sector_2
			,IMCO_Instrument
			,Private_Mkt_Country
			,Private_Mkt_Currency
			,Exposure_Scalar 
			,Income_Risk_Exposure_Scalar 
			,Metro_Area
			,Number_of_Assets
			,Property_Subtype
			,Property_Type_and_Region
			,Specific_Risk_Scalar 
			,Instrument_Type
			,PE_Common_Factor_Risk_Scalar
			,PE_Investment_Type
			,PE_Public_Proxy
			,Proxy_Identifier
			,Proxy_Identifier_Type
			,Price_Proxy
			,Proxy_Notional
			,Start_Date
			,End_Date
			,Is_Src_Deleted
			,Load_DTS
			,Record_Created_DTS
			--,Other_Info
			,Last_Update_DTS
			,Hash_Diff
			,ETL_Load_Key
		)

		SELECT	 t.Dim_Date_Key
				,coalesce(c.Dim_Client_Key, -1) Dim_Client_Key
				,coalesce(p.Dim_Portfolio_Key, -1) Dim_Portfolio_Key
				,t.Client
				,t.Portfolio_ID
				,Accounting_Fund_ID
				,Dynamo_Fund_ID
				,PRIMARY_ASSET_ID
				,PRIMARY_ASSET_ID_TYPE
				,Private_Mkt_Asset_ID
				,Private_Mkt_Fund
				,Private_Mkt_Fund_Name
				,Private_Mkt_Asset_Class
				,Private_Mkt_Asset_Name
				,Private_Mkt_Investment_Vehicle
				,Private_Mkt_Region
				,Private_Mkt_Asset_Type
				,Private_Mkt_Sector
				,Private_Mkt_Revenue_Source
				,Private_Mkt_Risk_Strategy
				,Private_Mkt_Partner
				,Private_Mkt_Leverage 
				,Issuer_Name
				,Country_Risk
				,Currency_Risk
				,Currency_Fund
				,GICS_INDUSTRY_GROUP
				,Market_Value
				,Market_Value_Local
				,Market_Value_Currency_Risk
				,Sector_2
				,IMCO_Instrument
				,Private_Mkt_Country
				,Private_Mkt_Currency
				,Exposure_Scalar 
				,Income_Risk_Exposure_Scalar 
				,Metro_Area
				,Number_of_Assets
				,Property_Subtype
				,Property_Type_and_Region
				,Specific_Risk_Scalar 
				,Instrument_Type
				,PE_Common_Factor_Risk_Scalar
				,PE_Investment_Type
				,PE_Public_Proxy
				,Proxy_Identifier
				,Proxy_Identifier_Type
				,Price_Proxy
				,Proxy_Notional
				,Start_Date
				,End_Date
				,t.Is_Src_Deleted
				,t.Load_DTS
				,@today
				,@today
				,t.Hash_Diff
				,@ETL_Load_Key

		From	#temp_src_manual_private_positions_tag t
				left Join EDW_Common.Dim_Portfolio p on t.Portfolio_ID = p.Portfolio_Id and t.Date between p.Record_Start_DTS and coalesce(p.[Record_End_DTS], '9999-12-31')
				left Join EDW_Common.Dim_Client c on t.Client = c.Client_Id and c.Record_Is_Current_Flag = 1

		where not exists 
		(
			Select 1
			From [EDW_Common].[Fact_Manual_Private_Position_Tag] tgt
			--Join EDW_Common.Dim_Portfolio pt on tgt.Dim_Portfolio_Key= pt.Dim_Portfolio_Key 
			Join EDW_Common.Dim_Client c on tgt.Dim_Client_Key= c.Dim_Client_Key 
			where	t.Dim_Date_Key = tgt.Dim_Date_Key 
					and t.Portfolio_Id = tgt.Portfolio_Id 
					and t.Client = c.Client_Id
					and t.Dynamo_Fund_ID = tgt.Dynamo_Fund_ID 
					and t.Accounting_Fund_ID = tgt.Accounting_Fund_ID
					and t.PRIMARY_ASSET_ID = tgt.PRIMARY_ASSET_ID 
					and t.Private_Mkt_Asset_Name = tgt.Private_Mkt_Asset_Name
					and t.Start_Date = tgt.Start_Date
					and tgt.Is_Src_Deleted = 0
					and coalesce(t.Hash_Diff,'') = coalesce(tgt.Hash_Diff,'')
		) and t.Is_Src_Deleted = 0


		--ETL Logging
		Select @rowsInserted = Count(*) 
		From EDW_Common.[Fact_Manual_Private_Position_Tag]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 0


		Select @rowsExpired = Count(*)
		From EDW_Common.[Fact_Manual_Private_Position_Tag]
		Where Last_Update_DTS = @today and Is_Src_Deleted = 1

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Manual_Private_Position_Tag', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Manual_Private_Position_Tag', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END