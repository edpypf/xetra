﻿CREATE PROC [EDW_Common].[Eagle_Fact_Eagle_Cash_Activity] @Load_Type [varchar](255),@Batch_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN


	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0,
			@lastLoadeDTS datetime2

			--@Load_Type varchar(255) = 'DELTA',
			--@Batch_DTS datetime2 = getdate(),
			--@ETL_Load_Key int = 0


	
	Begin Try


		-- get last loaded dts in current fact table
		Select	@lastLoadeDTS = coalesce(max(Load_DTS), '1900-01-01')
		From	EDW_Common.Fact_Eagle_Cash_Activity



		INSERT INTO EDW_Common.Fact_Eagle_Cash_Activity
		(
			 [Dim_Portfolio_Key]
			  ,[Dim_Security_Key]
			  ,[Dim_Eagle_Portfolio_Detail_Key]
			  ,[Dim_Eagle_Security_Detail_Key]
			  ,[Dim_Base_Currency_Key]
			  ,[Dim_Local_Currency_Key]
			  ,[Dim_Settlement_Currency_Key]
			  ,[Dim_Sys_Currency_Key]
			  ,[Dim_Date_Key]
			  ,Dim_Eagle_Interface_Key
			  ,Dim_Transaction_Type_Key
				,CASH_INT,
				POSITION_ID,
				TRANS_NUM,
				ORIG_TRANS_NUM,
				BASE_AMOUNT,
				LOCAL_AMOUNT,
				CURR_FX_RATE,
				ACCOUNT,
				TRANS_QUANTITY,
				TRADE_DATE,
				SETTLEMENT_DATE,
				PRICE,
				POST_DATE,
				ACCOUNTING_DATE,
				CASH_EVENT_TYPE,
				TRANSACTION_STATUS,
				GL_ACCOUNT,

				
				CANCEL_FLAG,
				CANCEL_STATUS,
				BASE_TOTAL_FLOW,
				LOCAL_TOTAL_FLOW,
				BASE_PRINCIPAL_FLOW,
				LOCAL_PRINCIPAL_FLOW,
				BASE_INCOME_FLOW,
				LOCAL_INCOME_FLOW,
				PERFORMANCE_FLOW_DESCR,
				REFLEXIVE_FLOW,
				STAR_TAG25,
				MASTER_TRANS_NUM,
				ESTAR_INSTANCE,
				COMMENTS1,
				SRC_SYS_C
				
			  ,[SRC_UPDATE_SOURCE]
			  ,[SRC_UPDATE_DATE]
			  ,Load_DTS
			  ,[Other_Info]
			  ,[Last_Update_DTS]
			  ,[Hash_Diff]
			  ,[ETL_Load_Key]
			  ,[Is_Src_Deleted]
		)


			SELECT	coalesce(p.Dim_Portfolio_Key, -1)						as Dim_Portfolio_Key,
					coalesce(sec.Dim_Security_Key, -1)						as Dim_Security_Key,
					coalesce(pd.Dim_Eagle_Portfolio_Detail_Key, -1)			as Dim_Eagle_Portfolio_Detail_Key,
					coalesce(secd.Dim_Eagle_Security_Detail_Key, -1)		as Dim_Eagle_Security_Detail_Key,
					coalesce(cur.Dim_Currency_Key, -1)						as Dim_Base_Currency_Key,
					coalesce(lc.Dim_Currency_Key, -1)						as Dim_Local_Currency_Key,
					coalesce(sc.Dim_Currency_Key, -1)						as [Dim_Settlement_Currency_Key],
					coalesce(sysc.Dim_Currency_Key, -1)						as [Dim_Sys_Currency_Key],
					convert(int, convert(varchar(15), Effective_Date, 112)) as Dim_Date_Key,
					coalesce(intf.Dim_Eagle_Interface_Key, -1)					as Dim_Interface_Key,
					coalesce(trans.Dim_Transaction_Type_Key, -1)					as Dim_Transaction_Type_Key,
					
					CASH_INT,
					POSITION_ID,
					TRANS_NUM,
					ORIG_TRANS_NUM,
					BASE_AMOUNT,
					LOCAL_AMOUNT,
					CURR_FX_RATE,
					ACCOUNT,
					TRANS_QUANTITY,
					TRADE_DATE,
					SETTLEMENT_DATE,
					PRICE,
					POST_DATE,
					ACCOUNTING_DATE,
					CASH_EVENT_TYPE,
					TRANSACTION_STATUS,
					GL_ACCOUNT,

					
					CANCEL_FLAG,
					CANCEL_STATUS,
					BASE_TOTAL_FLOW,
					LOCAL_TOTAL_FLOW,
					BASE_PRINCIPAL_FLOW,
					LOCAL_PRINCIPAL_FLOW,
					BASE_INCOME_FLOW,
					LOCAL_INCOME_FLOW,
					PERFORMANCE_FLOW_DESCR,
					REFLEXIVE_FLOW,
					STAR_TAG25,
					MASTER_TRANS_NUM,
					ESTAR_INSTANCE,
					COMMENTS1,
					SRC_SYS_C
					

				  ,[UPDATE_SOURCE]
				  ,[UPDATE_DATE]
				  ,Load_DTS
				  
				  ,case when p.Dim_Portfolio_key is null or pd.Dim_Eagle_Portfolio_Detail_Key is null 
				        or sec.Dim_Security_Key is null or secd.Dim_Eagle_Security_Detail_Key is null
						or trans.Dim_Transaction_Type_Key is null or intf.Dim_Eagle_Interface_Key is null 
						or cur.Dim_Currency_Key is null or lc.Dim_Currency_Key is null
						or trans.Dim_Transaction_Type_Key is null then
						'{' + 
						'"Portfolio_Id": "' + convert(varchar(50), src.Portfolio_ID) + '",' + 
						'"Security_Alias":"' + convert(varchar(50), src.Security_Id) + '",' + 
						'"SRC_INTFC_INST":"' + convert(varchar(50), src.SRC_INTFC_INST) + '",' + 
						'"Trans_Type":"' + Rtrim(src.[TRANS_TYPE]) + '",' + 
						'"Base_Currency":"' + src.BASE_CURRENCY + '",' + 
						'"Local_Currency":"' + src.Local_CURRENCY + '"' + 
						'}'
					else 
						null
					End
					
				  ,@today
				  ,src.Hash_Diff
				  ,@ETL_Load_Key
			      ,Is_Src_Deleted


			FROM  (
					Select  ca.ENTITY_ID as Portfolio_ID
							, cast(ca.Security_Alias as varchar) as Security_ID
							, ca.*
					From PSA.V_Eagle_Cash_Activity ca
					Where ca.Load_DTS > Coalesce(@lastLoadeDTS, '1900-01-01')
					and ca.SRC_INTFC_INST in (158, 283, 284, 285, 286) --DYNAMO, BNYM, BNYM_LOT, BNYM_ME, BNYM_ME_LOT
				) src

				 --Dim_Portfolio_Key
				 Left Join EDW_Common.Dim_Portfolio p on src.Portfolio_ID = p.Portfolio_Id 
							and src.EFFECTIVE_DATE between p.Record_Start_DTS and coalesce(p.[Record_End_DTS], '9999-12-31') 

				Left Join EDW_Common.Dim_Eagle_Portfolio_Detail pd on src.Portfolio_Id = pd.Portfolio_Id and pd.Record_Is_Current_Flag = 1

				 --Dim_Security_Key
				 Left Join EDW_Common.Dim_Security sec on 'Eagle_' + src.Security_Id = sec.Src_Security_Id and sec.Record_Is_Current_Flag = 1

				 Left Join EDW_Common.Dim_Eagle_Security_Detail secd on src.Security_Id = secd.Security_Id and secd.Record_Is_Current_Flag = 1

				 --Dim_Base_Currency_Key
				 Left Join EDW_Common.Dim_Currency cur on src.BASE_CURRENCY = cur.CURRENCY 
							and cur.Record_Is_Current_Flag = 1
				 --Dim_Local_Currency_Key
				 Left Join EDW_Common.Dim_Currency lc on src.Local_CURRENCY = lc.CURRENCY 
							and lc.Record_Is_Current_Flag = 1
				 --Dim_Settlement_Currency_Key
				 Left Join EDW_Common.Dim_Currency sc on src.SETTLEMENT_CURRENCY = sc.CURRENCY 
							and sc.Record_Is_Current_Flag = 1
				 --Dim_Sys_Currency_Key
				 Left Join EDW_Common.Dim_Currency sysc on src.SYS_CURRENCY = sysc.CURRENCY 
							and sysc.Record_Is_Current_Flag = 1							
				 --Dim_Interfaces_Key
				 Left Join EDW_Common.Dim_Eagle_Interface intf on convert(varchar(15), src.SRC_INTFC_INST) = intf.Interface_Instance 
	 						and intf.Record_Is_Current_Flag = 1

				-- Dim_Transaction_Type_Key
				 Left Join EDW_Common.Dim_Transaction_Type trans on 'Eagle_' + Rtrim(src.[TRANS_TYPE]) = trans.Transaction_Type_Code 
	 						and trans.Record_Is_Current_Flag = 1

		--LOGGING ETL RESULT
		Select @rowsInserted = Count(*) 
		From EDW_Common.[Fact_Eagle_Cash_Activity]
		Where Last_Update_DTS = @today

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Cash_Activity', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Fact_Eagle_Cash_Activity', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW @ErrorCode,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END