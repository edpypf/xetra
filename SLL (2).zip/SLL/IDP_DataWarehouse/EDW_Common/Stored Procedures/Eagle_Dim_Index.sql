﻿CREATE PROC [EDW_Common].[Eagle_Dim_Index] @Load_Type [varchar](255),@Load_DTS [datetime2],@ETL_Load_Key [int] AS
BEGIN
	Declare @today datetime2 = getdate()

	Declare @rowsInserted int = 0,
			@rowsUpdated int = 0,
			@rowsExpired int = 0
	
	Begin Try

		IF OBJECT_ID('tempdb..#temp_src_index_records') IS NOT NULL
		BEGIN
			DROP TABLE #temp_src_index_records
		END

		-- load everything from source

		create table #temp_src_index_records
		WITH
		(
				DISTRIBUTION = Round_Robin
		) as 
		Select *
		From (
			select distinct
				rtrim([Entity_ID]) as Index_ID,
				Rtrim([Entity_Name]) as Index_Name,
				Rtrim([Entity_Type]) as Index_Type,
				Rtrim([Portfolio_Type_Code]) as Index_Type_Code,
				Rtrim([Entity_Long_Name]) as Index_Long_Name,
				Rtrim([Legal_Name]) as Legal_Name,
				Rtrim([Inception_Date]) as Inception_Date,
				CONVERT(VARCHAR(64), hashbytes('SHA1', UPPER(concat(coalesce(rtrim([Entity_Name]),''), '|', coalesce(rtrim([Entity_Type]),''), 
													'|',  coalesce(rtrim([Portfolio_Type_Code]),''), '|', coalesce(rtrim([Entity_Long_Name]),''),
													'|', coalesce(rtrim([Legal_Name]),''), '|', coalesce(rtrim([Inception_Date]),'')))), 2) as Hash_Diff,
				Is_Src_Deleted,
				Row_Number() Over (Partition By Entity_Id order by Load_DTS Desc) rn
			From PSA.Eagle_Entity 
			Where Entity_Type in ('CIDX', 'INDX','AGG', 'SUB')
			) src
		where rn = 1


		Insert Into EDW_Common.Dim_Index (
				[Index_ID]
				,[Index_Name]
				,Index_Type
				,Index_Type_Code
				,Index_Long_Name
				,Legal_Name
				,Inception_Date
				,Record_Start_DTS
				,Record_End_DTS
				,Record_Is_Current_Flag
				,Last_Update_DTS
				,Hash_Diff
				,ETL_Load_Key
		)
		Select src.[Index_ID]
			  ,src.[Index_Name]
			  ,src.Index_Type
			  ,src.Index_Type_Code
			  ,src.Index_Long_Name
			  ,src.Legal_Name
			  ,src.Inception_Date
			  ,case when tgt.Index_Id is null then '2000-01-01' else @today end
			  , null
			  , 1
			  , @today
			  ,src.Hash_Diff
			  ,@ETL_Load_Key
		From #temp_src_index_records src
		Left Join EDW_Common.Dim_Index tgt on src.[Index_ID] = tgt.Index_Id and tgt.Record_Is_Current_Flag = 1
		where src.Is_Src_Deleted = 0 and tgt.Index_Id is null


		Update tgt
		Set Last_Update_DTS = @today, Record_End_DTS = @today, Record_Is_Current_Flag = 0, ETL_Load_Key = @ETL_Load_Key
		From EDW_Common.Dim_Index tgt
		Where tgt.Record_Is_Current_Flag = 1 and exists
		(
			Select 1
			From #temp_src_index_records src
			Where tgt.Index_Id = src.Index_Id and src.Is_Src_Deleted = 1
		)

		Select @rowsInserted = Count(*) 
		From EDW_Common.Dim_Index
		Where Record_Start_DTS = @today

		Select @rowsExpired = Count(*)
		From EDW_Common.Dim_Index
		Where Record_End_DTS = @today

		Select @rowsUpdated = @rowsExpired

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Index', @rowsInserted, @rowsUpdated, @rowsExpired, 'Completed', null

    END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage  VARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState    INT; 
        DECLARE @ErrorCode     INT;		

		SELECT   
			@ErrorMessage  = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState    = ERROR_STATE();

		Exec EDW_ETL.Update_ETL_Load_Control @ETL_Load_Key, 'EDW_Common.Dim_Index', 0, 0, 0, 'Failed', @ErrorMessage

        SET @ErrorCode = 50000 + @ErrorSeverity;
		
		THROW 50001,
			  @ErrorMessage,  
			  @ErrorState;

	END CATCH
	
END