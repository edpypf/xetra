﻿CREATE FUNCTION [dbo].[SUBSTRING_INDEX] (@str [VARCHAR](4000),@delim [VARCHAR](5),@count [INT]) RETURNS VARCHAR(4000)
AS
BEGIN
	declare @remainder as varchar(4000)

	declare @i as int

	set @remainder = replace(@str, @delim ,'|')
	set @i = 1

	While @i < @count
	Begin
		set @remainder = right(@remainder, len(@remainder)-charindex('|', @remainder))
		set @i = @i + 1
	End
	if charindex('|', @remainder) > 0 
		set @remainder = left(@remainder, charindex('|', @remainder)-1)

	return @remainder
END
GO
