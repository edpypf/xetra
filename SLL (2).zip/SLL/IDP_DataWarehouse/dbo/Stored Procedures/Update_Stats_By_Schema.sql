﻿CREATE PROC [dbo].[Update_Stats_By_Schema] @SchemaName [Varchar](255) AS
	DECLARE @indx INT              = 1,
			@totalRows INT         = 0,
			@sql VARCHAR(4000)   = '';


	IF @SchemaName IS NULL
	BEGIN
		THROW 151000,'@SchemaName parameter can not be empty',1;
	END;

	IF OBJECT_ID('tempdb..#stats_ddl') IS NOT NULL
	BEGIN
		DROP TABLE #stats_ddl;
	END;

	CREATE TABLE #stats_ddl
	WITH    (   DISTRIBUTION    = HASH([seq_nmbr])
			)
	AS
	SELECT
		s.Name AS SchemaName,
		t.Name AS TableName,
		ROW_NUMBER() Over (Order by t.Name) as seq_number
	From    sys.tables t
	LEFT OUTER JOIN  sys.schemas s ON t.schema_id = s.schema_id
	where s.Name = @SchemaName;

	

	Select @totalRows = count(*) From #stats_ddl;

	WHILE @indx <= @totalRows
	BEGIN
		SET @sql=(SELECT 'UPDATE STATISTICS ' + SchemaName + '.' +  TableName FROM #stats_ddl WHERE seq_nmbr = @indx);

		PRINT @sql;
		EXEC sp_executesql @sql;
		SET @indx += 1;
	END

	DROP TABLE #stats_ddl;