﻿CREATE PROC [dbo].[ChangeTableDistribution] @MySchema [varchar](100),@MyTable [varchar](100),@NewDist [varchar](50) AS
Begin

BEGIN TRY
    declare @SQL nvarchar( max );

	-- Create new table with new distribution from old table
	Select @SQL =
	'CREATE TABLE ' + @MySchema + '.' + @MyTable + '_redist
	 WITH
	  (
		CLUSTERED COLUMNSTORE INDEX,  
		DISTRIBUTION = ' + @NewDist  +
	'  )  
	 AS SELECT * FROM ' + @MySchema + '.' + @MyTable;
	print @SQL;
	Execute(@SQL);

	-- Switch table names & drop old table
	Select @SQL = 'RENAME OBJECT ' + @MySchema + '.' + @MyTable + ' to ' + @MyTable + '_old';
	print @SQL;
	Execute(@SQL);
	Select @SQL = 'RENAME OBJECT ' + @MySchema + '.' + @MyTable + '_redist TO ' + @MyTable;
	print @SQL;
	Execute(@SQL);
	Select @SQL = 'DROP TABLE ' + @MySchema + '.' + @MyTable + '_old';
	print @SQL;
	Execute(@SQL);
END TRY

BEGIN CATCH
	DECLARE @ErrorMessage  NVARCHAR(4000);  
	DECLARE @ErrorSeverity INT;  
	DECLARE @ErrorState    INT;  

	SELECT   
		@ErrorMessage  = ERROR_MESSAGE(),  
		@ErrorSeverity = ERROR_SEVERITY(),  
		@ErrorState    = ERROR_STATE();

	THROW;

END CATCH

End