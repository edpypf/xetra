﻿CREATE FUNCTION [dbo].[ReplaceASCII] (@inputString [VARCHAR](Max)) RETURNS VARCHAR(Max)
AS
BEGIN
         DECLARE @badStrings VARCHAR(100);
         DECLARE @increment INT= 1;
         WHILE @increment <= DATALENGTH(@inputString)
             BEGIN
                 IF(ASCII(SUBSTRING(@inputString, @increment, 1)) < 48
				    OR (ASCII(SUBSTRING(@inputString, @increment, 1)) > 57 and ASCII(SUBSTRING(@inputString, @increment, 1)) <65)
					OR (ASCII(SUBSTRING(@inputString, @increment, 1)) > 90 and ASCII(SUBSTRING(@inputString, @increment, 1)) <97)
					OR ASCII(SUBSTRING(@inputString, @increment, 1)) > 122
					)
                     BEGIN
                         SET @badStrings = CHAR(ASCII(SUBSTRING(@inputString, @increment, 1)));
                         SET @inputString = REPLACE(@inputString, @badStrings, '_');
                 END;
                 SET @increment = @increment + 1;
             END;
         RETURN @inputString;
     END