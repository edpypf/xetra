﻿CREATE FUNCTION [dbo].[fn_json_merge] (@a [nvarchar](max),@b [nvarchar](max)) RETURNS nvarchar(max)
AS
begin
	if(ISJSON(@a)=1 and ISJSON(@b)=1)
	begin
		if left(@a, 1) = '{' and left(@b, 1) = '{'
		begin
			set @a = REPLACE(@a, '}', REPLACE(@b, '{',','))
		end
		return @a
	end
	
	return @a
end