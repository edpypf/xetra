﻿CREATE FUNCTION [dbo].[Replace_Key_Value] (@orginal_string [varchar](4000),@replace_string [VARCHAR](4000)) RETURNS VARCHAR(4000)
AS
BEGIN

/*
  DECLARE @orginal_string varchar(255),
		  @replace_string varchar(255)
*/

  DECLARE @indx INT,          -- index
          @charIndx int,
		  @len int;

  DECLARE @keyword VARCHAR(255),
	      @value varchar(255),
		  @listSeparator varchar(255),
		  @delimiter varchar(255),
		  @result varchar(4000),
		  @keywordStr varchar(255),
		  @nameStr varchar(255),
		  @valueStr varchar(255),
		  @updatedStr varchar(4000)

  Set @indx = 1
  Set @charIndx = charindex('{', @replace_string)
  
  Set @result = @orginal_string

  While @charIndx > 0 Begin

	  Set @len = len(@replace_string)
	  Set @keywordStr = substring(@replace_string, 1, @charIndx -1)

	  Set @nameStr =  substring(@keywordStr, 1, charindex(':', @keywordStr) - 1)
	  Set @valueStr = substring(@keywordStr, charindex(':', @keywordStr) + 1, len(@keywordStr) - charindex(':', @keywordStr))

	  Set @result = replace(@result, '<<'+@nameStr+'>>', @valueStr)

	  Set @replace_string = substring(@replace_string, @charIndx + 1, @len - @charIndx)
	  Set @charIndx = charindex('{', @replace_string)
	   
  end
  if @charIndx = 0 and len(@replace_string) > 0 and charindex(':', @replace_string) > 0 Begin
	  Set @nameStr =  substring(@replace_string, 1, charindex(':', @replace_string) - 1)
	  Set @valueStr = substring(@replace_string, charindex(':', @replace_string) + 1, len(@replace_string) - charindex(':', @replace_string))
	  Set @result = replace(@result, '<<'+@nameStr+'>>', @valueStr)
  End

  RETURN @result
END