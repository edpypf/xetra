﻿CREATE TABLE [DWUtil].[DVRAW_Table_Field_Mapping] (
    [Source_System]             VARCHAR (255)  NOT NULL,
    [Raw_Table_Name]            VARCHAR (255)  NOT NULL,
    [Raw_Table_Column_Name]     VARCHAR (255)  NOT NULL,
    [Raw_Table_Column_Is_PK]    VARCHAR (255)  NOT NULL,
    [Staging_Table_Name]        VARCHAR (1000) NOT NULL,
    [Staging_Table_Column_Name] VARCHAR (40)   NOT NULL,
    [Transformation_Rule]       VARCHAR (4000) NULL,
    CONSTRAINT [Cnstr_DVRAW_Table_Field_Mapping_pk] PRIMARY KEY NONCLUSTERED ([Raw_Table_Name] ASC, [Raw_Table_Column_Name] ASC) NOT ENFORCED
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

